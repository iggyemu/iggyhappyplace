﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Ditech.SharpSsh
{
    public class SshClient : IDisposable
    {
        public SshClient(string serverName, string userName, string password, string serverPath, string prompt = "\n")
        {
            ServerName = serverName;
            UserName = userName;
            Password = password;
            ServerPath = serverPath;

            ClientStream = new SshStream(ServerName, UserName, Password);

            ClientStream.Prompt = prompt;
            ClientStream.RemoveTerminalEmulationCharacters = true;

            ClientStream.ReadResponse();

            ChangeDirectory(serverPath);
        }

        private string RawFileList(string remoteDirectory = "")
        {
            ChangeDirectory(remoteDirectory);

            return SendCommand("ls -l --time-style=full-iso");
        }

        public string ChangeDirectory(string remoteDirectory)
        {
            var result = string.Empty;

            if (!string.IsNullOrEmpty(remoteDirectory))
            {
                result = SendCommand("cd " + remoteDirectory);
                ServerPath = remoteDirectory;
            }

            return result;
        }

        public string Delete(string remoteFileName)
        {
            remoteFileName = GetFullRemoteFilePath(remoteFileName);

            return SendCommand("rm " + remoteFileName);
        }

        public string SendCommand(string command)
        {
            ClientStream.Write(command);
            Thread.Sleep(100);

            return ClientStream.ReadResponse();
        }

        public void Put(string localFileFullPath, string remoteFileName = "")
        {
            remoteFileName = GetFullRemoteFilePath(remoteFileName.Coalesce(Path.GetFileName(localFileFullPath)));

            var scp = new Scp();

            scp.To(localFileFullPath, ServerName, remoteFileName, UserName, Password);
        }

        public void Get(string remoteFileName, string localFileFullPath)
        {
            remoteFileName = GetFullRemoteFilePath(remoteFileName);

            var scp = new Scp();

            scp.From(ServerName, remoteFileName,  UserName, Password, localFileFullPath);

            var lastFileDate = LastModifiedDate(Path.GetFileName(remoteFileName));

            if (lastFileDate != null)
            {
                File.SetLastWriteTime(localFileFullPath, lastFileDate.Value);
            }
        }

        public string[] ListFiles(string remoteDirectory = "")
        {
            var fileList = new List<string>();

            var rawList = RawFileList(remoteDirectory);

            var splitLine = rawList.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

            for (var i = 0; i < splitLine.Length - 1; i++)
            {
                var line = new List<string>(splitLine[i].Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries));

                if (line.Count > 8)
                {
                    var fileName = string.Join(" ", line.GetRange(8, line.Count - 8).ToArray()).Remove("\r");

                    fileList.Add(fileName);
                }
            }

            return fileList.ToArray();
        }

        private string GetFullRemoteFilePath(string remoteFileName)
        {
            if (string.IsNullOrEmpty(remoteFileName))
            {
                throw new ApplicationException("Remote filename cannot be null or empty.");
            }

            if (remoteFileName.Contains("/"))
            {
                remoteFileName = Path.GetFileName(remoteFileName);
            }

            return Path.Combine(ServerPath, remoteFileName).Replace(@"\", "/");
        }

        public DateTime? LastModifiedDate(string remoteFileName)
        {
            DateTime? result = null;

            var fileList = RawFileList(Path.GetDirectoryName(remoteFileName));

            var splitLine = fileList.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

            for (var i = 0; i < splitLine.Length; i++)
            {
                var line = new List<string>(splitLine[i].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));

                if (line.Count > 8)
                {
                    var fileName = string.Join(" ", line.GetRange(8, line.Count - 8).ToArray()).Remove("\r");

                    if (fileName.ToUpper() == remoteFileName.ToUpper())
                    {
                        var rawModifiedDate = string.Join(" ", line.GetRange(5, 2).ToArray());

                        result = DateTime.Parse(rawModifiedDate);
                        break;
                    }
                }
            }

            return result;
        }

        public int? FileSize(string remoteFileName)
        {
            int? result = null;

            var fileList = RawFileList(Path.GetDirectoryName(remoteFileName));

            var splitLine = fileList.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

            for (var i = 0; i < splitLine.Length; i++)
            {
                var line = new List<string>(splitLine[i].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));

                if (line.Count > 8)
                {
                    var fileName = string.Join(" ", line.GetRange(8, line.Count - 8).ToArray()).Remove("\r");

                    if (fileName.ToUpper() == remoteFileName.ToUpper())
                    {
                        var rawFileLength = line[4];

                        result = (int?)Convert.ToNullableDecimal(rawFileLength);
                        break;
                    }  
                }
            }

            return result;
        }


        public void Dispose()
        {
            if (ClientStream != null)
            {
                ClientStream.Close();
            }
        }

        public SshStream ClientStream { get; set; }
        private string ServerName { get; set; }
        private string UserName { get; set; }
        private string Password { get; set; }
        private string ServerPath { get; set; }
    }
}
