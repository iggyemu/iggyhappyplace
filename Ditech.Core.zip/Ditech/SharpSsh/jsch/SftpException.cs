using System;

namespace EverBank.SharpSsh.jsch
{
	public class SftpException : Exception
	{
		public int id;
		public string message;
		public SftpException (int id, string message):base() 
		{
			this.id=id;
			this.message=message;
		}
		public string ToString()
		{
			return message;
		}
	}
}
