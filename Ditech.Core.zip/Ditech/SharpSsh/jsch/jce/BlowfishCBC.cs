using System;

namespace EverBank.SharpSsh.jsch.jce
{
	/// <summary>
	/// Summary description for BlowfishCBC.
	/// </summary>
	public class BlowfishCBC
	{
		public BlowfishCBC()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
