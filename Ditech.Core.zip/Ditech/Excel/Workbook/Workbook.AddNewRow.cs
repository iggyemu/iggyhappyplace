﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        public void AddNewRow(DataRow dataRow)
        {
            var values = new List<string>();

            for (var i = 0; i < dataRow.Table.Columns.Count; i++)
            {
                var excelType = ExcelDataType(dataRow.Table.Columns[i].DataType);

                var value = Convert.ToString(dataRow.ItemArray[i]);

                DateTime date;

                if (DateTime.TryParse(value, out date))
                {
                    value = date.ToString("MM/dd/yyyy");
                }

                switch (excelType)
                {
                    case "DATE":
                    case "NTEXT":
                        value = string.Format("'{0}'", value.Replace("'", "''"));
                        break;
                }

                values.Add(value);
            }

            var commandText = string.Format("INSERT INTO [{0}] ({1}) VALUES({2})", TableName, string.Join(",", Headers.ToArray()), string.Join(",", values.ToArray()));

            Execute(commandText);
        }
    }
}
