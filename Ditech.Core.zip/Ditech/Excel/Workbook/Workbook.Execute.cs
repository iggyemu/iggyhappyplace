﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        private void Execute(string commandText)
        {
            using (var command = new OleDbCommand(commandText, Connection))
            {
                if (Connection.State != ConnectionState.Open)
                {
                    Connection.Open();
                }

                command.ExecuteNonQuery();
            }
        }
    }
}
