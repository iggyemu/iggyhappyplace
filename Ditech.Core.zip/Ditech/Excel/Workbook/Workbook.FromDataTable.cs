﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EverBank.Excel
{
    public partial class Workbook
    {
        public static void FromDataTable(string outputPath, DataTable dataTable)
        {
            var dataSet = new DataSet();

            dataSet.Tables.Add(dataTable.Copy());

            FromDataSet(outputPath, dataSet);
        }
    }
}
