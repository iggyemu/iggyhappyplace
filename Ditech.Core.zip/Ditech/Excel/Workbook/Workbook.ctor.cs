﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Text;

namespace EverBank.Excel
{
    public partial class Workbook : IDisposable
    {
        public Workbook(string path, bool append)
        {
            if (!append)
            {
                IO.File.Delete(path);
            }

            InputFilePath = path;
            Connection = new OleDbConnection(ConnectionString);
            Headers = new List<string>();
        }

        public Workbook(string path) : this(path, false) { }
    }
}
