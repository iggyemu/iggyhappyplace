﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;

namespace EverBank.Excel
{
    partial class Workbook
    {
        private static void FormatCells(string outputPath, Dictionary<int, string> formatting)
        {
            _Application excelApplication = new Application();
            excelApplication.Workbooks.Open(outputPath, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                                            Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                                            Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            _Workbook _xlWB = excelApplication.ActiveWorkbook;
            _Worksheet _xlWS = (_Worksheet)_xlWB.ActiveSheet;

            var enmumerator = formatting.GetEnumerator();

            var format = "General";

            while (enmumerator.MoveNext())
            {
                switch (enmumerator.Current.Value)
                {
                    //Number data types
                    case "INTEGER":
                        format = "0";
                        break;
                    case "NUMBER":
                        format = "#,##0.00";
                        break;
                    case "DATE":
                        format = "mm/dd/yyyy";
                        break;
                }

                _xlWS.get_Range(_xlWS.Cells[1, enmumerator.Current.Key], _xlWS.Cells[65535, enmumerator.Current.Key]).
                    EntireColumn.NumberFormat = format;
            }


            _xlWB.Save();

            excelApplication.Quit();

            while (Marshal.ReleaseComObject(excelApplication) != 0) { }
            GC.Collect();
            GC.WaitForPendingFinalizers();

            var file = new FileInfo(outputPath);

            var backupFileName = Path.Combine(Path.GetDirectoryName(file.FullName), "Backup of " + Path.GetFileNameWithoutExtension(file.Name) + ".xlk");

            EverBank.IO.File.Delete(backupFileName);
        }
    }
}
