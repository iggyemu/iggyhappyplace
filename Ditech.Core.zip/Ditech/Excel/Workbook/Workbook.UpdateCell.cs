﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        public void UpdateCell(string cellLocation, object value)
        {
            if (value != null)
            {
                var type = value.GetType();

                if (type == typeof(DateTime))
                {
                    value = ((DateTime)value).ToShortDateString();
                }
                else
                {
                    if (type == typeof(string))
                    {
                        value = value.ToString().Replace("'", "''");
                    }
                }

                value = Convert.ToString(value);

                if ((string)value != string.Empty)
                {
                    var command = string.Format("UPDATE [{0}${1}:{1}] SET F1='{2}'", TableName, cellLocation, value);

                    Execute(command);
                }
            }
        }
    }
}
