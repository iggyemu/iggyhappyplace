﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook : IDisposable
    {
        public void Dispose()
        {
            if (Connection != null)
            {
                Connection.Dispose();

            }
        }

    }
}
