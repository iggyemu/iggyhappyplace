﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        public static void FromDataSet(string outputPath, DataSet dataSet)
        {
            var formatting = new Dictionary<int, string>();

            using (var spreadSheet = new Workbook(outputPath, false))
            {
                foreach (DataTable dataTable in dataSet.Tables)
                {
                    var headers = new Dictionary<string, string>();

                    for (int i = 0; i < dataTable.Columns.Count; i++)
                    {
                        var type = dataTable.Columns[i].DataType.ToString();

                        string excelType;

                        type = type.Mid(type.IndexOf('.') + 1).ToLower();

                        switch (type)
                        {
                            //Number data types
                            case "int":
                            case "int16":
                            case "int32":
                            case "int64":
                            case "byte":
                                excelType = "INTEGER";
                                break;
                            case "decimal":
                            case "double":
                                excelType = "NUMBER";
                                break;
                            // Boolean data types
                            case "boolean":
                                excelType = "LOGICAL";
                                break;
                            // DateTime data type
                            case "datetime":
                            case "date":
                                excelType = "DATE";
                                break;
                            // String data type
                            default:
                                excelType = "NTEXT";
                                break;
                        }

                        headers.Add(dataTable.Columns[i].ColumnName, excelType);

                        formatting.Add(i + 1, excelType);
                    }

                    spreadSheet.WriteTable(dataTable.TableName, headers);

                    for (var i = 0; i < dataTable.Rows.Count; i++)
                    {
                        spreadSheet.AddNewRow(dataTable.Rows[i]);
                    }
                }
            }

             FormatCells(outputPath, formatting);
        }
    }
}
