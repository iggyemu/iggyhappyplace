﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        public string CurrentTableName { get; set; }
        private string ExcelConnectionString
        {
            get
            {
                return
                    "Provider=Microsoft.{0}.OLEDB.{1};Data Source={2};Extended Properties=\"{3};HDR=YES\"";
            }
        }
        private string InputFilePath { get; set; }
        private bool IsText { get; set; }

        private OleDbConnection Connection { get; set; }

        public string ConnectionString
        {
            get
            {
                var fileExtension = new FileInfo(InputFilePath).Extension;

                string connectionString;

                switch (fileExtension)
                {
                    case ".xls":
                        connectionString = string.Format(ExcelConnectionString, "Jet", "4.0", InputFilePath, "Excel 8.0");
                        break;
                    case ".xlsb":
                        connectionString = string.Format(ExcelConnectionString, "Ace", "12.0", InputFilePath, "Excel 12.0");
                        break;
                    case ".xlsx":
                        connectionString = string.Format(ExcelConnectionString, "Ace", "12.0", InputFilePath, "Excel 12.0 Xml");
                        break;
                    default:
                        connectionString = string.Format(ExcelConnectionString, "Jet", "4.0", Path.GetDirectoryName(InputFilePath), "text;FMT=Delimited");
                        IsText = true;
                        break;
                }

                return connectionString;
            }
        }

        public List<string> Headers { get; set; }

        private string TableName
        {
            get
            {
                if (IsText)
                {
                    return Path.GetFileName(InputFilePath);
                }

                return CurrentTableName;
            }
        }

    }
}
