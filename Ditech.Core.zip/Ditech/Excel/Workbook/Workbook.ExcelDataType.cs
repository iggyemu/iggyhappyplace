﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        public static string ExcelDataType(Type systemType)
        {
            var type = systemType.ToString();

            string excelType;

            type = type.Mid(type.IndexOf('.') + 1).ToLower();

            switch (type)
            {
                //Number data types
                case "int":
                case "int16":
                case "int32":
                case "int64":
                case "byte":
                    excelType = "INTEGER";
                    break;
                case "decimal":
                case "double":
                    excelType = "NUMBER";
                    break;
                // Boolean data types
                case "boolean":
                    excelType = "LOGICAL";
                    break;
                // DateTime data type
                case "datetime":
                    excelType = "DATE";
                    break;
                // String data type
                default:
                    excelType = "NTEXT";
                    break;
            }

            return excelType;
        }
    }
}
