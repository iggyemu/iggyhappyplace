﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EverBank.Excel
{
    partial class Workbook
    {
        public void WriteTable(string tableName, Dictionary<string, string> tableDefinition)
        {
            if (tableName.StartsWith("'") && tableName.EndsWith("'"))
            {
                tableName = tableName.Mid(1, tableName.Length - 2);
            }


            CurrentTableName = tableName.EndsWith("$") ? tableName.Left(tableName.Length - 1) : tableName;

            var tableFields = new List<string>();

            foreach (var keyValuePair in tableDefinition)
            {
                var headerName = string.Format("[{0}]", keyValuePair.Key);

                Headers.Add(headerName);

                tableFields.Add(string.Format("{0} {1}", headerName, keyValuePair.Value));
            }

            var commandText = string.Format("CREATE TABLE [{0}] ({1})", TableName,
                                            string.Join(",", tableFields.ToArray()));

            Execute(commandText);
        }
    }
}
