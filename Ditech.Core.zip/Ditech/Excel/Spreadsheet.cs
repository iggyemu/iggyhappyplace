﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Convert = System.Convert;
using DataTable = Microsoft.Office.Interop.Excel.DataTable;

namespace Ditech.Excel
{
    public class Spreadsheet : IDisposable
    {
        #region Fields (4)

        public Application excel;
        public _Workbook workbook;
        public int CurrentRow { get; set; }
        private Range range;
        private _Worksheet worksheet;
        private Style TextStyle;
        private Style DateStyle;
        private Style NumberStyle;
        private Style PercentStyle;
        private Style DecimalStyle;
        private string sheetName = "Sheet1";
        private string excelFileName;
        public bool Visible
        {
            get
            {
                return excel.Visible;
            }
            set
            {
                excel.Visible = value;
            }
        }

        #endregion Fields

        #region Constructors (2)

        public Spreadsheet(string fileName)
            : this()
        {
            Open(fileName);
        }

        public Spreadsheet()
        {
            Initialize();

            workbook = excel.Workbooks.Add(Missing.Value);

            AddStylesToWorkbook();

            Visible = false;
        }

        private void AddStylesToWorkbook()
        {
            TextStyle = workbook.Styles.Add("Text", Missing.Value);
            TextStyle.NumberFormat = "@";

            DateStyle = workbook.Styles.Add("Date", Missing.Value);
            DateStyle.NumberFormat = "mm/dd/yyyy";

            NumberStyle = workbook.Styles.Add("Number", Missing.Value);
            NumberStyle.NumberFormat = "0";

            PercentStyle = workbook.Styles.Add("PercentStyle", Missing.Value);
            PercentStyle.NumberFormat = "0.00%";

            DecimalStyle = workbook.Styles.Add("Decimal", Missing.Value);
            DecimalStyle.NumberFormat = "#,###.00##";
        }


        public void Open(string fileName)
        {
            var extension = Path.GetExtension(fileName);
            if (extension.ToLower() == ".txt")
            {
                const int maxColumns = 16384;
                var fieldInfo = new int[maxColumns, 2];
                for (int i = 0; i < maxColumns; i++)
                {
                    fieldInfo[i, 0] = i;
                    fieldInfo[i, 1] = (int)XlColumnDataType.xlTextFormat;
                }
                // FieldInfo must be a MultiDimensional array ([,]) and not a jagged array ([][])
                excel.Workbooks.OpenText(fileName, DataType: XlTextParsingType.xlDelimited, Tab: true, FieldInfo: fieldInfo);
                workbook = excel.ActiveWorkbook;
            }
            else
            {
                workbook = excel.Workbooks.Open(fileName, 0, false, 5, string.Empty, string.Empty, false,
                                                XlPlatform.xlWindows, string.Empty, true, false, 0, true, false,
                                                XlCorruptLoad.xlRepairFile);
            }

            excelFileName = fileName;

            worksheet = (_Worksheet)workbook.ActiveSheet;
        }

        public void RemoveRows(_Worksheet sheet, int minimumColumnsPopulated)
        {
            try
            {
                Range rng = sheet.Range["A1", "A10"];
                var rowsMarkedForDeletion = new List<long>();

                for (int i = 0; i < rng.Rows.Count; i++)
                {
                    var row = (Range)rng[i + 1];

                    if (excel.WorksheetFunction.CountA(row.EntireRow) < minimumColumnsPopulated)
                    {
                        rowsMarkedForDeletion.Add(i + 1);
                    }
                }

                for (int i = rowsMarkedForDeletion.Count - 1; i >= 0; i--)
                {
                    var row = (Range)rng[rowsMarkedForDeletion[i]];

                    row.EntireRow.Delete();
                }
            }
            catch
            {
            }
        }

        public DataSet Read(string fileName, bool hasHeaders = true, bool removeEmptyRows = false, int minimumColumnsPopulated = 3)
        {
            if (fileName != excelFileName)
            {
                if (workbook != null)
                {
                    workbook.Close(false);
                }

                Open(fileName);
            }

            var dataSet = new DataSet();

            foreach (_Worksheet sheet in workbook.Worksheets)
            {
                if (removeEmptyRows)
                {
                    RemoveRows(sheet, minimumColumnsPopulated);
                }

                var excelRange = sheet.UsedRange;
                var data = (object[,])excelRange.Value[XlRangeValueDataType.xlRangeValueDefault];

                var fieldIdentifier = new Dictionary<string, int>();

                if (data != null)
                {
                    var dataTable = new System.Data.DataTable();

                    for (int i = 1; i <= data.GetLength(1); i++)
                    {
                        if (!hasHeaders || data.GetLength(0) == 0)
                        {
                            dataTable.Columns.Add();
                        }
                        else
                        {
                            var columnName = Convert.ToString(data[1, i]);

                            if (dataTable.Columns.Contains(columnName))
                            {
                                if (!fieldIdentifier.ContainsKey(columnName))
                                {
                                    fieldIdentifier.Add(columnName, 0);
                                }

                                fieldIdentifier[columnName]++;

                                columnName = columnName + "_" + fieldIdentifier[columnName];
                            }

                            dataTable.Columns.Add(columnName);
                        }
                    }

                    for (var rowIndex = hasHeaders ? 2 : 1; rowIndex <= data.GetLength(0); rowIndex++)
                    {
                        var row = new List<object>();

                        for (var columnIndex = 1; columnIndex <= data.GetLength(1); columnIndex++)
                        {
                            row.Add(data[rowIndex, columnIndex]);
                        }

                        dataTable.Rows.Add(row.ToArray());
                    }

                    dataTable.TableName = sheet.Name.Trim();
                    dataSet.Tables.Add(dataTable);
                }
            }

            return dataSet;
        }

        public static DataSet ReadToDataSet(string fileName, bool hasHeaders, bool removeEmptyRows = false, int minimumColumnsPopulated = 3)
        {
            DataSet dataSet;

            using (var spreadsheet = new Spreadsheet())
            {
                spreadsheet.excel.Application.AutomationSecurity = Microsoft.Office.Core.MsoAutomationSecurity.msoAutomationSecurityForceDisable;
                dataSet = spreadsheet.Read(fileName, hasHeaders, removeEmptyRows, minimumColumnsPopulated);
            }

            return dataSet;
        }

        /// <summary>
        /// Reads the worksheet.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="hasHeaders">if set to <c>true</c> [has headers].</param>
        /// <returns></returns>
        public static System.Data.DataTable ReadToDataTable(string fileName, bool hasHeaders, bool removeEmptyRows = false, int minimumColumnsPopulated = 3)
        {
            System.Data.DataTable dataTable;

            using (var spreadsheet = new Spreadsheet())
            {
                var dataSet = spreadsheet.Read(fileName, hasHeaders, removeEmptyRows, minimumColumnsPopulated);

                dataTable = dataSet.Tables[spreadsheet.worksheet.Name.Trim()];
            }

            return dataTable;
        }

        #endregion Constructors

        #region Methods (10)

        // Public Methods (7) 

        public void AddWorksheet(string worksheetName)
        {
            _Worksheet worksheet = (_Worksheet)workbook.Worksheets.Add(Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            worksheet.Name = worksheetName.Left(31);
            worksheet.Columns.Font.Name = "Tahoma";
            worksheet.Columns.Font.Size = "10";
            sheetName = worksheetName;

            CurrentRow = 1;
            ActivateSheet(worksheetName);
        }


        public void DeleteDefaultSheets()
        {
            DeleteSheet("Sheet1");
            DeleteSheet("Sheet2");
            DeleteSheet("Sheet3");
        }

        public void DeleteSheet(string worksheetName)
        {
            ((Worksheet)workbook.Sheets[worksheetName]).Delete();
        }

        public void ActivateSheet(string worksheetName)
        {
            Worksheet worksheet = (Worksheet)workbook.Sheets[worksheetName.Left(31)];

            worksheet.Select(Type.Missing);
        }

        public void Autofit(string currentWorksheet)
        {
            Autofit(GetWorksheet(currentWorksheet));
        }

        public void Autofit()
        {
            Autofit((Worksheet)workbook.ActiveSheet);
        }

        private void Autofit(Worksheet sheet)
        {
            sheet.Columns.AutoFit();
        }

        public void SetColumnWidth(int colIndex, int width)
        {
            Worksheet sheet = (Worksheet)workbook.ActiveSheet;
            ((Range)sheet.Cells[1, colIndex]).EntireColumn.ColumnWidth = width;
        }

        public List<string> GetColumnValueList(int rowIndex, int colIndex)
        {
            var list = new List<string>();

            while (((Range)worksheet.Cells[rowIndex, colIndex]).Value2 != null)
            {
                var value = ((Range)worksheet.Cells[rowIndex, colIndex]).Value2.ToString();
                list.Add(value);
                rowIndex++;
            }

            return list;
        }

        public int GetLastRow(string range1, string range2)
        {
            var last = worksheet.Cells.get_Range(range1, range2).get_End(XlDirection.xlDown).Row;

            return last + 1;
        }


        public string GetValue(int rowIndex, int colIndex)
        {
            return Convert.ToString(((Range)worksheet.Cells[rowIndex, colIndex]).Value2);
        }

        public void Dispose()
        {
            try
            {
                StaticDispose(excel, workbook);
            }
            catch
            {
            }

            workbook = null;
            excel = null;
        }

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        private static void StaticDispose(Application excel, _Workbook workbook)
        {
            var hWnd = excel.Hwnd;

            try
            {
                if (workbook != null)
                {
                    workbook.Close(Type.Missing, Type.Missing, Type.Missing);
                    ReleaseComObject(workbook);
                }

                if (excel != null)
                {
                    excel.Quit();
                    ReleaseComObject(excel);
                }
            }
            finally
            {
                uint processId; 

                GetWindowThreadProcessId((IntPtr)hWnd, out processId);

                Process[] procs = Process.GetProcessesByName("excel");

                foreach (Process p in procs)
                {
                    if (p.Id == processId)
                    {
                        p.Kill();
                    }
                }

                ReleaseComObject(excel);
            }
        }

        public void Save()
        {
            Save(excelFileName);
        }

        private static XlFileFormat GetFileFormat(string filePath)
        {
            XlFileFormat fileFormat;

            switch (Path.GetExtension(filePath.ToUpper()))
            {
                case ".CSV":
                    fileFormat = XlFileFormat.xlCSV;
                    break;
                case ".XLSB":
                    fileFormat = XlFileFormat.xlExcel12;
                    break;
                case ".XLSX":
                    fileFormat = XlFileFormat.xlOpenXMLWorkbook;
                    break;
                case ".XML":
                    fileFormat = XlFileFormat.xlXMLSpreadsheet;
                    break;
                default:
                    fileFormat = XlFileFormat.xlExcel8;
                    break;
            }

            return fileFormat;
        }

        public void Save(string fileName)
        {
            var fileType = GetFileFormat(fileName);

            workbook.SaveAs(fileName, fileType, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        }

        public enum ExcelFileType
        {
            Binary,
            Csv,
            Excel97,
            Excel2007,
            Xml
        }

        public void SaveCopy(string fileName)
        {
            workbook.SaveCopyAs(fileName);
        }

        public void SetBoldHeader(string currentWorksheet)
        {
            SetBoldHeader(GetWorksheet(currentWorksheet));
        }

        public void SetBoldHeader()
        {
            SetBoldHeader((Worksheet)workbook.ActiveSheet);
        }

        private void SetBoldHeader(Worksheet currentWorksheet)
        {
            ((Range)currentWorksheet.Cells[1, 1]).EntireRow.Font.Bold = true;
        }

        public void SetColumnFormat(string currentWorksheet, string column, string numberFormat)
        {
            Worksheet sheet = GetWorksheet(currentWorksheet);
            ((Range)sheet.Cells[1, GetColumnNumber(column)]).EntireColumn.NumberFormat = numberFormat;
        }

        public void SetValue(string cellToFill, string cellValue)
        {
            Worksheet sheet = ((Worksheet)workbook.ActiveSheet);
            Range range = sheet.get_Range(cellToFill, cellToFill);
            range.Value2 = cellValue;
        }

        public void SetValue(string currentWorksheet, string cellToFill, string cellValue)
        {
            Worksheet sheet = GetWorksheet(currentWorksheet);
            Range range = sheet.get_Range(cellToFill, cellToFill);
            range.Value2 = cellValue;
        }

        public void AddRow(string currentWorksheet, List<object> data)
        {
            AddRow(GetWorksheet(currentWorksheet), data);
        }


        public void AddFormattedRow(List<object> data)
        {
            AddFormattedRow(data, new List<int>() { });
        }

        public void AddFormattedRow(List<object> data, List<int> colors)
        {
            AddFormattedRow(data, colors, 0);
        }

        public void AddFormattedRow(List<object> data, List<int> colors, int offset)
        {
            Worksheet sheet = GetWorksheet(sheetName);

            for (int i = 0; i < data.Count; i++)
            {
                range = sheet.get_Range(GetColumnLetter(i + offset + 1) + CurrentRow, Missing.Value);

                var value = data[i];

                range.Style = GetStyle(value);

                range.Value2 = data[i];

                if (data.Count == colors.Count)
                {
                    range.Interior.Color = colors[i];
                }
            }

            CurrentRow++;
        }

        private Style GetStyle(object value)
        {
            var type = value.GetType().ToString().Remove("System.").ToUpper();

            Style style;

            switch (type)
            {
                case "DATETIME":
                    style = DateStyle;
                    break;
                case "INT":
                case "INT32":
                case "INT64":
                    style = NumberStyle;
                    break;
                case "FLOAT":
                case "DECIMAL":
                    style = DecimalStyle;
                    break;
                case "DOUBLE":
                    style = PercentStyle;
                    break;
                default:
                    style = TextStyle;
                    break;
            }

            return style;
        }


        public void AddRow(List<object> data)
        {
            AddRow((Worksheet)workbook.ActiveSheet, data);
        }

        private bool StylesSet { get; set; }

        private void AddRow(Worksheet sheet, List<object> data)
        {
            if (!StylesSet)
            {
                SetColumnStylesFromRow(sheet, data);
            }

            var range = sheet.get_Range(string.Format("A{0}", CurrentRow), GetColumnLetter(data.Count) + CurrentRow);

            range.Value2 = data.ToArray();

            CurrentRow++;
        }

        private void SetColumnStylesFromRow(Worksheet sheet, List<object> data)
        {
            StyleList = new Style[data.Count];

            for (int i = 0; i < data.Count; i++)
            {
                range = sheet.get_Range(GetColumnLetter(i + 1) + "1", Missing.Value);

                StyleList[i] = GetStyle(data[i]);
            }

            SetColumnStylesFromArray(sheet);
        }

        public static void ToPDF(string spreadsheetPath, string outputPath)
        {
            using (var spreadsheet = new Spreadsheet(spreadsheetPath))
            {
                spreadsheet.SavePdf(outputPath);
            }
        }

        public void SavePdf(string fileName)
        {
            var sheet = (_Worksheet)workbook.ActiveSheet;

            sheet.PageSetup.Orientation = XlPageOrientation.xlLandscape;
            sheet.PageSetup.Zoom = false;
            sheet.PageSetup.FitToPagesWide = 1;

            sheet.ExportAsFixedFormat(XlFixedFormatType.xlTypePDF, fileName, XlFixedFormatQuality.xlQualityStandard, true, false, Type.Missing, Type.Missing, false, Type.Missing);
        }

        private void SetColumnStylesFromArray(Worksheet sheet)
        {
            if (StyleList != null && !StylesSet)
            {
                for (int i = 0; i < StyleList.Length; i++)
                {
                    if (StyleList[i] == null)
                    {
                        StyleList[i] = GetStyle(string.Empty);
                    }

                    range = sheet.get_Range(GetColumnLetter(i + 1) + "1", Missing.Value);

                    range.EntireColumn.Style = StyleList[i];
                }

                StylesSet = true;
            }
        }

        private Style[] StyleList { get; set; }

        private void AddData(object[,] data)
        {
            if (data.GetLength(0) > 0)
            {
                var sheet = (Worksheet)workbook.ActiveSheet;

                SetColumnStylesFromArray(sheet);

                var startCell = string.Format("A" + CurrentRow);
                var endCell = GetColumnLetter(data.GetLength(1)) + (data.GetLength(0) + CurrentRow - 1);

                var range = sheet.get_Range(startCell, endCell);

                range.Value2 = data;

                CurrentRow += data.GetLength(0);
            }
        }

        public static void FromDataTable(System.Data.DataTable table, string outputPath, bool boldHeaders = true, bool sameSheet = false)
        {
            FromDataSet(Convert.ToDataSet(table), outputPath, boldHeaders, sameSheet);
        }

        public static void FromDataSet(DataSet dataSet, string outputPath, bool boldHeaders = true, bool sameSheet = false)
        {
            using (var spreadsheet = new Spreadsheet())
            {
                var tableName = string.Empty;

                var firstTime = true;

                foreach (System.Data.DataTable table in dataSet.Tables)
                {
                    if (!sameSheet || firstTime)
                    {
                        spreadsheet.CurrentRow = 1;
                        tableName = table.TableName;
                        spreadsheet.AddWorksheet(tableName);
                        spreadsheet.StylesSet = false;
                    }

                    // add breaker row
                    if (sameSheet && !firstTime)
                    {
                        var newDataTable = new System.Data.DataTable();
                        newDataTable.Columns.Add("");
                        newDataTable.Rows.Add(new object[1]);
                        spreadsheet.AddData(newDataTable, false);
                    }

                    spreadsheet.AddData(table);

                    spreadsheet.Autofit(tableName);

                    spreadsheet.SetBoldHeader(tableName);

                    firstTime = false;
                }

                spreadsheet.DeleteDefaultSheets();

                spreadsheet.Save(outputPath);
            }
        }

        public void AddData(System.Data.DataTable table, bool addHeaders = true)
        {
            if (addHeaders)
            {
                var header = new List<object>();

                foreach (DataColumn column in table.Columns)
                {
                    header.Add(column.ColumnName);
                }

                AddFormattedRow(header);
            }

            StyleList = new Style[table.Columns.Count];

            const int incrementCount = 10000;

            var data = new object[Math.Min(incrementCount, table.Rows.Count), table.Columns.Count];

            var currentBatchRow = 0;

            for (var i = 0; i < table.Rows.Count; i++)
            {
                for (var j = 0; j < table.Columns.Count; j++)
                {
                    var obj = table.Rows[i][j];

                    var rawType = obj.GetType();

                    if (rawType == typeof(TimeSpan))
                    {
                        data[currentBatchRow, j] = Convert.ToString((TimeSpan)obj);
                    }
                    else
                    {
                        data[currentBatchRow, j] = obj;
                    }

                    if (rawType != typeof(DBNull) && StyleList[j] == null)
                    {
                        var style = GetStyle(data[currentBatchRow, j]);

                        StyleList[j] = style;
                    }
                }

                currentBatchRow++;

                if (currentBatchRow >= incrementCount)
                {
                    AddData(data);
                    data = new object[Math.Min(incrementCount, table.Rows.Count), table.Columns.Count];
                    currentBatchRow = 0;
                }
            }

            AddData(data);
        }

        public void DeleteRow(int rowIndex, int colIndex)
        {
            ((Range)worksheet.Cells[rowIndex, colIndex]).EntireRow.Delete(XlDeleteShiftDirection.xlShiftUp);
        }

        public string GetValue(string currentWorksheet, string cellToGet)
        {
            Worksheet sheet = GetWorksheet(currentWorksheet);
            return GetValue(sheet, cellToGet);
        }

        private string GetValue(Worksheet sheet, string cellToGet)
        {
            var value = string.Empty;
            try
            {
                range = sheet.get_Range(cellToGet, cellToGet);

                value = Convert.ToString(range.Value2);
            }
            catch { }

            return value;
        }

        public string GetValue(string cellToGet)
        {
            Worksheet sheet = ((Worksheet)workbook.ActiveSheet);
            return GetValue(sheet, cellToGet);
        }

        public int GetColumnNumber(string columnLetter)
        {
            Worksheet sheet = (Worksheet)workbook.ActiveSheet;
            return sheet.get_Range(columnLetter + "1", Missing.Value).Column;
        }

        public static string GetColumnLetter(int columnNumber)
        {
            string result = string.Empty;
            for (int i = System.Convert.ToInt32(Math.Log(System.Convert.ToDouble(25 * (System.Convert.ToDouble(columnNumber) + 1))) / Math.Log(26)) - 1;
                 i >= 0;
                 i--)
            {
                int x = System.Convert.ToInt32(Math.Pow(26, i + 1) - 1) / 25 - 1;

                if (columnNumber > x)
                {
                    result += (char)(((columnNumber - x - 1) / System.Convert.ToInt32(Math.Pow(26, i))) % 26 + 65);
                }
            }
            return result;
        }


        // Private Methods (3) 

        private Worksheet GetWorksheet(string worksheetName)
        {
            worksheetName = worksheetName.Left(31);

            Worksheet sheet = null;
            try
            {
                sheet = (Worksheet)workbook.Worksheets.get_Item(worksheetName);
            }
            catch
            {
                try
                {
                    AddWorksheet(worksheetName);
                    sheet = (Worksheet)workbook.Worksheets.get_Item(worksheetName);
                }
                catch
                {
                }
            }

            return sheet;
        }

        private void Initialize()
        {
            excel = new Application
            {
                DisplayAlerts = false
            };

            CurrentRow = 1;
        }

        private static void ReleaseComObject(object comObject)
        {
            try
            {
                if (comObject != null)
                {
                    Marshal.ReleaseComObject(comObject);
                }
            }
            catch
            {
                // Do nothing.
            }
        }


        #endregion Methods

        public void Close()
        {
            workbook.Close(Type.Missing, Type.Missing, Type.Missing);
        }

        public bool SheetExists(string name)
        {
            bool result = false;

            foreach (Worksheet sheet in workbook.Sheets)
            {
                if (sheet.Name.Trim().ToUpper() == name.Trim().ToUpper())
                {
                    result = true;
                }
            }

            return result;
        }
    }
}
