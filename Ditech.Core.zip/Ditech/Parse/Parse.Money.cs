namespace Ditech
{
    /// <summary>
    /// This static class provides utility classes related to numbers.
    /// </summary>
    public static partial class Parse
    {
        #region�Methods�(8)�

        //�Public�Methods�(4)�

        /// <summary>
        /// Parses a substring to a currency-formatted value.  This method will parse out in each direction from the starting point to get the full money value.
        /// </summary>
        /// <param name="dataToRead">The data to read.</param>
        /// <param name="entryPoint">The entry point.</param>
        /// <returns>Returns the data in a money format.</returns>
        public static string Money(this string dataToRead, int entryPoint)
        {
            return Decimal(dataToRead, entryPoint).ToString("0.00");
        }

        /// <summary>
        /// Parses a substring to a numeric value.  This method will parse out in each direction from the starting point to get the full numeric value.
        /// </summary>
        /// <param name="dataToRead">The data to read.</param>
        /// <param name="entryPoint">The entry point.</param>
        /// <param name="blankIsZero">if set to <c>true</c> [blank is zero].</param>
        /// <returns>Returns the data in a money format.</returns>
        public static string Money(this string dataToRead, int entryPoint, bool blankIsZero)
        {
            var number = NullableDecimal(dataToRead, entryPoint);

            var result = string.Empty;

            if (number != null)
            {
                result = number.Value.ToString("0.00");
            }
            else
            {
                if (blankIsZero)
                {
                    result = "0.00";
                }
            }

            return result;
        }


        //�Private�Methods�(4)�

        private static bool IsValidMoneyEndCharacter(string dataToRead, int startPosition, int numberOfPositions)
        {
            return !dataToRead.Mid(startPosition, numberOfPositions).EndsWith(" ") &&
                   !dataToRead.Mid(startPosition, numberOfPositions).EndsWith("-") &&
                   (startPosition + numberOfPositions) < dataToRead.Length;
        }

        private static bool IsValidMoneyStartCharacter(string dataToRead, int startPosition)
        {
            return
                dataToRead.Mid(startPosition, 1) != (" ") && dataToRead.Mid(startPosition, 1) != "-" &&
                !dataToRead.Mid(startPosition, 1).IsAlpha() && startPosition >= 0;
        }

        private static bool IsValidMoneyStringEntryPoint(string dataToRead, int decimalPosition)
        {
            return !dataToRead.Mid(decimalPosition, 1).Equals(" ") &&
                   !dataToRead.Mid(decimalPosition, 1).IsAlpha();
        }

        private static string LastPositionInSubstring(string sourceString, int startPosition, int numberOfPositions)
        {
            return sourceString.Mid(startPosition, numberOfPositions).Mid(numberOfPositions - 1);
        }

        #endregion�Methods�
    }
}