﻿namespace Ditech
{
    public static partial class Parse
    {
        #region Methods (1) 

        // Public Methods (1) 

        /// <summary>
        /// Parses a substring to a decimal value.  This method will parse out in each direction from the starting point to get the full numeric value
        /// </summary>
        /// <param name="dataToRead">The data to read.</param>
        /// <param name="entryPoint">The entry point.</param>
        /// <returns>Returns data in decimal format.</returns>
        public static decimal Decimal(this string dataToRead, int entryPoint)
        {
            var result = NullableDecimal(dataToRead, entryPoint);

            return result != null ? result.Value : default(decimal);
        }

        #endregion Methods 
    }
}