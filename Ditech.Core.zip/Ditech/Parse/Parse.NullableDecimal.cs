﻿namespace Ditech
{
    public static partial class Parse
    {
        #region Methods (1) 

        // Public Methods (1) 

        /// <summary>
        /// Parses a substring to a nullable decimal value.  This method will parse out in each direction from the starting point to get the full numeric value
        /// </summary>
        /// <param name="dataToRead">The data to read.</param>
        /// <param name="entryPoint">The entry point.</param>
        /// <returns>Returns data in nullable decimal format.</returns>
        public static decimal? NullableDecimal(this string dataToRead, int entryPoint)
        {
            dataToRead = dataToRead.PadRight(entryPoint + 1);
            var inputValue = string.Empty;
            var startPosition = entryPoint;
            var numberOfPositions = 1;
            decimal? result = null;

            if (IsValidMoneyStringEntryPoint(dataToRead, entryPoint))
            {
                // Keep checking previous character until we get a space or reach the start of the string.
                while (IsValidMoneyStartCharacter(dataToRead, startPosition))
                {
                    startPosition--;
                    if (startPosition == -1)
                    {
                        break;
                    }
                }

                startPosition++;

                while (IsValidMoneyEndCharacter(dataToRead, startPosition, numberOfPositions))
                {
                    numberOfPositions++;

                    if (LastPositionInSubstring(dataToRead, startPosition, numberOfPositions).IsAlpha())
                    {
                        numberOfPositions--;
                        break;
                    }
                }

                inputValue = dataToRead.Mid(startPosition, numberOfPositions).Remove(new[] {"*", "%"});
            }

            if (inputValue.StartsWith("-") && inputValue.EndsWith("-"))
            {
                inputValue = inputValue.Mid(1);
            }

            decimal number;

            if (decimal.TryParse(inputValue, out number))
            {
                result = number;
            }

            return result;
        }

        #endregion Methods 
    }
}