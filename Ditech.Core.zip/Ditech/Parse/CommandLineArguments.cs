﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech
{
    public class CommandLineArguments
    {

        public const string DEFAULT_ALLOWED_DELIMITERS = @"-/";
        public const bool DEFAULT_CASE_SENSITIVE = false;

        public string AllowedDelimeters = DEFAULT_ALLOWED_DELIMITERS;
        public bool CaseSensitive { get; protected set; }

        public Dictionary<string, List<string>> ParsedArgs { get; protected set; }
        public List<string> NonspecificParameters { get; protected set; }
        protected Dictionary<string, int> argsWithParmCount { get; set; }

        public CommandLineArguments(IEnumerable<Tuple<string, int>> allowedArgs, bool caseSensitive = DEFAULT_CASE_SENSITIVE)
        {
            ParsedArgs = null;
            argsWithParmCount = caseSensitive ? new Dictionary<string, int>() : new Dictionary<string, int>(StringComparer.CurrentCultureIgnoreCase);
            foreach (Tuple<string, int> tup in allowedArgs)
                argsWithParmCount.Add(tup.Item1, tup.Item2);
            NonspecificParameters = new List<string>();
        }

        public Dictionary<string, List<string>> Parse(IEnumerable<string> givenArgs)
        {
            List<string> argsAsList = givenArgs.ToList();
            ParsedArgs = new Dictionary<string, List<string>>();

            for (int argnum = 0; argnum < argsAsList.Count; )
            {
                string trimArg = argsAsList[argnum++].TrimStart(); // not sure this makes any difference but just in case...
                if (string.IsNullOrWhiteSpace(trimArg) || (trimArg.Length < 1))
                    continue;
                if (AllowedDelimeters.Contains(trimArg[0]))
                {
                    // looks like a new parameter...
                    if (argsWithParmCount.ContainsKey(trimArg.Substring(1)))
                    {
                        int parmCount = argsWithParmCount[trimArg.Substring(1)];
                        ParsedArgs[trimArg.Substring(1)] = new List<string>(parmCount);
                        for (int last = argnum + parmCount - 1; argnum <= last && (argnum < argsAsList.Count); ++argnum)
                        {
                            string trimmedParm = argsAsList[argnum].Trim();
                            if (trimmedParm.StartsWith("\""))
                            {
                                List<string> multiWordParm = new List<string>(new string[1] {trimmedParm});
                                for (; !trimmedParm.EndsWith(("\"")); multiWordParm.Add(trimmedParm))
                                    trimmedParm = argsAsList[++argnum].Trim();
                                trimmedParm = string.Join(" ", multiWordParm);
                                trimmedParm = trimmedParm.Substring(1, trimmedParm.Length - 2);
                            }

                            ParsedArgs[trimArg.Substring(1)].Add(trimmedParm);
                        }
                    }
                    // apparently it wasn't an expected parameter after all...
                    else
                    {
                        NonspecificParameters.Add(trimArg);
                    }
                }
                else
                {
                    // if this is NOT an allowed argument throw it in the catch-all bucket
                    NonspecificParameters.Add(trimArg);
                }
            }

            return ParsedArgs;
        }
    }
}
