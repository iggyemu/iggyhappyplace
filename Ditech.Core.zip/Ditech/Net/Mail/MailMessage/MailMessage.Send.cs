﻿using System;
using System.Net.Mail;
using System.Runtime.Remoting.Messaging;

namespace Ditech.Net.Mail
{
    /// <summary>
    /// Creates an e-mail message.
    /// </summary>
    public partial class MailMessage : System.Net.Mail.MailMessage, IValidState
    {
        #region Methods (4) 

        // Public Methods (4) 

        /// <summary>
        /// Sends the email using the default internal SMTP server.
        /// </summary>
        public void Send()
        {
            Send(Configuration.MailServer);
        }

        /// <summary>
        /// Sends the email using the SMTP server specified.
        /// </summary>
        /// <param name="smtpServer">The SMTP server.</param>
        public void Send(string smtpServer)
        {
            SmtpServer = smtpServer;

#if DEBUG
            Subject += " (Dev)";
#endif

            if (!IsValidState)
            {
                throw new InvalidOperationException("The MailMessage object is not properly initialized.");
            }

            var smtpClient = new SmtpClient(SmtpServer) { Timeout = 200000 };


            smtpClient.Send(this);
            Dispose();
        }

        /// <summary>
        /// Sends the email using the default SMTP server.
        /// </summary>
        /// <param name="ignoreErrors">The bool expression for ignoring errors in message.</param>
        public void Send(bool ignoreErrors)
        {
            Send(ignoreErrors, Configuration.MailServer);
        }

        /// <summary>
        /// Sends the email using the SMTP server specified.
        /// </summary>
        /// <param name="ignoreErrors">if set to <c>true</c> [ignore errors].</param>
        /// <param name="smtpServer">The SMTP server.</param>
        public void Send(bool ignoreErrors, string smtpServer)
        {
            try
            {
                Send(smtpServer);
            }
            catch
            {
                if (!ignoreErrors)
                {
                    throw;
                }
            }
        }

        #endregion Methods 
    }
}