using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;

namespace Ditech.Net.Mail
{
    /// <summary>
    /// Creates an e-mail message.
    /// </summary>
    public partial class MailMessage : System.Net.Mail.MailMessage, IValidState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailMessage"/> class.
        /// </summary>
        /// <param name="fromAddress">From address.</param>
        /// <param name="toAddress">To address.  You can also use a comma separated list of addresses here.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        public MailMessage(string fromAddress, string toAddress, string subject, string body)
            : base(fromAddress, toAddress, subject, body)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MailMessage"/> class.
        /// </summary>
        /// <param name="fromAddress">From address.</param>
        /// <param name="toAddress">To address.  You can also use a comma separated list of addresses here.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        public MailMessage(string fromAddress, string toAddress, string subject, string body, bool ccSender)
            : base(fromAddress, toAddress, subject, body)
        {
            if (ccSender)
            {
                CC.Add(fromAddress);
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MailMessage"/> class.
        /// </summary>
        /// <param name="fromAddress">From address.</param>
        /// <param name="toAddress">To address.  You can also use a comma separated list of addresses here.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        /// <param name="attachments">The attachments.</param>
        public MailMessage(string fromAddress, string toAddress, string subject, string body, bool ccSender,
                           params string[] attachments)
            : this(fromAddress, toAddress, subject, body, ccSender)
        {
            // Attach all the files to the e-mail
            if (attachments != null)
            {
                if (attachments.Length > 0 && attachments[0] != null)
                {
                    var totalLength = 0l;
                    var fileList = new List<string>();

                    foreach (var attachmentPath in attachments)
                    {
                        try
                        {
                            var fileInfo = new FileInfo(attachmentPath);

                            totalLength += fileInfo.Length;
                            fileList.Add(string.Format("{0}: {1} bytes", fileInfo.Name,
                                                       fileInfo.Length.ToString("#,##0")));
                        }
                        catch (Exception)
                        {
                        }

                        Attachments.Add(new Attachment(attachmentPath));
                    }

                    try
                    {
                        var mbLimit = 15;
                        var byteLimit = (mbLimit*1024)*1024;

                        if (totalLength > byteLimit)
                        {
                            var warningMessage = new MailMessage(fromAddress, toAddress,
                                                                 "WARNING: Large attachments found",
                                                                 string.Format(
                                                                     "This message may not have gone through due to attachment size limit of {0} MB:\n\nFile List:\n\n{1}\n\nSubject: {2}\nBody:\n\n{3}",
                                                                     mbLimit,
                                                                     string.Join("\n", fileList.ToArray()), subject,
                                                                     body), true);

                            warningMessage.Send();
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MailMessage"/> class.
        /// </summary>
        /// <param name="fromAddress">From address.</param>
        /// <param name="toAddresses">To addresses.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        /// <param name="attachments">The attachments.</param>
        public MailMessage(string fromAddress, string[] toAddresses, string subject, string body, bool ccSender,
                           params string[] attachments)
            : this(fromAddress, string.Join(",", toAddresses), subject, body, ccSender, attachments)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MailMessage"/> class.
        /// </summary>
        /// <param name="fromAddress">From address.</param>
        /// <param name="toAddresses">To addresses.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        /// <param name="attachments">The attachments.</param>
        public MailMessage(string fromAddress, List<string> toAddresses, string subject, string body, bool ccSender,
                           params string[] attachments)
            : this(fromAddress, toAddresses.ToArray(), subject, body, ccSender, attachments)
        {
        }

        private string SmtpServer { get; set; }
    }
}