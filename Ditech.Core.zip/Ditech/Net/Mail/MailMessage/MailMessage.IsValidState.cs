﻿namespace Ditech.Net.Mail
{
    /// <summary>
    /// Creates an e-mail message.
    /// </summary>
    public partial class MailMessage : System.Net.Mail.MailMessage, IValidState
    {
        #region IValidState Members

        /// <summary>
        /// Gets a value indicating whether this instance is in a valid state.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is valid state; otherwise, <c>false</c>.
        /// </value>
        public bool IsValidState
        {
            get
            {
                bool result;
                if (From != null && To != null && !string.IsNullOrEmpty(Subject) && !string.IsNullOrEmpty(Body)
                    && !string.IsNullOrEmpty(SmtpServer))
                {
                    result = true;
                }
                else
                {
                    result = false;
                }

                return result;
            }
        }

        #endregion
    }
}