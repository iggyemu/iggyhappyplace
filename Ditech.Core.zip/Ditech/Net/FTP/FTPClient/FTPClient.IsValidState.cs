﻿namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        #region IValidState Members

        /// <summary>
        /// Gets a value indicating whether this instance is in valid state.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is valid state; otherwise, <c>false</c>.
        /// </value>
        public bool IsValidState
        {
            get
            {
                bool result;
                if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password) || string.IsNullOrEmpty(ServerName))
                {
                    result = false;
                }
                else
                {
                    result = true;
                }

                return result;
            }
        }

        #endregion
    }
}