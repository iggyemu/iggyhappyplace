﻿using System;
using System.Globalization;
using System.IO;
using System.Net;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Gets the specified remote file.
        /// </summary>
        /// <param name="remoteFileName">Name of the remote file.</param>
        /// <returns>[true] Date Time with last modified time of file, [false]</returns>
        public DateTime? ModifiedDate(string remoteFileName)
        {
            DateTime? result = null;

            try
            {
                var ftpRequest = CreateRequest(CreateUri(remoteFileName));

                ftpRequest.Method = WebRequestMethods.Ftp.GetDateTimestamp;

                using (var response = (FtpWebResponse)ftpRequest.GetResponse())
                {
                    result = response.LastModified;
                }
            }
            catch { }

            return result;
        }
    }
}