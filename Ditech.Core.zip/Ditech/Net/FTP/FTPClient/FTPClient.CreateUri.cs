﻿using System;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        private Uri CreateUri()
        {
            return CreateUri(string.Empty);
        }


        private Uri CreateUri(string fileName)
        {
            CheckState();

            if (fileName != string.Empty)
            {
                fileName = string.Format("/{0}", fileName);
            }

            return new Uri(System.String.Format(@"ftp://{0}/{1}{2}", ServerName, ServerPath, fileName));
        }
    }
}