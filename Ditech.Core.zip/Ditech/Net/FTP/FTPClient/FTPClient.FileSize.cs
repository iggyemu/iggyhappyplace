﻿using System.Net;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Gets the specified remote file.
        /// </summary>
        /// <param name="remoteFileName">Name of the remote file.</param>
        /// <returns>[true] Date Time with last modified time of file, [false]</returns>
        public int? FileSize(string remoteFileName)
        {
            int? result = null;

            try
            {
                var ftpRequest = CreateRequest(CreateUri(remoteFileName));

                ftpRequest.Method = WebRequestMethods.Ftp.GetFileSize;

                using (var response = (FtpWebResponse)ftpRequest.GetResponse())
                {
                    result = (int) Convert.ToDecimal(response.ContentLength);
                }
            }
            catch { }

            return result;
        }
	}
}
