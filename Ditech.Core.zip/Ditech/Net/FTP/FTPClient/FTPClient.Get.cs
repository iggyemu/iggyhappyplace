﻿using System;
using System.IO;
using System.Linq;
using System.Net;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Gets the specified remote file.
        /// </summary>
        /// <param name="remoteFileName">Name of the remote file.</param>
        /// <param name="localFileFullPath">The local file full path.</param>
        /// <returns>[true] if the file was retrieved successfully, otherwise, [false]</returns>
        public bool Get(string remoteFileName, string localFileFullPath)
        {
            var result = false;

            var ftpRequest = CreateRequest(CreateUri(remoteFileName));

            ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;

            // Write file
            using (var response = (FtpWebResponse) ftpRequest.GetResponse())
            {
                using (var ftpStream = response.GetResponseStream())
                {
                    var buffer = new byte[BufferSize];

                    var readCount = ftpStream.Read(buffer, 0, buffer.Length);

                    using (var outputStream = new FileStream(localFileFullPath, FileMode.Create))
                    {
                        while (readCount > 0)
                        {
                            outputStream.Write(buffer, 0, readCount);
                            readCount = ftpStream.Read(buffer, 0, buffer.Length);
                        }
                    }
                }
            }

            var lastModified =
                ListFileDetails().Where(x => x.Item1 == remoteFileName).Select(x => x.Item2).FirstOrDefault();

            if (lastModified.HasValue)
            {
                File.SetLastWriteTime(localFileFullPath, lastModified.Value);
            }
            result = true;

            return result;
        }
    }
}