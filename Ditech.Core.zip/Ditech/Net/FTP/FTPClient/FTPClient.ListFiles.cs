﻿using System.Collections.Generic;
using System.IO;
using System.Net;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Gets all files in FTP directory.
        /// </summary>
        /// <returns></returns>
        public string[] ListFiles()
        {
            return ListFiles(string.Empty);
        }

        /// <summary>
        /// Gets all files in FTP directory that end with the specified file extension (not case sensitive).
        /// </summary>
        /// <returns></returns>
        public string[] ListFiles(string extension)
        {
            var request = CreateRequest(CreateUri());

            request.Method = WebRequestMethods.Ftp.ListDirectory;

            var list = new List<string>();

            using (var response = (FtpWebResponse)request.GetResponse())
            {
                using (var input = new StreamReader(response.GetResponseStream()))
                {
                    string line;

                    while ((line = input.ReadLine()) != null)
                    {
                        if (extension == string.Empty || line.ToLower().EndsWith(extension.ToLower()))
                        {
                            var filename = line;

                            if (filename.Contains("/"))
                            {
                                var fileFullName = filename.Split(new[] {'/'});
                                filename = fileFullName[fileFullName.Length - 1];
                            }

                            list.Add(filename);
                        }
                    }
                }
            }

            return list.ToArray();
        }
    }
}