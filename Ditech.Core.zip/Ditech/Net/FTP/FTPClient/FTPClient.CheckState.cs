﻿using System;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        private void CheckState()
        {
            if (!IsValidState)
            {
                throw new InvalidOperationException("The FtpClient is not in a valid state.");
            }
        }
    }
}