﻿using System;
using System.IO;
using System.Net;
using System.Text;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Puts the specified local file onto the server.
        /// </summary>
        /// <param name="localFileFullPath">The local file full path.</param>
        public void Put(string localFileFullPath, bool usePassive = false)
        {
            Put(localFileFullPath, Path.GetFileName(localFileFullPath), usePassive);
        }

        /// <summary>
        /// Puts the specified local file onto the server.
        /// </summary>
        /// <param name="localFileFullPath">The local file full path.</param>
        /// <param name="remoteFileName">Name of the remote file.</param>
        public void Put(string localFileFullPath, string remoteFileName, bool usePassive = false)
        {
            CheckState();

            var target = CreateUri(remoteFileName);

            var ftpRequest = CreateRequest(target, usePassive);

            ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;

            var buffer = new byte[BufferSize];

            using (var sourceStream = new FileStream(localFileFullPath, FileMode.Open))
            {
                using (var requestStream = ftpRequest.GetRequestStream())
                {
                    int bytesRead;

                    do
                    {
                        bytesRead = sourceStream.Read(buffer, 0, buffer.Length);

                        requestStream.Write(buffer, 0, bytesRead);
                    } 
                    while (bytesRead > 0);
                }
            }
        }
    }
}