﻿using System;
using System.Net;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Renames the file.
        /// </summary>
        /// <param name="remoteFileName">Name of the FTP file.</param>
        /// <param name="newName">Nwe name of the FTP file.</param>
        public void Rename(string remoteFileName, string newName)
        {
            var client = CreateRequest(CreateUri(remoteFileName));

            client.Method = WebRequestMethods.Ftp.Rename;
            client.RenameTo = newName;

            client.GetResponse().Close();
        }
    }
}
