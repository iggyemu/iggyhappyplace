﻿using System.Net;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        /// <summary>
        /// Deletes the file.
        /// </summary>
        /// <param name="remoteFileName">Name of the FTP file.</param>
        public void Delete(string remoteFileName)
        {
            var client = CreateRequest(CreateUri(remoteFileName));


            client.Method = WebRequestMethods.Ftp.DeleteFile;

            client.GetResponse().Close();
        }
    }
}