﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {
        private FtpWebRequest CreateRequest(Uri uri, bool usePassive = false)
        {
            CheckState();

            var ftpRequest = (FtpWebRequest)WebRequest.Create(uri);

            ftpRequest.UseBinary = true;
            ftpRequest.UsePassive = usePassive;
            ftpRequest.Proxy = null;
            ftpRequest.KeepAlive = false;

            ftpRequest.Credentials = new NetworkCredential(UserName, Password);

            return ftpRequest;
        }
    }
}
