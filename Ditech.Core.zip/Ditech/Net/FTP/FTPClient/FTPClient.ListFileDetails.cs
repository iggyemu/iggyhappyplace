﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Net.FTP
{
    /// <summary>
    /// FTP Client class for uploading and downloading files.
    /// </summary>
    public partial class FtpClient : IValidState
    {  
        /// <summary>
        /// Gets all files in FTP directory that end with the specified file extension (not case sensitive).
        /// </summary>
        /// <returns></returns>
        public List<Tuple<string, DateTime?>> ListFileDetails()
        {
            var request = CreateRequest(CreateUri());

            request.Method = WebRequestMethods.Ftp.ListDirectoryDetails;

            var list = new List<Tuple<string, DateTime?>>();

            using (var response = (FtpWebResponse)request.GetResponse())
            {
                using (var input = new StreamReader(response.GetResponseStream()))
                {
                    string line;

                    while ((line = input.ReadLine()) != null)
                    {
                        var lastIndex = line.LastIndexOf("/");

                        var fileName = line.Mid(lastIndex + 1).Trim();

                        var firstIndex = line.IndexOf("/");

                        var modifiedDateString = line.Mid(firstIndex - 2, 17);

						var modifiedDate = Convert.ToNullableDateTime(modifiedDateString);

						list.Add(new Tuple<string, DateTime?>(fileName, modifiedDate));
                    }
                }
            }

            return list;
        }
    }
}
