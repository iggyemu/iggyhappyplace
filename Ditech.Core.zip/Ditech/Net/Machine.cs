﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;

namespace Ditech.Net
{
    public static class Machine
    {
        public static string FullyQualifiedDomainName
        {
            get
            {
                string fqdn;
                try
                {
                    var domainName = IPGlobalProperties.GetIPGlobalProperties().DomainName;
                    var hostName = Dns.GetHostName();
                    if (!hostName.Contains(domainName))
                        fqdn = hostName + "." + domainName;
                    else
                        fqdn = hostName;
                }
                catch (Exception)
                {
                    fqdn = "unknown";
                }
                return fqdn;
            }
        }
    }
}
