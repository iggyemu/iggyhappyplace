﻿using System.Collections;

namespace Ditech.Debug
{
    public static partial class ObjectDumper
    {
        private static void DumpCollection(ICollection collection, int level, ArrayList previous)
        {
            foreach (var child in collection)
            {
                Dump(child, level + 1, previous);
            }
        }
    }
}