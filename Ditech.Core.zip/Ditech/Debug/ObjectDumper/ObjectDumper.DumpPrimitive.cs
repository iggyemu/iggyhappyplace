﻿using System;
using System.Collections;

namespace Ditech.Debug
{
    public static partial class ObjectDumper
    {
        private static void DumpPrimitive(object value, Type type, string name, int level, ArrayList previous)
        {
            if (name != null)
            {
                objectDumpResponse.AppendLine(Pad(level, "{0} ({1}): {2}", name, type.Name, value));
            }
            else
            {
                objectDumpResponse.AppendLine(Pad(level, "({0}) {1}", type.Name, value));
            }
        }
    }
}