﻿using System.Collections;

namespace Ditech.Debug
{
    public static partial class ObjectDumper
    {
        private static void DumpDictionary(IDictionary dictionary, int level, ArrayList previous)
        {
            foreach (var key in dictionary.Keys)
            {
                objectDumpResponse.AppendLine(Pad(level + 1, "[{0}] ({1}):", key, key.GetType().Name));

                Dump(dictionary[key], level + 2, previous);
            }
        }
    }
}