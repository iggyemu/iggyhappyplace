﻿using System.Text;

namespace Ditech.Debug
{
    /// <summary>
    /// Dumps the fields/properties, their values, and the hierarchy to a string.
    /// </summary>
    public static partial class ObjectDumper
    {
        #region Fields (1)

        internal static StringBuilder objectDumpResponse;

        #endregion Fields 
    }
}