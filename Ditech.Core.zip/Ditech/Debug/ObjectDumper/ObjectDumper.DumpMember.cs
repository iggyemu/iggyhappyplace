﻿using System.Collections;
using System.Reflection;

namespace Ditech.Debug
{
    public static partial class ObjectDumper
    {
        private static void DumpMember(object value, MemberInfo member, int level, ArrayList previous)
        {
            if (member is MethodInfo || member is ConstructorInfo ||
                member is EventInfo)
            {
                return;
            }

            if (member is FieldInfo)
            {
                var field = (FieldInfo) member;

                var name = member.Name;
                if ((field.Attributes & FieldAttributes.Public) == 0)
                {
                    name = "#" + name;
                }

                Dump(field.GetValue(value), field.FieldType, name, level + 1, previous);
            }
            else if (member is PropertyInfo)
            {
                var prop = (PropertyInfo) member;

                if (prop.GetIndexParameters().Length == 0 && prop.CanRead)
                {
                    var name = member.Name;
                    var getter = prop.GetGetMethod();

                    if ((getter.Attributes & MethodAttributes.Public) == 0)
                    {
                        name = "#" + name;
                    }

                    Dump(prop.GetValue(value, null), prop.PropertyType, name, level + 1, previous);
                }
            }
        }
    }
}