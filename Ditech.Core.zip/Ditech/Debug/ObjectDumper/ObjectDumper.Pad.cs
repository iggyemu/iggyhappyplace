namespace Ditech.Debug
{
    /// <summary>
    /// Dumps the fields/properties, their values, and the hierarchy to a string.
    /// </summary>
    public static partial class ObjectDumper
    {
        private static string Pad(int level, string message, params object[] arguments)
        {
            var val = System.String.Format(message, arguments);
            return val.PadLeft((level*4) + val.Length);
        }
    }
}