﻿using System;
using System.Collections;
using System.Reflection;

namespace Ditech.Debug
{
    public static partial class ObjectDumper
    {
        private static void DumpComposite(object value, Type type, string name, int level, ArrayList previous)
        {
            if (name != null)
            {
                objectDumpResponse.AppendLine(Pad(level, "{0} ({1}):", name, type.Name));
            }
            else
            {
                objectDumpResponse.AppendLine(Pad(level, "({0})", type.Name));
            }

            if (value is IDictionary)
            {
                DumpDictionary((IDictionary) value, level, previous);
            }
            else if (value is ICollection)
            {
                DumpCollection((ICollection) value, level, previous);
            }
            else
            {
                var members = value.GetType().GetMembers(BindingFlags.Instance | BindingFlags.Public |
                                                         BindingFlags.NonPublic);

                foreach (var member in members)
                {
                    try
                    {
                        DumpMember(value, member, level, previous);
                    }
                    catch
                    {
                    }
                }
            }
        }
    }
}