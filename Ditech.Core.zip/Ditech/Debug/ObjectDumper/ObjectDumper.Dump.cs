﻿using System;
using System.Collections;
using System.Text;

namespace Ditech.Debug
{
    public static partial class ObjectDumper
    {
        /// <summary>
        /// Dumps the fields/properties, their values, and the hierarchy to a string.
        /// </summary>
        /// <param name="value">The object.</param>
        /// <returns>Dump of the object.</returns>
        public static string Dump(this object value)
        {
            objectDumpResponse = new StringBuilder();
            Dump(value, 0, new ArrayList());
            return objectDumpResponse.ToString();
        }


        // Private Methods (8) 

        private static void Dump(object value, int level, ArrayList previous)
        {
            Type type = null;

            if (value != null)
            {
                type = value.GetType();
            }

            Dump(value, type, null, level, previous);
        }

        private static void Dump(object value, Type type, string name, int level, ArrayList previous)
        {
            if (value == null)
            {
                objectDumpResponse.AppendLine(Pad(level, "{0} ({1}): (null)", name, type.Name));
                return;
            }

            if (previous.Contains(value))
            {
                return;
            }

            previous.Add(value);

            if (type.IsPrimitive || value is string)
            {
                DumpPrimitive(value, type, name, level, previous);
            }
            else
            {
                DumpComposite(value, type, name, level, previous);
            }
        }
    }
}