﻿namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        #region Properties (2)

        private long StartTicks { get; set; }

        private long StopTicks { get; set; }

        #endregion Properties 
    }
}