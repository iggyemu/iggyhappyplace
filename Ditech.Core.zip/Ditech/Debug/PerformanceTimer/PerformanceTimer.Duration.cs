﻿using System;

namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        /// <summary>
        /// Gets the duration type and returns in seconds.
        /// </summary>
        /// <param name="durationType">The duration type.</param>
        /// <returns>Duration object.</returns>
        public double Duration(DurationType durationType)
        {
            double result = 0;

            switch (durationType)
            {
                case DurationType.Milliseconds:
                    result = TickSpan()/TimeSpan.TicksPerMillisecond;
                    break;
                case DurationType.Seconds:
                    result = TickSpan()/TimeSpan.TicksPerSecond;
                    break;
                case DurationType.Minutes:
                    result = TickSpan()/TimeSpan.TicksPerMinute;
                    break;
            }

            return result;
        }
    }
}