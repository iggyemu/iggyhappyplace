﻿using System;

namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        /// <summary>
        /// Stops the timer.
        /// </summary>
        public void Stop()
        {
            StopTicks = Environment.TickCount;
        }
    }
}