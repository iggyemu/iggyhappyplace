﻿namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        #region DurationType enum

        /// <summary>
        /// The measurement to use for duration.
        /// </summary>
        public enum DurationType
        {
            /// <summary>
            /// Milliseconds
            /// </summary>
            Milliseconds,
            /// <summary>
            /// Seconds
            /// </summary>
            Seconds,
            /// <summary>
            /// Minutes
            /// </summary>
            Minutes
        }

        #endregion
    }
}