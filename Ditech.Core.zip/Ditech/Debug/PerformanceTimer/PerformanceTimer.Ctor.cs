namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PerformanceTimer"/> class.
        /// </summary>
        public PerformanceTimer()
        {
            Start();
        }
    }
}