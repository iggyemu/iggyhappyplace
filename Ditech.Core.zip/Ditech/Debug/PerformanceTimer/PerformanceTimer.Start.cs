﻿using System;
using System.Threading;

namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        /// <summary>
        /// Starts the timer.
        /// </summary>
        public void Start()
        {
            Thread.Sleep(0);
            StartTicks = Environment.TickCount;
        }
    }
}