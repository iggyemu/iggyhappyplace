﻿namespace Ditech.Debug
{
    /// <summary>
    /// This is a quick timer class to use for measuring app performance.
    /// </summary>
    public partial class PerformanceTimer
    {
        private double TickSpan()
        {
            if (StopTicks == 0)
            {
                Stop();
            }

            return StopTicks - StartTicks;
        }
    }
}