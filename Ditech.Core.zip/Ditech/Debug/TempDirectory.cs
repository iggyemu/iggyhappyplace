﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace Ditech.Debug
{
    /// <summary>
    /// Class for creating paths to temporary directories.
    /// </summary>
    public static class TempDirectory
    {
        private const string DefaultCompanyName = "Ditech";
        private static readonly string TimeStamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");

        /// <summary>
        /// Returns the path to the company level directory and creates the directory if it does not exist.
        /// </summary>
        /// <param name="companyName">Optional. Defaults to Ditech</param>
        /// <returns>Full path to company level directory</returns>
        public static string GetCompanyDirectory(string companyName = DefaultCompanyName)
        {
            // todo: to remove dependency on arbitrary network shares, consider storing base path in app.config and in absence of config use %appdata%
            const string basePath = @"\\JVFLNTFPS83\shared\Everyone\UserScripts\Servicing";
            var appDataCompanyDir = Path.Combine(basePath, companyName);
            Directory.CreateDirectory(appDataCompanyDir);
            return appDataCompanyDir;
        }

        /// <summary>
        /// Returns the path to the application level directory (and creates it if it does not exist) in the company directory.  
        /// By default, a sub-directory will be created within the application level directory using a timestamp-formatted name 
        /// to prevent collisions.  The timestamp is generated once per application.
        /// </summary>
        /// <param name="appName">Optional. Defaults to the entry assembly name</param>
        /// <param name="useTimestamp">Optional. Defaults to using a timestamp subdirectory</param>
        /// <param name="companyName">Optional. Defaults to Ditech</param>
        /// <returns>Full path to application level directory</returns>
        public static string GetApplicationDirectory(string appName = null, bool useTimestamp = true, string companyName = DefaultCompanyName)
        {
            var appDataApplicationDir = Path.Combine(GetCompanyDirectory(companyName), GetAppName(appName));

            if (useTimestamp)
            {
                appDataApplicationDir = Path.Combine(appDataApplicationDir, TimeStamp);
            }

            Directory.CreateDirectory(appDataApplicationDir);
            return appDataApplicationDir;
        }

        /// <summary>
        /// Returns the path to the log directory for the given application creates it if it does not exist.  The log
        /// directory resides under the company directory.
        /// </summary>
        /// <param name="appName">Optional. Defaults to the entry assembly name</param>
        /// <param name="companyName">Optional. Defaults to Ditech</param>
        /// <returns>Full path to log directory</returns>
        public static string GetApplicationLogDirectory(string appName = null, string companyName = DefaultCompanyName)
        {
            var logPath = Path.Combine(GetCompanyDirectory(companyName), "logs");
            return Path.Combine(logPath, GetAppName(appName));
        }

        internal static string GetAppName(string appName)
        {
            if (string.IsNullOrEmpty(appName))
            {
                var asm = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
                appName = asm.GetName().Name;
            }
            return appName;
        }
    }
}
