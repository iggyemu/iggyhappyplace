﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text;
using Ditech.DirectoryServices;
using Ditech.Net;

namespace Ditech.Debug
{
    /// <summary>
    /// Enables logging of debug output.  The logs can be found in %appdata%\Ditech\logs\{application_name}\*.ebtrace
    /// </summary>
    public static class LogDebugMessages
    {
        private const int MaxHistoryCount = 20;
        private const string Extension = ".ebtrace";
        private static bool _running = false;
        public static event EventHandler LogFileClosing;

        /// <summary>
        /// Begins automatic logging of debug messages.
        /// </summary>
        [Conditional("DEBUG")]
        public static void Initialize(string appName = null)
        {
            PrivateInit(TempDirectory.GetAppName(appName), DateTime.Now.ToString("yyyyMMddHHmmss") + Extension);
        }

        [Conditional("DEBUG")]
        private static void PrivateInit(string appName, string fileName)
        {
            if (_running) return;
            _running = true;

            var appDirectory = TempDirectory.GetApplicationLogDirectory(appName);
            appDirectory = Path.Combine(appDirectory, Machine.FullyQualifiedDomainName);
            var filePath = Path.Combine(appDirectory, fileName);

            Directory.CreateDirectory(appDirectory);
            CleanOldFiles(appDirectory);

            var trace = new TextWriterTraceListener(File.CreateText(filePath));
            System.Diagnostics.Debug.Listeners.Add(trace);

            AppDomain.CurrentDomain.ProcessExit += CurrentDomainOnProcessExit;
            var exePath = (Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly()).GetName().CodeBase;
            var user = User.WindowsUserName != User.CurrentWindowsUserName
                           ? string.Format("{0} ({1})", User.WindowsUserName, User.CurrentWindowsUserName)
                           : User.WindowsUserName;
            System.Diagnostics.Debug.WriteLine(string.Format("Start: {0} - {1}, {2}, \"{3}\"", DateTime.Now, user, Machine.FullyQualifiedDomainName, exePath));
            System.Diagnostics.Debug.WriteLine(new string('=', 60));
        }


        private static void CleanOldFiles(string directory)
        {
            var files = Directory.GetFiles(directory, "*" + Extension);
            var list = new List<string>(files);
            if (list.Count >= MaxHistoryCount)
            {
                list.Sort();
                File.Delete(list[0]); // delete the oldest file (assumes file name is yyyyMMddHHmmss format)
            }
        }

        private static void CurrentDomainOnProcessExit(object sender, EventArgs eventArgs)
        {
            if (LogFileClosing != null)
            {
                LogFileClosing(sender, eventArgs);
            }
            System.Diagnostics.Debug.Unindent();
            System.Diagnostics.Debug.WriteLine(new string('=', 60));
            System.Diagnostics.Debug.WriteLine(string.Format("End: {0}", DateTime.Now));
            System.Diagnostics.Debug.Flush();
            System.Diagnostics.Debug.Close();
        }
    }
}
