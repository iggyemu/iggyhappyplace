﻿using System;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        /// <summary>
        /// Gets or sets the base class.
        /// </summary>
        /// <value>The base class.</value>
        protected string BaseClass { get; set; }

        /// <summary>
        /// Gets or sets the base method.
        /// </summary>
        /// <value>The base method.</value>
        protected string BaseMethod { get; set; }

        /// <summary>
        /// Logs number of successful records.
        /// </summary>
        protected Type CallingType { get; private set; }

        /// <summary>
        /// The eventID stored in the logging database for the currently executing process.
        /// </summary>
        public string EventID { get; protected set; }

        /// <summary>
        /// The Exception object that caused the failure.
        /// </summary>
        protected Exception FailureException { get; set; }

        /// <summary>
        /// Logs number of failed records.
        /// </summary>
        public int FailureRecords { get; set; }

        /// <summary>
        /// An optional string that will be stored in the logging database.
        /// </summary>
        public string OtherInfo { get; set; }

        /// <summary>
        /// Name of the class being executed.
        /// </summary>
        protected string ProcessClass { get; set; }

        /// <summary>
        /// Name of the machine running the process.
        /// </summary>
        protected string ProcessMachine { get; private set; }

        /// <summary>
        /// Name of the method the process started from.
        /// </summary>
        protected string ProcessMethod { get; private set; }

        /// <summary>
        /// The name of the currently executing module.
        /// </summary>
        public string ProcessName { get; protected set; }

        /// <summary>
        ///Path of the executing assembly.
        /// </summary>
        protected string ProcessPath { get; private set; }

        /// <summary>
        /// The name of the user currently executing the process.
        /// </summary>
        public string ProcessUser { get; protected set; }

        /// <summary>
        /// The version of the currently executing process.
        /// </summary>
        public string ProcessVersion { get; protected set; }

        /// <summary>
        /// Logs number of successful records.
        /// </summary>
        public int SuccessRecords { get; set; }
    }
}