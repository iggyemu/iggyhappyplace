﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Mail;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Web.Hosting;
using MailMessage = Ditech.Net.Mail.MailMessage;

namespace Ditech
{
    public abstract partial class Log : IDisposable
    {
        public class LogConfig
        {
            public string TextEntryFormat { get; set; }
            public string TextOptionalExceptionFormat { get; set; }
            public string LogEmailSubjectFormat { get; set; }
            public LogSeverityEnum? MinimumLogSeverity { get; set; }
            public LogSeverityEnum? MinimumLogEmailSeverity { get; set;}
            public string LogEmailSenderAddress { get; set; }
            public IEnumerable<string> LogEmailRecipientAddresses { get; set; }

            public Func<LogEntry, bool> LogEntryOutputFunc { get; set; }  // accepts log entry, returns true to prevent default log
                                                                          // behavior (i.e. replacement) or false to use default 
                                                                          // log behavior (i.e. addition)

            public static LogConfig Default = new LogConfig()
            {
                TextEntryFormat =
                    "{LogEntryDateTime:yyyy-MM-dd hh:mm:ss.ffff}\t[{Severity}]\t{ProcessName}@{ProcessHost}\t{ShortMessage}",
                TextOptionalExceptionFormat = "\n*** EXCEPTION START ***\n{LoggedException}\n*** EXCEPTION END ***\n",
                LogEmailSubjectFormat =
                    "Logger {ProcessName}@{ProcessHost} [{LogEntryDateTime}] > {Severity} : {ShortMessage}",
                MinimumLogSeverity = LogSeverityEnum.NonFatalError,
                MinimumLogEmailSeverity = null,
                LogEmailSenderAddress = null,
                LogEmailRecipientAddresses = null,
                LogEntryOutputFunc = (logEntry) => { return false; }
            };

            public void PopulateMissingFromDefault()
            {
                // note that if the default of any of these is null, this will run over and over and keep setting it to
                // null, but that doesn't cause incorrect behavior just a bit of inefficiency
                if (TextEntryFormat == null)                TextEntryFormat = Default.TextEntryFormat;
                if (TextOptionalExceptionFormat == null)    TextOptionalExceptionFormat = Default.TextOptionalExceptionFormat;
                if (LogEmailSubjectFormat == null)          LogEmailSubjectFormat = Default.LogEmailSubjectFormat;
                if (MinimumLogSeverity == null)             MinimumLogSeverity = Default.MinimumLogSeverity;
                if (MinimumLogEmailSeverity == null)        MinimumLogEmailSeverity = Default.MinimumLogEmailSeverity;
                if (LogEmailSenderAddress == null)          LogEmailSenderAddress = Default.LogEmailSenderAddress;
                if (LogEmailRecipientAddresses == null)     LogEmailRecipientAddresses = Default.LogEmailRecipientAddresses;
                if (LogEntryOutputFunc == null)             LogEntryOutputFunc = Default.LogEntryOutputFunc;
            }
        }


        class LogEmailException : Exception
        {

            public LogEmailException() : base() { }

            public LogEmailException(string msg, Exception innerException) : base(msg, innerException) { }

        }

        public LogConfig Config { get; protected set; }

        /// <summary>
        /// the Ditech logging functionality is somewhat split between the old version and the new version but 
        /// the same class is handling both so rather than add a constructor with config arguments, we'll keep 
        /// the constructor the same (with no arguments) and allow arguments to be set with this method
        /// </summary>
        /// <param name="cfg"></param>
        public void SetConfig(LogConfig cfg)
        {
            Config = cfg;
        }

        public string FormatTextLogEntry(LogEntry logEntry)
        {
            Config.PopulateMissingFromDefault();
            Dictionary<string, object> logEntryDict = logEntry.ToPropertyDictionary();
            string optionalExceptionMsg = (Config.TextOptionalExceptionFormat == null 
                ? string.Empty 
                : logEntryDict.FormatNamed(Config.TextOptionalExceptionFormat));
            return 
                logEntryDict.FormatNamed(Config.TextEntryFormat) 
                + (optionalExceptionMsg ?? string.Empty);
        }

        /// <summary>
        /// Logs process failures.
        /// </summary>
        /// <param name="ex">The exception.</param>
        public virtual void MessageAtSeverity(LogSeverityEnum severity, string message, Exception ex = null, bool forceEmail = false)
        {
            Config.PopulateMissingFromDefault();
            // default logging to TRUE if no minimum set
            bool doLog = ((Config.MinimumLogSeverity == null) || ((int) severity >= (int) Config.MinimumLogSeverity));
            // default email sending to FALSE if no minimum set
            bool doEmail = (
                (Config.MinimumLogEmailSeverity != null)
                && ((int) severity >= (int) Config.MinimumLogEmailSeverity)
                && (ex == null || !(ex is LogEmailException))
                );

            LogEntry logEntry = null;
            if (doLog || doEmail)
            {
                string msgBody = null;
                string processHost = null;
                string processNameInfo = null;
                string processUser = null;

                processHost = Environment.MachineName;
                processNameInfo = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
                processUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                logEntry = new LogEntry()
                {
                    ProcessName = processNameInfo,
                    ShortMessage = message,
                    ProcessHost = processHost,
                    LogEntryDateTime = DateTime.Now,
                    ProcessUser = processUser,
                    LoggedException = ex,
                    Severity = severity
                };
            }

            if (doLog)
            {
                // try the set logger and if none, or it returns false, then do default logging
                if (
                    (Config.LogEntryOutputFunc == null)
                    || (!Config.LogEntryOutputFunc(logEntry)))
                    LogConfig.Default.LogEntryOutputFunc(logEntry);
            }

            if (doEmail)
            {
                Dictionary<string, object> logEntryDict = logEntry.ToPropertyDictionary();
                string subject = logEntryDict.FormatNamed(Config.LogEmailSubjectFormat);
                string body = FormatTextLogEntry(logEntry);
                SendLogEmail(null, null, subject, body);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="processNameInfo">null to determine automatically</param>
        /// <param name="processUser">null to determine automatically</param>
        protected void SendLogEmail(string fromAddr, IEnumerable<string> toAddr, string subject, string body)
        {
            // never allow the log to kill the app...
            try
            {
                if (fromAddr == null)
                    fromAddr = Config.LogEmailSenderAddress;
                if (toAddr == null)
                    toAddr = Config.LogEmailRecipientAddresses;
                var mmsg = new MailMessage(fromAddr, toAddr.FirstOrDefault(), subject, body);
                foreach (string extraToAddr in toAddr.Skip(1))
                    mmsg.To.Add(extraToAddr);
                mmsg.Send();
            }
            catch (Exception ex)
            {
                // logic in the below method prevents trying to re-email LogEmailExceptions, so that this doesn't infinite loop...
                MessageAtSeverity(LogSeverityEnum.NonFatalError, "Error sending log email", new LogEmailException("Error sending log email", ex));
            }
        }

    }
}
