﻿using System;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        /// <summary>
        /// Logs when a process ends.
        /// </summary>
        protected abstract void End();
    }
}