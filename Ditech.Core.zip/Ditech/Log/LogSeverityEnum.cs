﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech
{
    public partial class Log
    {
        public enum LogSeverityEnum
        {
            VerboseDebug = 0,
            Debug = 1,
            Info = 2,
            Warn = 3,
            NonFatalError = 4,
            FatalError = 5
        }
    }
}
