﻿using System;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        /// <summary>
        /// Logs the start of the process.  This must be called from the derived class.
        /// </summary>
        /// <returns>eventID of the process (used for updating the record to reflect success/failure)</returns>
        protected abstract string Start();
    }
}