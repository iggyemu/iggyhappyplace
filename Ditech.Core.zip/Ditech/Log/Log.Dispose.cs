﻿using System;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        #region IDisposable Members

        /// <summary>
        /// Disposes the inner command object when the object is disposed of.
        /// </summary>
        public void Dispose()
        {
            End();
        }

        #endregion
    }
}