using System;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        /// <summary>
        /// Create a logging object using the version information from the calling assembly.
        /// </summary>
        protected Log() : this(string.Empty) {}

        /// <summary>
        /// Create a logging object using the version information from the calling assembly.
        /// </summary>
        protected Log(string baseClass)
        {
            // Finds out from the stack who called the last function
            GetCallerInfo(baseClass);

            // Get all the information about the calling assembly and process information
            ProcessName = CallingType.Assembly.GetName().Name;
            ProcessPath = CallingType.Assembly.GetName().CodeBase;
            ProcessClass = BaseClass;
            ProcessMethod = BaseMethod;
            ProcessVersion = CallingType.Assembly.GetName().Version.ToString();
            ProcessUser = Environment.UserName.ToUpper();
            ProcessMachine = Environment.MachineName.ToUpper();
            OtherInfo = System.String.Empty;
            SuccessRecords = 0;
            FailureRecords = 0;
        }
    }
}