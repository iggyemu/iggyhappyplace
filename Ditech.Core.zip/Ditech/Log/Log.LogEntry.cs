﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Ditech
{
    public class LogEntry
    {
        public DateTime LogEntryDateTime { get; set; }
        public Log.LogSeverityEnum Severity { get; set; }
        public string ShortMessage { get; set; }
        public Exception LoggedException { get; set; }
        public string ProcessHost { get; set; }
        public string ProcessName { get; set; }
        public string ProcessUser { get; set; }

    }
}
