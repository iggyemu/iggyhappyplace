﻿using System;
using System.Diagnostics;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        // Function to display parent function
        /// <summary>
        /// Find what called the last function on the stack
        /// </summary>
        protected void GetCallerInfo()
        {
            GetCallerInfo(string.Empty);
        }

        // Function to display parent function
        /// <summary>
        /// Find what called the last function on the stack
        /// </summary>
        protected void GetCallerInfo(string baseClass)
        {
            // Create a new stack trace
            var stackTrace = new StackTrace();

            StackFrame stackFrame = null;

            for (var i = 2; i < stackTrace.FrameCount; i++)
            {
                stackFrame = stackTrace.GetFrame(i);

                if (stackFrame.GetMethod().ReflectedType != GetType())
                {
                    break;
                }
            }

            // Get the name of the method that did the calling
            var methodBase = stackFrame.GetMethod();

            CallingType = methodBase.ReflectedType;

            BaseClass = !string.IsNullOrEmpty(baseClass) ? baseClass : CallingType.FullName;

            BaseMethod = methodBase.Name;
        }
    }
}