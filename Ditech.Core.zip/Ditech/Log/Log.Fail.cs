﻿using System;

namespace Ditech
{
    ///<summary>
    /// Abstract logging class that provides a typical set of fields for logging tasks and processes.
    ///</summary>
    public abstract partial class Log : IDisposable
    {
        /// <summary>
        /// Logs process failures.
        /// </summary>
        /// <param name="ex">The exception.</param>
        public abstract void Fail(Exception ex);
    }
}