﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using EverBank.Servicing.Data.Common;
using EverBank.Servicing.Net.FTP;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Servicing.Test
{


    /// <summary>
    ///This is a test class for FtpClientTest and is intended
    ///to contain all FtpClientTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DbConnectionTest
    {

        [TestMethod()]
        public void DbConnectionDataAsOfDateTest()
        {
            using (var connection = Connection.Create(ConnectionType.Development, DataType.Msp))
            {
                connection.Open();

                DateTime testDate = Connection.DataAsOfDate(ConnectionType.Development, SqlDbName.Msp);

                using (var command = new SqlCommand("sp_GetMaxPifDate", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    DateTime origDate = (DateTime)command.ExecuteScalar();

                    Assert.AreEqual(origDate, testDate);
                }
            }
        }
    }
}
