﻿using System.Collections.Generic;
using System.IO;
using EverBank.Servicing.Net.FTP;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Servicing.Test
{
    
    
    /// <summary>
    ///This is a test class for FtpClientTest and is intended
    ///to contain all FtpClientTest Unit Tests
    ///</summary>
    [TestClass()]
    public class FtpClientTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        [TestMethod()]
        public void FTPDavoxFullTest()
        {
            FtpClient client = new FtpClient(FtpCredentials.DavoxDefault);

            string[] files = client.ListFiles();

            Assert.IsNotNull(files);

            foreach(string fileName in files)
            {
                client.Get(fileName, fileName);

                Assert.IsTrue(File.Exists(fileName));

                File.Delete(fileName);
            }
        }

        [TestMethod()]
        public void FTPEquifaxFullTest()
        {
            string fileName = "test.txt";

            string filePath = @"C:\" + fileName;

            using (StreamWriter output = new StreamWriter(filePath))
            {
                output.Write("test");
            }
 
            FtpClient client = new FtpClient(FtpCredentials.EquifaxIncoming);

            client.Put(filePath);

            List<string> files = new List<string>(client.ListFiles());

            Assert.IsTrue(files.Contains(fileName));

            client.Get(fileName, fileName);

            Assert.IsTrue(File.Exists(fileName));

            client.Delete(fileName);

            File.Delete(fileName);
        }

    }
}
