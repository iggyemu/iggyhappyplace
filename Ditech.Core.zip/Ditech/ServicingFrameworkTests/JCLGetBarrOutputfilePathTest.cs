﻿using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EverBank.Servicing.Transactions;

namespace EverBank.Servicing.Test
{
    [TestClass]
    public class JCLGetBarrOutputfilePathTest
    {
        bool forceOldBarr;
        const string fileName = "FileName";

        private string GetBarrOutputFilePath(JCL.JCLType jclType, bool oldBarr = false)
        {
            return JCL.GetBarrOutputFilePath(jclType, oldBarr);
        }

        [TestMethod()]
        public void JCLTypeDaily()
        {
            forceOldBarr = true;
            var basePath = forceOldBarr ? @"\\jvflbarrb" : @"\\swjax1p020";
            var filePath = forceOldBarr ? @"fid\in\Fid1\" : @"FTP\fid\in\Fid1\";
            var retVal = GetBarrOutputFilePath(JCL.JCLType.Daily, forceOldBarr) + fileName;

            Assert.AreEqual(Path.Combine(basePath, filePath) + fileName, retVal, false);
        }

        [TestMethod()]
        public void JCLTypeCollections()
        {
            forceOldBarr = false;
            var basePath = forceOldBarr ? @"\\jvflbarrb" : @"\\swjax1p020";
            var filePath = forceOldBarr ? @"fid\in\Fid2\" : @"fid\in\fidcol\";
            var retVal = GetBarrOutputFilePath(JCL.JCLType.Collections, forceOldBarr) + fileName;

            Assert.AreEqual(Path.Combine(basePath, filePath) + fileName, retVal, false);
        }

        [TestMethod()]
        public void JCLTypeT01C()
        {
            forceOldBarr = true;
            var basePath = forceOldBarr ? @"\\jvflbarrb" : @"\\swjax1p020";
            var filePath = forceOldBarr ? @"fid\in\01CTEST\" : @"fid\in\01C\";
            var retVal = GetBarrOutputFilePath(JCL.JCLType.T01C, forceOldBarr) + fileName;

            Assert.AreEqual(Path.Combine(basePath, filePath) + fileName, retVal, false);
        }

        [TestMethod()]
        public void JCLTypeT01D()
        {
            forceOldBarr = false;
            var basePath = forceOldBarr ? @"\\jvflbarrb" : @"\\swjax1p020";
            var filePath = forceOldBarr ? @"\fid\in\01DTEST\" : @"fid\in\01D\";
            var retVal = GetBarrOutputFilePath(JCL.JCLType.T01D, forceOldBarr) + fileName;

            Assert.AreEqual(Path.Combine(basePath, filePath) + fileName, retVal, false);
        }

        [TestMethod()]
        public void JCLTypeDefault()
        {
            forceOldBarr = true;
            var basePath = forceOldBarr ? @"\\jvflbarrb" : @"\\swjax1p020";
            var filePath = forceOldBarr ? @"NJEXMIT\" : @"TRANSMIT\fid\NJEXMIT\";
            var retVal = GetBarrOutputFilePath(JCL.JCLType.None, forceOldBarr) + fileName;

            Assert.AreEqual(Path.Combine(basePath, filePath) + fileName, retVal, false);
        }
    }
}
