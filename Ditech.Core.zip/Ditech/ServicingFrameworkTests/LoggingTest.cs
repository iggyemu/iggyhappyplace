﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EverBank.Servicing.Data.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Servicing.Test
{
    [TestClass()]
    public class LoggingTest
    {
        [TestMethod]
        public void LoggingMainTest()
        {
            using (var executionLog = new Log(ConnectionType.Development))
            {

                executionLog.SuccessRecords++;

                Assert.AreEqual(1, executionLog.SuccessRecords);

                executionLog.FailureRecords++;

                Assert.AreEqual(1, executionLog.FailureRecords);

                executionLog.OtherInfo = "test";

                Assert.AreEqual("test", executionLog.OtherInfo);

            }
        }
    }
}
