﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EverBank.Servicing.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Servicing.Test
{
    [TestClass()]
    public class JCLTest
    {
        [TestMethod]
        public void JCLGetBarrInputFilePathTest()
        {
            Assert.AreEqual(@"\\swjax1p020\fid\in\ncp\", JCL.GetBarrInputFilePath(true));
            Assert.AreEqual(@"\\jvflbarrb\ftp\in\ncp\", JCL.GetBarrInputFilePath(true, true));
        }

        [TestMethod]
        public void JCLGetBarrOutputFilePathTest()
        {
            Assert.AreEqual(@"\\swjax1p020\FTP\fid\in\Fid1\", JCL.GetBarrOutputFilePath(JCL.JCLType.Daily));
            Assert.AreEqual(@"\\swjax1p020\fid\in\fidcol\", JCL.GetBarrOutputFilePath(JCL.JCLType.Collections));
            Assert.AreEqual(@"\\swjax1p020\TRANSMIT\fid\NJEXMIT\", JCL.GetBarrOutputFilePath(JCL.JCLType.None));

            Assert.AreEqual(@"\\jvflbarrb\ftp\in\Fid1\", JCL.GetBarrOutputFilePath(JCL.JCLType.Daily, true));
            Assert.AreEqual(@"\\jvflbarrb\ftp\in\Fid2\", JCL.GetBarrOutputFilePath(JCL.JCLType.Collections, true));
            Assert.AreEqual(@"\\jvflbarrb\NJEXMIT\", JCL.GetBarrOutputFilePath(JCL.JCLType.None, true));
        }

        [TestMethod]
        public void JCLNoJCLSubmitTest()
        {
            //TODO: Fix local file reference

           // JCL.JclSubmit(@"C:\heartbeat file wrapped.txt", JCL.JCLType.None, false);
        }

        [TestMethod]
        public void JCLWrapJCLSubmitTest()
        {
            //JCL.JclSubmit(@"C:\heartbeat file.txt", JCL.JCLType.Daily, false);
        }
    }
}
