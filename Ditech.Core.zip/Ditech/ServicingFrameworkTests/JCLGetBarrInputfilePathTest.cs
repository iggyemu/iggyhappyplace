﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EverBank.Servicing.Transactions;

namespace EverBank.Servicing.Test
{
    [TestClass]
    public class JCLGetBarrInputfilePathTest
    {
        private string GetBarrInputFilePath(bool isNCP = false, bool forceOldBarr = false)
        {
            return JCL.GetBarrInputFilePath(isNCP, forceOldBarr);
        }

        /// <summary>
        /// isNCP = true, forceOldBarr = true
        /// </summary>
        [TestMethod]
        public void GetBarrInputFilePathTT()
        {
            var expected = Path.Combine(@"\\jvflbarrb", @"ftp\in\ncp\");
            var actual = GetBarrInputFilePath(true, true);
            Assert.AreEqual(expected,actual);
        }

        /// <summary>
        /// isNCP = true, forceOldBarr = false
        /// </summary>
        [TestMethod]
        public void GetBarrInputFilePathTF()
        {
            var expected = Path.Combine(@"\\swjax1p020", @"fid\in\ncp\");
            var actual = GetBarrInputFilePath(true);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// isNCP = false, forceOldBarr = true
        /// </summary>
        [TestMethod]
        public void GetBarrInputFilePathFT()
        {
            var expected = Path.Combine(@"\\jvflbarrb", @"ftp\out\");
            var actual = GetBarrInputFilePath(false, true);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// isNCP = false, forceOldBarr = false
        /// </summary>
        [TestMethod]
        public void GetBarrInputFilePathFF()
        {
            var expected = Path.Combine(@"\\swjax1p020", @"FTP\fid\out\");
            var actual = GetBarrInputFilePath();
            Assert.AreEqual(expected, actual);
        }
    }
}
