

using System;
using System.Collections.Generic;

namespace EverBank
{
    public static partial class Date
    {
        /// <summary>
        /// Available pre-defined DateTime formats.
        /// </summary>
        public enum DateTimeFormat
        {
            /// <summary>
            /// 10/12/2002
            /// </summary>
            ShortDate,
            /// <summary>
            /// December 10, 2002
            /// </summary>
            LongDate,
            /// <summary>
            /// 10:11 PM
            /// </summary>
            ShortTime,
            /// <summary>
            /// 10:11:29 PM
            /// </summary>
            LongTime,
            /// <summary>
            /// December 10, 2002 10:11 PM
            /// </summary>
            FullDateTime,
            /// <summary>
            /// December 10, 2002 10:11:29 PM
            /// </summary>
            FullDateTimeLong,
            /// <summary>
            /// 10/12/2002 10:11 PM
            /// </summary>
            DefaultDateTime,
            /// <summary>
            /// 10/12/2002 10:11:29 PM
            /// </summary>
            DefaultDateTimeLong,
            /// <summary>
            /// December 10
            /// </summary>
            MonthDayPattern,
            /// <summary>
            /// Tue, 10 Dec 2002 22:11:29 GMT
            /// </summary>
            RFC1123,
            /// <summary>
            /// 2002-12-10T22:11:29
            /// </summary>
            SortableDate,
            /// <summary>
            /// 2002-12-10 22:13:50Z
            /// </summary>
            UniversalSortableLocal,
            /// <summary>
            /// December 11, 2002 3:13:50 AM
            /// </summary>
            UniversalSortableGMT,
            /// <summary>
            /// December, 2002
            /// </summary>
            YearMonth
        }

        internal static string DateTimeFormatString(DateTimeFormat dateFormat)
        {
            string result;

            switch (dateFormat)
            {
                case DateTimeFormat.ShortDate:
                    result = "d";
                    break;
                case DateTimeFormat.LongDate:
                    result = "D";
                    break;
                case DateTimeFormat.ShortTime:
                    result = "t";
                    break;
                case DateTimeFormat.LongTime:
                    result = "T";
                    break;
                case DateTimeFormat.FullDateTime:
                    result = "f";
                    break;
                case DateTimeFormat.FullDateTimeLong:
                    result = "F";
                    break;
                case DateTimeFormat.DefaultDateTime:
                    result = "g";
                    break;
                case DateTimeFormat.DefaultDateTimeLong:
                    result = "G";
                    break;
                case DateTimeFormat.MonthDayPattern:
                    result = "M";
                    break;
                case DateTimeFormat.RFC1123:
                    result = "r";
                    break;
                case DateTimeFormat.SortableDate:
                    result = "s";
                    break;
                case DateTimeFormat.UniversalSortableLocal:
                    result = "u";
                    break;
                case DateTimeFormat.UniversalSortableGMT:
                    result = "U";
                    break;
                case DateTimeFormat.YearMonth:
                    result = "Y";
                    break;
                default:
                    throw new NotImplementedException("This enum has no handler.");
            }

            return result;
        }
    }
}
