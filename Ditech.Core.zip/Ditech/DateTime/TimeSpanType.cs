

namespace EverBank
{
    public static partial class Date
    {

		#region Enums (1) 

        public enum TimeSpanType
        {
            Days,
            Hours,
            Minutes,
            Seconds,
            Milliseconds
        }

		#endregion Enums 

    }
}
