

using System;
using System.Globalization;

namespace EverBank
{
    
    public static partial class Date
    {


        #region Methods(9)

        /// <summary>
        /// Returns the first date of the month and year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfMonth(int monthValue, int yearValue)
        {
            return new DateTime(yearValue, monthValue, 1, 0, 0, 0, 0);
        }

        /// <summary>
        /// Returns the last date of the month and year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfMonth(int monthValue, int yearValue)
        {
            return new DateTime(yearValue, monthValue, DateTime.DaysInMonth(yearValue, monthValue), 23, 59, 59, 999);
        }

        /// <summary>
        /// Returns the first date of last month's month and year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfLastMonth()
        {
            if (DateTime.Now.Month == 1)
            {
                return GetStartOfMonth(12, DateTime.Now.Year - 1);
            }
            return GetStartOfMonth(DateTime.Now.Month - 1, DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the last date of last month's month and year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfLastMonth()
        {
            if (DateTime.Now.Month == 1)
            {
                return GetEndOfMonth(12, DateTime.Now.Year - 1);
            }
            return GetEndOfMonth(DateTime.Now.Month - 1, DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the first date of current month and year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfCurrentMonth()
        {
            return GetStartOfMonth(DateTime.Now.Month, DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the last date of current month and year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfCurrentMonth()
        {
            return GetEndOfMonth(DateTime.Now.Month, DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the first date of next month's month and year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfNextMonth()
        {
            if (DateTime.Now.Month == 12)
            {
                return GetStartOfMonth(1, DateTime.Now.Year + 1);
            }
            return GetStartOfMonth(DateTime.Now.Month + 1, DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the last date of next month's month and year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfNextMonth()
        {
            if (DateTime.Now.Month == 12)
            {
                return GetEndOfMonth(1, DateTime.Now.Year + 1);
            }
            return GetEndOfMonth(DateTime.Now.Month + 1, DateTime.Now.Year);
        }


        /// <summary>
        /// Returns the name of the specified month using the Current Culture
        /// </summary>
        public static string GetMonthName(int value)
        {
            return DateTimeFormatInfo.CurrentInfo.GetMonthName(value);
        }

        #endregion
    }

}
