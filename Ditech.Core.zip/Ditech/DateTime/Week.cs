

using System;
using System.Globalization;

namespace EverBank
{
    public partial class Date
    {
        /// <summary>
        /// Returns the first date of the week at 00:00:00:000 using the defualt start of week
        /// </summary>
        public static DateTime GetStartOfWeek(DateTime value)
        {
            var daysToSubtract = (int)value.DayOfWeek;
            var tempDate = value.Subtract(TimeSpan.FromDays(daysToSubtract));
            return new DateTime(tempDate.Year, tempDate.Month, tempDate.Day, 0, 0, 0, 0);
        }

        /// <summary>
        /// Returns the last date of the week at 23:59:59:999 using the defualt start of week
        /// </summary>
        public static DateTime GetEndOfWeek(DateTime value)
        {
            var tempDate = GetStartOfWeek(value).AddDays(6);
            var result = new DateTime(tempDate.Year, tempDate.Month, tempDate.Day, 23, 59, 59, 999);
            return result;
        }

        /// <summary>
        /// Returns the first date of last week at 00:00:00:000 using the defualt start of week
        /// </summary>
        public static DateTime GetStartOfLastWeek()
        {
            var daysToSubtract = (int)DateTime.Now.DayOfWeek + 7;
            var tempDate = DateTime.Now.Subtract(TimeSpan.FromDays(daysToSubtract));
            return new DateTime(tempDate.Year, tempDate.Month, tempDate.Day, 0, 0, 0, 0);
        }

        /// <summary>
        /// Returns the last date of last week at 23:59:59:999 using the defualt start of week
        /// </summary>
        public static DateTime GetEndOfLastWeek()
        {
            var tempDate = GetStartOfLastWeek().AddDays(6);
            return new DateTime(tempDate.Year, tempDate.Month, tempDate.Day, 23, 59, 59, 999);
        }

        /// <summary>
        /// Returns the first date of the current week at 00:00:00:000 using the defualt start of week
        /// </summary>
        public static DateTime GetStartOfCurrentWeek()
        {
            return GetStartOfWeek(DateTime.Now);
        }

        /// <summary>
        /// Returns the last date of the current week at 23:59:59:999 using the defualt start of week
        /// </summary>
        public static DateTime GetEndOfCurrentWeek()
        {
            return GetEndOfWeek(DateTime.Now);
        }

        /// <summary>
        /// Returns the first date of next week at 00:00:00:000 using the defualt start of week
        /// </summary>
        public static DateTime GetStartOfNextWeek()
        {
            var tempDate = GetEndOfCurrentWeek().AddDays(1);
            return new DateTime(tempDate.Year, tempDate.Month, tempDate.Day, 0, 0, 0, 0);
        }

        /// <summary>
        /// Returns the last date of next week at 23:59:59:999 using the defualt start of week
        /// </summary>
        public static DateTime GetEndOfNextWeek()
        {
            DateTime tempDate = GetStartOfNextWeek().AddDays(6);
            return new DateTime(tempDate.Year, tempDate.Month, tempDate.Day, 23, 59, 59, 999);
        }

        /// <summary>
        /// Returns the week of the year where the first week is at least fours long.
        /// <para>The week starts on Sunday</para>
        /// </summary>
        public static int GetWeekOfCurrentYear()
        {
            return GetWeekOfCurrentYear(CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Sunday);
        }

        /// <summary>
        /// Returns the current week of the year where the first week is at least fours days long
        /// </summary>
        public static int GetWeekOfCurrentYear(DayOfWeek value)
        {
            return GetWeekOfCurrentYear(CalendarWeekRule.FirstFourDayWeek, value);
        }

        /// <summary>
        /// Returns the current week of the year where the week starts on Sunday
        /// </summary>
        public static int GetWeekOfCurrentYear(CalendarWeekRule value)
        {
            return GetWeekOfCurrentYear(value, DayOfWeek.Sunday);
        }

        /// <summary>
        /// Returns the current week of the year
        /// </summary>
        public static int GetWeekOfCurrentYear(CalendarWeekRule calendarWeekRule, DayOfWeek value)
        {
            return GetWeekOfYear(DateTime.Now, CalendarWeekRule.FirstFourDayWeek, value);
        }

        /// <summary>
        /// Returns the week of the year where the first week is at least fours long.
        /// <para>The week starts on Sunday</para>
        /// </summary>
        public static int GetWeekOfYear(DateTime value)
        {
            return GetWeekOfYear(value, DayOfWeek.Sunday);
        }

        /// <summary>
        /// Returns the week of the year where the first week is at least fours days long
        /// </summary>
        public static int GetWeekOfYear(DateTime value, DayOfWeek firstDayOfWeek)
        {
            return GetWeekOfYear(value, CalendarWeekRule.FirstFourDayWeek, firstDayOfWeek);
        }

        /// <summary>
        /// Returns the week of the year where the week starts on Sunday
        /// </summary>
        public static int GetWeekOfYear(DateTime value, CalendarWeekRule calendarWeekRule)
        {
            return GetWeekOfYear(value, calendarWeekRule, DayOfWeek.Sunday);
        }

        /// <summary>
        /// Returns the week of the year
        /// </summary>
        public static int GetWeekOfYear(DateTime value, CalendarWeekRule calendarWeekRule, DayOfWeek firstDayOfWeek)
        {
            Calendar calendar = CultureInfo.CurrentCulture.Calendar;
            return calendar.GetWeekOfYear(value, calendarWeekRule, firstDayOfWeek);
        }

        /// <summary>
        /// Returns whether the specified date is a Saturday or Sunday
        /// </summary>
        public static bool IsWeekend(DateTime value)
        {
            return (value.DayOfWeek == DayOfWeek.Saturday || value.DayOfWeek == DayOfWeek.Sunday);
        }

    }
}
