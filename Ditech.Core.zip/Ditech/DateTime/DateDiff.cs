

using System;
using System.Globalization;

namespace EverBank
{
    public static partial class Date
    {

		#region Methods (1) 


		// Public Methods (1) 

        /// <summary>
        /// Calculates the difference between two dates.
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="timeSpanType">Type of the date.</param>
        /// <returns>
        /// Int representing the difference between the dates.
        /// </returns>
        /// <exception cref="ArgumentException"><c>ArgumentException</c> is returned if a TimeSpanType is passsed that wasn't accounted for.</exception>
        public static int DateDiff(DateTime startDate, DateTime endDate, TimeSpanType timeSpanType)
        {
            TimeSpan timeSpan = endDate - startDate;
            int result;

            switch (timeSpanType)
            {
                case TimeSpanType.Days:
                    result = timeSpan.Days;
                    break;
                case TimeSpanType.Hours:
                    result = timeSpan.Hours;
                    break;
                case TimeSpanType.Minutes:
                    result = timeSpan.Minutes;
                    break;
                case TimeSpanType.Seconds:
                    result = timeSpan.Seconds;
                    break;
                case TimeSpanType.Milliseconds:
                    result = timeSpan.Milliseconds;
                    break;
                default:
                    throw new ArgumentException("Invalid TimeSpanType Passed.");
            }

            return result;
        }


		#endregion Methods 

    }
}
