

using System;
using System.Collections.Generic;

namespace EverBank
{
    public static partial class Date
    {


        #region Methods(6)

        /// <summary>
        /// Returns a list of all the dates between two dates
        /// <para>The start date must be before the end date</para>
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <returns></returns>
        public static List<DateTime> GetDatesBetweenDates(DateTime startDate, DateTime endDate)
        {
            return GetDatesBetweenDates(startDate, endDate, null);
        }

        /// <summary>
        /// Returns a list of all the Sundays remaining in the current year
        /// <para>The start date must be before the end date</para>
        /// </summary>
        /// <returns></returns>
        public static List<DateTime> GetSundaysThroughCurrentYear()
        {
            return GetDatesBetweenDates(DateTime.Today, GetStartOfCurrentYear(), DayOfWeek.Sunday);
        }

        /// <summary>
        /// Returns a list of Sundays between two dates
        /// <para>The start date must be before the end date</para>
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <returns></returns>
        public static List<DateTime> GetSundaysBetweenDates(DateTime startDate, DateTime endDate)
        {
            return GetDatesBetweenDates(startDate, endDate, DayOfWeek.Sunday);
        }

        /// <summary>
        /// Returns a list of Saturdays remaining in the current year
        /// </summary>
        /// <returns></returns>
        public static List<DateTime> GetSaturdaysThroughCurrentYear()
        {
            return GetDatesBetweenDates(DateTime.Today, GetStartOfCurrentYear(), DayOfWeek.Saturday);
        }

        /// <summary>
        /// Returns a list of Saturdays between two dates
        /// <para>The start date must be before the end date</para>
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <returns></returns>
        public static List<DateTime> GetSaturdaysBetweenDates(DateTime startDate, DateTime endDate)
        {
            return GetDatesBetweenDates(startDate, endDate, DayOfWeek.Saturday);

        }

        /// <summary>
        /// Gets the dates between dates.
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="dayOfWeek">The day of week.</param>
        /// <returns></returns>
        public static List<DateTime> GetDatesBetweenDates(DateTime startDate, DateTime endDate, DayOfWeek dayOfWeek)
        {
            return GetDatesBetweenDates(startDate, endDate, new List<DayOfWeek> {dayOfWeek});
        }

        /// <summary>
        /// Returns A list of DateTime objects between two dates and on the specified days of the week
        /// <para>The start date must be before the end date</para>
        /// </summary>
        public static List<DateTime> GetDatesBetweenDates(DateTime startDate, DateTime endDate, List<DayOfWeek> daysOfWeek)
        {
            var result = new List<DateTime>();

            for (DateTime currentDate = startDate; currentDate <= endDate; currentDate = currentDate.AddDays(1))
            {
                if (daysOfWeek == null || daysOfWeek.Contains(currentDate.DayOfWeek))
                {
                    result.Add(currentDate);
                }
            }

            return result;
        }

        #endregion
    }
}
