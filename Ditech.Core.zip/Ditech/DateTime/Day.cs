

using System;
using System.Globalization;

namespace EverBank
{
    public static partial class Date
    {

		#region Methods (5) 


		// Public Methods (5) 

        /// <summary>
        /// Returns the name of the specified DayOfWeek using the current culture
        /// </summary>
        public static string GetDayName(DayOfWeek value)
        {
            return DateTimeFormatInfo.CurrentInfo.GetDayName(value);
        }

        /// <summary>
        /// Returns the whole number of days between two dates
        /// <para>The oldDate is subtracted from the new date and the difference returned</para>
        /// </summary>
        public static int GetDaysBetweenDates(DateTime oldValue, DateTime newValue)
        {
            var ts = (newValue - oldValue);
            return ts.Days;
        }

        /// <summary>
        /// Returns the date with a time of 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfDay(DateTime value)
        {
            return new DateTime(value.Year, value.Month, value.Day, 23, 59, 59, 999);
        }

        /// <summary>
        /// Returns the date with a time of 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfDay(DateTime value)
        {
            return new DateTime(value.Year, value.Month, value.Day, 0, 0, 0, 0);
        }

        /// <summary>
        /// Returns the whole and fractional number of days between two dates
        /// <para>The oldDate is subtracted from the new date and the difference returned</para>
        /// </summary>
        public static double GetTotalDaysBetweenDates(DateTime oldValue, DateTime newValue)
        {
            var ts = (newValue - oldValue);
            return ts.TotalDays;
        }


		#endregion Methods 

    }
}
