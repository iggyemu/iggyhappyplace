

using System;

namespace EverBank
{
    public static partial class Date
    {

		#region Methods (8) 


		// Public Methods (8) 

        /// <summary>
        /// Returns the last date of the current year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfCurrentYear()
        {
            return GetEndOfYear(DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the last date of last year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfLastYear()
        {
            return GetEndOfYear(DateTime.Now.Year - 1);
        }

        /// <summary>
        /// Returns the last date of next year at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfNextYear()
        {
            return GetEndOfYear(DateTime.Now.Year + 1);
        }

        /// <summary>
        /// Returns the last date of the year provided at 23:59:59:999
        /// </summary>
        public static DateTime GetEndOfYear(int value)
        {
            return new DateTime(value, 12, DateTime.DaysInMonth(value, 12), 23, 59, 59, 999);
        }

        /// <summary>
        /// Returns the first date of the current year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfCurrentYear()
        {
            return GetStartOfYear(DateTime.Now.Year);
        }

        /// <summary>
        /// Returns the start date of last year with a time of 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfLastYear()
        {
            return GetStartOfYear(DateTime.Now.Year - 1);
        }

        /// <summary>
        /// Returns the first date of next year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfNextYear()
        {
            return GetStartOfYear(DateTime.Now.Year + 1);
        }

        /// <summary>
        /// Returns the first date of the specified year at 00:00:00:000
        /// </summary>
        public static DateTime GetStartOfYear(int value)
        {
            return new DateTime(value, 1, 1, 0, 0, 0, 0);
        }


		#endregion Methods 

    }
}
