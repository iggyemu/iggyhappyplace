

using System;

namespace EverBank
{
    public static partial class Date
    {

		#region Methods (7) 


		// Public Methods (7) 

        /// <summary>
        /// Indicates whether the specified date is the same year and month as the current date
        /// </summary>
        public static bool IsCurrentMonthAndYear(DateTime value)
        {
            return IsMonthAndYearEqual(DateTime.Now, value);
        }

        /// <summary>
        /// Indicates whether the specified year and month is the same as the current month and year
        /// </summary>
        public static bool IsCurrentMonthAndYear(int year, int month)
        {
            return IsCurrentMonthAndYear(new DateTime(year, month, 1));
        }

        /// <summary>
        /// Indicates whether the specified dates have the same month and year
        /// </summary>
        public static bool IsMonthAndYearEqual(DateTime dateOne, DateTime dateTwo)
        {
            if (dateOne.Year == dateTwo.Year)
            {
                if (dateOne.Month == dateTwo.Month)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Indicates whether the specified date is the same as the month and year after the current month
        /// </summary>
        public static bool IsNextMonthAndYear(DateTime value)
        {
            return IsMonthAndYearEqual(DateTime.Now, value);
        }

        /// <summary>
        /// Inficates whether the specified month and year is the same as the month and year after the current month
        /// </summary>
        public static bool IsNextMonthAndYear(int year, int month)
        {
            return IsNextMonthAndYear(new DateTime(year, month, 1));
        }

        /// <summary>
        /// Indicates whether the specified date is the same as the month and year before the current month
        /// </summary>
        public static bool IsPreviousMonthAndYear(DateTime value)
        {
            return IsMonthAndYearEqual(DateTime.Now, value);
        }

        /// <summary>
        /// Indicates whether the specified month and year is the same as the month and year before the current month
        /// </summary>
        public static bool IsPreviousMonthAndYear(int year, int month)
        {
            return IsPreviousMonthAndYear(new DateTime(year, month, 1));
        }


		#endregion Methods 

    }
}
