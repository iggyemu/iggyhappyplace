

using EverBank.String;

namespace EverBank.Parsing.Numbers
{
    /// <summary>
    /// This static class provides utility classes related to numbers.
    /// </summary>
    public static partial class Numbers
    {

		#region Methods (6) 


		// Public Methods (2) 

        /// <summary>
        /// Used when the exact position of a money value could shift within a string or line.
        /// Provide a string and the position within the string that you know will be part of the money value.
        /// This method will parse out in each direction from the starting point to get the full money value.
        /// </summary>
        /// <param name="dataToRead">The data to read.</param>
        /// <param name="entryPoint">The entry point.</param>
        /// <returns></returns>
        public static decimal ParseMoneyValue(string dataToRead, int entryPoint)
        {
            dataToRead = dataToRead.PadRight(entryPoint + 1);
            string inputValue = "0";
            int startPosition = entryPoint;
            int numberOfPositions = 1;
            decimal result = 0;

            if (IsValidMoneyStringEntryPoint(dataToRead, entryPoint))
            {
                // Keep checking previous character until we get a space or reach the start of the string.
                while (IsValidMoneyStartCharacter(dataToRead, startPosition))
                {
                    startPosition--;
                    if (startPosition == -1)
                    {
                        break;
                    }
                }

                startPosition++;

                while (IsValidMoneyEndCharacter(dataToRead, startPosition, numberOfPositions))
                {
                    numberOfPositions++;

                    if (LastPositionInSubstring(dataToRead, startPosition, numberOfPositions).IsAlpha())
                    {
                        numberOfPositions--;
                        break;
                    }
                }

                inputValue = dataToRead.Substring(startPosition, numberOfPositions).Replace("*", string.Empty);
            }

            if (inputValue.StartsWith("-") && inputValue.EndsWith("-"))
            {
                inputValue = inputValue.Substring(1);
            }

            inputValue = inputValue.Trim();

            if (!inputValue.Contains("."))
            {
                if (inputValue.EndsWith("-"))
                {
                    inputValue = inputValue.Insert(inputValue.Length - 1, ".00");
                }
                else
                {
                    inputValue += ".00";
                }
            }

            if (inputValue.Replace(",", string.Empty).IsMoney(false))
            {
                result = decimal.Parse(inputValue);
            }

            return result;
        }

        /// <summary>
        /// Parses the money value.
        /// </summary>
        /// <param name="dataToRead">The data to read.</param>
        /// <param name="entryPoint">The entry point.</param>
        /// <param name="blankIsZero">if set to <c>true</c> [blank is zero].</param>
        /// <returns></returns>
        public static string ParseMoneyValue(string dataToRead, int entryPoint, bool blankIsZero)
        {
            string result;

            if (!blankIsZero && string.IsNullOrEmpty(dataToRead.Mid(entryPoint, 1).Trim()))
            {
                result = string.Empty;
            }
            else
            {
                result = ParseMoneyValue(dataToRead, entryPoint).ToString();
            }

            return result;
        }



		// Private Methods (4) 

        private static bool IsValidMoneyEndCharacter(string dataToRead, int startPosition, int numberOfPositions)
        {
            return !dataToRead.Substring(startPosition, numberOfPositions).EndsWith(" ") &&
                   !dataToRead.Substring(startPosition, numberOfPositions).EndsWith("-") &&
                   (startPosition + numberOfPositions) < dataToRead.Length;
        }

        private static bool IsValidMoneyStartCharacter(string dataToRead, int startPosition)
        {
            return
                dataToRead.Substring(startPosition, 1) != (" ") && dataToRead.Substring(startPosition, 1) != "-" &&
                !dataToRead.Substring(startPosition, 1).IsAlpha() && startPosition >= 0;
        }

        private static bool IsValidMoneyStringEntryPoint(string dataToRead, int decimalPosition)
        {
            return !dataToRead.Substring(decimalPosition, 1).Equals(" ") &&
                   !dataToRead.Substring(decimalPosition, 1).IsAlpha();
        }

        private static string LastPositionInSubstring(string sourceString, int startPosition, int numberOfPositions)
        {
            return sourceString.Substring(startPosition, numberOfPositions).Substring(numberOfPositions - 1);
        }


		#endregion Methods 

    }
}
