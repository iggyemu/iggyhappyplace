﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Data
{
    public class SelfLoadingDictionary<K,V> : Dictionary<K,V>
    {

        protected Func<K, V> loaderFunc;


        protected SelfLoadingDictionary() :base() { }  // not allowed (invisible to public)

        public SelfLoadingDictionary(Func<K, V> loadValueForKeyFunc) : this()
        {
            loaderFunc = loadValueForKeyFunc;
        } 


        public V this[K key]
        {
            get
            {
                if (!this.ContainsKey(key))
                    base[key] = loaderFunc(key);
                return base[key];
            }

            set { base[key] = value; }
        }
    }
}
