﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text;
using System.Threading;

namespace Ditech.Data.Common
{
    public partial class DbCommand : IValidState, IDisposable
    {
		private delegate object ExecuteMethod();
        private delegate int FillMethod(DataAdapter adapter, DataSet dataset);

        private object ExecuteCommand(ExecuteMethod method)
        {
            return ExecuteCommand((object) method);
        }

        private object ExecuteCommand(FillMethod method, DataAdapter adapter, DataSet dataset)
        {
            return ExecuteCommand((object)method, adapter, dataset);
        }

		private object ExecuteCommand(object method, DataAdapter adapter = null, DataSet dataset = null)
		{
            OpenConnection();

            var retry = 5;

            object result = null;

            do
            {
                try
                {
                    bool methodInvoked = false;

                    if (method is ExecuteMethod)
                    {
                        result = ((ExecuteMethod) method).Invoke();
                        methodInvoked = true;
                    }

                    if (method is FillMethod)
                    {
                        result = ((FillMethod)method).Invoke(adapter, dataset);
                        methodInvoked = true;
                    }

					if (!methodInvoked)
					{
					    throw new ApplicationException("Unsupported method passed to ExecuteCommand()");
					}

                    break;
                }
                catch (SqlException ex)
                {
                    var message = ex.Message.ToLower();

                    if (retry > 0 && (message.Contains("timeout") || message.Contains("network")))
                    {
                        retry--;

                        Thread.Sleep(5000);

                        OpenConnection();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            while (true);

		    return result;
		}
    }
}
