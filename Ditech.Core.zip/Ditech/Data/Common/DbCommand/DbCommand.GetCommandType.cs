﻿using System;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Gets the DbCommandType of the current database connection.
        /// </summary>
        /// <returns>Returns the DbCommand type.</returns>
        private DbCommandType GetCommandType()
        {
            return GetCommandType(Command.Connection.GetType().ToString());
        }

        /// <summary>
        /// Gets the DbCommandType of the specified System DbConnection object type.
        /// </summary>
        /// <param name="connectionType">The raw type as a string of the connection object.</param>
        /// <returns>Returns the DbCommand type.</returns>
        private static DbCommandType GetCommandType(string connectionType)
        {
            var data = connectionType.Split(new[] {'.'});

            connectionType = data[data.Length - 1];

            return
                (DbCommandType)
                Enum.Parse(typeof (DbCommandType), connectionType.Replace("Connection", "Command"), true);
        }
    }
}