﻿using System;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Throws an exception stating that the database connection type is not supported.
        /// </summary>
        protected static void InvalidOperation()
        {
            throw new InvalidOperationException("The database connection type is not supported for this operation.");
        }
    }
}