using System;
using System.Collections;
using System.Data.Common;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        #region�Enums�(1)�

        /// <summary>
        /// Database command types.
        /// </summary>
        protected enum DbCommandType
        {
            /// <summary>
            /// SQL Server
            /// </summary>
            SqlCommand,
            /// <summary>
            /// Oracle
            /// </summary>
            OracleCommand,
            /// <summary>
            /// OLEDB Compliant Source
            /// </summary>
            OleDbCommand
        }

        #endregion�Enums�

        #region�Constructors�(6)�

        /// <summary>
        /// Initializes the object using the stored procedure's name and a single parameter.  
        /// The stored procedure parameter is built using the name.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="connection">The connection used for the stored procedure (only SQL is supported).</param>
        /// <param name="parameterName">The parameter name.</param>
        /// <param name="parameterValue">The parameter value.</param>
        public DbCommand(string storedProcedureName, DbConnection connection, string parameterName,
                         object parameterValue)
            : this(storedProcedureName, connection, new[] {parameterName}, new[] {parameterValue})
        {
        }

        /// <summary>
        /// Initializes the object using the stored procedure's name and arrays for the parameters.  
        /// The array indexs should correspond to each other for the appropriate parameter name and value.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="connection">The connection used for the stored procedure.</param>
        /// <param name="parameterNames">The parameter names.</param>
        /// <param name="parameterValues">The parameter values.</param>
        public DbCommand(string storedProcedureName, DbConnection connection, string[] parameterNames,
                         object[] parameterValues) : this(storedProcedureName, connection)
        {
            if (parameterNames.Length != parameterValues.Length)
            {
                throw new ArgumentException("Number of parameter names does not match number of parameter values.");
            }

            for (var i = 0; i < parameterNames.Length; i++)
            {
                AddWithValue(parameterNames[i], parameterValues[i]);
            }
        }

        /// <summary>
        /// Initializes the object using the stored procedure's name, the framework's DbConnection, and a Hashtable of parameters.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="connection">The connection used for the stored procedure (only SQL is supported).</param>
        /// <param name="parameters">Hashtable that holds the parameters. The parameter name is the key and the parameter value is the value.</param>
        public DbCommand(string storedProcedureName, DbConnection connection, Hashtable parameters)
            : this(storedProcedureName, connection)
        {
            var enumerator = parameters.GetEnumerator();

            while (enumerator.MoveNext())
            {
                AddWithValue(enumerator.Key.ToString(), enumerator.Value);
            }
        }

        /// <summary>
        /// Initializes the object using the stored procedure's name and the framework's DbConnection.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="connection">The connection used for the stored procedure (only SQL is supported).</param>
        public DbCommand(string storedProcedureName, DbConnection connection)
        {
            Initialize(GetCommandType(connection.GetType().ToString()));

            Command.Connection = connection;

            Command.CommandText = storedProcedureName;
        }

        /// <summary>
        /// Initializes the object using the stored procedure's name and no parameters.  By default, the Command will be a SqlCommand.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        public DbCommand(string storedProcedureName) : this()
        {
            Command.CommandText = storedProcedureName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DbCommand"/> class to empty.  By default, the Command will be a SqlCommand.
        /// </summary>
        public DbCommand()
        {
            Initialize(DbCommandType.SqlCommand);
        }

        #endregion�Constructors�

        #region�Properties�(4)�

        /// <summary>
        /// Gets or sets the inner .NET DbCommand object.
        /// </summary>
        /// <value>The connection.</value>
        protected System.Data.Common.DbCommand Command { get; set; }

        /// <summary>
        /// Gets or sets the inner .NET CommandTimeout object.
        /// </summary>
        /// <value>The connection.</value>
        public int CommandTimeout
        {
            get { return Command.CommandTimeout; }
            set { Command.CommandTimeout = value; }
        }

        /// <summary>
        /// Gets or sets the inner .NET Connection object.
        /// </summary>
        /// <value>The connection.</value>
        public DbConnection Connection
        {
            get { return Command.Connection; }
            set { Command.Connection = value; }
        }

        /// <summary>
        /// Gets or sets the inner .NET CommandText object.
        /// </summary>
        /// <value>The connection.</value>
        public string CommandText
        {
            get { return Command.CommandText; }
            set { Command.CommandText = value; }
        }

        /// <summary>
        /// Gets the inner Parameters collection object for Command.
        /// </summary>
        /// <value>The connection.</value>
        public DbParameterCollection Parameters
        {
            get { return Command.Parameters; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is in a valid state.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is valid state; otherwise, <c>false</c>.
        /// </value>
        public bool IsValidState
        {
            get { return (Command != null && Command.Connection != null); }
        }

        #endregion�Properties�

        #region�Methods�(12)�

        //�Public�Methods�(7)�


        //�Protected�Methods�(2)�


        //�Private�Methods�(3)�

        #endregion�Methods�
    }
}