﻿using System;
using System.Collections.Generic;
using System.Data.Common;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Converts the DB Command to a SQL string.  Useful for generating SQL scripts.
        /// </summary>
        /// <value>A SQL command.</value>
        public string ToSqlString
        {
            get
            {
                string sql = string.Format("EXEC {0} ", CommandText);
                List<string> parameters = new List<string>();
                foreach (DbParameter dbParameter in Parameters)
                {
                    if (dbParameter.Value == null)
                    {
                        parameters.Add(string.Format("{0} = NULL", dbParameter.ParameterName));
                    }
                    else
                    {
                        parameters.Add(string.Format("{0} = '{1}'", dbParameter.ParameterName, dbParameter.Value.ToString().Replace("'", "''")));
                    }
                }

                sql += string.Join(", ", parameters.ToArray());

                return sql;
            }
        }
    }
}