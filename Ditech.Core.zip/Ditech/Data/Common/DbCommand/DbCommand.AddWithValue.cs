﻿using System;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Adds the stored procedure parameter with the specified value
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="value">The value.</param>
        /// <returns>Returns the DbParameter. </returns>
        public DbParameter AddWithValue(string parameterName, object value)
        {
            DbParameter result = null;

            switch (GetCommandType())
            {
                case DbCommandType.SqlCommand:
                    result = ((SqlParameterCollection) Parameters).AddWithValue(parameterName, value);
                    break;
                case DbCommandType.OleDbCommand:
                    result = ((OleDbParameterCollection) Parameters).AddWithValue(parameterName, value);
                    break;
                default:
                    InvalidOperation();
                    break;
            }

            return result;
        }

        /// <summary>
        /// Adds the stored procedure parameter with the specified value
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="value">The value.</param>
        /// <param name="skipNullValue">if set to <c>true</c> [skip null value].</param>
        /// <param name="skipEmptyString">if set to <c>true</c> [skip empty string].</param>
        /// <returns>Returns the DbParameter.</returns>
        public DbParameter AddWithValue(string parameterName, string value, bool skipNullValue, bool skipEmptyString)
        {
            if (value != null && value.Length == 0 && skipEmptyString)
            {
                value = null;
            }

            return AddWithValue(parameterName, value, skipNullValue);
        }

        /// <summary>
        /// Adds the stored procedure parameter with the specified value
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="value">The value.</param>
        /// <param name="skipNullValue">if set to <c>true</c> [skip null value].</param>
        /// <returns>Returns the DbParameter.</returns>
        public DbParameter AddWithValue(string parameterName, object value, bool skipNullValue)
        {
            DbParameter result = null;

            if (value != null || !skipNullValue)
            {
                result = AddWithValue(parameterName, value);
            }

            return result;
        }
    }
}