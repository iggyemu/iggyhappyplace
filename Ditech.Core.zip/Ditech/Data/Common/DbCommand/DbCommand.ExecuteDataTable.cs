﻿using System;
using System.Data;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Executes a stored procedure and returns a DataTable value.  Opens connection first if it is not already open.
        /// </summary>
        /// <returns>DataTable filled with command results.</returns>
        public DataTable ExecuteDataTable()
        {
            var dataSet = ExecuteDataSet();

            var dataTable = dataSet.Tables[0];

            dataSet.Tables.Remove(dataTable);

            return dataTable;
        }
    }
}