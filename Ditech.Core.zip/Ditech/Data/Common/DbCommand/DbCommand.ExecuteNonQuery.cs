﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Executes a stored procedure without using a reader.  Opens connection first if it is not already open.
        /// </summary>
        /// <returns>Integer result from the command operation</returns>
        public int ExecuteNonQuery()
        {
            return (int)ExecuteCommand(NonQuery);
        }

        private object NonQuery()
        {
            return Command.ExecuteNonQuery();
        }
    }
}