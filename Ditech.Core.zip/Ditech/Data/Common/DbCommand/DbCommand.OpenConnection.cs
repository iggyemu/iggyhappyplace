﻿using System;
using System.Data;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Throws an exception if the state is not valid. Opens the connection if the connection is not already open.
        /// </summary>
        protected void OpenConnection()
        {
            if (!IsValidState)
            {
                throw new InvalidOperationException("Inner command object is invalid.");
            }

            if (Command.Connection.State != ConnectionState.Open)
            {
                Command.Connection.Open();
            }
        }
    }
}