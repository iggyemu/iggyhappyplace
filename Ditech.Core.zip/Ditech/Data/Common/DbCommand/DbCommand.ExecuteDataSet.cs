﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using Ditech.IO;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Executes a stored procedure and returns a DataSet object with the results.  Opens connection first if it is not already open.
        /// </summary>
        /// <returns>DataSet object with query results.</returns>
        public DataSet ExecuteDataSet()
        {
            OpenConnection();

            DbDataAdapter dataAdapter = null;

            switch (GetCommandType())
            {
                case DbCommandType.SqlCommand:
                    dataAdapter = new SqlDataAdapter((SqlCommand)Command);
                    break;
                case DbCommandType.OleDbCommand:
                    dataAdapter = new OleDbDataAdapter((OleDbCommand)Command);
                    break;
                default:
                    InvalidOperation();
                    break;
            }

            // Initialize a new data set
            var dataset = new DataSet();

            ExecuteCommand(Fill, dataAdapter, dataset);

            // Return the data set
            return dataset;
        }

        private int Fill(DataAdapter adapter, DataSet dataset)
        {
            return adapter.Fill(dataset);
        }
    }
}