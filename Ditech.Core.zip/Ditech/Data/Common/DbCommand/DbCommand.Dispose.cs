﻿using System;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        #region IDisposable Members

        /// <summary>
        /// Disposes the inner command object when the object is disposed of.
        /// </summary>
        public void Dispose()
        {
            if (IsValidState)
            {
                Command.Dispose();
            }
        }

        #endregion
    }
}