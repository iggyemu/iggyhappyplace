﻿using System;
using System.Data.Common;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Executes a stored procedure and returns a DbDataReader object.  Opens connection first if it is not already open.
        /// </summary>
        /// <returns>DataReader result from the command</returns>
        public DbDataReader ExecuteReader()
        {
            return (DbDataReader)ExecuteCommand(Reader);
        }

        private object Reader()
        {
            return Command.ExecuteReader();
        }
    }
}