﻿using System;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Executes a stored procedure and returns the first column of the first row as an object.  Opens connection first if it is not already open.
        /// </summary>
        /// <returns>Object result from the command</returns>
        public object ExecuteScalar()
        {
            return ExecuteCommand(Scalar);
        }

        private object Scalar()
        {
            return Command.ExecuteScalar();
        }
    }
}