﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Ditech.Data.Common
{
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Executes a stored procedure and returns a List value.  Opens connection first if it is not already open.
        /// </summary>
        /// <returns>List filled with command results.</returns>
        public List<object> ExecuteList()
        {
            var dataSet = ExecuteDataSet();

            var dataTable = dataSet.Tables[0];

            dataSet.Tables.Remove(dataTable);
            
            var list = new List<object>();

            foreach (DataRow dataRow in dataTable.Rows)
            {
                list.Add(dataRow[0]);
            }

            return list;
        }
    }
}
