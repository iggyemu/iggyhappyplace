﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace Ditech.Data.Common
{
    /// <summary>
    /// DbCommand class that wraps SQL, Oracle, and OleDb readers
    /// </summary>
    public partial class DbCommand : IValidState, IDisposable
    {
        /// <summary>
        /// Initializes the inner DbCommand object.
        /// </summary>
        private void Initialize(DbCommandType connectionType)
        {
            switch (connectionType)
            {
                case DbCommandType.SqlCommand:
                    Command = new SqlCommand();
                    break;
                case DbCommandType.OleDbCommand:
                    Command = new OleDbCommand();
                    break;
                default:
                    InvalidOperation();
                    break;
            }

            Command.CommandType = CommandType.StoredProcedure;
        }
    }
}