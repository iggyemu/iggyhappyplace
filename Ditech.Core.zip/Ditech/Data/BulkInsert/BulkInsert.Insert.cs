﻿using System;
using System.IO;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        private void Insert()
        {
            if (!IsValidState)
            {
                throw new ApplicationException(string.Format("Invalid state for running insert, please review the fields below.\n\nTable Name: {0}Database null?: {1}Output File Path: {2}\nBulk Insert Path: {3}", Table, DbConnection == null, TemporaryLocalFilePath, TemporaryBulkInsertPath));
            }

            Output.Close();

            IO.File.Copy(TemporaryLocalFilePath, TemporaryBulkInsertPath, true);

            InsertFile(DbConnection, RawTable, RecordCount <= BatchSize ? TruncateTable : false, TemporaryBulkInsertPath, Delimiter, OrderByColumn);

            Output = new StreamWriter(TemporaryLocalFilePath);
        }
    }
}
