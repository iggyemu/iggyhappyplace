﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        ///<summary>
        /// The default delimiter used for the insert
        ///</summary>
        public static string DefaultDelimiter { get { return "\t"; } }

        ///<summary>
        /// The number of records written to the temporary file using Add() before the Insert() method is triggered.
        ///</summary>
        public int BatchSize { get; set; }

        ///<summary>
        /// The file path of the delimited file used in the insert.  This is usually a file located on a network share available to the database server.
        ///</summary>
        public string TemporaryBulkInsertPath { get; set; }

        private SqlConnection DbConnection { get; set; }

        private string Database { get; set; }
        private string Schema { get; set; }
        private string RawTable { get; set; }

        ///<summary>
        /// The delimiter used in the file.
        ///</summary>
        public string Delimiter { get; set; }

        private List<string> Fields { get; set; }

        ///<summary>
        /// The name of the identity column in the table.  The ID column value is filled in on the bulk insert file if the identity column name is present.
        ///</summary>
        public string IdentityColumnName { get; set; }

        ///<summary>
        /// Returns whether the bulk insert object is in a valid state.
        ///</summary>
        public bool IsValidState
        {
            get
            {
                return !string.IsNullOrEmpty(Table) && !string.IsNullOrEmpty(TemporaryLocalFilePath) &&
                       !string.IsNullOrEmpty(TemporaryBulkInsertPath) && DbConnection != null;
            }
        }

        private StreamWriter Output { get; set; }

        ///<summary>
        /// The temporary file path to be used while writing bulk insert files.
        ///</summary>
        public string TemporaryLocalFilePath { get; set; }

        private List<PropertyInfo> PropertyOrder { get; set; }

        ///<summary>
        /// The current number of objects added for bulk insert
        ///</summary>
        public int RecordCount { get; private set; }

        private string Table { get; set; }

        ///<summary>
        /// If set to true, truncate the table before running the bulk insert.
        ///</summary>
        public bool TruncateTable { get; set; }

        private int IdentityColumnPosition { get; set; }

        ///<summary>
        /// If the file is ordered by a specific database column, put the name of the field here to speed up the bulk insert.
        ///</summary>
        public string OrderByColumn { get; set; }
    }
}
