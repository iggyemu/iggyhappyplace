﻿using System;
using System.Collections.Generic;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        ///<summary>
        /// Adds the object to the temporary bulk insert file.  Reflection is used to match each property in the object to the correct database field by name.
        /// If the current file's record count is equal to the batch size, then Insert() is automatically called.
        ///</summary>
        ///<param name="obj"></param>
        public void Add(object obj)
        {
            if (obj != null)
            {
                if (PropertyOrder == null)
                {
                    SetLookup(obj);
                }

                RecordCount++;

                var record = new List<string>();

                for (var i = 0; i < PropertyOrder.Count; i++)
                {
                    var stringValue = i == IdentityColumnPosition ? RecordCount.ToString() : GetStringValue(PropertyOrder[i], obj);

                    record.Add(stringValue);
                }

                var line = string.Join(Delimiter, record.ToArray());

                Output.WriteLine(line);

                if (RecordCount % BatchSize == 0)
                {
                    Insert();
                }
            }
        }
    }
}
