﻿using System;
using System.Reflection;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        private static string GetStringValue(PropertyInfo property, object obj)
        {
            var stringValue = string.Empty;

            if (property != null)
            {
                var rawValue = property.GetValue(obj, null);

                if (property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(DateTime?))
                {
                    if (property.PropertyType == typeof(DateTime))
                    {
                        stringValue = FormatDate((DateTime)rawValue);
                    }
                    else
                    {
                        if (property.PropertyType == typeof(DateTime?))
                        {
                            stringValue = FormatDate((DateTime?)rawValue);
                        }
                    }
                }
                else
                {
                    if (property.PropertyType == typeof(bool) || property.PropertyType == typeof(bool?))
                    {
                        if (property.PropertyType == typeof(bool))
                        {
                            stringValue = ((bool)rawValue) ? "1" : "0";
                        }
                        else
                        {
                            if (property.PropertyType == typeof(bool?))
                            {
                                if (rawValue == null)
                                {
                                    stringValue = string.Empty;
                                }
                                else
                                {
                                    stringValue = ((bool?)rawValue).Value ? "1" : "0";
                                }
                            }
                        }
                    }
                    else
                    {
                        stringValue = Convert.ToString(rawValue);
                    }
                }
            }

            return stringValue;
        }
    }
}
