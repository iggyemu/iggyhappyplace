﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        private void SetLookup(object obj)
        {
            IO.Directory.Create(Path.GetDirectoryName(TemporaryLocalFilePath));
            Output = new StreamWriter(TemporaryLocalFilePath);

            var type = obj.GetType();

            var properties = type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            var lookup = new Dictionary<string, PropertyInfo>();

            foreach (var propertyInfo in properties)
            {
                var name = propertyInfo.Name;

                name = name.ToUpper().Remove("_");

                lookup.Add(name, propertyInfo);
            }

            PropertyOrder = new List<PropertyInfo>();

            for (var i = 0; i < Fields.Count; i++)
            {
                var field = Fields[i];

                PropertyInfo propertyInfo = null;

                if (lookup.ContainsKey(field))
                {
                    propertyInfo = lookup[field];
                }
                else
                {
                    if (!string.IsNullOrEmpty(IdentityColumnName) && field == IdentityColumnName)
                    {
                        IdentityColumnPosition = i;
                    }
                }

                PropertyOrder.Add(propertyInfo);
            }
        }
    }
}
