﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        ///<summary>
        /// Inserts the tab-delimited file at the bulk insert path into the specified table.
        ///</summary>
        ///<param name="connection">The database connection used.</param>
        ///<param name="tableName">The database table used for the insert.</param>
        ///<param name="truncateTable">If set to true, truncate the table before running the bulk insert.</param>
        ///<param name="bulkInsertPath">The file path of the delimited file.  This is usually a file located on a network share available to the database server.</param>
        public static void InsertFile(SqlConnection connection, string tableName, bool truncateTable, string bulkInsertPath)
        {
            InsertFile(connection, tableName, truncateTable, bulkInsertPath, DefaultDelimiter);
        }

        ///<summary>
        /// Inserts the delimited file at the bulk insert path into the specified table.
        ///</summary>
        ///<param name="connection">The database connection used.</param>
        ///<param name="tableName">The database table used for the insert.</param>
        ///<param name="truncateTable">If set to true, truncate the table before running the bulk insert.</param>
        ///<param name="bulkInsertPath">The file path of the delimited file.  This is usually a file located on a network share available to the database server.</param>
        ///<param name="delimiter">The delimiter used in the file.</param>
        ///<param name="orderByColumn">If the file is ordered by a specific database column, put the name of the field here to speed up the bulk insert.</param>
        public static void InsertFile(SqlConnection connection, string tableName, bool truncateTable, string bulkInsertPath, string delimiter, string orderByColumn = "")
        {
            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }

            using (var command = new SqlCommand(string.Format("TRUNCATE TABLE {0}", tableName), connection))
            {
                command.CommandTimeout = 10000;

                if (truncateTable)
                {
                    command.ExecuteNonQuery();
                }

                if (!string.IsNullOrEmpty(orderByColumn))
                {
                    orderByColumn = string.Format(", ORDER ({0} ASC)", orderByColumn);
                }

                command.CommandText =
                    string.Format(
                        "BULK INSERT {0} FROM '{1}' WITH ( FIELDTERMINATOR= '{2}', KEEPNULLS, TABLOCK {3})",
                        tableName, bulkInsertPath, delimiter, orderByColumn);

                command.ExecuteNonQuery();
            }
        }
    }
}
