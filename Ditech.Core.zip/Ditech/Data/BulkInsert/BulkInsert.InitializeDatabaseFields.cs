﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        private void InitializeDatabaseFields()
        {
            if (DbConnection.State == ConnectionState.Closed)
            {
                DbConnection.Open();
            }

            var databaseIdentifier = string.IsNullOrEmpty(Database) ? string.Empty : string.Format("[{0}].", Database);

            var schemaCriteria = Schema.Length == 0
                                     ? string.Empty
                                     : string.Format("AND TABLE_SCHEMA = '{0}'", Schema.Remove(new[] {'[', ']'}));

            var query = string.Format(
                "SELECT COLUMN_NAME FROM {0}INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{1}' {2} ORDER BY ORDINAL_POSITION", databaseIdentifier,
                Table.Remove(new[] { '[', ']' }), schemaCriteria);

            using (var command = new SqlCommand(query, DbConnection))
            {
                command.CommandTimeout = 1000;

                Fields = new List<string>();

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var field = Convert.ToString(reader[0]).Trim().ToUpper();

                        field = field.Remove(new[] { " ", "_", "-", "&", "/" });

                        Fields.Add(field);
                    }
                }
            }
        }
    }
}
