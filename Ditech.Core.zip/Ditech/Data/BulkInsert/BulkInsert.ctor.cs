﻿using System;
using System.Data.SqlClient;

namespace Ditech.Data.Common
{
	///<summary>
	/// Used to handle bulk inserts of objects and files into SQL Server tables
	///</summary>
	public partial class BulkInsert : IDisposable, IValidState
	{
        #region Constructors (2)

        ///<summary>
        /// Initializes the bulk insert object.  This also initializes the database table field information lookup.
        ///</summary>
        ///<param name="table">The database table to be used.  This needs to be fully qualified if the table is in a different database than the one used in the currrent connection.</param>
        ///<param name="dbConnection">The database connection.</param>
        ///<param name="temporaryFilePath">The temporary file path to be used while writing bulk insert files.</param>
        ///<param name="bulkInsertPath">The file path of the delimited file.  This is usually a file located on a network share available to the database server.</param>
        ///<param name="orderByColumn">The column the bulk insert file will be ordered by.</param>
        public BulkInsert(string table, SqlConnection dbConnection, string temporaryFilePath, string bulkInsertPath, string orderByColumn = "")
        {
            Delimiter = DefaultDelimiter;
            BatchSize = 100000;
            IdentityColumnPosition = -1;
            TruncateTable = false;
            OrderByColumn = orderByColumn;

            TemporaryLocalFilePath = temporaryFilePath;
            TemporaryBulkInsertPath = bulkInsertPath;

            DbConnection = dbConnection;

            string database, schema;

            RawTable = table;

            GetTableIdentifiers(RawTable, out database, out schema, out table);

            Database = database;
            Schema = schema;
            Table = table;

            InitializeDatabaseFields();
        }

	    ///<summary>
        /// Initializes the bulk insert object.  This also initializes the database table field information lookup.  Only use this constructor if the file paths will be set at a later time.
        ///</summary>
        ///<param name="table">The database table to be used.  This needs to be fully qualified if the table is in a different database than the one used in the currrent connection.</param>
        ///<param name="dbConnection">The database connection.</param>
        protected BulkInsert(string table, SqlConnection dbConnection) : this(table, dbConnection, string.Empty, string.Empty) { }

        #endregion Constructors 

	}
}
