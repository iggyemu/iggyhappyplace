﻿using System;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        private static string FormatDate(DateTime? date)
        {
            return date == null ? string.Empty : FormatDate(date.Value);
        }

        private static string FormatDate(DateTime date)
        {
            return date.ToString("s");
        }
    }
}
