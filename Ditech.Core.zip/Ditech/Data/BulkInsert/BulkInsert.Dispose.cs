﻿using System;
using System.Threading;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        ///<summary>
        /// Disposes the object, Inserting any remaining records and deleting the temporary files
        ///</summary>
        public void Dispose()
        {
            if (Output != null)
            {
                if (RecordCount != 0 && RecordCount % BatchSize != 0)
                {
                    Insert();
                }

                Output.Dispose();
            }

            if (DbConnection != null)
            {
                DbConnection.Close();
            }

            Thread.Sleep(500);

            try
            {
                IO.File.Delete(TemporaryLocalFilePath);
                IO.File.Delete(TemporaryBulkInsertPath);
            } catch {}
        }

    }
}
