﻿using System;

namespace Ditech.Data.Common
{
    public partial class BulkInsert : IDisposable, IValidState
    {
        private static void GetTableIdentifiers(string rawTableName, out string database, out string schema, out string table)
        {
            var splitName = rawTableName.Split(new[] { '.' });
            schema = string.Empty;
            database = string.Empty;

            switch (splitName.Length)
            {
                case 2:
                    schema = splitName[0].Trim().Coalesce("dbo");
                    break;
                case 3:
                    database = splitName[0].Trim().ToUpper();
                    schema = splitName[1].Trim().Coalesce("dbo");
                    break;
            }

            table = splitName[splitName.Length - 1].Trim();
        }
    }
}
