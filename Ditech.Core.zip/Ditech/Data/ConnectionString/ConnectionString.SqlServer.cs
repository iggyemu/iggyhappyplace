﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;

namespace Ditech.Data
{
    public static partial class ConnectionString
    {
        /// <summary>
        /// Builds a SQL Server connection string.
        /// </summary>
        /// <param name="serverName">Name of the server.</param>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <returns>Sql Server ConnectionString</returns>
        public static string SqlServer(string serverName, string databaseName, string userName, string password)
        {
            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder
            {
                DataSource = serverName,
                InitialCatalog = databaseName,
                UserID = userName,
                Password = password,
                ApplicationName = GetCaller(),
                WorkstationID = Environment.MachineName.ToUpper()
            };

            return sqlConnectionStringBuilder.ToString();
        }

        /// <summary>
        /// Builds a SQL Server connection string.
        /// </summary>
        /// <param name="serverName">Name of the server.</param>
        /// <param name="databaseName">Name of the database.</param>
        /// <returns>Sql Server ConnectionString</returns>
        public static string SqlServer(string serverName, string databaseName)
        {




            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder
            {
                DataSource = serverName,
                InitialCatalog = databaseName,
                IntegratedSecurity = true,
                ApplicationName = GetCaller(),
                WorkstationID = Environment.MachineName.ToUpper()
            };

            return sqlConnectionStringBuilder.ToString();
        }

        private static string GetCaller()
        {
            var stackTrace = new StackTrace();

            string callingType, callingName;

            var i = 2;

            do
            {
                var stackFrame = stackTrace.GetFrame(i);
                var methodBase = stackFrame.GetMethod();

                callingType = methodBase.ReflectedType.Name;
                callingName = methodBase.ReflectedType.FullName;

                i++;

            } while (callingType == "Connection");

            return callingName;
        }
    }
}
