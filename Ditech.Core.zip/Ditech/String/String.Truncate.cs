namespace Ditech
{
    /// <summary>
    /// A utility class containing methods for string manipulation.
    /// </summary>
    public static partial class String
    {
        #region�Methods�(1)�

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string Truncate(this string input, int length)
        {
            if (string.IsNullOrEmpty(input) || input.Length < length)
            {
                return input;
            }
            else
            {
                return input.Substring(0, length) + "...";
            }
        }

        #endregion�Methods�
    }
}