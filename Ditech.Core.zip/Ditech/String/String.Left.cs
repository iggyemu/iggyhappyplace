namespace Ditech
{
    public static partial class String
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Returns the specified number of characters, starting from the left.
        /// If the length of the string is less than the requested length, the whole string is returned.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="length">The length.</param>
        /// <returns>Substring of specified length.</returns>
        public static string Left(this string value, int length)
        {
            string result;

            if (string.IsNullOrEmpty(value) || value.Length <= length)
            {
                result = value;
            }
            else
            {
                result = value.Substring(0, length);
            }

            return result;
        }

        #endregion�Methods�
    }
}