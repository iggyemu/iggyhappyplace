using System;

namespace Ditech
{
    public static partial class String
    {
        #region UniqueIdOptions enum

        /// <summary>
        /// Formatting options for the GUID
        /// </summary>
        public enum UniqueIdOptions
        {
            /// <summary>
            /// Returns XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX - 8-4-4-4-12
            /// </summary>
            WithDashes,
            /// <summary>
            /// Returns {XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX} - {8-4-4-4-12}
            /// </summary>
            WithCurlyBraces,
            /// <summary>
            /// Returns (XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX) - (8-4-4-4-12)
            /// </summary>
            WithParenthesis,
            /// <summary>
            /// Returns 32 characters; no dashes or brackets
            /// </summary>
            ValueOnly
        }

        #endregion

        /// <summary>
        /// Gets a unique id (GUID) for use in applications or databases (no dashes).
        /// </summary>
        /// <returns>GUID String</returns>
        public static string UniqueId()
        {
            return UniqueId(UniqueIdOptions.ValueOnly);
        }

        /// <summary>
        /// Gets a unique id (GUID) for use in applications or databases.
        /// </summary>
        /// <param name="uniqueIdOptions">GUID formatting options.</param>
        /// <returns>GUID String</returns>
        public static string UniqueId(UniqueIdOptions uniqueIdOptions)
        {
            string result;
            var guid = Guid.NewGuid();
            switch (uniqueIdOptions)
            {
                case UniqueIdOptions.WithDashes:
                    result = guid.ToString("D");
                    break;
                case UniqueIdOptions.WithCurlyBraces:
                    result = guid.ToString("B");
                    break;
                case UniqueIdOptions.WithParenthesis:
                    result = guid.ToString("P");
                    break;
                default:
                    result = guid.ToString("N");
                    break;
            }

            return result.ToUpper();
        }
    }
}