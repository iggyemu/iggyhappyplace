﻿using System.Collections.Generic;

namespace Ditech
{
    /// <summary>
    /// A utility class containing methods for string manipulation.
    /// </summary>
    public static partial class String
    {
        #region Methods (1)

        // Public Methods (1) 

        /// <summary>
        /// Checks to see if string exists in the string array
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="possibleValues">The possible values.</param>
        /// <returns></returns>
        public static bool In(this string value, string[] possibleValues)
        {
            return new List<string>(possibleValues).Contains(value);
        }

        /// <summary>
        /// Checks to see if string exists in the string array
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="possibleValues">The possible values.</param>
        /// <returns></returns>
        public static bool In(this string value, List<object> possibleValues)
        {
            return new List<object>(possibleValues).Contains(value);
        }

        /// <summary>
        /// Checks to see if string exists in the string array
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="possibleValues">The possible values.</param>
        /// <returns></returns>
        public static bool In(this string value, List<string> possibleValues)
        {
            return new List<string>(possibleValues).Contains(value);
        }

        #endregion Methods
    }
}