using System.Collections;

namespace Ditech
{
    public static partial class String
    {
        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Removes the specified value from the string.
        /// </summary>
        /// <param name="value">The input string.</param>
        /// <param name="removedValue">The value to remove.</param>
        /// <returns>Returns a string value.</returns>
        public static string Remove(this string value, string removedValue)
        {
            return value.Replace(removedValue, string.Empty);
        }

        /// <summary>
        /// Removes the specified value from the string.
        /// </summary>
        /// <param name="value">The input string.</param>
        /// <param name="removedValues">The values to remove.</param>
        /// <returns>Returns a string value.</returns>
        public static string Remove(this string value, IEnumerable removedValues)
        {
            if (!string.IsNullOrEmpty(value))
            {
                foreach (var removeVal in removedValues)
                {
                    value = value.Remove(Convert.ToString(removeVal));
                }
            }

            return value;
        }

        #endregion�Methods�
    }
}