namespace Ditech
{
    public static partial class String
    {
        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Returns a string from the specified start position to the end.
        /// If the length of the start position to the end is less than the requested length, the portion from the start position to the end is returned.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="startPosition">The position to start from.</param>
        /// <returns>Substring beginning at start position.</returns>
        public static string Mid(this string value, int startPosition)
        {
            string result;

            if (startPosition >= value.Length || startPosition < 0)
            {
                result = string.Empty;
            }
            else
            {
                result = value.Substring(startPosition);
            }

            return result;
        }

        /// <summary>
        /// Returns a string of specified length, starting from the specified position.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="startPosition">The position to start from.</param>
        /// <param name="length">The length.</param>
        /// <returns>Substring beginning at the start position.</returns>
        public static string Mid(this string value, int startPosition, int length)
        {
            var result = string.Empty;

            if (startPosition >= value.Length)
            {
                result = string.Empty;
            }
            else if (startPosition + length > value.Length)
            {
                var numOfCharacters = value.Length - startPosition;

                if (numOfCharacters > 0)
                {
                    result = Right(value, numOfCharacters);
                }
            }
            else
            {
                result = value.Substring(startPosition, length);
            }

            return result;
        }

        #endregion�Methods�
    }
}