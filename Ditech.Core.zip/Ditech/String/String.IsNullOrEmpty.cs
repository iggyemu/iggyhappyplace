namespace Ditech
{
    public static partial class String
    {
        /// <summary>
        /// Determines whether the string is null or empty.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="trimValueBeforeCheck">if set to <c>true</c> [trim value before check].</param>
        /// <returns>
        /// 	<c>true</c> if [is null or empty] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNullOrEmpty(this string value, bool trimValueBeforeCheck)
        {
            return trimValueBeforeCheck
                       ? string.IsNullOrEmpty(Convert.ToString(value).Trim())
                       : string.IsNullOrEmpty(value);
        }
    }
}