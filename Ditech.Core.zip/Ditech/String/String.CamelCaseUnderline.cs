﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech
{
    public static partial class String
    {
        public static string UnderlineToCamel(this string textWithUnderlines, bool firstLetterUpper = true)
        {
            string[] pieces = textWithUnderlines.Split(new char[] { '_' });
            string noUnderlines = string.Join("", pieces.Where(p => !string.IsNullOrEmpty(p)).Skip(firstLetterUpper ? 0 : 1).Select(p => Char.ToUpper(p[0]) + p.Substring(1)));
            pieces = noUnderlines.Split(new char[] {' '});
            return string.Join("", pieces);
        }

        public static string CamelToUnderline(this string textCamelCased)
        {
            List<int> upPos = new int[] { 0 }.Union(Enumerable.Range(1, textCamelCased.Length - 1).Where(p => Char.IsUpper(textCamelCased[p]))).ToList<int>();
            return string.Join("_", Enumerable.Range(1, upPos.Count - 1).Select(p => textCamelCased.Substring(upPos[p - 1], upPos[p] - upPos[p - 1])));
        }

        public static bool EqualsInclUnderscoreAndCamelcase(this string str1, string str2) {
            if (String.Equals(str1, str2))
                return true;
            if (
                ((str1.IndexOf('_') > -1) || (str2.IndexOf(' ') > -1))
                && String.Equals(str1.UnderlineToCamel().ToLower(), str2.UnderlineToCamel().ToLower())
                )
                return true;

            if (
                ((str1.IndexOf('_') == -1) || (str2.IndexOf(' ') == -1))
                && String.Equals(str1.CamelToUnderline().ToLower(), str2.CamelToUnderline().ToLower())
                )
                return true;

            return false;

        }
    }
}
