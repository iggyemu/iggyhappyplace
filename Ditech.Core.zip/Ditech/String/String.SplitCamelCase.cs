﻿using System.Collections.Specialized;

namespace Ditech
{
    public static partial class String
    {
        /// <summary>
        /// Splits a camel case string.
        /// </summary>
        /// <param name="stringToSplit">The string to split.</param>
        /// <returns>Returns a split string.</returns>
        public static string[] SplitCamelCase(string stringToSplit)
        {
            if (stringToSplit == null)
            {
                return new string[] {}; //Return empty array.
            }

            if (stringToSplit.Length == 0)
            {
                return new[] {string.Empty};
            }
            var words = new StringCollection();

            var wordStartIndex = 0;

            var letters = stringToSplit.ToCharArray();

            // Skip the first letter. we don't care what case it is.
            for (var i = 1; i < letters.Length; i++)
            {
                if (char.IsUpper(letters[i]))
                {
                    //Grab everything before the current index.
                    words.Add(new string(letters, wordStartIndex, i - wordStartIndex));
                    wordStartIndex = i;
                }
            }

            // We need to have the last word.
            words.Add(new string(letters, wordStartIndex, letters.Length - wordStartIndex));

            // Copy to a string array.
            var wordArray = new string[words.Count];
            words.CopyTo(wordArray, 0);

            return wordArray;
        }
    }
}