namespace Ditech
{
    /// <summary>
    /// A utility class containing methods for string manipulation.
    /// </summary>
    public static partial class String
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Replaces the original value of the string with the new value if the string is currently empty.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="defaultValueIfEmpty">The new value.</param>
        /// <returns>Returns a string value.</returns>
        public static string Coalesce(this string value, string defaultValueIfEmpty)
        {
            return value.IsNullOrEmpty(true) ? defaultValueIfEmpty : value;
        }

        #endregion�Methods�
    }
}