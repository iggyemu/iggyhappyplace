

using CarlosAg.ExcelXmlWriter;

namespace Ditech.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Writes the cell value.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <param name="row">The row.</param>
        public static void WriteCellValue(object data, WorksheetRow row)
        {
            WriteCellValue(data, row, string.Empty);
        }

        /// <summary>
        /// Writes the cell value.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <param name="row">The row.</param>
        /// <param name="styleID">The style ID.</param>
        public static void WriteCellValue(object data, WorksheetRow row, string styleID)
        {
            // Create a new cell to hold the data
            var cell = new WorksheetCell();

            if (data != null)
            {
                var stringData = data.ToString();

                var type = data.GetType().ToCarlosAgDataType();

                switch (type)
                {
                    case DataType.DateTime:
                        stringData = Convert.ToDateTimeString(data, Format.DateTimeFormat.SortableDate, true);
                        styleID = styleID.Coalesce("date");
                        break;
                    case DataType.Number:
                        styleID = styleID.Coalesce("number");
                        break;
                    case DataType.Integer:
                        type = DataType.Number;
                        styleID = styleID.Coalesce("integer");
                        break;
                    case DataType.Boolean:
                        stringData = System.Convert.ToInt16(data).ToString();
                        break;
                }

                // Else, create the new cell with the data
                cell = styleID.Length > 0
                           ? new WorksheetCell(stringData, type, styleID)
                           : new WorksheetCell(stringData, type);
            }

            // Add the cell to the row
            row.Cells.Add(cell);
        }
    }
}