

using CarlosAg.ExcelXmlWriter;

namespace Ditech.CarlosAg
{
    /// <summary>
    /// Instantiates the Spreadsheet class.
    /// </summary>
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="book">The book.</param>
        public static void InitializeWorkbook(out Workbook book)
        {
            // Create a new workbook and add a new worksheet
            book = new Workbook();

            var dateStyle = book.Styles.Add("date");
            dateStyle.NumberFormat = "Short Date";

            var numberStyle = book.Styles.Add("number");
            numberStyle.NumberFormat = "#,##0.00##";

            var integerStyle = book.Styles.Add("integer");
            integerStyle.NumberFormat = "#,##0";
        }

        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        public static void InitializeWorkbook(out Workbook book, out Worksheet sheet)
        {
            // Create a new workbook and add a new worksheet
            InitializeWorkbook(out book);

            sheet = book.Worksheets.Add("Sheet1");
        }

        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="headers">The header.</param>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        public static void InitializeWorkbook(string[] headers, out Workbook book, out Worksheet sheet)
        {
            InitializeWorkbook(out book, out sheet);

            var headerRow = CreateHeaderRow(book, sheet);

            // Add a header to each column
            foreach (var header in headers)
            {
                // Add each 
                sheet.Table.Columns.Add(new WorksheetColumn());
                headerRow.Cells.Add(new WorksheetCell(header, "Bold"));
            }
        }
    }
}