

using System;
using System.Globalization;
using CarlosAg.ExcelXmlWriter;

namespace Ditech.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Autoes the size columns.
        /// </summary>
        /// <param name="sheet">The sheet.</param>
        /// <returns></returns>
        public static void AutoSizeColumns(Worksheet sheet)
        {
            for (var i = 0; i < sheet.Table.Columns.Count; i++)
            {
                var columnWidth = 10;

                for (var j = 0; j < sheet.Table.Rows.Count; j++)
                {
                    var data = sheet.Table.Rows[j].Cells[i].Data;

                    if (!string.IsNullOrEmpty(data.Text))
                    {
                        DateTime date;
                        int cellWidth;

                        if (DateTime.TryParseExact(data.Text, "s",
                                                   CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                        {
                            cellWidth = date.ToShortDateString().Length*6;
                        }
                        else
                        {
                            cellWidth = data.Text.Length*6;
                        }

                        if (cellWidth > columnWidth)
                        {
                            columnWidth = cellWidth + 8;
                        }
                    }
                }

                sheet.Table.Columns[i].Width = columnWidth;
            }
        }
    }
}