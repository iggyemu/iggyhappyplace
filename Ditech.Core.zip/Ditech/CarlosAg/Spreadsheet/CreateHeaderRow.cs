

using CarlosAg.ExcelXmlWriter;

namespace Ditech.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Creates the bold header row.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        /// <returns></returns>
        public static WorksheetRow CreateHeaderRow(Workbook book, Worksheet sheet)
        {
            if (book.Styles.IndexOf("Bold") < 0)
            {
                // Add the bold style to the worksheet
                var boldStyle = book.Styles.Add("Bold");
                boldStyle.Font.Bold = true;
                boldStyle.Font.FontName = "Calibri";
                boldStyle.Font.Size = 11;
                boldStyle.Font.Color = "#000000";
            }
            // Initialize the header row
            return sheet.Table.Rows.Add();
        }
    }
}