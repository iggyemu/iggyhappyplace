

using System;
using CarlosAg.ExcelXmlWriter;

namespace Ditech.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Gets the type of the carlos AG data.
        /// </summary>
        /// <param name="dataType">Type of the data.</param>
        /// <returns>CarlosAG Datatype of the passed .NET Type.</returns>
        public static DataType ToCarlosAgDataType(this Type dataType)
        {
            // Convert the Type to its string representation
            var type = dataType.ToString();

            DataType carlosAgDataType;

            // Cut "System." off the string
            type = type.Mid(type.IndexOf('.') + 1).ToLower();

            // Return the match data type in carlos ag
            switch (type)
            {
                    //Number data types
                case "int":
                case "int16":
                case "int32":
                case "int64":
                case "byte":
                    carlosAgDataType = DataType.Integer;
                    break;
                case "decimal":
                case "double":
                    carlosAgDataType = DataType.Number;
                    break;
                    // Boolean data types
                case "boolean":
                    carlosAgDataType = DataType.Boolean;
                    break;
                    // DateTime data type
                case "datetime":
                    carlosAgDataType = DataType.DateTime;
                    break;
                    // String data type
                default:
                    carlosAgDataType = DataType.String;
                    break;
            }

            // If no match was found, return type string
            return carlosAgDataType;
        }
    }
}