

using System.Data;
using CarlosAg.ExcelXmlWriter;

namespace Ditech.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// This override is for single tab spreadsheets only Writes the data reader to spreadsheet.
        /// </summary>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="dataSet">The data reader.</param>
        /// <param name="outputPath">The output path.</param>
        ///<param name="addHeadersForEachTable">if [true] write out the headers after each dataset.</param>
        public static void WriteDataSetToSpreadsheet(bool outputHeaders, DataSet dataSet, string outputPath, bool addHeadersForEachTable)
        {
            WriteDataSetToSpreadsheet(outputHeaders, dataSet, outputPath, true, addHeadersForEachTable);
        }

        /// <summary>
        /// Writes the data reader to spreadsheet.
        /// </summary>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="dataSet">The data reader.</param>
        /// <param name="outputPath">The output path.</param>
        /// <returns></returns>
        private static void WriteDataSetToSpreadsheet(bool outputHeaders, DataSet dataSet, string outputPath, bool singleTab, bool addHeadersForEachTable)
        {
            const int MAX_ROWS = 65536;

            Workbook book;
            Worksheet sheet = null;

            var count = 0;
            var columnCount = 0;

            InitializeWorkbook(out book);

            var spreadsheetCount = 1;
            var newPath = outputPath;

            for (var i = 0; i < dataSet.Tables.Count; i++)
            {
                var table = dataSet.Tables[i];

                if (!singleTab || i == 0)
                {
                    sheet = book.Worksheets.Add(table.TableName.Remove(new[] {"$", "'"}).Left(30));
                }

                while (columnCount < table.Columns.Count)
                {
                    sheet.Table.Columns.Add(new WorksheetColumn());
                    columnCount++;
                }

                if (outputHeaders)
                {
                    if (i == 0 || addHeadersForEachTable)
                    {
                        var headerRow = CreateHeaderRow(book, sheet);

                        // Add a header to each column
                        foreach (DataColumn column in table.Columns)
                        {
                            headerRow.Cells.Add(new WorksheetCell(column.ColumnName, "Bold"));
                        }

                        count++;
                    }
                }

                // Read in the results of the query (one record at a time)
                foreach (DataRow dataRow in table.Rows)
                {
                    if (count >= MAX_ROWS)
                    {
                        var index = outputPath.IndexOf('.');
                        newPath = outputPath.Insert(index, "_" + spreadsheetCount);

                        book.Save(newPath);

                        InitializeWorkbook(outputHeaders, table, out book, out sheet, out count);

                        spreadsheetCount++;
                    }

                    // A new row to the spreadsheet to hold the new record
                    var row = sheet.Table.Rows.Add();

                    // Output each field
                    foreach (DataColumn dataColumn in table.Columns)
                    {
                        // Get the correct data type

                        // Get the data as a string
                        var data = dataRow[dataColumn];

                        WriteCellValue(data, row);

                        if (sheet.Table.Columns.Count < table.Columns.Count)
                        {
                            sheet.Table.Columns.Add();
                        }
                    }

                    count++;
                }

                if (spreadsheetCount == 1)
                {
                    newPath = outputPath;
                }
                else
                {
                    var index = outputPath.IndexOf('.');
                    newPath = outputPath.Insert(index, "_" + spreadsheetCount);
                }

                AutoSizeColumns(sheet);
            }

            // Processing finished, save off the book
            book.Save(newPath);
        }

        /// <summary>
        /// Writes the data reader to spreadsheet.
        /// </summary>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="dataSet">The data reader.</param>
        /// <param name="outputPath">The output path.</param>
        /// <returns></returns>
        public static void WriteDataSetToSpreadsheet(bool outputHeaders, DataSet dataSet, string outputPath)
        {
            WriteDataSetToSpreadsheet(outputHeaders, dataSet, outputPath, false, true);
        }

        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="dataTable">The data table.</param>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        /// <param name="count">The count.</param>
        private static void InitializeWorkbook(bool outputHeaders, DataTable dataTable, out Workbook book,
                                               out Worksheet sheet, out int count)
        {
            InitializeWorkbook(out book, out sheet);

            // Output the headers if needed
            if (outputHeaders)
            {
                var headerRow = CreateHeaderRow(book, sheet);

                // Add a header to each column
                foreach (DataColumn column in dataTable.Columns)
                {
                    // Add each 
                    sheet.Table.Columns.Add(new WorksheetColumn());
                    headerRow.Cells.Add(new WorksheetCell(column.ColumnName, "Bold"));
                }
            }

            count = 0;

            if (outputHeaders)
            {
                count = 1;
            }
        }
    }
}