﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Ditech.Security.Cryptography
{
    using Properties;

    /// <summary>
    /// Static class for Rijndael encryption/decryption.
    /// </summary>
    public static class Rijndael
    {
        /// <summary>
        /// Encrypts the specified text.
        /// </summary>
        /// <param name="textToEncrypt">The text to encrypt.</param>
        /// <param name="salt">The salt.</param>
        /// <returns></returns>
        public static string Encrypt(string textToEncrypt, string salt = null)
        {
            if (string.IsNullOrEmpty(salt))
            {
                salt = Resources.CryptoKey;
            }

            RijndaelManaged rijndaelCipher = CreateCipher(salt);

            ICryptoTransform cryptoTransform = rijndaelCipher.CreateEncryptor();

            byte[] plainText = Encoding.UTF8.GetBytes(textToEncrypt);

            byte[] encryptedData = cryptoTransform.TransformFinalBlock(plainText, 0, plainText.Length);

            return (BitConverter.ToString(encryptedData).Replace("-", string.Empty));
        }

        /// <summary>
        /// Decrypts the specified text.
        /// </summary>
        /// <param name="textToDecrypt">The text to decrypt.</param>
        /// <param name="salt">The salt.</param>
        /// <returns></returns>
        public static string Decrypt(string textToDecrypt, string salt = null)
        {
            if (string.IsNullOrEmpty(salt))
            {
                salt = Resources.CryptoKey;
            }

            RijndaelManaged rijndaelCipher = CreateCipher(salt);

            ICryptoTransform transform = rijndaelCipher.CreateDecryptor();

            List<byte> bytes = new List<byte>();

            for (int i = 0; i < textToDecrypt.Length; i += 2)
            {
                bytes.Add(System.Convert.ToByte(textToDecrypt.Substring(i, 2), 16));
            }

            byte[] byteArray = bytes.ToArray();
            byte[] plainText = transform.TransformFinalBlock(byteArray, 0, byteArray.Length);

            return Encoding.UTF8.GetString(plainText);
        }

        private static RijndaelManaged CreateCipher(string salt)
        {
            byte[] pwdBytes = Encoding.UTF8.GetBytes(salt);

            byte[] keyBytes = new byte[16];

            int len = (pwdBytes.Length > keyBytes.Length) ? keyBytes.Length : pwdBytes.Length;

            Array.Copy(pwdBytes, keyBytes, len);

            return new RijndaelManaged
            {
                Mode = CipherMode.CBC,
                Padding = PaddingMode.PKCS7,
                KeySize = 128,
                BlockSize = 128,
                Key = keyBytes,
                IV = keyBytes
            };
        }
    }
}
