﻿using System.Data;

namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Sorts the table.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <param name="sortCriteria">The sort criteria.</param>
        /// <returns></returns>
        public static DataTable ToSortedDataTable(DataTable table, string sortCriteria)
        {
            var result = new DataTable(table.TableName);

            foreach (DataColumn column in table.Columns)
            {
                result.Columns.Add(column.ColumnName);
            }

            table.DefaultView.Sort = sortCriteria;

            foreach (DataRow row in table.Select())
            {
                var newRow = result.Rows.Add();

                for (int i = 0; i < row.ItemArray.Length; i++)
                {
                    newRow[i] = row[i];
                }
            }

            return result;
        }
    }
}
