﻿#region

using System;
using System.Data;
using System.Text;

#endregion

namespace Ditech
{
     public static partial class Convert
     {
          /// <summary>
          ///      Converts a DataTable to an HTML table with a header row
          /// </summary>
          /// <param name="table">The table.</param>
          /// <param name="bootstrapFormatting">
          ///      This will add the hover highlight and bootstrap formatting included in the
          ///      bootstrap.css and bootstrap.js. These must be added to your project before this formatting will be rendered
          /// </param>
          public static string ToHtmlTable(DataTable table, bool bootstrapFormatting = false,
               bool shortdateFormat = false, bool usePropertyTypes = false)
          {
               var result = new StringBuilder();

               result.Append(bootstrapFormatting
                    ? "<table class=\"table table-bordered table-hover\"><thead>"
                    : "<table border=1 cellspacing=1 cellpadding=1><thead>");

               // add headers
               for (var i = 0; i < table.Columns.Count; i++)
               {
                    result.Append("<th>");
                    result.Append(table.Columns[i].ColumnName);
                    result.Append("</th>");
               }

               result.Append("</thead>");

               // add rows
               for (var i = 0; i < table.Rows.Count; i++)
               {
                    result.Append("<tr>");

                    for (var j = 0; j < table.Columns.Count; j++)
                    {
                        var obj = table.Rows[i][j];
                         var value = Convert.ToString(table.Rows[i][j]);

                         result.Append("<td>");

                        if (usePropertyTypes)
                        {
                            result.Append(AppendTypedValue(obj, shortdateFormat));
                        }
                        else
                        {

                            if (value.IsMoney(true))
                            {
                                result.Append(decimal.Parse(value) < 0
                                    ? "<td style=\"color:red; text-align: right;\">"
                                    : "<td style=\"text-align: right;\">");
                                result.Append(decimal.Parse(value).ToString("C"));
                            }
                            else if (shortdateFormat)
                            {
                                DateTime dateTimeValue;
                                DateTime.TryParse(value, out dateTimeValue);
                                if (dateTimeValue != DateTime.MinValue)
                                {
                                    result.Append(ToDateTimeString(value, "yyyy-MM-dd"));
                                }
                                else
                                {
                                    result.Append(value);
                                }
                            }
                            else
                            {
                                result.Append(value);
                            }
                        }

                        result.Append("</td>");
                    }

                    result.Append("</tr>");
               }
               result.Append("</table>");

               return result.ToString();
          }

         private static string AppendTypedValue(object obj, bool shortdateFormat)
         {
             var type = obj.GetType().ToString().Remove("System.").ToUpper();
             string value;

              switch (type)
              {
                  case "DATETIME":
                      value = ToDateTimeString(obj,
                          shortdateFormat ? Format.DateTimeFormat.SortableShortDate : Format.DateTimeFormat.DefaultDateTime);
                      break;
                  case "INT":
                  case "INT32":
                  case "INT64":
                      value = ToDecimalString(obj, true, Format.NumberFormat.Number);
                      break;
                  case "FLOAT":
                  case "DECIMAL":
                      value = ToDecimalString(obj, true, Format.NumberFormat.Currency);
                      break;
                  case "DOUBLE":
                      value = ToDecimalString(obj, true, Format.NumberFormat.Percent);
                      break;
                  default:
                      value = ToString(obj);
                      break;
              }

              return value;
          }
     }
}