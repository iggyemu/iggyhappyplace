﻿#region

using System;
using System.Data;
using System.Data.OleDb;
using System.IO;

#endregion

namespace Ditech
{
    /// <summary>
    /// A utility class containing methods to help with data type conversions. 
    /// </summary>
    public static partial class Convert
    {
        private const string excelConnectionString =
            "Provider=Microsoft.{0}.OLEDB.{1};Data Source={2};Extended Properties=\"{3};HDR={4}\"";
 
        /// <summary>
        /// Converts an Excel spreadsheet to a DataSet using OLEDB.  Supports XLS, XLSB, and XLSX file extensions.
        /// </summary>
        /// <param name="inputFile">The excel spread sheet.</param>
        /// <param name="hasHeader">if set to <c>true</c> [has header].</param>
        /// <returns>DataSet containing the spreadsheet data.</returns>
        public static DataSet ToDataSet(FileInfo inputFile, bool hasHeader)
        {
            var inputDataSet = new DataSet();

            var fileExtension = inputFile.Extension;

            var header = hasHeader ? "YES" : "NO";

            string connectionString;

            switch (fileExtension.ToLower())
            {
                case ".xls":
                    connectionString = string.Format(excelConnectionString, "Ace", "12.0", inputFile.FullName, "Excel 8.0", header);
                    break;
                case ".xlsb":
                    connectionString = string.Format(excelConnectionString, "Ace", "12.0", inputFile.FullName, "Excel 12.0", header);
                    break;
                case ".xlsx":
                    connectionString = string.Format(excelConnectionString, "Ace", "12.0", inputFile.FullName, "Excel 12.0 Xml", header);
                    break;
                default:
                    throw new NotSupportedException("File type not supported: " + inputFile.Name);
            }

            // Open db connection to Excel
            using (var dbConnection = new OleDbConnection(connectionString))
            {
                dbConnection.Open();

                // initialize DataTable and get the schema to find sheet name
                var inputDataTable =
                    dbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] {null, null, null, "TABLE"});

                foreach (DataRow row in inputDataTable.Rows)
                {
                    // '2' is the location of 'TABLE_NAME' in the returned schema
                    var tableName = ToString(row.ItemArray[2]);

                    if (!tableName.StartsWith("_xlnm#"))
                    {
                        // Get all data from the table
                        var dbInputAdapter =
                            new OleDbDataAdapter("SELECT * FROM [" + tableName + "]", dbConnection);

                        // Clear the dataTable for the new data
                        var table = new DataTable();


                        try
                        {
                            // Fill the dataTable with the new data
                            dbInputAdapter.Fill(table);

                            table.TableName = tableName.Remove("'");

                            inputDataSet.Tables.Add(table);
                        }
#pragma warning disable 168
                        catch (OleDbException ex)
#pragma warning restore 168
                        {

                        }
                    }
                }
            }

            return inputDataSet;
        }

        /// <summary>
        /// Converts a DataTable to DataSet.
        /// </summary>
        /// <param name="dataTable">The DataTable to be converted to a DataSet.</param>
        /// <returns></returns>
        public static DataSet ToDataSet(DataTable dataTable)
        {
            var result = new DataSet();

            result.Tables.Add(dataTable);

            return result;
        }
    }
}