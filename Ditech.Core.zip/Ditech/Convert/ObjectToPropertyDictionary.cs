﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Ditech.Data;

namespace Ditech
{
    public static class ObjectToPropertyDictionary
    {
        private static Dictionary<Type, Delegate> mTypeDictionaryizerCacheDict = new Dictionary<Type, Delegate>();

        public static Func<T, Dictionary<string, object>> GetPropertyDictionaryizerFunc<T>() where T: class
        {

            var sourceProperties = typeof(T).GetProperties();
            System.Reflection.MethodInfo addMethod = typeof(Dictionary<string, object>).GetMethod("Add");

            // Create two ElementInit objects that represent the
            // two key-value pairs to add to the Dictionary.
            List<ElementInit> initExpressions = new List<ElementInit>(sourceProperties.Length);
            ParameterExpression sourceParam = Expression.Parameter(typeof(LogEntry), "source");
            foreach (var prop in sourceProperties)
            {
                var sourcePropertyRead = Expression.MakeMemberAccess(sourceParam, prop);
                Expression typeConverter = Expression.Convert(sourcePropertyRead, typeof(object));
                System.Linq.Expressions.ElementInit elementInit =
                    System.Linq.Expressions.Expression.ElementInit(
                        addMethod,
                        System.Linq.Expressions.Expression.Constant(prop.Name),
                        typeConverter);
                initExpressions.Add(elementInit);
            }

            // Create a NewExpression that represents constructing
            // a new instance of Dictionary<int, string>.
            System.Linq.Expressions.NewExpression newDictionaryExpression =
                System.Linq.Expressions.Expression.New(typeof(Dictionary<string, object>));

            // Create a ListInitExpression that represents initializing
            // a new Dictionary<> instance with two key-value pairs.
            System.Linq.Expressions.ListInitExpression listInitExpression =
                System.Linq.Expressions.Expression.ListInit(newDictionaryExpression, initExpressions);

            var delg = Expression.Lambda<Func<T, Dictionary<string, object>>>(listInitExpression, sourceParam);
            var result = delg.Compile();
            return result;
        }

        public static Dictionary<string, object> ToPropertyDictionary<T>(this T obj) where T: class
        {
            Func<T, Dictionary<string, object>> converterFunc = null;
            Type t = typeof (T);
            if (mTypeDictionaryizerCacheDict.ContainsKey(t))
                converterFunc = (Func<T, Dictionary<string, object>>) mTypeDictionaryizerCacheDict[t];
            else
            {
                converterFunc = GetPropertyDictionaryizerFunc<T>();
                mTypeDictionaryizerCacheDict[t] = converterFunc;
            }
            return converterFunc(obj);
        }


    }
}
