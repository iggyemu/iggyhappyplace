#region

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;

#endregion

namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Creates a DataTable from the information contained in a file.  Supports extensions XLS, XLSB, XLSX, and CSV. Any other extension is treated a text delimited files.  Delimiter is ignored if the file not text delimited.
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="hasHeader">if set to <c>true</c> [has header].</param>
        /// <returns>DataTable containing the input file data.</returns>
        [Obsolete]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public static DataTable ToDataTable(FileInfo inputFile, bool hasHeader)
        {
            return ToDataTable(inputFile, hasHeader, '\t');
        }

        /// <summary>
        /// Creates a DataTable from the information contained in a file.  Supports extensions XLS, XLSB, XLSX, and CSV. Any other extension is treated a text delimited files.  Delimiter is ignored if the file not text delimited.
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="hasHeader">if set to <c>true</c> [has header].</param>
        /// <returns>DataTable containing the input file data.</returns>
        [Obsolete]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public static DataTable ToDataTable(FileInfo inputFile, char delimiter, bool hasHeader)
        {
            return ToDataTable(inputFile, hasHeader, delimiter);
        }

        /// <summary>
        /// Creates a DataTable from the information contained in a file.  Supports extensions XLS, XLSB, XLSX, and CSV. Any other extension is treated a text delimited files.  Delimiter is ignored if the file not text delimited.
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="hasHeader">if set to <c>true</c> [has header].</param>
        /// <returns>DataTable containing the input file data.</returns>
        public static DataTable ToDataTable(FileInfo inputFile, bool hasHeader = true, char delimiter = '\t')
        {
            DataTable dataTable;

            switch (inputFile.Extension.ToUpper())
            {
                case ".XLS":
                case ".XLSB":
                case ".XLSX":
                    dataTable = ProcessExcelFile(inputFile, hasHeader);
                    break;
                case ".CSV":
                    dataTable = ProcessCsvFile(inputFile, hasHeader);
                    break;
                default:
                    dataTable = ProcessDelimitedFile(inputFile, hasHeader, delimiter);
                    break;
            }

            return dataTable;
        }
        /// <summary>
        /// Converts a list to a data table
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            var props =TypeDescriptor.GetProperties(typeof(T));
            var table = new DataTable();
            for (var i = 0; i < props.Count; i++)
            {
                var prop = props[i];
                table.Columns.Add(prop.Name);
            }
            var values = new object[props.Count];
            foreach (var item in data)
            {
                for (var i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }

            //var specialProperites = TypeDescriptor.GetProperties(typeof (T), new Attribute[] {new System.ComponentModel.DisplayNameAttribute()});

            //if(specialProperites.Count>0)
            //{
            //    foreach (PropertyDescriptor prop in specialProperites)
            //    {
            //        foreach (var a in prop.Attributes)
            //        {
            //            var display = a as System.ComponentModel.DisplayNameAttribute;
            //            if (display != null)
            //            {
            //                table.Columns[prop.Name].ColumnName = display.DisplayName;
            //                break;
            //            }
            //        } 
            //    }

            //}

            return table;
        }
        private static DataTable ProcessDelimitedFile(FileInfo inputFile, bool hasHeader, char delimiter)
        {
            string filename = inputFile.FullName;
            var dataTable = new DataTable();

            using (var input = new StreamReader(filename))
            {
                string line;

                if (hasHeader)
                {
                    // first line has headers
                    line = input.ReadLine();
                    CreateColumns(line, delimiter, dataTable, true);
                }

                // fill the rest of the table; positional
                while ((line = input.ReadLine()) != null)
                {
                    // If the input file doesn't have headers, then just output columns.
                    if (!hasHeader)
                    {
                        CreateColumns(line, delimiter, dataTable, false);
                        hasHeader = true;
                    }

                    DataRow row = dataTable.NewRow();
                    string[] fields = line.Split(delimiter);

                    for (int i = 0; i < fields.Length; i++)
                    {
                        row[i] = fields[i];
                    }

                    dataTable.Rows.Add(row);
                }
            }

            return dataTable;
        }

        /// <summary>
        /// Creates the columns.
        /// </summary>
        /// <param name="line">The line.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="dt">The datatable.</param>
        /// <param name="isHeaderLine">if set to <c>true</c> [is header line].</param>
        private static void CreateColumns(string line, char delimiter, DataTable dt, bool isHeaderLine)
        {
            if (line != null)
            {
                string[] fields = line.Split(delimiter);

                foreach (string s in fields)
                {
                    if (isHeaderLine)
                    {
                        dt.Columns.Add(s);
                    }
                    else
                    {
                        dt.Columns.Add();
                    }
                }
            }
            else
            {
                // it's empty, that's an error
                throw new ApplicationException("The data provided is not in a valid format.");
            }
        }

        /// <summary>
        /// Parses a CSV file into a DataTable.
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="hasHeaderRow">if set to <c>true</c> [has header row].</param>
        /// <returns>DataTable containing the input file data.</returns>
        private static DataTable ProcessCsvFile(FileInfo inputFile, bool hasHeaderRow)
        {
            string inputString = File.ReadAllText(inputFile.FullName);

            var table = new DataTable();

            // declare the Regular Expression that will match versus the input string
            var expression =
                new Regex("((?<field>[^\",\\r\\n]+)|\"(?<field>([^\"]|\"\")+)\")(,|(?<rowbreak>\\r\\n|\\n|$))");

            var fieldArray = new List<string>();
            var rowArray = new List<List<string>>();

            int maxColumnCount = 0;

            MatchCollection matches = expression.Matches(inputString);
            string rowbreak = string.Empty;

            foreach (Match match in matches)
            {
                // retrieve the field and replace two double-quotes with a single double-quote
                string field = match.Result("${field}").Replace("\"\"", "\"");
                rowbreak = match.Result("${rowbreak}");

                if (field.Length > 0)
                {
                    fieldArray.Add(field);
                }

                if (rowbreak.Length != 0)
                {
                    // add the column array to the row Array List
                    rowArray.Add(fieldArray);

                    if (fieldArray.Count > maxColumnCount)
                    {
                        maxColumnCount = fieldArray.Count;
                    }

                    // create a new Array List to hold the field values
                    fieldArray = new List<string>();
                }
            }

            if (rowbreak.Length == 0)
            {
                // add the column array to the row Array List
                rowArray.Add(fieldArray);

                if (fieldArray.Count > maxColumnCount)
                {
                    maxColumnCount = fieldArray.Count;
                }
            }

            if (hasHeaderRow)
            {
                List<string> headerRow = rowArray[0];

                for (int i = 0; i < headerRow.Count; i++)
                {
                    string columnName = headerRow[i];
                    int increment = 1;

                    while (table.Columns.Contains(columnName))
                    {
                        columnName = headerRow[i] + increment;
                        increment++;
                    }

                    table.Columns.Add(columnName);
                }


            }
            else
            {
                // create the columns for the table
                for (int i = 0; i < maxColumnCount; i++)
                {
                    table.Columns.Add();
                }
            }

            for (var i = hasHeaderRow ? 1 : 0; i < rowArray.Count; i++)
            {
                var row = rowArray[i];

                // create a new DataRow
                DataRow newRow = table.NewRow();

                // add each field into the new DataRow
                for (int j = 0; j < row.Count; j++)
                {
                    newRow[j] = row[j];
                }

                // add the new DataRow to the DataTable
                table.Rows.Add(newRow);
            }

            //foreach (var row in rowArray)
            //{

            //    // create a new DataRow
            //    DataRow newRow = table.NewRow();

            //    // add each field into the new DataRow
            //    for (int j = 0; j < row.Count; j++)
            //    {
            //        newRow[j] = row[j];
            //    }

            //    // add the new DataRow to the DataTable
            //    table.Rows.Add(newRow);
            //}

            // in case no data was parsed, create a single column
            if (table.Columns.Count == 0)
            {
                table.Columns.Add("NoData");
            }

            return table;
        }

        /// <summary>
        /// Creates a DataTable from the information contained in a file.
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="hasHeader">if set to <c>true</c> [has header].</param>
        /// <returns>
        /// DataTable containing the input file data.
        /// </returns>
        private static DataTable ProcessExcelFile(FileInfo inputFile, bool hasHeader)
        {
            var result = new DataTable();

            DataSet dataSet = ToDataSet(inputFile, hasHeader);

            if (dataSet.Tables.Count > 0)
            {
                result = dataSet.Tables[0];
            }

            return result;
        }

    }
}