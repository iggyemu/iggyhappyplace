#region

using System;

#endregion

namespace Ditech
{
    public static partial class Convert
    {
        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Returns a decimal value of 0 if the conversion fails.</returns>
        public static decimal ToDecimal(object value)
        {
            return ToDecimal(value, false);
        }

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="throwException">if set to <c>true</c> [throws InvalidOperationEexception] on conversion failure, else returns 0.</param>
        /// <returns>Returns a decimal value.</returns>
        public static decimal ToDecimal(object value, bool throwException)
        {
            decimal result;

            if (!decimal.TryParse(ToString(value), out result) && throwException)
            {
                throw new InvalidOperationException("Unable to convert to decimal" + value != null
                                                        ? ": " + value
                                                        : string.Empty);
            }

            return result;
        }

        /// <summary>
        /// Converts a zoned value to decimal format.
        /// </summary>
        /// <param name="zonedValue">The value.</param>
        /// <param name="decimalPlaces">The decimal places.</param>
        /// <returns>Returns a decimal value containing the specified number of decimal places.</returns>
        public static decimal ToDecimal(string zonedValue, int decimalPlaces)
        {
            var result = zonedValue.Trim().Left(zonedValue.Length - 1);
            var lastDigit = string.Empty;

            switch (zonedValue.Right(1))
            {
                case "{":
                    lastDigit = "0";
                    break;
                case "A":
                    lastDigit = "1";
                    break;
                case "B":
                    lastDigit = "2";
                    break;
                case "C":
                    lastDigit = "3";
                    break;
                case "D":
                    lastDigit = "4";
                    break;
                case "E":
                    lastDigit = "5";
                    break;
                case "F":
                    lastDigit = "6";
                    break;
                case "G":
                    lastDigit = "7";
                    break;
                case "H":
                    lastDigit = "8";
                    break;
                case "I":
                    lastDigit = "9";
                    break;
                case "}":
                    lastDigit = "0-";
                    break;
                case "J":
                    lastDigit = "1-";
                    break;
                case "K":
                    lastDigit = "2-";
                    break;
                case "L":
                    lastDigit = "3-";
                    break;
                case "M":
                    lastDigit = "4-";
                    break;
                case "N":
                    lastDigit = "5-";
                    break;
                case "O":
                    lastDigit = "6-";
                    break;
                case "P":
                    lastDigit = "7-";
                    break;
                case "Q":
                    lastDigit = "8-";
                    break;
                case "R":
                    lastDigit = "9-";
                    break;
            }

            result += lastDigit;

            var number = decimal.Parse(result);

            if (!result.Contains("."))
            {
                number = number/(ToDecimal(Math.Pow(10, decimalPlaces)));
            }

            return number;
        }

        #endregion�Methods�
    }
}