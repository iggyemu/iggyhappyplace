﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Linq.Expressions;
using Ditech;

namespace Ditech
{
    public static class PropertywiseInstantiator
    {
        public static Func<DataRow, T> ConstructPropertywiseInstantiatorFromDatarow<T>(IEnumerable<string> fieldNamesInOrder)
        {
            Dictionary<string, int> mapColumnNameToIndex = new Dictionary<string, int>(StringComparer.CurrentCultureIgnoreCase);
            int o = 0;
            foreach (string fieldName in fieldNamesInOrder)
                mapColumnNameToIndex[fieldName] = o++;

            var createdType = typeof(T);
            var ctor = Expression.New(createdType);
            var dataRowParam = Expression.Parameter(typeof(DataRow), "row");

            List<MemberBinding> memberBindingList = new List<MemberBinding>();
            var properties = typeof(T).GetProperties();

            foreach (var property in properties)
            {
                if (mapColumnNameToIndex.ContainsKey(property.Name))
                {
                    Expression columnIndexer = Expression.Property(dataRowParam, "Item", new Expression[] { Expression.Constant(mapColumnNameToIndex[property.Name]) });
                    Expression typeConverter = Expression.Convert(columnIndexer, property.PropertyType);
                    var propertyAssignment = Expression.Bind(property, typeConverter);
                    memberBindingList.Add(propertyAssignment);
                }
            }
            var memberInit = Expression.MemberInit(ctor, memberBindingList.ToArray());
            var delg = Expression.Lambda<Func<DataRow, T>>(memberInit, dataRowParam);
            var result = delg.Compile();
            return result;
        }
        public static Func<DataRow, T> ConstructPropertywiseInstantiatorFromDatarow<T>(DataTable tbl)
        {
            return ConstructPropertywiseInstantiatorFromDatarow<T>(tbl.Columns.Cast<DataColumn>().Select(c => c.ColumnName));
        }
        public static Func<IDataReader, T> ConstructPropertywiseInstantiatorFromDataReader<T>(IDataReader reader)
        {
            Dictionary<string, int> mapColumnNameToIndex = new Dictionary<string, int>(StringComparer.CurrentCultureIgnoreCase);
            int o = 0;
            foreach (string fieldName in Enumerable.Range(0,reader.FieldCount).Select(n => reader.GetName(n)))
                mapColumnNameToIndex[fieldName] = o++;

            var createdType = typeof(T);
            var ctor = Expression.New(createdType);
            var dataReaderParam = Expression.Parameter(typeof(IDataReader), "reader");

            List<MemberBinding> memberBindingList = new List<MemberBinding>();
            var properties = typeof(T).GetProperties();
            var getPropInfo = typeof(IDataRecord).GetProperty("Item", new[] { typeof(string) });

            foreach (var property in properties)
            {
                string matchingKey =
                    mapColumnNameToIndex.Keys.FirstOrDefault(k => k.EqualsInclUnderscoreAndCamelcase(property.Name));
                if (matchingKey != null)
                {
                    // Expression columnIndexer = Expression.Property(dataReaderParam, "Item", new Expression[] { Expression.Constant(mapColumnNameToIndex[property.Name]) });
                    Expression columnIndexer = Expression.MakeIndex(dataReaderParam, getPropInfo, new[] { Expression.Constant(matchingKey, typeof(string)) });
                    Expression typeConverter = Expression.Convert(columnIndexer, property.PropertyType);
                    var propertyAssignment = Expression.Bind(property, typeConverter);
                    memberBindingList.Add(propertyAssignment);
                }
            }
            var memberInit = Expression.MemberInit(ctor, memberBindingList.ToArray());
            var delg = Expression.Lambda<Func<IDataReader, T>>(memberInit, dataReaderParam);
            var result = delg.Compile();
            return result;
        }

        public static Func<S, T> ConstructGenericPropertywiseInstantiator<S, T>()
        {
            var sourceProperties = typeof(S).GetProperties();
            var targetProperties = typeof(T).GetProperties();

            var createdType = typeof(T);
            var ctor = Expression.New(createdType);
            var sourceParam = Expression.Parameter(typeof(S), "source");

            List<MemberBinding> memberBindingList = new List<MemberBinding>();
            foreach (var prop in sourceProperties)
            {
                var targetProp = targetProperties.FirstOrDefault(t => prop.Name.EqualsInclUnderscoreAndCamelcase(t.Name));
                if (targetProp == null)
                    continue;

                var sourcePropertyRead = Expression.MakeMemberAccess(sourceParam, prop);
                Expression typeConverter = Expression.Convert(sourcePropertyRead, targetProp.PropertyType);
                var propertyAssignment = Expression.Bind(targetProp, typeConverter);
                memberBindingList.Add(propertyAssignment);

            }
            var memberInit = Expression.MemberInit(ctor, memberBindingList.ToArray());
            var delg = Expression.Lambda<Func<S, T>>(memberInit, sourceParam);
            var result = delg.Compile();
            return result;
        }

    }
}
