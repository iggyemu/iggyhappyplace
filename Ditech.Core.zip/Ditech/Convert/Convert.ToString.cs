namespace Ditech
{
    public static partial class Convert
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Converts to string from a value, or empty string if it's null.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Returns a string from value</returns>
        public static string ToString(object value)
        {
            return value != null ? value.ToString() : string.Empty;
        }

        #endregion�Methods�
    }
}