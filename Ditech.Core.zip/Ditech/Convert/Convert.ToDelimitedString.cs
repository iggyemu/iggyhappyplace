﻿using System;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;

namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Converts a DataTable to a delimited string for output to a file.
        /// </summary>
        /// <param name="dataTable">The data table.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="isHeaderRowIncluded">if set to <c>true</c> [is header row included].</param>
        /// <param name="isOutputFormattedForExcel">if set to <c>true</c> [is output formatted for excel].</param>
        /// <returns></returns>
        public static string ToDelimitedString(this DataTable dataTable, string delimiter, bool isHeaderRowIncluded, bool isOutputFormattedForExcel)
        {
            
            var stringBuilder = new StringBuilder();
            
            if (isHeaderRowIncluded)
            {
                for (var i = 0; i < dataTable.Columns.Count; i++)
                {
                    if (i > 0)
                    {
                        stringBuilder.Append(delimiter);
                    }

                    stringBuilder.Append(dataTable.Columns[i].ColumnName);
                }

                stringBuilder.AppendLine();
            } 

            foreach (DataRow dataRow in dataTable.Rows)
            {
                for (var i = 0; i < dataTable.Columns.Count; i++)
                {
                    if (i > 0)
                    {
                        stringBuilder.Append(delimiter);
                    }
                    
                      var regex = new Regex("</?(.*)>", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    //var dataElement = ToString(dataRow[i]);
                      var dataElement = regex.Replace(ToString(dataRow[i]), string.Empty);

                      if (isOutputFormattedForExcel)
                      {
                          var type = dataTable.Columns[i].DataType;

                          if (type == typeof(DateTime))
                          {
                              var date = ToNullableDateTime(dataRow[i]);

                              if (date != null)
                              {
                                  var format = date.Value.TimeOfDay == new TimeSpan(0, 0, 0)
                                                   ? "MM/dd/yyyy"
                                                   : "MM/dd/yyyy hh:mm:ss tt";

                                  dataElement = ToDateTimeString(date.Value, format);

                                  dataElement = FormatCsvValue(dataElement);
                              }
                          }

                          if (dataTable.Columns[i].DataType == typeof(string))
                          {
                              dataElement = FormatCsvValue(dataElement);
                          }
                      }

                    stringBuilder.Append(dataElement);
                }

                stringBuilder.AppendLine();
            }

            return stringBuilder.ToString();
        }

        private static string FormatCsvValue(string value)
        {
            return string.Format("=\"{0}\"", value);
        }


        /// <summary>
        /// Converts a DataReader to a delimited string for output to a file.
        /// </summary>
        /// <param name="dataReader">The data reader.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="isHeaderRowIncluded">if set to <c>true</c> [is header row included].</param>
        /// <param name="isOutputFormattedForExcel">if set to <c>true</c> [is output formatted for excel].</param>
        /// <returns>String representation of the data reader.</returns>
        public static string ToDelimitedString(this IDataReader dataReader, string delimiter, bool isHeaderRowIncluded, bool isOutputFormattedForExcel)
        {
            var stringBuilder = new StringBuilder();

            if (isHeaderRowIncluded)
            {
                for (var i = 0; i < dataReader.FieldCount; i++)
                {
                    if (i > 0)
                    {
                        stringBuilder.Append(delimiter);
                    }

                    stringBuilder.Append(dataReader.GetName(i));
                }

                stringBuilder.AppendLine();
            }

            while(dataReader.Read())
            {
                for (var i = 0; i < dataReader.FieldCount; i++)
                {
                    if (i > 0)
                    {
                        stringBuilder.Append(delimiter);
                    }

                    string dataElement = ToString(dataReader[i]);
                    if (isOutputFormattedForExcel && dataElement.Length > 0 && dataElement.Left(1).Equals("0") && dataElement.IsNumeric(false, false))
                    {
                        dataElement = string.Format("=\"{0}\"", dataElement);
                    }

                    stringBuilder.Append(dataElement);
                }

                stringBuilder.AppendLine();
            }

            return stringBuilder.ToString();
        }
    }
}