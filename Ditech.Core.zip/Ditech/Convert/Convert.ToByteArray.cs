﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Converts a serializable object into a byte array
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static byte[] ToByteArray(object obj)
        {
            try
            {
                var binaryFormatter = new BinaryFormatter();
                var memoryStream = new MemoryStream();

                binaryFormatter.Serialize(memoryStream, obj);

                return memoryStream.ToArray();
            }
            catch(Exception ex)
            {
                //Show exception message
                Console.WriteLine(ex.Message);

                return null;
            }
        }
    }
}
