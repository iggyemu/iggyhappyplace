﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a int.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// Returns a decimal value of 0 if the conversion fails.
        /// </returns>
        public static int? ToNullableInt(object value)
        {
            int? result = null;

            int number;

            if (int.TryParse(ToString(value), out number))
            {
                result = number;
            }

            return result;
        }
    }
}
