namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>A string representation of the decimal.</returns>
        public static string ToDecimalString(object value)
        {
            return ToDecimalString(value, true);
        }

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="blankIsZero">if set to <c>true</c> result will be an empty string on conversion failure, else the result will be "0".</param>
        /// <returns>A string representation of the decimal.</returns>
        public static string ToDecimalString(object value, bool blankIsZero)
        {
            return ToDecimalString(value, blankIsZero, Format.NumberFormat.General);
        }

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="blankIsZero">if set to <c>true</c> result will be an empty string on conversion failure, else the result will be "0".</param>
        /// <param name="numberFormat">The number format.</param>
        /// <returns>A string representation of the decimal.</returns>
        public static string ToDecimalString(object value, bool blankIsZero, Format.NumberFormat numberFormat)
        {
            return ToDecimalString(value, blankIsZero, Format.NumberFormatString(numberFormat));
        }

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="blankIsZero">if set to <c>true</c> result will be an empty string on conversion failure, else the result will be "0".</param>
        /// <param name="numberFormat">The number format.</param>
        /// <param name="decimalPlaces">The decimal places.</param>
        /// <returns>A string representation of the decimal.</returns>
        public static string ToDecimalString(object value, bool blankIsZero, Format.NumberFormat numberFormat,
                                             int decimalPlaces)
        {
            return ToDecimalString(value, blankIsZero, Format.NumberFormatString(numberFormat, decimalPlaces));
        }

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="blankIsZero">if set to <c>true</c> result will be an empty string on conversion failure, else the result will be "0".</param>
        /// <param name="format">The output numeric format.</param>
        /// <returns>A string representation of the decimal.</returns>
        public static string ToDecimalString(object value, bool blankIsZero, string format)
        {
            var result = string.Empty;

            if (blankIsZero)
            {
                result = ToDecimal(value).ToString(format);
            }
            else
            {
                if (value != null)
                {
                    decimal number;

                    if (decimal.TryParse(value.ToString(), out number))
                    {
                        result = number.ToString(format);
                    }
                }
            }

            return result;
        }
    }
}