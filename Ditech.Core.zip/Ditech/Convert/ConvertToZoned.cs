

using System;
using EverBank.String;

namespace EverBank
{
    public static partial class Numbers
    {
        /// <summary>
        /// Converts a decimal string to zoned format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Zoned EBCDIC value</returns>
        public static string ConvertToZoned(string value)
        {
            bool isNegativeNumber = decimal.Parse(value) < 0 ? true : false;

            value = Math.Abs(decimal.Parse(value)).ToString();

            string result = value.Left(value.Length - 1);

            string lastDigit = string.Empty;

            if (isNegativeNumber)
            {
                switch (value.Right(1))
                {
                    case "0":
                        lastDigit = "}";
                        break;
                    case "1":
                        lastDigit = "J";
                        break;
                    case "2":
                        lastDigit = "K";
                        break;
                    case "3":
                        lastDigit = "L";
                        break;
                    case "4":
                        lastDigit = "M";
                        break;
                    case "5":
                        lastDigit = "N";
                        break;
                    case "6":
                        lastDigit = "O";
                        break;
                    case "7":
                        lastDigit = "P";
                        break;
                    case "8":
                        lastDigit = "Q";
                        break;
                    case "9":
                        lastDigit = "R";
                        break;
                }
            }
            else
            {
                switch (value.Right(1))
                {
                    case "0":
                        lastDigit = "{";
                        break;
                    case "1":
                        lastDigit = "A";
                        break;
                    case "2":
                        lastDigit = "B";
                        break;
                    case "3":
                        lastDigit = "C";
                        break;
                    case "4":
                        lastDigit = "D";
                        break;
                    case "5":
                        lastDigit = "E";
                        break;
                    case "6":
                        lastDigit = "F";
                        break;
                    case "7":
                        lastDigit = "G";
                        break;
                    case "8":
                        lastDigit = "H";
                        break;
                    case "9":
                        lastDigit = "I";
                        break;
                }
            }

            result = result + lastDigit;

            return result;
        }

        /// <summary>
        /// Converts a decimal string to zoned format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Zoned EBCDIC value</returns>
        public static string ConvertToZoned(decimal value)
        {
            return ConvertToZoned(value.ToString());
        }

        /// <summary>
        /// Converts a decimal string to zoned format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Zoned EBCDIC value</returns>
        public static string ConvertToZoned(int value)
        {
            return ConvertToZoned(value.ToString());
        }

        /// <summary>
        /// Converts a decimal string to zoned format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Zoned EBCDIC value</returns>
        public static string ConvertToZoned(long value)
        {
            return ConvertToZoned(value.ToString());
        }
    }
}
