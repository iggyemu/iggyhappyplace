#region

using System;

#endregion

namespace Ditech
{
    public static partial class Convert
    {
        #region�Methods�(4)�

        //�Public�Methods�(4)�

        /// <summary>
        /// Converts a numeric value to zoned format.  The method can also take string representations of numeric values.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <param name="nullReturnsDefaultValue">if set to <c>true</c> [null returns default value].</param>
        /// <param name="emptyReturnsDefaultValue">if set to <c>true</c> [empty returns default value].</param>
        /// <param name="exceptionReturnsDefaultValue">if set to <c>true</c> [exception returns default value].</param>
        /// <returns>Zoned EBCDIC value.</returns>
        public static string ToZonedString(object value, string defaultValue, bool nullReturnsDefaultValue,
                                           bool emptyReturnsDefaultValue, bool exceptionReturnsDefaultValue)
        {
            string result;

            if (value == null)
            {
                result = nullReturnsDefaultValue ? defaultValue : null;
            }
            else if (value.ToString().Trim().Length == 0)
            {
                result = emptyReturnsDefaultValue ? defaultValue : string.Empty;
            }
            else if (exceptionReturnsDefaultValue)
            {
                try
                {
                    result = ToZonedString(value);
                }
                catch
                {
                    result = defaultValue;
                }
            }
            else
            {
                result = ToZonedString(value);
            }

            return result;
        }

        /// <summary>
        /// Converts a numeric value to zoned format.  The method can also take string representations of numeric values.
        /// </summary>  
        /// <param name="value">The value.</param>
        /// <returns>Zoned EBCDIC value</returns>
        public static string ToZonedString(object value)
        {
            string result = string.Empty;

            if (value != null && value.ToString() != string.Empty)
            {
                var valueString = ToDecimalString(value, false, "0.00");

                decimal number;

                if (!decimal.TryParse(valueString, out number))
                {
                    throw new InvalidOperationException("The value is not numeric:\t" + value);
                }

                var isNegativeNumber = number < 0 ? true : false;

                // Remove decimal.  Zoned values cannot have decimals.
                var stringValue = Math.Abs(number).ToString().Remove(".");

                result = stringValue.Left(stringValue.Length - 1);

                var lastZonedDigit = string.Empty;

                var lastOriginalDigit = stringValue.Right(1);

                if (isNegativeNumber)
                {
                    switch (lastOriginalDigit)
                    {
                        case "0":
                            lastZonedDigit = "}";
                            break;
                        case "1":
                            lastZonedDigit = "J";
                            break;
                        case "2":
                            lastZonedDigit = "K";
                            break;
                        case "3":
                            lastZonedDigit = "L";
                            break;
                        case "4":
                            lastZonedDigit = "M";
                            break;
                        case "5":
                            lastZonedDigit = "N";
                            break;
                        case "6":
                            lastZonedDigit = "O";
                            break;
                        case "7":
                            lastZonedDigit = "P";
                            break;
                        case "8":
                            lastZonedDigit = "Q";
                            break;
                        case "9":
                            lastZonedDigit = "R";
                            break;
                    }
                }
                else
                {
                    switch (lastOriginalDigit)
                    {
                        case "0":
                            lastZonedDigit = "{";
                            break;
                        case "1":
                            lastZonedDigit = "A";
                            break;
                        case "2":
                            lastZonedDigit = "B";
                            break;
                        case "3":
                            lastZonedDigit = "C";
                            break;
                        case "4":
                            lastZonedDigit = "D";
                            break;
                        case "5":
                            lastZonedDigit = "E";
                            break;
                        case "6":
                            lastZonedDigit = "F";
                            break;
                        case "7":
                            lastZonedDigit = "G";
                            break;
                        case "8":
                            lastZonedDigit = "H";
                            break;
                        case "9":
                            lastZonedDigit = "I";
                            break;
                    }
                }
                result += lastZonedDigit;
            }


            return result;
        }

        #endregion�Methods�
    }
}