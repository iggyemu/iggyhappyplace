﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Ditech
{
    /// <summary>
    /// A utility class containing methods to help with data type conversions. 
    /// </summary>
    public static partial class Convert
    {
        /// <summary>
        /// Creates a generic list from DataTable used as an extension method
        /// </summary>
        /// <returns>DataTable as a generic list</returns>
        public static List<T> DataTableToList<T>(this DataTable dt)
        {
            var columnNames = dt.Columns.Cast<DataColumn>()
                .Select(c => c.ColumnName)
                .ToList();

            var properties = typeof (T).GetProperties();

            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();

                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name))
                        pro.SetValue(objT, row[pro.Name] == DBNull.Value ? string.Empty : row[pro.Name]);
                }

                return objT;
            }).ToList();

        }
    }
}
