﻿using System;

namespace Ditech
{
    public static partial class Convert
    {

        /// <summary>
        /// Converts the object to a nullable DateTime object.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Converted nullable DateTime object, will be null if conversion failed.</returns>
        public static DateTime? ToNullableDateTime(object value)
        {
            DateTime? result = null;

            DateTime date;

            if (DateTime.TryParse(ToString(value), out date))
            {
                result = date;
            }

            return result;
        }
    }
}
