﻿using System.Globalization;

namespace Ditech
{
    public static partial class Convert
    {

        /// <summary>
        /// Converts any numeric object or a string representation of a numeric to a decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// Returns a decimal value of 0 if the conversion fails.
        /// </returns>
        public static decimal? ToNullableDecimal(object value)
        {      
            decimal? result = null;

            decimal number;

            if (decimal.TryParse(ToString(value), NumberStyles.Any, CultureInfo.CurrentCulture, out number))
            {
                result = number;
            }

            return result;
        }
    }
}
