﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech
{
    public static partial class Convert
    {
        /// <summary>
        /// Converts byte arrays to hexadecimal string representations
        /// </summary>
        /// <param name="byteArray"></param>
        /// <returns></returns>
        public static string ToHexaDecimalString(byte[] byteArray)
        {
            var output = new StringBuilder(byteArray.Length);

            for (var i = 0; i < byteArray.Length; i++)
            {
                //To string using hex formatting
                output.Append(byteArray[i].ToString("X2"));
            }

            return output.ToString();
        }
    }
}
