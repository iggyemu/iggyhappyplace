#region

using System;

#endregion

namespace Ditech
{
    public static partial class Convert
    {
        #region�Methods�(3)

        //�Public�Methods�(3)�

        /// <summary>
        /// Converts the object to a DateTime object represented as a string in specified format.  Returns string.Empty if the conversion fails.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="dateTimeFormat">The output date format.</param>
        /// <returns>DateTime string in requested format.</returns>
        public static string ToDateTimeString(object value, Format.DateTimeFormat dateTimeFormat)
        {
            return ToDateTimeString(value, Format.DateTimeFormatString(dateTimeFormat));
        }

        /// <summary>
        /// Converts the object to a DateTime object represented as a string in specified format.  Returns string.Empty if the conversion fails.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="outputDateFormat">The output date format.</param>
        /// <returns>DateTime string in requested format.</returns>
        public static string ToDateTimeString(object value, string outputDateFormat)
        {
            return ToDateTimeString(value, outputDateFormat, false);
        }

        /// <summary>
        /// Converts the object to a DateTime object represented as a string in specified format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="outputDateFormat">The output date format.</param>
        /// <param name="emptyStringOnError">if set to <c>true</c> [return an empty string if invalid date value is provided].</param>
        /// <returns>DateTime string in requested format.</returns>
        public static string ToDateTimeString(object value, string outputDateFormat, bool emptyStringOnError)
        {
            var result = string.Empty;

            try
            {
                result = DateTime.Parse(value.ToString()).ToString(outputDateFormat);
            }
            catch (FormatException)
            {
                if (!emptyStringOnError)
                {
                    throw new FormatException("Object was not a valid DateTime object: " + value);
                }
            }
            catch (Exception ex)
            {
                if (!emptyStringOnError)
                {
                    throw ex;
                }
            }

            return result;
        }

        /// <summary>
        /// Converts the object to a DateTime object represented as a string in specified format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="dateTimeFormat">The output date format.</param>
        /// <param name="emptyStringOnError">if set to <c>true</c> [return an empty string if invalid date value is provided].</param>
        /// <returns>DateTime string in requested format.</returns>
        public static string ToDateTimeString(object value, Format.DateTimeFormat dateTimeFormat,
                                              bool emptyStringOnError)
        {
            return ToDateTimeString(value, Format.DateTimeFormatString(dateTimeFormat), emptyStringOnError);
        }

        #endregion�Methods
    }
}