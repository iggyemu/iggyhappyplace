﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech
{
    public class PropertywiseInstantiatorCacheUnlimitedDictionary : IPropertywiseInstantiatorCache
    {
        protected Dictionary<Tuple<Type, Type>, Dictionary<string, object>> mPropertywiseInstantiatorCacheDict;

        #region IPropertywiseInstantiatorCache
        public void Initialize(string configString)
        {
            mPropertywiseInstantiatorCacheDict = new Dictionary<Tuple<Type, Type>, Dictionary<string, object>>();
        }

        public Func<I, O> GetOrCreatePropertywiseInstantiator<I, O>(string propertywiseInstantiatorName, Func<Func<I, O>> createPropertywiseInstantiatorFunc)
        {
            // not sure where this is eventually going to live but for now double-check that init has been done, and if
            // it hasn't then do it
            if (mPropertywiseInstantiatorCacheDict == null)
                Initialize(string.Empty);

            object resultObj;
            Tuple<Type, Type> key = new Tuple<Type, Type>(typeof(I), typeof(O));
            Dictionary<string, object> typePropertywiseInstantiatorsByName = null;
            lock (mPropertywiseInstantiatorCacheDict)
            {
                if (!mPropertywiseInstantiatorCacheDict.ContainsKey(key))
                    typePropertywiseInstantiatorsByName = mPropertywiseInstantiatorCacheDict[key] = new Dictionary<string, object>();
                typePropertywiseInstantiatorsByName = mPropertywiseInstantiatorCacheDict[key];
            }
            lock (typePropertywiseInstantiatorsByName)
            {
                if (!typePropertywiseInstantiatorsByName.ContainsKey(propertywiseInstantiatorName))
                    resultObj = typePropertywiseInstantiatorsByName[propertywiseInstantiatorName] = createPropertywiseInstantiatorFunc();
                resultObj = typePropertywiseInstantiatorsByName[propertywiseInstantiatorName];
            }
            return resultObj as Func<I, O>;
        }
        #endregion

    }
}
