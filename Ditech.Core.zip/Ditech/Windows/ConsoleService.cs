﻿using System;
using System.Collections.Generic;
using System.Configuration.Install;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Windows
{
    public partial class ConsoleService : ServiceBase
    {
        public static Action<Exception> LastResortExceptionHandler;

        public virtual void RunConsole(string[] args)
        {
            OnStart(args);
            Console.WriteLine(this.ServiceName + " running... Press any key to stop");
            Console.ReadKey();
            OnStop();
        }

        public static void Run<TService>(string[] args) where TService : ConsoleService, new()
        {
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
            if (Environment.UserInteractive)
            {
                try
                {
                    string option = args.Length > 0 ? args[0].ToUpperInvariant() : string.Empty;
                    switch (option)
                    {
                        case "-I":
                        case "/I":
                            ManagedInstallerClass.InstallHelper(new string[] { Assembly.GetCallingAssembly().Location });
                            break;
                        case "-U":
                        case "/U":
                            ManagedInstallerClass.InstallHelper(new string[] { "/U", Assembly.GetCallingAssembly().Location });
                            break;
                        default:
                            new TService().RunConsole(args);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    if (LastResortExceptionHandler != null)
                        LastResortExceptionHandler(ex);
                    Console.Error.WriteLine(ex.Message);
                }
            }
            else
            {
                ServiceBase[] servicesToRun = new ServiceBase[] { new TService() };
                ServiceBase.Run(servicesToRun);
            }
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if ((e.ExceptionObject is Exception) && (LastResortExceptionHandler != null))
                LastResortExceptionHandler((Exception)e.ExceptionObject);
        }
    }
}
