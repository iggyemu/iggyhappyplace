namespace Ditech.Windows.Forms
{
    /// <summary>
    /// Initializes a new instance of the <see cref="MultipleInputForm"/> class.
    /// </summary>
    public class InputEntry
    {
		#region�Fields�(10)�

        private object defaultValue;
        private string labelText = "Please enter a value";
        private int maximumCharacters = int.MaxValue;
        private string maximumDate = string.Empty;
        private decimal maximumValue = decimal.MaxValue;
        private string minimumDate = string.Empty;
        private decimal minimumValue = decimal.MinValue;
        private string name = String.UniqueId();
        private int numberOfMultipleLines = 1;
        private DataType type = DataType.String;

		#endregion�Fields�

		#region�Properties�(13)�

        /// <summary>
        /// Gets or sets the default value for the input box.
        /// </summary>
        /// <value>The default value.</value>
        public object DefaultValue
        {
            get { return defaultValue ?? string.Empty; }
            set { defaultValue = value; }
        }

        /// <summary>
        /// Gets or sets the default multiple selection value.
        /// </summary>
        /// <value>The default multiple selection value.</value>
        public string DefaultMultipleSelectionValue { get; set;}

        /// <summary>
        /// Gets or sets the name of the extra button.
        /// </summary>
        /// <value>The name of the extra button.</value>
        public string ExtraButtonName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the dropdown from ComboBox (default value) is sorted.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is read only; otherwise, <c>false</c>.
        /// </value>
        public bool IsDropDownSorted { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is read only.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is read only; otherwise, <c>false</c>.
        /// </value>
        public bool IsReadOnly { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether a value is required for this field.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is required; otherwise, <c>false</c>.
        /// </value>
        public bool IsRequired { get; set; }

        /// <summary>
        /// Gets or sets the label text that corresponds to the input box.
        /// </summary>
        /// <value>The label text.</value>
        public string LabelText
        {
            get { return labelText; }
            set { labelText = value; }
        }

        /// <summary>
        /// Gets or sets the maximum characters.
        /// </summary>
        /// <value>The maximum characters.</value>
        public int MaximumCharacters
        {
            get { return maximumCharacters; }
            set { maximumCharacters = value; }
        }

        /// <summary>
        /// Gets or sets the maximum date.
        /// </summary>
        /// <value>The maximum date.</value>
        public string MaximumDate
        {
            get { return maximumDate; }
            set { maximumDate = value; }
        }

        /// <summary>
        /// Gets or sets the maximum value for a numeric field.
        /// </summary>
        /// <value>The maximum value.</value>
        public decimal MaximumValue
        {
            get { return maximumValue; }
            set { maximumValue = value; }
        }

        /// <summary>
        /// Gets or sets the minimum characters.
        /// </summary>
        /// <value>The minimum characters.</value>
        public int MinimumCharacters { get; set; }

        /// <summary>
        /// Gets or sets the minimum date.
        /// </summary>
        /// <value>The minimum date.</value>
        public string MinimumDate
        {
            get { return (minimumDate); }
            set { minimumDate = value; }
        }

        /// <summary>
        /// Gets or sets the minimum value for a numeric field.
        /// </summary>
        /// <value>The minimum value.</value>
        public decimal MinimumValue
        {
            get { return (minimumValue); }
            set { minimumValue = value; }
        }

        /// <summary>
        /// Gets or sets the name of the input entry, to be used when referencing the returned hashtable.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the number of multiple lines in a textbox.
        /// </summary>
        /// <value>The number of multiple lines.</value>
        public int NumberOfMultipleLines
        {
            get { return numberOfMultipleLines; }
            set { numberOfMultipleLines = value; }
        }

        /// <summary>
        /// Gets or sets the type of data to be entered into the input box.
        /// </summary>
        /// <value>The type.</value>
        public DataType Type
        {
            get { return type; }
            set { type = value; }
        }

		#endregion�Properties�



        #region DataType enum

        /// <summary>
        /// Data types for input boxes.
        /// </summary>
        public enum DataType
        {
            // Be careful of moving String out of 1st position, perhaps causes some validation problems?
            /// <summary>
            /// String data.
            /// </summary>
            String,
            /// <summary>
            /// String data but not numeric.
            /// </summary>
            StringNotNumeric,
            /// <summary>
            /// DateTime data.
            /// </summary>
            DateTime,
            /// <summary>
            /// Money data.
            /// </summary>
            Money,
            /// <summary>
            /// Numeric data.
            /// </summary>
            Numeric,
            /// <summary>
            /// Phone Number
            /// </summary>
            PhoneNumber,
            /// <summary>
            /// Radio Button
            /// </summary>
            RadioButton

        }

        #endregion
    }
}