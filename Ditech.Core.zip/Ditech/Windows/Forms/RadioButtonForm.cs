using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;

namespace Ditech.Windows.Forms
{
    /// <summary>
    /// Creates a simple windows form with radio buttons.
    /// </summary>
    public partial class RadioButtonForm : Form
    {
        private string selection;

        /// <summary>
        /// Initializes a new instance of the <see cref="RadioButtonForm"/> class.
        /// </summary>
        /// <param name="caption">The caption.</param>
        /// <param name="menuOptions">The menu options.</param>
        public RadioButtonForm(string caption, ArrayList menuOptions)
        {
            InitializeComponent();

            Text = caption;

            var baseX = 10;
            var baseY = 20;

            foreach (string menuOption in menuOptions)
            {
                var radioButton = new RadioButton
                                      {
                                          Text = string.Format(menuOption),
                                          Location = new Point(baseX, baseY),
                                          AutoSize = true,
                                          Font = new Font("Tahoma", 10.0F)
                                      };
                radioButton.Click += radioButton_Click;

                Controls.Add(radioButton);
                baseY += 25;
            }

            Height += 20;
            Width += 20;
        }

        private void radioButton_Click(object sender, EventArgs e)
        {
            selection = ((RadioButton) sender).Text;
            Close();
        }

        /// <summary>
        /// Gets a string representing the value of the selected radio button.
        /// </summary>
        /// <returns>
        /// Value of the selected radio button.
        /// </returns>
        public override string ToString()
        {
            ShowDialog();
            return selection;
        }
    }
}