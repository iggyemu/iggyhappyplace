#region

using System;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace Ditech.Windows.Forms
{
    /// <summary>
    /// Creates a simple windows form with a single input box.
    /// </summary>
    public partial class SingleInputForm : Form
    {
        #region�Fields�(3)�

        private readonly ErrorProvider errorProvider;
        private readonly bool required;
        private readonly bool showCancelButton;

        #endregion�Fields�

        #region�Constructors�(4)�

        /// <summary>
        /// Initializes a new instance of the <see cref="SingleInputForm"/> class.
        /// </summary>
        /// <param name="caption">The caption.</param>
        /// <param name="required">if set to <c>true</c> [required].</param>
        /// <param name="numberOfLines">The number of lines presented by the textbox.</param>
        /// <param name="showCancelButton">if set to <c>true</c> [show cancel button].</param>
        public SingleInputForm(string caption, bool required, int numberOfLines, bool showCancelButton)
            : this(caption, required, showCancelButton)
        {
            MakeMultiLine(numberOfLines);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SingleInputForm"/> class.
        /// </summary>
        /// <param name="caption">The caption.</param>
        /// <param name="numberOfLines">The number of lines presented by the textbox.</param>
        public SingleInputForm(string caption, int numberOfLines)
            : this(caption)
        {
            MakeMultiLine(numberOfLines);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SingleInputForm"/> class.
        /// </summary>
        /// <param name="caption">The caption.</param>
        /// <param name="required">if set to <c>true</c> [required].</param>
        /// <param name="showCancelButton">if set to <c>true</c> [show cancel button].</param>
        public SingleInputForm(string caption, bool required, bool showCancelButton)
            : this(caption)
        {
            this.required = required;
            if (this.required)
            {
                txtInput.BackColor = Color.LightYellow;
            }
            this.showCancelButton = showCancelButton;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SingleInputForm"/> class.
        /// </summary>
        /// <param name="caption">The caption.</param>
        public SingleInputForm(string caption)
        {
            InitializeComponent();
            Text = caption;
            errorProvider = new ErrorProvider(this);
        }

        #endregion�Constructors�

        #region�Methods�(3)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Gets a string representing the value entered into the text box.
        /// </summary>
        /// <returns>
        /// Value entered in the text box.
        /// </returns>
        public override string ToString()
        {
            ShowDialog();
            return txtInput.Text ?? string.Empty;
        }

        //�Private�Methods�(2)�

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInput.Text.Replace("\r\n", string.Empty).Trim()) || !required)
            {
                Close();
            }
            else
            {
                errorProvider.SetError(txtInput, "This is a required field.");
                txtInput.Text = string.Empty;
                txtInput.Focus();
            }
        }

        private void MakeMultiLine(int numberOfLines)
        {
            AutoSize = true;
            txtInput.Multiline = true;
            txtInput.ScrollBars = ScrollBars.Vertical;
            txtInput.Height = System.Convert.ToInt16(numberOfLines*16.5);
            SetButtonPositions();
        }

        #endregion�Methods�

        /// <summary>
        /// Sets the button positions.
        /// </summary>
        private void SetButtonPositions()
        {
            btnCancel.Visible = showCancelButton;
            if (showCancelButton)
            {
                btnSubmit.Location = new Point(Width/2 - 80, txtInput.Size.Height + 15);
                btnCancel.Location = new Point(Width/2 + 4, txtInput.Size.Height + 15);
            }
            else
            {
                btnSubmit.Location = new Point(Width/2 - 60, txtInput.Size.Height + 15);
            }
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            ErrorHandling.ExitOnError = true;
            ErrorHandling.ShowErrorMessage("Execution Canceled.", "User canceled workflow.");
        }
    }
}