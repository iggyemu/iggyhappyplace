using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace Ditech.Windows.Forms
{
    /// <summary>
    /// This is a windows form that can be called from any windows app to display an about box.
    /// </summary>
    public partial class AboutForm : Form
    {
        #region�Enums�(1)�

        /// <summary>
        /// Provides a list of available company logos for the about box.
        /// </summary>
        public enum Company
        {
            /// <summary>
            /// EverHome Mortgage Company
            /// </summary>
            EverHome,
            /// <summary>
            /// Ditech
            /// </summary>
            Ditech
        }

        #endregion�Enums�

        #region�Constructors�(2)�

        /// <summary>
        /// Initializes a new instance of the <see cref="AboutForm"/> class.
        /// </summary>
        /// <param name="companyName">Name of the company.</param>
        public AboutForm(Company companyName)
        {
            InitializeComponent(companyName);
            SetControlValues();

            Show();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AboutForm"/> class using the EverHome logo.
        /// </summary>
        public AboutForm()
        {
            new AboutForm(Company.EverHome);
        }

        #endregion�Constructors�

        #region�Methods�(2)�

        //�Private�Methods�(2)�

        private void okButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void SetControlValues()
        {
            Text = string.Format("About {0}", AssemblyTitle);
            lblProductName.Text = AssemblyProduct;
            lblVersion.Text = string.Format("Version {0} (Compiled {1})", AssemblyVersion, AssemblyDate);
            lblCopyright.Text = AssemblyCopyright;
            lblSupportInfo.Text = AssemblyDescription;
        }

        #endregion�Methods�

        #region Assembly Attribute Accessors

        /// <summary>
        /// Gets the assembly title.
        /// </summary>
        /// <value>The assembly title.</value>
        public string AssemblyTitle
        {
            get
            {
                var attributes = Assembly.GetEntryAssembly().GetCustomAttributes(typeof (AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    var titleAttribute = (AssemblyTitleAttribute) attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        /// <summary>
        /// Gets the assembly date.
        /// </summary>
        /// <value>The assembly date.</value>
        public string AssemblyDate
        {
            get
            {
                var assemblyInfo = AssemblyVersion.Split('.');
                var dateTime = new DateTime(2000, 1, 1);

                return dateTime.AddDays(double.Parse(assemblyInfo[2])).ToString("MMMM d, yyyy");
            }
        }

        /// <summary>
        /// Gets the assembly version.
        /// </summary>
        /// <value>The assembly version.</value>
        public string AssemblyVersion
        {
            get { return Assembly.GetEntryAssembly().GetName().Version.ToString(); }
        }

        /// <summary>
        /// Gets the assembly description.
        /// </summary>
        /// <value>The assembly description.</value>
        public string AssemblyDescription
        {
            get
            {
                var attributes = Assembly.GetEntryAssembly().GetCustomAttributes(typeof (AssemblyDescriptionAttribute),
                                                                                 false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute) attributes[0]).Description;
            }
        }

        /// <summary>
        /// Gets the assembly product.
        /// </summary>
        /// <value>The assembly product.</value>
        public string AssemblyProduct
        {
            get
            {
                var attributes = Assembly.GetEntryAssembly().GetCustomAttributes(typeof (AssemblyProductAttribute),
                                                                                 false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute) attributes[0]).Product;
            }
        }

        /// <summary>
        /// Gets the assembly copyright.
        /// </summary>
        /// <value>The assembly copyright.</value>
        public string AssemblyCopyright
        {
            get
            {
                var attributes = Assembly.GetEntryAssembly().GetCustomAttributes(typeof (AssemblyCopyrightAttribute),
                                                                                 false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute) attributes[0]).Copyright;
            }
        }

        /// <summary>
        /// Gets the assembly company.
        /// </summary>
        /// <value>The assembly company.</value>
        public string AssemblyCompany
        {
            get
            {
                var attributes = Assembly.GetEntryAssembly().GetCustomAttributes(typeof (AssemblyCompanyAttribute),
                                                                                 false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute) attributes[0]).Company;
            }
        }

        #endregion
    }
}