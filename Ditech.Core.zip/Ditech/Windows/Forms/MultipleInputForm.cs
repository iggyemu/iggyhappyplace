#region

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Label = System.Windows.Forms.Label;
using RadioButton = System.Windows.Forms.RadioButton;
using ScrollBars = System.Windows.Forms.ScrollBars;
using TextBox = System.Windows.Forms.TextBox;

#endregion

namespace Ditech.Windows.Forms
{
    /// <summary>
    /// Creates a simple windows form with one or more input boxes.
    /// </summary>
    public partial class MultipleInputForm : Form, IValidState
    {
        #region�Fields�(7)

        private readonly ErrorProvider errorProvider;
        private readonly List<InputEntry> inputEntries;
        private int maxInputBoxWidth;
        private int xOffset = 10;
        private int yOffset = 20;
        private const int yOffsetIncrement = 25;
        private const int yOffsetPanelSize = 5;
        private const int yOffsetInstructions = 30;
        private const int radioButtonOffset = 19;
        private const int multipleLineOffset = 19;

        #endregion�Fields

        #region�Constructors�(4)

        /// <summary>
        /// Initializes a new instance of the <see cref="MultipleInputForm"/> class.
        /// </summary>
        /// <param name="instructions">The instructions.</param>
        /// <param name="caption">The caption.</param>
        /// <param name="inputEntries">The input entries.</param>
        /// <param name="showCancelButton">if set to <c>true</c> [show cancel button].</param>
        public MultipleInputForm(string instructions, string caption, List<InputEntry> inputEntries,
                                 bool showCancelButton)
        {
            InitializeComponent();

            Text = caption;
            this.inputEntries = inputEntries;
            errorProvider = new ErrorProvider(this);

            if (!string.IsNullOrEmpty(instructions))
            {
                CreateInstructionLabel(instructions);

                yOffset = yOffset + yOffsetInstructions;
            }

            int initialYOffset = yOffset;

            CreateInputLabels();

            yOffset = initialYOffset;
            CreateInputControls();
            //ResizeInputBoxes();

            AutoSize = true;
            SetButtonPositions(showCancelButton);
            Width += 15;

            ShowDialog();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MultipleInputForm"/> class.
        /// </summary>
        /// <param name="caption">The caption.</param>
        /// <param name="inputEntries">The input entries.</param>
        /// <param name="showCancelButton">if set to <c>true</c> [show cancel button].</param>
        public MultipleInputForm(string caption, List<InputEntry> inputEntries, bool showCancelButton)
            : this(string.Empty, caption, inputEntries, showCancelButton)
        {
        }

        #endregion�Constructors

        #region�Properties�(6)

        /// <summary>
        /// Autosize attribute
        /// </summary>
        [Browsable(false)]
        public override bool AutoSize { get; set; }

        /// <summary>
        /// A hashtable containing the values of the form textboxes.  Use this hashtable to get values that have been entered.
        /// </summary>
        /// <value>The form values.</value>
        public Hashtable FormValues { get; private set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is extra button clicked.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is extra button clicked; otherwise, <c>false</c>.
        /// </value>
        public bool IsExtraButtonClicked { get; private set; }

        /// <summary>
        /// Gets a value indicating whether this instance is in a valid state.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is valid state; otherwise, <c>false</c>.
        /// </value>
        public bool IsValidState
        {
            get
            {
                bool isValid = true;
                FormValues = new Hashtable();
                for (int i = 0; i < inputEntries.Count; i++)
                {
                    Control currentControl = Controls[string.Format("txt{0}", inputEntries[i].Name)];
                    string controlValue = string.Empty;

                    if (inputEntries[i].Type == InputEntry.DataType.RadioButton)
                    {
                        foreach (Control ctrl in currentControl.Controls)
                        {
                            if (ctrl.GetType() == typeof(RadioButton))
                            {
                                var radioButton = (RadioButton)ctrl;
                                if (radioButton.Checked)
                                {
                                    controlValue = radioButton.Text;
                                }
                            }
                        }
                    }
                    else
                    {
                        controlValue = currentControl.Text;
                    }

                    string errorMessage = string.Empty;
                    FormValues.Add(inputEntries[i].Name, controlValue);

                    // Required fields must contain a value.
                    if ((inputEntries[i].IsRequired && inputEntries[i].Type != InputEntry.DataType.RadioButton) &&
                        string.IsNullOrEmpty(controlValue.Replace("\r\n", string.Empty).Trim()))
                    {
                        errorMessage = "This field is required.";
                    }
                    // Non-required fields are OK if blank.
                    else if (!string.IsNullOrEmpty(controlValue))
                    {
                        switch (inputEntries[i].Type)
                        {
                            case InputEntry.DataType.DateTime:
                                errorMessage = !Validation.IsDate(controlValue)
                                                   ? "Please enter a valid date."
                                                   : ValidationRangeMessage(controlValue, inputEntries[i]);
                                break;
                            case InputEntry.DataType.Money:
                                controlValue = controlValue.Remove("$").Remove(",");
                                errorMessage = !controlValue.IsMoney(true)
                                                   ? "Please enter a valid dollars & cents that includes the decimal."
                                                   : ValidationRangeMessage(controlValue, inputEntries[i]);
                                break;
                            case InputEntry.DataType.Numeric:
                                controlValue = controlValue.Remove("$").Remove(",");
                                errorMessage = !controlValue.IsNumeric()
                                                   ? "Please enter a valid numeric value."
                                                   : ValidationRangeMessage(controlValue, inputEntries[i]);
                                if (string.IsNullOrEmpty(errorMessage))
                                {
                                    errorMessage = ValidationCharacterMinimumLengthMessage(controlValue, inputEntries[i]);
                                }
                                break;
                            case InputEntry.DataType.StringNotNumeric:
                            case InputEntry.DataType.String:
                                errorMessage = ValidationCharacterMaximumLengthMessage(controlValue, inputEntries[i]);
                                if (string.IsNullOrEmpty(errorMessage) && inputEntries[i].Type == InputEntry.DataType.StringNotNumeric)
                                {
                                    errorMessage = ValidationStringNotNumericMessage(controlValue);
                                }
                                if (string.IsNullOrEmpty(errorMessage))
                                {
                                    errorMessage = ValidationCharacterMinimumLengthMessage(controlValue, inputEntries[i]);
                                }
                                break;
                            case InputEntry.DataType.PhoneNumber:
                                controlValue = controlValue.Remove("(").Remove(")").Remove("_").Remove("-").Remove(" ").Trim();
                                if (controlValue.Length != 10)
                                {
                                    errorMessage = "Please enter a valid phone number.";
                                }
                                break;
                            default:
                                break;
                        }
                    }

                    if (errorMessage.Length > 0)
                    {
                        // sets focus to first error
                        if (isValid)
                        {
                            currentControl.Focus();
                        }
                        isValid = false;
                    }
                    errorProvider.SetError(currentControl, errorMessage);
                }
                return (isValid);
            }
        }

        #endregion�Properties

        #region�Methods�(14)

        //�Private�Methods�(14)�

        /// <summary>
        /// Handles the Click event of the btnCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected virtual void btnCancel_Click(object sender, EventArgs e)
        {
            ErrorHandling.ExitOnError = true;
            ErrorHandling.ShowErrorMessage("Execution Canceled.", "User canceled workflow.");
        }

        private void btnExtra_Click(object sender, EventArgs e)
        {
            if (IsValidState)
            {
                IsExtraButtonClicked = true;
                Close();
            }
        }

        /// <summary>
        /// Handles the Click event of the btnSubmit control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (IsValidState)
            {
                Close();
            }
        }

        private void CreateInputControls()
        {
            for (int i = 0; i < inputEntries.Count; i++)
            {
                Control control;
                if (inputEntries[i].Type == InputEntry.DataType.DateTime && inputEntries[i].IsRequired)
                {
                    control = new DateTimePicker
                    {
                        Name = string.Format("txt{0}", inputEntries[i].Name),
                        Location = new Point(xOffset, yOffset),
                        AutoSize = true,
                        Font = new Font("Tahoma", 8.0F),
                        Text = inputEntries[i].DefaultValue.ToString(),
                        Enabled = !inputEntries[i].IsReadOnly
                    };
                }
                else if (inputEntries[i].Type == InputEntry.DataType.PhoneNumber && inputEntries[i].IsRequired)
                {
                    control = new MaskedTextBox("(999) 000-0000")
                    {
                        Name = string.Format("txt{0}", inputEntries[i].Name),
                        Location = new Point(xOffset, yOffset),
                        AutoSize = true,
                        Font = new Font("Tahoma", 8.0F),
                        Text = inputEntries[i].DefaultValue.ToString(),
                        Enabled = !inputEntries[i].IsReadOnly
                    };
                }
                else if (inputEntries[i].DefaultValue is string || !(inputEntries[i].DefaultValue is IEnumerable))
                {
                    lblResizeText.Visible = false;
                    lblResizeText.AutoSize = true;
                    lblResizeText.Text = inputEntries[i].DefaultValue.ToString();

                    control = new TextBox
                    {
                        Name = string.Format("txt{0}", inputEntries[i].Name),
                        Location = new Point(xOffset, yOffset),
                        AutoSize = true,
                        Font = new Font("Tahoma", 10.0F),
                        MaxLength = inputEntries[i].MaximumCharacters,
                        Enabled = !inputEntries[i].IsReadOnly,
                        AcceptsReturn = true
                    };

                    if (lblResizeText.Width > control.Width)
                    {
                        control.Width = lblResizeText.Width;
                    }
                    if (lblResizeText.Height > control.Height)
                    {
                        control.Height = lblResizeText.Height;
                    }
                    control.Text = lblResizeText.Text;

                    if (inputEntries[i].NumberOfMultipleLines > 1)
                    {
                        MakeMultiLine(control, inputEntries[i].NumberOfMultipleLines);
                    }
                }
                else if (inputEntries[i].Type == InputEntry.DataType.RadioButton)
                {
                    control = new Panel
                    {
                        Name = string.Format("txt{0}", inputEntries[i].Name),
                        Location = new Point(xOffset, yOffset + 1),
                        Font = new Font("Tahoma", 10.0F),
                        AutoSizeMode = AutoSizeMode.GrowAndShrink,
                        Enabled = !inputEntries[i].IsReadOnly,
                        AutoSize = true,
                        BorderStyle = BorderStyle.Fixed3D
                    };

                    yOffset = yOffset + yOffsetPanelSize;

                    var radioButtons = new RadioButton[5];

                    var choices = (IEnumerable)inputEntries[i].DefaultValue;
                    int radioButtonValuesCount = 0;
                    foreach (object o in choices)
                    {
                        radioButtons[radioButtonValuesCount] = new RadioButton
                        {
                            Location = new Point(0, radioButtonOffset * radioButtonValuesCount),
                            Text = o.ToString(),
                            Name = string.Format("{0}", o),
                            AutoSize = true
                        };
                        if (inputEntries[i].DefaultMultipleSelectionValue == radioButtons[radioButtonValuesCount].Name)
                        {
                            radioButtons[radioButtonValuesCount].Checked = true;
                        }
                        else
                        {
                            radioButtons[radioButtonValuesCount].Checked = false;
                        }

                        if (radioButtonValuesCount == 0 && string.IsNullOrEmpty(inputEntries[i].DefaultMultipleSelectionValue))
                        {
                            if (inputEntries[i].IsRequired)
                            {
                                radioButtons[radioButtonValuesCount].Checked = true;
                            }
                        }
                        control.Controls.Add(radioButtons[radioButtonValuesCount]);

                        radioButtonValuesCount++;
                        if (radioButtonValuesCount == 5)
                        {
                            throw new Exception("Only a maximum of 5 values are allowed for radio buttons.");
                        }
                    }
                    // a 'default' option needs to be specified, use the Value property on Property list to check one radio button after creating it. 
                    // To begin a new radio group, the new RadioGroup control can be inserted on your form. 

                    yOffset += (radioButtonOffset * radioButtonValuesCount) - radioButtonOffset;

                    Controls.Add(control);
                }
                else
                {
                    control = new ComboBox
                    {
                        Name = string.Format("txt{0}", inputEntries[i].Name),
                        Location = new Point(xOffset, yOffset),
                        AutoSize = true,
                        Font = new Font("Tahoma", 10.0F),
                        DropDownStyle = ComboBoxStyle.DropDownList,
                        Enabled = !inputEntries[i].IsReadOnly,
                        Sorted = inputEntries[i].IsDropDownSorted
                    };

                    var dropDownOptions = (IEnumerable)inputEntries[i].DefaultValue;

                    int maximumCharacterLength = 10;
                    ((ComboBox)control).Items.Add(string.Empty);
                    foreach (object o in dropDownOptions)
                    {
                        ((ComboBox)control).Items.Add(o.ToString());
                        if (o.ToString().Length > maximumCharacterLength)
                        {
                            maximumCharacterLength = o.ToString().Length;
                        }
                    }
                    if (!string.IsNullOrEmpty(inputEntries[i].DefaultMultipleSelectionValue))
                    {
                        ((ComboBox) control).SelectedItem = inputEntries[i].DefaultMultipleSelectionValue;
                    }
                    else
                    {
                        ((ComboBox)control).SelectedIndex = 0;                        
                    }
                    ResizeComboBox(control, maximumCharacterLength);
                }

                if (inputEntries[i].IsRequired)
                {
                    control.BackColor = Color.LightYellow;
                }

                if (!string.IsNullOrEmpty(inputEntries[i].ExtraButtonName))
                {
                    btnExtra.Text = inputEntries[i].ExtraButtonName;
                    btnExtra.Visible = true;
                }

                Controls.Add(control);


                ResizeInputBoxes2(i, control.Width);

                maxInputBoxWidth = control.Width > maxInputBoxWidth && control.Width != 360
                                       ? control.Width
                                       : maxInputBoxWidth;
                yOffset += yOffsetIncrement;
            }
        }

        private void CreateInputLabels()
        {
            int labelMaxWidth = 0;
            for (int i = 0; i < inputEntries.Count; i++)
            {
                var label = new Label
                {
                    Name = string.Format("lbl{0}", inputEntries[i].Name),
                    Text = string.Format("{0}:", string.Format(inputEntries[i].LabelText)),
                    Location = new Point(xOffset, yOffset),
                    AutoSize = true,
                    Font = new Font("Tahoma", 10.0F)
                };

                Controls.Add(label);

                labelMaxWidth = labelMaxWidth < label.Size.Width ? label.Size.Width : labelMaxWidth;
                if (inputEntries[i].Type == InputEntry.DataType.RadioButton)
                {
                    int radioButtonValuesCount = 0;
#pragma warning disable 168
                    foreach (object o in (IEnumerable)inputEntries[i].DefaultValue)
#pragma warning restore 168
                    {
                        radioButtonValuesCount++;
                    }
                    yOffset += MultipleOffset(radioButtonValuesCount, radioButtonOffset - yOffsetPanelSize);
                }
                if (inputEntries[i].NumberOfMultipleLines > 1)
                {
                    yOffset += MultipleOffset(inputEntries[i].NumberOfMultipleLines, multipleLineOffset);
                }
                else
                {
                    yOffset += yOffsetIncrement;
                }
            }

            xOffset += labelMaxWidth + 5;
        }

        private void CreateInstructionLabel(string instructions)
        {
            var label = new Label
            {
                Name = "lblInstructions",
                Text = instructions,
                Location = new Point(xOffset, yOffset),
                AutoSize = true,
                Font = new Font("Tahoma", 8.0F, FontStyle.Bold),
            };

            Controls.Add(label);

            int count = instructions.Split('\n').Length - 1;

            yOffset = yOffset + (yOffsetInstructions * count);
        }

        /// <summary>
        /// Makes the multi line.
        /// </summary>
        /// <param name="control">The control.</param>
        /// <param name="numberOfLines">The number of lines.</param>
        private void MakeMultiLine(Control control, int numberOfLines)
        {
            var s = new Size(380, yOffset); // 50 chars.

            (control).Size = s;
            ((TextBox)control).Multiline = true;
            ((TextBox)control).ScrollBars = ScrollBars.Vertical;
            control.Height = MultipleOffset(numberOfLines, multipleLineOffset);
            yOffset += control.Height - 25;
        }

        private void MultipleInputForm_Activated(object sender, EventArgs e)
        {
            Controls[string.Format("txt{0}", inputEntries[0].Name)].Focus();
        }

        private static int MultipleOffset(int numberOfOffsets, int offset)
        {
            return System.Convert.ToInt16(numberOfOffsets * offset);
        }

        private static void ResizeComboBox(Control control, int maximumLength)
        {
            (control).Size = new Size(System.Convert.ToInt16(7.5 * maximumLength), 21);
        }

        private void ResizeInputBoxes2(int i, int inputBoxwidth)
        {
            Controls[string.Format("txt{0}", inputEntries[i].Name)].Width = inputBoxwidth;
        }

        /// <summary>
        /// Sets the button positions.
        /// </summary>
        /// <param name="showCancelButton">if set to <c>true</c> [show cancel button].</param>
        private void SetButtonPositions(bool showCancelButton)
        {
            btnCancel.Visible = showCancelButton;

            if (showCancelButton)
            {
                btnSubmit.Location = new Point(Width / 2 - 80, yOffset + 5);

                if (btnExtra.Text != "Extra")
                {
                    btnExtra.Location = new Point(Width / 2 + 4, yOffset + 5);
                    btnCancel.Location = new Point(Width / 2 + 88, yOffset + 5);
                }
                else
                {
                    btnCancel.Location = new Point(Width / 2 + 4, yOffset + 5);
                }
            }
            else
            {
                btnSubmit.Location = new Point(Width / 2 - 38, yOffset + 5);
                if (btnExtra.Text != "Extra")
                {
                    btnExtra.Location = new Point(Width / 2 + 50, yOffset + 5);
                }
            }
        }

        private static string ValidationCharacterMaximumLengthMessage(string controlValue, InputEntry inputEntry)
        {
            string result = string.Empty;

            if (controlValue.Length > inputEntry.MaximumCharacters)
            {
                result = string.Format(
                    "You have exceeded the maximum number of characters of {0} with {1}.  Please reduce the size of your input.",
                    inputEntry.MaximumCharacters, controlValue.Length);
            }

            return result;
        }

        private static string ValidationCharacterMinimumLengthMessage(string controlValue, InputEntry inputEntry)
        {
            string result = string.Empty;

            if (controlValue.Length < inputEntry.MinimumCharacters)
            {
                result = string.Format(
                    "You have not exceeded the minimum number of characters of {0} with {1}.  Please increase the size of your input.",
                    inputEntry.MinimumCharacters, controlValue.Length);
            }

            return result;
        }

        private static string ValidationRangeMessage(string controlValue, InputEntry inputEntry)
        {
            string result = string.Empty;

            if (Validation.IsDate(controlValue))
            {
                if (!string.IsNullOrEmpty(inputEntry.MinimumDate) &&
                    Date.Difference(Convert.ToNullableDateTime(inputEntry.MinimumDate).Value, Convert.ToNullableDateTime(controlValue).Value,
                                    Date.TimeSpanType.Days) < 0)
                {
                    result = string.Format("Please enter a date greater than or equal {0}.", inputEntry.MinimumDate);
                }
                else if (!string.IsNullOrEmpty(inputEntry.MaximumDate) &&
                         Date.Difference(Convert.ToNullableDateTime(inputEntry.MaximumDate).Value, Convert.ToNullableDateTime(controlValue).Value,
                                         Date.TimeSpanType.Days) > 0)
                {
                    result = string.Format("Please enter a date less than or equal {0}", inputEntry.MaximumDate);
                }
            }
            else
            {
                decimal value = decimal.Parse(controlValue);

                if (value < inputEntry.MinimumValue)
                {
                    result = string.Format("Please enter a value greater than or equal {0}.", inputEntry.MinimumValue);
                }
                else if (value > inputEntry.MaximumValue)
                {
                    result = string.Format("Please enter a value less than or equal {0}", inputEntry.MaximumValue);
                }
            }

            return result;
        }

        private static string ValidationStringNotNumericMessage(string controlValue)
        {
            string result = string.Empty;

            var regex = new Regex("[0-9]");

            if (regex.Match(controlValue).Success)
            {
                result = "You have specified a numeric value 0 through 9 in a non numeric field.  Please try again.";
            }

            return result;
        }



        #endregion�Methods
    }
}