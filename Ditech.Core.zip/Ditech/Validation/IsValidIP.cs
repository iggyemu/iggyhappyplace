﻿using System.Text.RegularExpressions;

namespace EverBank
{
    public static partial class Validation
    {
        /// <summary> 
        /// An IP Address is valid if  10 digits long. 
        /// </summary> 
        /// <param name="value">The IP Address to validate</param> 
        /// <returns>True if IP Address is valid, false otherwise.</returns> 
        public static bool ValidateIPAddress(string value)
        {
            value.Trim().Replace(".", string.Empty);
            value.Replace("http://", string.Empty).Replace("https://", string.Empty).Replace("ftp://", string.Empty);

            const string regExPattern = @"^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$";
            
            return MatchString(value, regExPattern);
        } 


    }
}
