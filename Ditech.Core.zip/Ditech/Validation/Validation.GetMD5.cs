﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Calculates MD5 hash for a serializable object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetMD5(object obj)
        {
            var objByteArray = Convert.ToByteArray(obj);
            var hashByteArray = new MD5CryptoServiceProvider().ComputeHash(objByteArray);

            return Convert.ToHexaDecimalString(hashByteArray);
        }
    }
}
