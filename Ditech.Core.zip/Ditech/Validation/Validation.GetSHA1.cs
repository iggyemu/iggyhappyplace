﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Calculates SHA1 hash for a serializable object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetSHA1(object obj)
        {
            var objByteArray = Convert.ToByteArray(obj);
            var hashByteArray = new SHA1CryptoServiceProvider().ComputeHash(objByteArray);

            return Convert.ToHexaDecimalString(hashByteArray);
        }
    }
}
