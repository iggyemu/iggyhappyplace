namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is a valid SSN.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is an SSN; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsSsn(this string value)
        {
            //Assert position at the beginning of the string �^�
            //Assert that it is impossible to match the regex below starting at this position (negative lookahead) �(?!000)�
            //   Match the characters �000� literally �000�
            //Assert that it is impossible to match the regex below starting at this position (negative lookahead) �(?!666)�
            //   Match the characters �666� literally �666�
            //Match the regular expression below and capture its match into backreference number 1 �([0-6]\d{2}|7([0-6]\d|7[012]))�
            //   Match either the regular expression below (attempting the next alternative only if this one fails) �[0-6]\d{2}�
            //      Match a single character in the range between �0� and �6� �[0-6]�
            //      Match a single digit 0..9 �\d{2}�
            //         Exactly 2 times �{2}�
            //   Or match regular expression number 2 below (the entire group fails if this one fails to match) �7([0-6]\d|7[012])�
            //      Match the character �7� literally �7�
            //      Match the regular expression below and capture its match into backreference number 2 �([0-6]\d|7[012])�
            //         Match either the regular expression below (attempting the next alternative only if this one fails) �[0-6]\d�
            //            Match a single character in the range between �0� and �6� �[0-6]�
            //            Match a single digit 0..9 �\d�
            //         Or match regular expression number 2 below (the entire group fails if this one fails to match) �7[012]�
            //            Match the character �7� literally �7�
            //            Match a single character present in the list �012� �[012]�
            //Match the regular expression below and capture its match into backreference number 3 �([ -]?)�
            //   Match a single character present in the list below �[ -]?�
            //      Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
            //      The character � � � �
            //      The character �-� �-�
            //Assert that it is impossible to match the regex below starting at this position (negative lookahead) �(?!00)�
            //   Match the characters �00� literally �00�
            //Match a single digit 0..9 �\d�
            //Match a single digit 0..9 �\d�
            //Match the same text as most recently matched by capturing group number 3 �\3�
            //Assert that it is impossible to match the regex below starting at this position (negative lookahead) �(?!0000)�
            //   Match the characters �0000� literally �0000�
            //Match a single digit 0..9 �\d{4}�
            //   Exactly 4 times �{4}�
            //Assert position at the end of the string (or before the line break at the end of the string, if any) �$�
            var ssnValidPattern =
                @"^(?!000)(?!666)([0-6]\d{2}|7([0-6]\d|7[012]))([ -]?)(?!00)\d\d\3(?!0000)\d{4}$";

            // Any number that repeats 9 times or is 123456789 is known to be invalid.
            var knownBadPatterns = @"^((.)\1{9}|123456789)$";

            return
                !MatchString(value.Replace("-", string.Empty), knownBadPatterns) && MatchString(value, ssnValidPattern);
        }
    }
}