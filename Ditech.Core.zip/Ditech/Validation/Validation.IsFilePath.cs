using System.IO;
using Path=Ditech.IO.Path;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified file path is valid and that the file exists.
        /// </summary>
        /// <param name="value">The file path.</param>
        /// <param name="throwException">if set to <c>true</c> [throw exception].</param>
        /// <returns>
        /// 	<c>true</c> if [is file path] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsFilePath(this string value, bool throwException)
        {
            var result = true;

            if (Path.Type(value) != Path.PathType.File)
            {
                result = false;

                if (throwException)
                {
                    throw new IOException("File path is not valid: \"" + value + "\"");
                }
            }

            return result;
        }
    }
}