using System;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary> 
        /// Validates a date using C#-built in DateTime.TryParse() 
        /// function. 
        /// </summary> 
        /// <param name="value">The date to validate</param> 
        /// <returns>True if the date is valid, false otherwise.</returns> 
        public static bool IsDate(string value)
        {
            //Dates can be entered in different formats: 
            //1. 2006-03-04 
            //2. 03-04-2006 
            //3. April 3 2006 
            //4. April 3, 2006 
            //5. Apr 3, 2006 
            //6. 03-APR-2006 
            //7. 3-APR-06 
            //method to validate the date. 

            DateTime dateParsed;
            return DateTime.TryParse(value, out dateParsed);
        }
    }
}