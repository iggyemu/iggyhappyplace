﻿
namespace EverBank
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether [is valid file type] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if [is valid file name] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsValidFileType(this string value)
        {
            const string regExPattern = @"(.*?)\.(doc|pdf|xls|gif)$";
            return MatchString(value, regExPattern);
        }
    }
}
