namespace Ditech
{
    public static partial class Validation
    {
        /// <summary> 
        /// An IP Address is valid if 10 digits long. 
        /// </summary> 
        /// <param name="value">The IP Address to validate</param> 
        /// <returns>True if IP Address is valid, false otherwise.</returns> 
        public static bool IsIPAddress(string value)
        {
            const string regExPattern =
                @"^(([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\.){3}([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$";

            return MatchString(value, regExPattern);
        }

        /// <summary>
        /// Determines whether [is IP address] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="allowPrefix">if set to <c>true</c> [allow prefix].</param>
        /// <returns>
        /// 	<c>true</c> if [is IP address] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsIPAddress(string value, bool allowPrefix)
        {
            if (allowPrefix)
            {
                value = value.Trim().Replace(".", string.Empty);
                value = value.Replace("http://", string.Empty).Replace("https://", string.Empty).Replace("ftp://",
                                                                                                         string.Empty);
            }

            return IsIPAddress(value);
        }
    }
}