namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is a phone number.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is phone; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsPhone(this string value)
        {
            //Assert position at the beginning of the string �^�
            //Assert that it is impossible to match the regex below starting at this position (negative lookahead) �(?!(.)\1{9})�
            //   Match the regular expression below and capture its match into backreference number 1 �(.)�
            //      Match any single character that is not a line break character �.�
            //   Match the same text as most recently matched by capturing group number 1 �\1{9}�
            //      Exactly 9 times �{9}�
            //Match the regular expression below and capture its match into backreference number 2 �((\([2-9]\d{2}\)[ ]?)|([2-9]\d{2}[ -]?))�
            //   Match either the regular expression below (attempting the next alternative only if this one fails) �(\([2-9]\d{2}\)[ ]?)�
            //      Match the regular expression below and capture its match into backreference number 3 �(\([2-9]\d{2}\)[ ]?)�
            //         Match the character �(� literally �\(�
            //         Match a single character in the range between �2� and �9� �[2-9]�
            //         Match a single digit 0..9 �\d{2}�
            //            Exactly 2 times �{2}�
            //         Match the character �)� literally �\)�
            //         Match the character � � �[ ]?�
            //            Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
            //   Or match regular expression number 2 below (the entire group fails if this one fails to match) �([2-9]\d{2}[ -]?)�
            //      Match the regular expression below and capture its match into backreference number 4 �([2-9]\d{2}[ -]?)�
            //         Match a single character in the range between �2� and �9� �[2-9]�
            //         Match a single digit 0..9 �\d{2}�
            //            Exactly 2 times �{2}�
            //         Match a single character present in the list below �[ -]?�
            //            Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
            //            The character � � � �
            //            The character �-� �-�
            //Match the regular expression below and capture its match into backreference number 5 �(\d{3})�
            //   Match a single digit 0..9 �\d{3}�
            //      Exactly 3 times �{3}�
            //Match the regular expression below and capture its match into backreference number 6 �([ -]?)�
            //   Match a single character present in the list below �[ -]?�
            //      Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
            //      The character � � � �
            //      The character �-� �-�
            //Match the regular expression below and capture its match into backreference number 7 �(\d{4})�
            //   Match a single digit 0..9 �\d{4}�
            //      Exactly 4 times �{4}�
            var regExPattern = @"^(?!(.)\1{9})((\([2-9]\d{2}\)[ ]?)|([2-9]\d{2}[ -]?))(\d{3})([ -]?)(\d{4})$";

            return MatchString(value, regExPattern);
        }
    }
}