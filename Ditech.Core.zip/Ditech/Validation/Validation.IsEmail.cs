namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified email address is valid.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if [is valid email] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsEmail(this string value)
        {
            const string regExPattern = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                                        @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                                        @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

            return MatchString(value, regExPattern);
        }
    }
}