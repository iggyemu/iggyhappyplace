namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is a valid money value.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <param name="decimalRequired">if set to <c>true</c> [decimal required].</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is money; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsMoney(this string value, bool decimalRequired)
        {
            value = value.Replace(",", string.Empty);
            string regExPattern;

            if (decimalRequired)
            {
                //Match either the regular expression below (attempting the next alternative only if this one fails) �^(-?\$?[0-9]*\.[0-9]{2}-?)�
                //   Assert position at the beginning of the string �^�
                //   Match the regular expression below and capture its match into backreference number 1 �(-?\$?[0-9]*\.[0-9]{2}-?)�
                //      Match the character �-� literally �-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match the character �$� literally �\$?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match a single character in the range between �0� and �9� �[0-9]*�
                //         Between zero and unlimited times, as many times as possible, giving back as needed (greedy) �*�
                //      Match the character �.� literally �\.�
                //      Match a single character in the range between �0� and �9� �[0-9]{2}�
                //         Exactly 2 times �{2}�
                //      Match the character �-� literally �-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //Or match regular expression number 2 below (the entire match attempt fails if this one fails to match) �(\$?\-?[0-9]*\.[0-9]{2}-?)$�
                //   Match the regular expression below and capture its match into backreference number 2 �(\$?\-?[0-9]*\.[0-9]{2}-?)�
                //      Match the character �$� literally �\$?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match the character �-� literally �\-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match a single character in the range between �0� and �9� �[0-9]*�
                //         Between zero and unlimited times, as many times as possible, giving back as needed (greedy) �*�
                //      Match the character �.� literally �\.�
                //      Match a single character in the range between �0� and �9� �[0-9]{2}�
                //         Exactly 2 times �{2}�
                //      Match the character �-� literally �-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //   Assert position at the end of the string (or before the line break at the end of the string, if any) �$�
                regExPattern = @"^((-?\$?[0-9]*\.[0-9]{2}-?)|(\$?\-?[0-9]*\.[0-9]{2}-?))$";
            }

            else
            {
                //Match either the regular expression below (attempting the next alternative only if this one fails) �^(-?\$?[0-9]*\.?[0-9]{2}-?)�
                //   Assert position at the beginning of the string �^�
                //   Match the regular expression below and capture its match into backreference number 1 �(-?\$?[0-9]*\.?[0-9]{2}-?)�
                //      Match the character �-� literally �-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match the character �$� literally �\$?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match a single character in the range between �0� and �9� �[0-9]*�
                //         Between zero and unlimited times, as many times as possible, giving back as needed (greedy) �*�
                //      Match the character �.� literally �\.?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match a single character in the range between �0� and �9� �[0-9]{2}�
                //         Exactly 2 times �{2}�
                //      Match the character �-� literally �-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //Or match regular expression number 2 below (the entire match attempt fails if this one fails to match) �(\$?\-?[0-9]*\.?[0-9]{2}-?)$�
                //   Match the regular expression below and capture its match into backreference number 2 �(\$?\-?[0-9]*\.?[0-9]{2}-?)�
                //      Match the character �$� literally �\$?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match the character �-� literally �\-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match a single character in the range between �0� and �9� �[0-9]*�
                //         Between zero and unlimited times, as many times as possible, giving back as needed (greedy) �*�
                //      Match the character �.� literally �\.?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //      Match a single character in the range between �0� and �9� �[0-9]{2}�
                //         Exactly 2 times �{2}�
                //      Match the character �-� literally �-?�
                //         Between zero and one times, as many times as possible, giving back as needed (greedy) �?�
                //   Assert position at the end of the string (or before the line break at the end of the string, if any) �$�
                regExPattern = @"^((-?\$?[0-9]*\.?[0-9]{2}-?)|(\$?\-?[0-9]*\.?[0-9]{2}-?))$";
            }

            return MatchString(value, regExPattern);
        }
    }
}