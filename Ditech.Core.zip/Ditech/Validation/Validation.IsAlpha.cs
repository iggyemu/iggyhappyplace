namespace Ditech
{
    /// <summary>
    /// This static class provides re-usable validation methods.
    /// </summary>
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value contains only alpha characters.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is alpha; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsAlpha(this string value)
        {
            return value.IsAlpha(false);
        }


        /// <summary>
        /// Determines whether the specified value only alpha characters.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <param name="allowSpaces">if set to <c>true</c> [allow spaces].</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is alpha; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsAlpha(this string value, bool allowSpaces)
        {
            string regExPattern;

            if (allowSpaces)
            {
                regExPattern = @"^[A-Za-z ]+$";
            }
            else
            {
                regExPattern = @"^[A-Za-z]+$";
            }

            return MatchString(value, regExPattern);
        }
    }
}