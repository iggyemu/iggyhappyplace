namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether value follows camel case.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if [is proper case] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsProperCase(this string value)
        {
            const string regExPattern = @"^[A-Z][a-z ]+";

            return MatchString(value, regExPattern);
        }
    }
}