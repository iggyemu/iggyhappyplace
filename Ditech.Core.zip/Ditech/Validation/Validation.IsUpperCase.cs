namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether [is upper case] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if [is upper case] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsUpperCase(this string value)
        {
            const string regExPattern = @"^[A-Z]+";

            return MatchString(value, regExPattern);
        }
    }
}