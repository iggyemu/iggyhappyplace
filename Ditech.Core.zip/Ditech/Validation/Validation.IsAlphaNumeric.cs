namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value contains only alphanumeric characters.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is alphanumeric; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsAlphaNumeric(this string value)
        {
            return value.IsAlphaNumeric(false);
        }


        /// <summary>
        /// Determines whether the specified value contains only alphanumeric characters.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <param name="allowSpaces">if set to <c>true</c> [allow spaces].</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is alphanumeric; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsAlphaNumeric(this string value, bool allowSpaces)
        {
            var regExPattern = allowSpaces ? @"^[a-zA-Z0-9 ]+$" : @"^[a-zA-Z0-9]+$";

            return MatchString(value, regExPattern);
        }
    }
}