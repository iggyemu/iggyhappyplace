﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Indicates which hash function to use
        /// </summary>
        public enum HashType
        {
            /// <summary>
            /// MD5 hash function
            /// </summary>
            MD5,
            /// <summary>
            /// SHA1 hash function
            /// </summary>
            SHA1
        }

        /// <summary>
        /// Performs a checksum to see if two objects a equal
        /// </summary>
        /// <param name="object1"></param>
        /// <param name="object2"></param>
        /// <param name="hashType"></param>
        /// <returns></returns>
        public static bool Checksum(object object1, object object2, HashType hashType = HashType.MD5)
        {
            string hash1 = null;
            string hash2 = null;

            switch (hashType)
            {        
                case HashType.SHA1 :
                    hash1 = GetSHA1(object1);
                    hash2 = GetSHA1(object2);
                    break;
                default :
                    hash1 = GetMD5(object1);
                    hash2 = GetMD5(object2);
                    break;
            }

            return hash1 == hash2;
        }
    }
}
