using System;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Returns whether the specified date is a Saturday or Sunday
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is weekend; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsWeekend(this DateTime value)
        {
            return (value.DayOfWeek == DayOfWeek.Saturday || value.DayOfWeek == DayOfWeek.Sunday);
        }
    }
}