namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is a zip code.
        /// Accepts 5, 9, and 5+4 digit formats.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if [is zip code] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsZipCode(this string value)
        {
            // Allows 5 digit, 5+4 digit and 9 digit zip codes
            var regExPattern = @"^\d{5}(-?\d{4})?$";
            return MatchString(value, regExPattern);
        }
    }
}