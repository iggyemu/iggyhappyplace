using System.Collections.Generic;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is a state.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is state; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsState(this string value)
        {
            // Names of the states
            string[] stateNames = {
                                      "ALABAMA", "ALASKA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO",
                                      "CONNECTICUT",
                                      "DELAWARE", "FLORIDA", "GEORGIA", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA"
                                      ,
                                      "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARYLAND", "MASSACHUSETTS",
                                      "MICHIGAN",
                                      "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA",
                                      "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA",
                                      "NORTH DAKOTA", "OHIO", "OKLAHOMA", "OREGON", "PENNSYLVANIA", "RHODE ISLAND",
                                      "SOUTH CAROLINA", "SOUTHDAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT",
                                      "VIRGINIA",
                                      "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"
                                  };
            // Abbreviations of the states
            string[] stateCodes = {
                                      "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI", "ID", "IL"
                                      ,
                                      "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE"
                                      ,
                                      "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD"
                                      ,
                                      "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
                                  };

            value = value.ToUpper();

            var stateCodesList = new List<string>(stateCodes);
            var stateNamesList = new List<string>(stateNames);

            return (stateCodesList.Contains(value) || stateNamesList.Contains(value));
        }
    }
}