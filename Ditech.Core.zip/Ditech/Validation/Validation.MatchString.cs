using System.Text.RegularExpressions;

namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Decomposed method which actually creates the pattern object and determines the match.
        /// Used by all of the other IsXXX functions. 
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="regExPattern">The reg ex pattern.</param>
        /// <returns>
        /// 	<c>true</c> if [is match] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool MatchString(string value, string regExPattern)
        {
            value = value.Trim();
            var pattern = new Regex(regExPattern);

            return pattern.IsMatch(value);
        }
    }
}