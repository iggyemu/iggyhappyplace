namespace Ditech
{
    /// <summary>
    /// Interface for objects that can either be valid or invalid
    /// </summary>
    public interface IValidState
    {
        /// <summary>
        /// Gets a value indicating whether this instance is in a valid state.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is valid state; otherwise, <c>false</c>.
        /// </value>
        bool IsValidState { get; }
    }
}