namespace Ditech
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is a positive integer (no negative, decimal, or commas). 
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is numeric; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNumeric(this string value)
        {
            return IsNumeric(value, false);
        }

        /// <summary>
        /// Determines whether the specified value is an integer (no decimals or commas).
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="allowNegative">if set to <c>true</c> [allow negative numbers].</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is numeric; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNumeric(this string value, bool allowNegative)
        {
            return IsNumeric(value, allowNegative, false);
        }

        /// <summary>
        /// Determines whether the specified value is numeric (no commas).
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="allowNegative">if set to <c>true</c> [allow negative numbers].</param>
        /// <param name="allowDecimal">if set to <c>true</c> [allow decimal].</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is numeric; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNumeric(this string value, bool allowNegative, bool allowDecimal)
        {
            return IsNumeric(value, allowNegative, allowDecimal, false);
        }

        /// <summary>
        /// Determines whether the specified value is numeric.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="allowNegative">if set to <c>true</c> [allow negative].</param>
        /// <param name="allowDecimal">if set to <c>true</c> [allow decimal].</param>
        /// <param name="allowComma">if set to <c>true</c> [allow comma].</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is numeric; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNumeric(this string value, bool allowNegative, bool allowDecimal, bool allowComma)
        {
            var regExPattern = "0-9";

            regExPattern += allowNegative ? "-" : string.Empty;
            regExPattern += allowDecimal ? "." : string.Empty;
            regExPattern += allowComma ? "," : string.Empty;

            regExPattern = System.String.Format("^[{0}]+$", regExPattern);

            return MatchString(Convert.ToString(value), regExPattern);
        }
    }
}