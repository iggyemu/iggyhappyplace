using System.Diagnostics;

namespace Ditech
{
    /// <summary>
    /// A class that provides small useful tools.
    /// </summary>
    public static class Performance
    {
        /// <summary>
        /// Frees up RAM.
        /// </summary>
        public static void FreeUpMemory()
        {
            try
            {
                var process = Process.GetCurrentProcess();
                process.MaxWorkingSet = process.MaxWorkingSet;
                process.Dispose();
            }
            catch
            {
            }
        }
    }
}