

using System.DirectoryServices;

namespace EverBank.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class DirectoryServices
    {
        /// <summary>
        /// Gets all the user information and returns it as a search result
        /// </summary>
        /// <param name="userQuery">The user query.</param>
        /// <param name="userAttribute">The user attribute.</param>
        /// <returns></returns>
        public static SearchResult UserInfo(string userQuery, UserAttribute userAttribute)
        {
            SearchResult result = null;

            if (userAttribute == UserAttribute.sid)
            {
                userQuery = GetSamAccountNameFromSid(userQuery);
                userAttribute = UserAttribute.samAccountName;
            }

            // create the directories and initialize the directory searcher
            DirectorySearcher[] searches = GetAllDirectories();

            // set the properties to return from a search for each domain
            foreach (DirectorySearcher search in searches)
            {
                // Find user by EMPLID
                search.Filter =
                    string.Format("(&(objectClass=user)(objectCategory=person)({0}={1}))",
                                  userAttribute.ToString("G"), userQuery);

                // finds the first entry
                result = search.FindOne();

                // return the result if not null
                if (result != null)
                {
                    break;
                }
            }

            return result;
        }
    }
}
