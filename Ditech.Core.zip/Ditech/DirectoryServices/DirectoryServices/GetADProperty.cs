﻿using System.DirectoryServices;

namespace EverBank.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class DirectoryServices
    {
        /// <summary>
        /// Pulls the AD property.
        /// </summary>
        /// <param employeeName="activeDirectoryResults">The active directory results.</param>
        /// <param employeeName="propertyName">Name of the property.</param>
        /// <returns></returns>
        public static object GetADProperty(SearchResult activeDirectoryResults, string propertyName)
        {
            // Iterate through each item in in the list (only returns first item)
            foreach (object myCollection in activeDirectoryResults.Properties[propertyName])
            {
                // Return the property as a string
                return myCollection;
            }

            // If no item found, return an empty string
            return null;
        }

        /// <summary>
        /// Pulls the AD property.
        /// </summary>
        /// <param name="activeDirectoryResults">The active directory results.</param>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="forceString">if set to <c>true</c> [force string].</param>
        /// <returns></returns>
        public static string GetADProperty(SearchResult activeDirectoryResults, string propertyName, bool forceString)
        {
            string result = string.Empty;

            object field = GetADProperty(activeDirectoryResults, propertyName);

            if (field != null)
            {
                result = field.ToString().Trim().Replace("'", "''");
            }

            return result;
        }


    }
}
