using System.DirectoryServices;

namespace Ditech.DirectoryServices
{
    public static partial class Property
    {
        /// <summary>
        /// Pulls the Active Directory property as a string. Returns a missing or null property as string.Empty
        /// </summary>
        /// <param employeeName="activeDirectoryResults">The active directory results.</param>
        /// <param employeeName="propertyName">Name of the property.</param>
        /// <returns>Returns active directory properties as a string.</returns>
        public static string ToString(this SearchResult activeDirectoryResults, string propertyName)
        {
            var rawResult = ToObject(activeDirectoryResults, propertyName);

            return Convert.ToString(rawResult);
        }
    }
}