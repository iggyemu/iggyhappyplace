using System.DirectoryServices;

namespace Ditech.DirectoryServices
{
    public static partial class Property
    {
        /// <summary>
        /// Pulls the Active Directory property as a raw object.
        /// </summary>
        /// <param name="activeDirectoryResults">The active directory results.</param>
        /// <param name="propertyName">Name of the property.</param>
        /// <returns>Returns an object</returns>
        public static object ToObject(this SearchResult activeDirectoryResults, string propertyName)
        {
            return activeDirectoryResults.Properties[propertyName].Count > 0
                       ? activeDirectoryResults.Properties[propertyName][0]
                       : null;
        }
    }
}