using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class Property
    {
        /// <summary>
        /// Gets multiple values from a property that is an array.
        /// </summary>
        /// <param name="userInfo">The user info SearchResult.</param>
        /// <param name="fieldToCheck">The field to check.</param>
        /// <param name="cleanUpCns">If set to true, the name of each employee will be parsed out of the CN.</param>
        /// <returns>ArrayList of groups.</returns>
        public static List<string> ToListString(SearchResult userInfo, string fieldToCheck, bool cleanUpCns)
        {
            var list = new List<string>();

            foreach (DictionaryEntry property in userInfo.Properties)
            {
                var splitKey = property.Key.ToString().Split(new[] {';'});

                var propertyName = splitKey[0];

                if (propertyName.ToUpper() == fieldToCheck.ToUpper())
                {
                    var propertyList = (ResultPropertyValueCollection) property.Value;

                    for (var i = 0; i < propertyList.Count; i++)
                    {
                        var propertyValue = propertyList[i].ToString();

                        if (cleanUpCns)
                        {
                            propertyValue = ToValueFromCn(propertyValue);
                        }

                        list.Add(propertyValue);
                    }
                }
            }



            list.Sort();
            return list;
        }
    }
}