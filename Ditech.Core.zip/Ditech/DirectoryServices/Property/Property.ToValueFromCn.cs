namespace Ditech.DirectoryServices
{
    public static partial class Property
    {
        /// <summary>
        /// A CN value has multiple parts separated by commas. This gets just the first part.
        /// </summary>
        /// <param name="cnValue">The cn value.</param>
        /// <returns>Returns a string.</returns>
        public static string ToValueFromCn(string cnValue)
        {
            return string.IsNullOrEmpty(cnValue) ? string.Empty : cnValue.Split(',')[0].Remove("CN=");
        }
    }
}