

using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace EverBank.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class Conversions
    {
        /// <summary>
        /// Gets the active directory account name using the sid.
        /// </summary>
        /// <param name="sid">The sid.</param>
        /// <returns></returns>
        public static string GetSamAccountNameFromSid(string sid)
        {
            IntPtr _sid = IntPtr.Zero; //pointer to binary form of SID string.
            int _nameLength = 0; //size of object name buffer
            int _domainLength = 0; //size of domain name buffer
            int _use; //type of object
            StringBuilder _domain = new StringBuilder(); //domain name variable
            int _error = 0;
            StringBuilder _name = new StringBuilder(); //object name variable

            //converts SID string into the binary form
            bool _rc0 = ConvertStringSidToSid(sid, ref _sid);

            if (_rc0 == false)
            {
                _error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(_sid);
                throw (new Exception(new Win32Exception(_error).Message));
            }

            //first call of method returns the size of domain name 
            //and object name buffers
            bool _rc = LookupAccountSid(null, _sid, _name, ref _nameLength, _domain,
                                        ref _domainLength, out _use);
            _domain = new StringBuilder(_domainLength); //allocates memory for domain name
            _name = new StringBuilder(_nameLength); //allocates memory for object name
            _rc = LookupAccountSid(null, _sid, _name, ref _nameLength, _domain,
                                   ref _domainLength, out _use);

            if (_rc == false)
            {
                _error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(_sid);
                throw (new Exception(new Win32Exception(_error).Message));
            }
            else
            {
                Marshal.FreeHGlobal(_sid);
                //return _domain.ToString() + "\\" + _name.ToString();
                return _name.ToString();
            }
        }

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool LookupAccountSid(
            [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
            IntPtr sid,
            [Out, MarshalAs(UnmanagedType.LPTStr)] StringBuilder name,
            ref int cbName,
            StringBuilder referencedDomainName,
            ref int cbReferencedDomainName,
            out int use);
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool LookupAccountName(
            [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
            [In, MarshalAs(UnmanagedType.LPTStr)] string accountName,
            IntPtr sid,
            ref int cbSid,
            StringBuilder referencedDomainName,
            ref int cbReferencedDomainName,
            out int use);
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool ConvertSidToStringSid(
            IntPtr sid,
            [In, Out, MarshalAs(UnmanagedType.LPTStr)] ref string pStringSid);
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool ConvertStringSidToSid(
            [In, MarshalAs(UnmanagedType.LPTStr)] string pStringSid,
            ref IntPtr sid);
    }
}
