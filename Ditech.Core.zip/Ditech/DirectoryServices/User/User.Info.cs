﻿using System.DirectoryServices;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This class returns a User object based on parameters passed in.
    /// </summary>
    public partial class User : IValidState
    {
        /// <summary>
        /// Gets all the user information. 
        /// </summary>
        /// <param name="userQuery">The user query.</param>
        /// <param name="userAttribute">The user attribute.</param>
        /// <returns>Returns search result.</returns>
        public static SearchResult Info(string userQuery, UserAttribute userAttribute)
        {
            SearchResult result = null;

            if (userAttribute == UserAttribute.Sid)
            {
                userQuery = Conversions.ToSamAccountName(userQuery);
                userAttribute = UserAttribute.SamAccountName;
            }

            // create the directories and initialize the directory searcher
            var searches = Current.AllDirectories();

            // set the properties to return from a search for each domain
            foreach (var search in searches)
            {
                // Find user by EMPLID
                search.Filter =
                    System.String.Format("(&({0}={1}))",
                                         userAttribute.ToString("G"), userQuery);

                // finds the first entry
                result = search.FindOne();

                // return the result if not null
                if (result != null)
                {
                    break;
                }
            }

            return result;
        }
    }
}