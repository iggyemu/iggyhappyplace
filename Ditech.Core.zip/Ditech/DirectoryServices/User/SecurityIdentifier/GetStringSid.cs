

using System;
using System.Runtime.InteropServices;

namespace EverBank.DirectoryServices
{    
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class Conversions
    {      
        /// <summary>
        /// Converts the sid to string sid.
        /// </summary>
        /// <param name="sidArray">The sid array.</param>
        /// <returns></returns>
        public static string GetStringSid(this byte[] sidArray)
        {
            string stringSid = string.Empty;

            int size = Marshal.SizeOf(sidArray[0]) * sidArray.Length;
            IntPtr bytePointer = Marshal.AllocHGlobal(size);
            ;
            Marshal.Copy(sidArray, 0, bytePointer, size);

            ConvertSidToStringSid(bytePointer, ref stringSid);

            return stringSid;
        }
    }
}
