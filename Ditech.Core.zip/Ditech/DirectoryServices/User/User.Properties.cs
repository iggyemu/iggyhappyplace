﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.DirectoryServices;
using System.Security.Principal;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This class returns a User object based on parameters passed in.
    /// </summary>
    public partial class User : IValidState
    {
        #region Properties (26)

        /// <summary>
        /// Gets the adsPath.
        /// </summary>
        /// <value>The AdsPath.</value>
        public string AdsPath { get; private set; }

        /// <summary>
        /// Gets the cn.
        /// </summary>
        /// <value>The cn.</value>
        public string Cn { get; private set; }

        /// <summary>
        /// Gets the company.
        /// </summary>
        /// <value>The company.</value>
        public string Company { get; private set; }

        /// <summary>
        /// Gets the cost center.
        /// </summary>
        /// <value>The cost center.</value>
        public string CostCenter { get; private set; }

        /// <summary>
        /// Gets the department.
        /// </summary>
        /// <value>The department.</value>
        public string Department { get; private set; }

        /// <summary>
        /// Gets the names of direct reports.
        /// </summary>
        /// <value>The direct reports.</value>
        public List<string> DirectReports { get; private set; }

        /// <summary>
        /// Gets the full CN values for direct reports.
        /// </summary>
        /// <value>The direct reports CN values.</value>
        public List<string> DirectReportsCns { get; private set; }

        /// <summary>
        /// Gets the displayed name.
        /// </summary>
        /// <value>The name of the distinguished.</value>
        public string DisplayName { get; private set; }

        /// <summary>
        /// Gets the name of the distinguished.
        /// </summary>
        /// <value>The name of the distinguished.</value>
        public string DistinguishedName { get; private set; }

        /// <summary>
        /// Get the name of the Division
        /// </summary>
        /// <value>The number of the department</value>
        public string Division { get; private set; }

        /// <summary>
        /// Gets or sets the domain.
        /// </summary>
        /// <value>The domain.</value>
        public string Domain { get; private set; }

        /// <summary>
        /// Gets the empl ID.
        /// </summary>
        /// <value>The empl ID.</value>
        public string EmplID { get; private set; }

        /// <summary>
        /// Gets the type of the employee.
        /// </summary>
        /// <value>The type of the employee.</value>
        public string EmployeeType { get; private set; }

        /// <summary>
        /// Gets the name of the given.
        /// </summary>
        /// <value>The name of the given.</value>
        public string GivenName { get; private set; }

        /// <summary>
        /// Gets the initials.
        /// </summary>
        /// <value>The initials.</value>
        public string Initials { get; private set; }


        /// <summary>
        /// Gets the mail.
        /// </summary>
        /// <value>The mail.</value>
        public string Mail { get; private set; }

        /// <summary>
        /// Gets the manager.
        /// </summary>
        /// <value>The manager.</value>
        public string Manager { get; private set; }

        /// <summary>
        /// Gets the manager name.
        /// </summary>
        /// <value>The manager.</value>
        public string ManagerName { get; private set; }

        /// <summary>
        /// Gets the name of the sam account.
        /// </summary>
        /// <value>The name of the sam account.</value>
        public string SamAccountName { get; private set; }

        /// <summary>
        /// Gets or sets the Security Identifer.
        /// </summary>
        /// <value>The sid.</value>
        public byte[] Sid { get; private set; }

        /// <summary>
        /// Gets the sn.
        /// </summary>
        /// <value>The sn.</value>
        public string Sn { get; private set; }

        /// <summary>
        /// Gets the telephone number.
        /// </summary>
        /// <value>The telephone number.</value>
        public string TelephoneNumber { get; private set; }

        /// <summary>
        /// Gets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; private set; }

        private SearchResult UserInfo { get; set; }

        /// <summary>
        /// Gets a value indicating whether this instance is in a valid state.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is valid state; otherwise, <c>false</c>.
        /// </value>
        public bool IsValidState
        {
            get { return (UserInfo != null); }
        }


        /// <summary>
        /// Gets or sets the user attributes.
        /// </summary>
        /// <value>The user attributes.</value>
        public HybridDictionary UserAttributes { get; private set; }

        private static WindowsIdentity _currentWindowsIdentity;
        public static WindowsIdentity CurrentWindowsIdentity
        {
            get { return _currentWindowsIdentity = (_currentWindowsIdentity ?? WindowsIdentity.GetCurrent()); }
        }

        /// <summary>
        /// The name of the current windows identity formatted as DOMAIN\UserName.  This is the account
        /// that the application is running as which is not necessarily the same as the account that is
        /// currently logged into windows.
        /// </summary>
        public static string CurrentWindowsUserName 
        {
            get
            {
                var res = string.Empty;
                if (CurrentWindowsIdentity != null)
                {
                    res = CurrentWindowsIdentity.Name;
                }
                return res;
            }
        }

        /// <summary>
        /// The name of the logged in windows identity formatted as DOMAIN\UserName.  This is the account
        /// that is currently logged in to the Windows OS.
        /// </summary>
        public static string WindowsUserName
        {
            get
            {
                return string.Format(@"{0}\{1}", Environment.UserDomainName, Environment.UserName);
            }
        }

        /// <summary>
        /// Extension Attribute 5: MSP User ID
        /// </summary>
        public string ExtensionAttribute5 { get; set; }

        /// <summary>
        /// Extension Attribute 6: MSP Security Template
        /// </summary>
        public string ExtensionAttribute6 { get; set; }

        #endregion Properties 
    }
}