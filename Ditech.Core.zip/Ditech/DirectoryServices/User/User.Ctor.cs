using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Security.Principal;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This class returns a User object based on parameters passed in.
    /// </summary>
    [Serializable]
    public partial class User : IValidState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class.
        /// </summary>
        /// <param name="userAttribute">The user attribute.</param>
        /// <param name="attributeValue">The attribute value.</param>
        public User(UserAttribute userAttribute, string attributeValue)
        {
            // ASP.NET applications will pass the user name as DOMAIN\USERNAME.  This will allow those names to also be formatted.
            if (userAttribute == UserAttribute.SamAccountName)
            {
                attributeValue = Path.GetFileName(attributeValue);
            }

            UserInfo = Info(attributeValue, userAttribute);

            if (IsValidState)
                {
                    try
                    {
                        UserAttributes = new HybridDictionary(true);

                        foreach (string propertyName in UserInfo.Properties.PropertyNames)
                        {
                            UserAttributes.Add(propertyName, UserInfo.Properties[propertyName]);
                        }

                        AdsPath = UserInfo.ToString("adsPath");
                        Cn = UserInfo.ToString("cn");
                        Company = UserInfo.ToString("company");
                        Department = UserInfo.ToString("department");
                        DisplayName = UserInfo.ToString("displayName");
                        DistinguishedName = UserInfo.ToString("distinguishedName");
                        Division = UserInfo.ToString("extensionAttribute4");

                        var startLocation = AdsPath.IndexOf("DC=") + "DC=".Length;
                        var endLocation = AdsPath.IndexOf(",", startLocation);
                        Domain = AdsPath.Mid(startLocation, endLocation - startLocation).Trim();

                        EmplID = UserInfo.ToString("employeeNumber");
                        EmployeeType = UserInfo.ToString("employeeType");
                        CostCenter = UserInfo.ToString("extensionAttribute1");
                        GivenName = UserInfo.ToString("givenName");
                        Initials = UserInfo.ToString("initials");
                        Mail = UserInfo.ToString("mail");
                        Manager = UserInfo.ToString("manager");
                        ManagerName = Property.ToValueFromCn(Manager);
                        SamAccountName = UserInfo.ToString("samAccountName");
                        Sn = UserInfo.ToString("sn");
                        TelephoneNumber = UserInfo.ToString("telephoneNumber");
                        Title = UserInfo.ToString("title");
                        DirectReports = Property.ToListString(UserInfo, "directReports", true);
                        DirectReportsCns = Property.ToListString(UserInfo, "directReports", false);
                        Sid = (byte[])UserInfo.ToObject("objectsid");
                        ExtensionAttribute5 = UserInfo.ToString("extensionattribute5");
                        ExtensionAttribute6 = UserInfo.ToString("extensionattribute6");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("User lookup problem (" + attributeValue + "): " + ex.Message);
                    }
                }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class.
        /// </summary>
        /// <param name="samAccountName">The user's network login.  Can be DOMAIN\LOGIN or just LOGIN.</param>
        public User(string samAccountName) : this(UserAttribute.SamAccountName, samAccountName)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class using the current app user.
        /// </summary>
        public User() : this(UserAttribute.SamAccountName, CurrentWindowsUserName)
        {
        }
    }
}