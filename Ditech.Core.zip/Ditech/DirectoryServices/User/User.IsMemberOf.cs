﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using System.Windows.Forms.VisualStyles;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This class returns a User object based on parameters passed in.
    /// </summary>
    public partial class User : IValidState
    {
        /// <summary>
        /// Determines whether the user [is a member of] [the specified group name].
        /// </summary>
        /// <param name="groupName">Name of the group.</param>
        /// <returns>
        /// 	<c>true</c> if [is member of] [the specified group name]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsMemberOf(string groupName)
        {
            var result = false;

            try
            {
                var user = GetUserPrincipal();

                var group = GetGroupPrincipal(groupName);

                result = user.IsMemberOf(group);
            }
            catch { }

            return result;
        }

        private UserPrincipal GetUserPrincipal()
        {
            UserPrincipal user = null;

            foreach (var domain in Current.DomainListing)
            {
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, domain);
                user = UserPrincipal.FindByIdentity(ctx, IdentityType.SamAccountName,
                    SamAccountName);

                if (user != null)
                {
                    break;
                }
            }

            if (user == null)
            {
                throw new ApplicationException("Unable to find a user principal matching this SAM account name: " +
                                               SamAccountName);
            }

            return user;
        }

        private GroupPrincipal GetGroupPrincipal(string groupName)
        {
            GroupPrincipal group = null;

            foreach (var domain in Current.DomainListing)
            {
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain, domain);
                group = GroupPrincipal.FindByIdentity(ctx, groupName);

                if (group != null)
                {
                    break;
                }
            }

            if (group == null)
            {
                throw new ApplicationException("Unable to find a group principal matching this group name: " + groupName);
            }

            return group;
        }
    }
}