using System.Text;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public class LDAP
    {
        /// <summary>
        /// Builds the LDAP path for the specified domain
        /// </summary>
        /// <param name="domainName">Name of the domain.</param>
        /// <returns>Returns the path</returns>
        public static string Path(string domainName)
        {
            return Path(domainName, string.Empty);
        }

        /// <summary>
        /// Builds the LDAP path for the specified domain
        /// </summary>
        /// <param name="domainName">Name of the domain.</param>
        /// <param name="filter">The filter.</param>
        /// <returns>Returns the path.</returns>
        public static string Path(string domainName, string filter)
        {
            // split out the rest of the path on periods (corporate.us.local)
            var splitDomainName = domainName.Split(new[] {'.'});

            // Initialize the string builder
            var newPath = new StringBuilder("LDAP://");

            // Add the filter

            if (filter != string.Empty)
            {
                newPath.Append(filter + ",");
            }

            newPath.Append("dc=");

            newPath.Append(System.String.Join(",dc=", splitDomainName));

            // Return the new path
            return newPath.ToString();
        }
    }
}