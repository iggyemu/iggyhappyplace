namespace Ditech.DirectoryServices
{
    /// <summary>
    /// List of user attributes that can be queried against.
    /// </summary>
    public enum UserAttribute
    {
        /// <summary>
        /// Canonical Name
        /// </summary>
        CN,
        /// <summary>
        /// Distinguished Name
        /// </summary>
        DistinguishedName,
        /// <summary>
        /// EMPLID
        /// </summary>
        EmployeeNumber,
        /// <summary>
        /// Email Address
        /// </summary>
        Mail,
        /// <summary>
        /// Login Name
        /// </summary>
        SamAccountName,
        /// <summary>
        /// SID
        /// </summary>
        Sid
    }
}