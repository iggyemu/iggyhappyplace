using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class Current
    {
        /// <summary>
        /// Returns the listing of domains for Ditech
        /// </summary>
        public static string[] DomainListing
        {
            get
            {
                return new[]
                {
                    @"gtfc.com", @"ditech.us"
                };
            }
        }

        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Gets all directories in domain.
        /// </summary>
        /// <param name="filter">The filter.</param>
        /// <returns>All directories</returns>
        public static DirectorySearcher[] AllDirectories(string filter)
        {
            var directories = new List<DirectorySearcher>();

            foreach (var domain in DomainListing)
            {
                directories.Add(Add(domain));
            }

            return directories.ToArray();
        }

        private static DirectorySearcher Add(string name)
        {
            var directoryContext = new DirectoryContext(DirectoryContextType.Forest, name);
            var forest = Forest.GetForest(directoryContext);

            var catalog = forest.FindGlobalCatalog();

            var searcher = catalog.GetDirectorySearcher();

            searcher.PageSize = 999;
            return searcher;
        }

        /// <summary>
        /// Gets all directories.
        /// </summary>
        /// <returns>All directories.</returns>
        public static DirectorySearcher[] AllDirectories()
        {
            return AllDirectories(string.Empty);
        }

        #endregion�Methods�
    }
}