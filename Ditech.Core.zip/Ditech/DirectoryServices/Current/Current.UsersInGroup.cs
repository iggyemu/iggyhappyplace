using System.Collections.Generic;
using System.DirectoryServices;
using System.Text.RegularExpressions;
using System.Web.Caching;

namespace Ditech.DirectoryServices
{
    public static partial class Current
    {
        /// <summary>
        /// Gets all users in the group.
        /// </summary>
        /// <param name="groupName">Name of the group.</param>
        /// <returns>Returns list of users in the group or null</returns>
        public static List<User> UsersInGroup(string groupName)
        {
            var userList = new List<User>();

            var searches = AllDirectories();

            foreach (var directorySearcher in searches)
            {
                directorySearcher.PropertiesToLoad.Add("member");
                directorySearcher.SearchScope = SearchScope.Subtree;
                directorySearcher.Filter = "(CN=" + groupName + ")";
                directorySearcher.PageSize = 500; // In pages of 500 entries
                var searchResult = directorySearcher.FindOne();

                if (searchResult != null)
                {
                    foreach (var value in Property.ToListString(searchResult, "member", true))
                    {
                        var attributeType = UserAttribute.CN;

                        var isSid = Regex.IsMatch(value, @"^S-\d-\d+-(\d+-){1,14}\d+$");

                        if (isSid)
                        {
                            attributeType = UserAttribute.Sid;
                        }

                        userList.Add(new User(attributeType, value));
                    }

                    break;
                }
            }

            return userList;
        }
    }
}