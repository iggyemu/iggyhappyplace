using System.Collections.Generic;
using System.DirectoryServices;

namespace Ditech.DirectoryServices
{
    public static partial class Current
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Gets all employees in a specified location.
        /// </summary>
        /// <param name="specifiedLocation">The specific location.</param>
        /// <param name="propertiesToLoad">Specify which properties to load</param>
        /// <returns>Returns search result for a specific location.</returns>
        public static SearchResult[] AllEmployees(string specifiedLocation = null, ICollection<string> propertiesToLoad = null)
        {
            var list = new List<SearchResult>();

            foreach (var currentDirectory in AllDirectories())
            {
                currentDirectory.Filter = "(&(objectClass=user)(objectCategory=person))";

                if (propertiesToLoad != null)
                {
                    foreach (var property in propertiesToLoad)
                    {
                        currentDirectory.PropertiesToLoad.Add(property);
                    }
                }

                var searchResults = currentDirectory.FindAll();

                foreach (SearchResult person in searchResults)
                {
                    var company = person.ToString("company");
                    var adsPath = person.ToString("adsPath");
                    var employeeType = person.ToString("employeeType");

                    if (!company.Contains("Service Accounts")
                        && !company.Contains("Train")
                        && (adsPath.Contains("OU=Employees") || adsPath.Contains("OU=EBN") || adsPath.Contains("OU=ECF"))
                        && !employeeType.Contains("Exclude"))
                    {
                        if (!string.IsNullOrEmpty(specifiedLocation))
                        {
                            var location = person.ToString("l");

                            if (location == specifiedLocation)
                            {
                                list.Add(person);
                            }
                        }
                        else
                        {
                            list.Add(person);
                        }
                    }
                }
            }

            return list.ToArray();
        }

        #endregion�Methods�
    }
}