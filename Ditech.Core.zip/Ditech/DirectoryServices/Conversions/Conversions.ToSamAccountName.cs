using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace Ditech.DirectoryServices
{
    /// <summary>
    /// This static class provides re-usable directory service methods.
    /// </summary>
    public static partial class Conversions
    {
        #region�Methods�(2)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Gets the active directory account name using the sid.
        /// </summary>
        /// <param name="sid">The sid.</param>
        /// <returns>SAM account name.</returns>
        public static string ToSamAccountName(string sid)
        {
            var sidPointer = IntPtr.Zero; //pointer to binary form of SID string.
            var nameLength = 0; //size of object name buffer
            var domainLength = 0; //size of domain name buffer
            int use; //type of object
            var domainName = new StringBuilder(); //domain name variable
            var samAccountName = new StringBuilder(); //object name variable

            //converts SID string into the binary form
            CheckResult(ConvertStringSidToSid(sid, ref sidPointer), sidPointer);

            //first call of method returns the size of domain name 
            //and object name buffers
            LookupAccountSid(null, sidPointer, samAccountName, ref nameLength, domainName,
                             ref domainLength, out use);

            domainName = new StringBuilder(domainLength); //allocates memory for domain name
            samAccountName = new StringBuilder(nameLength); //allocates memory for object name

            CheckResult(LookupAccountSid(null, sidPointer, samAccountName, ref nameLength, domainName,
                                         ref domainLength, out use), sidPointer);

            Marshal.FreeHGlobal(sidPointer);

            return samAccountName.ToString();
        }


        //�Private�Methods�(1)�

        private static void CheckResult(bool result, IntPtr sidPointer)
        {
            if (result == false)
            {
                var error = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(sidPointer);
                throw (new Exception(new Win32Exception(error).Message));
            }
        }

        #endregion�Methods�

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool LookupAccountSid(
            [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
            IntPtr sid,
            [Out, MarshalAs(UnmanagedType.LPTStr)] StringBuilder name,
            ref int cbName,
            StringBuilder referencedDomainName,
            ref int cbReferencedDomainName,
            out int use);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool LookupAccountName(
            [In, MarshalAs(UnmanagedType.LPTStr)] string systemName,
            [In, MarshalAs(UnmanagedType.LPTStr)] string accountName,
            IntPtr sid,
            ref int cbSid,
            StringBuilder referencedDomainName,
            ref int cbReferencedDomainName,
            out int use);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool ConvertSidToStringSid(
            IntPtr sid,
            [In, Out, MarshalAs(UnmanagedType.LPTStr)] ref string pStringSid);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool ConvertStringSidToSid(
            [In, MarshalAs(UnmanagedType.LPTStr)] string pStringSid,
            ref IntPtr sid);
    }
}