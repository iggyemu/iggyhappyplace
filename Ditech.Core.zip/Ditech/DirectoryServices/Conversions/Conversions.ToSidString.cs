using System.Runtime.InteropServices;

namespace Ditech.DirectoryServices
{
    public static partial class Conversions
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Converts the sid to string sid.
        /// </summary>
        /// <param name="sidArray">The sid array.</param>
        /// <returns>Returns the string sid.</returns>
        public static string ToSidString(this byte[] sidArray)
        {
            var stringSid = string.Empty;

            var size = Marshal.SizeOf(sidArray[0])*sidArray.Length;
            var bytePointer = Marshal.AllocHGlobal(size);

            Marshal.Copy(sidArray, 0, bytePointer, size);

            ConvertSidToStringSid(bytePointer, ref stringSid);

            return stringSid;
        }

        #endregion�Methods�
    }
}