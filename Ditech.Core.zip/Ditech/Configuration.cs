﻿using System.Collections.Specialized;
using System.Configuration;

namespace Ditech
{
    public static class Configuration
    {
        //private static System.Configuration.Configuration _configuration =
        //     ConfigurationManager.OpenExeConfiguration("Ditech.dll");

        //private static AppSettingsSection _appSettings = (AppSettingsSection)_configuration.GetSection("appSettings");
        private static NameValueCollection _appSettings = ConfigurationManager.AppSettings;
        
        public static string OleDbConnectionString
        {
            get { return _appSettings["OleDbConnectionString"]; }
        }

        public static string OleDbProvider
        {
            get { return _appSettings["OleDbProvider"]; }
        }

        public static string OleDbServerName
        {
            get { return _appSettings["OleDbServerName"]; }
        }

        public static string OracleConnectionString
        {
            get { return _appSettings["OracleConnectionString"]; }
        }

        public static string OracleServerName
        {
            get { return _appSettings["OracleServerName"]; }
        }

        public static string Password
        {
            get { return _appSettings["Password"]; }
        }

        public static string SqlConnectionString
        {
            get { return _appSettings["SqlConnectionString"]; }
        }

        public static string SqlInitialCatalog
        {
            get { return _appSettings["SqlInitialCatalog"]; }
        }

        public static string SqlServerName
        {
            get { return _appSettings["SqlServerName"]; }
        }
        
        public static string UserName
        {
            get { return _appSettings["UserName"]; }
        }
        
        public static string MailServer
        {
            get { return _appSettings["MailServer"]; }
        }
    }
}
