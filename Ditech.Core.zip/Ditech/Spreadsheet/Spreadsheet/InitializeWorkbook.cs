

using System.Data;
using CarlosAg.ExcelXmlWriter;

namespace EverBank.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        public static void InitializeWorkbook(out Workbook book, out Worksheet sheet)
        {
            // Create a new workbook and add a new worksheet
            book = new Workbook();
            sheet = book.Worksheets.Add("Sheet1");

            WorksheetStyle dateStyle = book.Styles.Add("date");
            dateStyle.NumberFormat = "Short Date";
        }

        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="headers">The header.</param>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        public static void InitializeWorkbook(string[] headers, out Workbook book, out Worksheet sheet)
        {
            InitializeWorkbook(out book, out sheet);

                WorksheetRow headerRow = CreateHeaderRow(book, sheet);

                // Add a header to each column
                foreach (string header in headers)
                {
                    // Add each 
                    sheet.Table.Columns.Add(new WorksheetColumn());
                    headerRow.Cells.Add(new WorksheetCell(header, "Bold"));
                }
        }
    }
}
