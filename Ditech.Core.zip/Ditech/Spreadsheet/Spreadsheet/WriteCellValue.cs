

using System;
using CarlosAg.ExcelXmlWriter;

namespace EverBank.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Writes the cell value.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="data">The data.</param>
        /// <param name="row">The row.</param>
        public static void WriteCellValue(DataType type, string data, WorksheetRow row)
        {
            // Create a new cell to hold the data
            WorksheetCell cell;

            // If it is DateTime data, output it in the short DateTime format
            if (type == DataType.DateTime)
            {
                DateTime date;

                DateTime.TryParse(data, out date);

                cell = new WorksheetCell(date.ToString("s"), type, "date");
            }
            else
            {
                // Else, create the new cell with the data
                cell = new WorksheetCell(data, type);
            }

            // Add the cell to the row
            row.Cells.Add(cell);
        }
    }
}
