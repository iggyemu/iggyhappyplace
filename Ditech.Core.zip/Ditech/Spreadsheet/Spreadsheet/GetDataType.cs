

using System;
using System.Data;
using CarlosAg.ExcelXmlWriter;

namespace EverBank.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Gets the type of the carlos AG data.
        /// </summary>
        /// <param name="dataType">Type of the data.</param>
        /// <returns>CarlosAG Datatype of the passed .NET Type.</returns>
        private static DataType GetDataType(Type dataType)
        {
            // Convert the Type to its string representation
            string type = dataType.ToString();

            DataType dt;

            // Cut "System." off the string
            type = type.Mid(type.IndexOf('.') + 1).ToLower();

            // Return the match data type in carlos ag
            switch (type)
            {
                //Number data types
                case "decimal":
                case "int":
                case "int16":
                case "int32":
                case "int64":
                case "byte":
                    dt = DataType.Number;
                    break;
                // Boolean data types
                case "boolean":
                    dt = DataType.Boolean;
                    break;
                // DateTime data type
                case "datetime":
                    dt = DataType.DateTime;
                    break;
                // String data type
                default:
                    dt = DataType.String;
                    break;
            }

            // If no match was found, return type string
            return dt;
        }
    }
}
