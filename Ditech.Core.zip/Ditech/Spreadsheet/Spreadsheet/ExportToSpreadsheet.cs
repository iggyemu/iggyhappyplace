

using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using CarlosAg.ExcelXmlWriter;
using DbCommand=EverBank.Data.Common.DbCommand;

namespace EverBank.CarlosAg
{
    public static partial class Spreadsheet
    {
        /// <summary>
        /// Exports to spreadsheet.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="outputPath">The output path.</param>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="connection">The connection.</param>
        /// <returns></returns>
        public static DataSet ExportToSpreadsheet(string query, string outputPath, bool outputHeaders,
                                               DbConnection connection)
        {
            DataSet dataset;

            // Create a new sql command object with the parameters
            using (var command = new DbCommand(query, connection))
            {
                command.CommandTimeout = 0;

                dataset = command.ExecuteDataSet();
            }

            WriteDataSetToSpreadsheet(outputHeaders, dataset, outputPath);


            return dataset;
        }
    }
}
