

using System.Data;
using CarlosAg.ExcelXmlWriter;

namespace EverBank.CarlosAg
{
    public static partial class Spreadsheet
    {

        /// <summary>
        /// Writes the data reader to spreadsheet.
        /// </summary>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="dataSet">The data reader.</param>
        /// <param name="outputPath">The output path.</param>
        /// <returns></returns>
        public static void WriteDataSetToSpreadsheet(bool outputHeaders, DataSet dataSet, string outputPath)
        {
            const int MAX_ROWS = 65536;

            Workbook book;
            Worksheet sheet;

            int count;

            InitializeWorkbook(outputHeaders, dataSet, out book, out sheet, out count);

            int spreadsheetCount = 1;
            string newPath;

            // Read in the results of the query (one record at a time)
            foreach (DataRow dataRow in dataSet.Tables[0].Rows)
            {
                if (count >= MAX_ROWS)
                {
                    int index = outputPath.IndexOf('.');
                    newPath = outputPath.Insert(index, "_" + spreadsheetCount);

                    book.Save(newPath);

                    InitializeWorkbook(outputHeaders, dataSet, out book, out sheet, out count);

                    spreadsheetCount++;
                }

                // A new row to the spreadsheet to hold the new record
                WorksheetRow row = sheet.Table.Rows.Add();

                // Output each field
                foreach (DataColumn dataColumn in dataSet.Tables[0].Columns)
                {
                    // Get the correct data type
                    DataType type = GetDataType(dataRow[dataColumn].GetType());

                    // Get the data as a string
                    string data = dataRow[dataColumn].ToString();

                    WriteCellValue(type, data, row);
                }

                count++;
            }

            if (spreadsheetCount == 1)
            {
                newPath = outputPath;
            }
            else
            {
                int index = outputPath.IndexOf('.');
                newPath = outputPath.Insert(index, "_" + spreadsheetCount);
            }

            // Processing finished, save off the book
            book.Save(newPath);
        }

        /// <summary>
        /// Initializes the work book.
        /// </summary>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        /// <param name="dataSet">The data set.</param>
        /// <param name="book">The book.</param>
        /// <param name="sheet">The sheet.</param>
        /// <param name="count">The count.</param>
        private static void InitializeWorkbook(bool outputHeaders, DataSet dataSet, out Workbook book, out Worksheet sheet, out int count)
        {
            InitializeWorkbook(out book, out sheet);

            // Output the headers if needed
            if (outputHeaders)
            {
                WorksheetRow headerRow = CreateHeaderRow(book, sheet);

                // Add a header to each column
                foreach (DataColumn column in dataSet.Tables[0].Columns)
                {
                    // Add each 
                    sheet.Table.Columns.Add(new WorksheetColumn());
                    headerRow.Cells.Add(new WorksheetCell(column.ColumnName, "Bold"));
                }
            }

            count = 0;

            if (outputHeaders)
            {
                count = 1;
            }
        }
    }
}
