﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Text;
using EverBank.DirectoryServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{
    [TestClass()]
    public class ActiveDirectoryTests
    {
        public string samAccountName = WindowsIdentity.GetCurrent().Name.Split(new char[] {'\\'})[1];

        [TestMethod()]
        public void ActiveDirectoryUserConstructorSamAccountName()
        {
            User user = new User("canderso");

            Assert.AreEqual("Anderson", user.Sn);
        }

        [TestMethod()]
        public void ActiveDirectoryUserEmptyConstructor()
        {
            User user = new User();

            Assert.AreEqual(samAccountName, user.SamAccountName);
        }

        [TestMethod()]
        public void ActiveDirectoryUserConstructor()
        {
            User user = new User(UserAttribute.SamAccountName, "canderso");

            Assert.AreEqual("Anderson", user.Sn);
        }

        [TestMethod()]
        public void ActiveDirectorySamAccountNameConversionTest()
        {
            User user = new User();

            string sid = user.Sid.ToSidString();

            Assert.AreEqual(user.SamAccountName, Conversions.ToSamAccountName(sid));
        }
    }
}
