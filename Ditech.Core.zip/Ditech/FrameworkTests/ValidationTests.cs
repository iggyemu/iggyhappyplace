﻿using System;
using System.Resources;
using EverBank.Net.Mail;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{
    /// <summary>
    ///This is a test class for MailTest and is intended
    ///to contain all MailTest Unit Tests
    ///</summary>
    [TestClass]
    public class ValidationTest
    {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///A test for MailServer
        ///</summary>
        [TestMethod]
        public void ValidationIsAlpha()
        {
            Assert.IsTrue(Validation.IsAlpha("cat"));
            Assert.IsFalse(Validation.IsAlpha("cat dog"));

            Assert.IsTrue(Validation.IsAlpha("cat dog", true));
            Assert.IsFalse(Validation.IsAlpha("cat dog", false));

            Assert.IsTrue(Validation.IsAlpha("cat", false));

        }

        /// <summary>
        ///A test for MailServer
        ///</summary>
        [TestMethod]
        public void ValidationIsMoney()
        {
            Assert.IsTrue(Validation.IsMoney("0.00", false));
            Assert.IsTrue(Validation.IsMoney("0.00", true));
            
            Assert.IsFalse(Validation.IsMoney("0", true));

            Assert.IsTrue(Validation.IsMoney("1,000.00", false));
            Assert.IsTrue(Validation.IsMoney("1,000.00", true));

            Assert.IsTrue(Validation.IsMoney("$1,000.00", false));
            Assert.IsTrue(Validation.IsMoney("$1,000.00", true));

            Assert.IsFalse(Validation.IsMoney("0.0", false));

            Assert.IsFalse(Validation.IsMoney("$1", true));
            Assert.IsFalse(Validation.IsMoney("1", true));

            Assert.IsTrue(Validation.IsMoney("1,000,000.00",false));
            
        }

        /// <summary>
        ///A test for MailServer
        ///</summary>
        [TestMethod]
        public void ValidationIsNumeric()
        {
            Assert.IsTrue(Validation.IsNumeric("0", false, false, false));

            Assert.IsTrue(Validation.IsNumeric("1000", false, false, false));
            Assert.IsTrue(Validation.IsNumeric("1000", true, false, false));
            Assert.IsTrue(Validation.IsNumeric("1000", true, true, false));
            Assert.IsTrue(Validation.IsNumeric("1000", true, true, true));

            Assert.IsFalse(Validation.IsNumeric("-1000", false, false, false));
            Assert.IsTrue(Validation.IsNumeric("-1000", true, false, false));
            Assert.IsTrue(Validation.IsNumeric("-1000", true, true, false));
            Assert.IsTrue(Validation.IsNumeric("-1000", true, true, true));

            Assert.IsFalse(Validation.IsNumeric("-1000.00", false, false, false));
            Assert.IsFalse(Validation.IsNumeric("-1000.00", true, false, false));
            Assert.IsTrue(Validation.IsNumeric("-1000.00", true, true, false));
            Assert.IsTrue(Validation.IsNumeric("-1000.00", true, true, true));

            Assert.IsFalse(Validation.IsNumeric("-1,000.00", false, false, false));
            Assert.IsFalse(Validation.IsNumeric("-1,000.00", true, false, false));
            Assert.IsFalse(Validation.IsNumeric("-1,000.00", true, true, false));
            Assert.IsTrue(Validation.IsNumeric("-1,000.00", true, true, true));
        }



        /// <summary>
        ///A test for MailServer
        ///</summary>
        [TestMethod]
        public void ValidationIsZipCode()
        {
            Assert.IsFalse(Validation.IsZipCode("1234"));
            Assert.IsTrue(Validation.IsZipCode("12345"));

            Assert.IsTrue(Validation.IsZipCode("12345-6789"));
            Assert.IsTrue(Validation.IsZipCode("123456789"));
        }


        /// <summary>
        ///A test for MailServer
        ///</summary>
        [TestMethod]
        public void ValidationIsIPAddress()
        {
            Assert.IsTrue(Validation.IsIPAddress("208.60.35.95"));
            Assert.IsTrue(Validation.IsIPAddress("192.168.6.25"));
            Assert.IsTrue(Validation.IsIPAddress("4.3.2.1"));
            Assert.IsFalse(Validation.IsIPAddress("0.0.0.0"));
        }

        /// <summary>
        ///A test for MailServer
        ///</summary>
        [TestMethod]
        public void ValidationIsEmail()
        {
            Assert.IsTrue(Validation.IsEmail("test@test.com"));
            Assert.IsFalse(Validation.IsIPAddress("test"));
            Assert.IsFalse(Validation.IsIPAddress("test.com"));
            Assert.IsFalse(Validation.IsIPAddress("test@test"));
            Assert.IsFalse(Validation.IsIPAddress("test@"));
        }
    }
}