﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Directory=EverBank.IO.Directory;

namespace EverBank.Test
{
    public class EverBankIODirectoryTest
    {
        [TestClass]
        public class DirectoryTest
        {

            private string testDirectoryName = "test";
            /// <summary>
            ///A test for DbConnection Constructor
            ///</summary>
            [TestMethod()]
            public void SystemIODirectoryCreateTest()
            {
                CreateTestDirectory();

                Assert.IsTrue(System.IO.Directory.Exists(testDirectoryName));
            }

            [TestMethod()]
            public void SystemIOFileMoveTest()
            {
                string inputPath = "test.txt";
                string outputPath = "test2.txt";

                TestException.ThrowsException<System.IO.IOException>(() => IO.File.Move(inputPath, outputPath));

                TestException.ThrowsException<System.IO.IOException>(() => IO.File.Move(@"C:\testdir", outputPath));

                TestException.ThrowsException<System.IO.IOException>(() => IO.File.Move(inputPath, @"C:\testdir"));

                IO.File.Output(inputPath, "test", false);

                Assert.IsTrue(File.Exists(inputPath));

                IO.File.Move(inputPath, outputPath);

                Assert.IsTrue(File.Exists(outputPath));

                File.Delete(outputPath);
            }



            private void CreateTestDirectory()
            {
                Directory.Create(testDirectoryName);
            }

            private void DeleteTestDirectory()
            {
                Directory.Create(testDirectoryName);
            }
        }
    }
}
