﻿using System.IO;
using System.Security.Principal;
using EverBank.DirectoryServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{


    /// <summary>
    ///This is a test class for MailTest and is intended
    ///to contain all MailTest Unit Tests
    ///</summary>
    [TestClass]
    public class DirectoryServicesTest
    {
        private static string samAccountName = "wschillo";

        private static string localUser = System.IO.Path.GetFileName(WindowsIdentity.GetCurrent().Name);

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void UserDefaultConstructorTest()
        {
            var target = new User();

            Assert.IsNotNull(target);

            CheckObjectValues(target, localUser);
        }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void UserSamAccountNameConstructorTest()
        {
            var target = new User(samAccountName);

            Assert.IsNotNull(target);

            CheckObjectValues(target, samAccountName);
        }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void UserCriteriaConstructorTest()
        {
            var target = new User(UserAttribute.SamAccountName, samAccountName);

            Assert.IsNotNull(target);

            CheckObjectValues(target, samAccountName);
        }

        private static void CheckObjectValues(User target, string accountName)
        {
            Assert.AreEqual(accountName, target.SamAccountName);

        }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void CheckSamAccountNameTest()
        {
            var target = new User(UserAttribute.SamAccountName, samAccountName);

            string sid = Conversions.ToSidString(target.Sid);

            string testName = Conversions.ToSamAccountName(sid);

            Assert.AreEqual(samAccountName, testName);
        }
    }
}
