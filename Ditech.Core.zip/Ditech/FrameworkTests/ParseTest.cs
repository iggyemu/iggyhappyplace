﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{
    [TestClass()]
    public class ParseTest
    {
        [TestMethod]
        public void MoneyTest()
        {
            Assert.AreEqual(string.Empty.Decimal(1), default(decimal));
            Assert.AreEqual(string.Empty.NullableDecimal(1), null);
            Assert.AreEqual("3.34".Decimal(1), 3.34m);
            Assert.AreEqual("3.34".NullableDecimal(1), 3.34m);
            Assert.AreEqual("3.345".Decimal(1), 3.345m);
            Assert.AreEqual("3.345".NullableDecimal(1), 3.345m);
            Assert.AreEqual("3.34".Money(1), "3.34");
            Assert.AreEqual("3.345".Money(1), "3.35");
            Assert.AreEqual(string.Empty.Money(1), "0.00");
            Assert.AreEqual(string.Empty.Money(1, true), "0.00");
            Assert.AreEqual(string.Empty.Money(1, false), string.Empty);
        }
    }
}
