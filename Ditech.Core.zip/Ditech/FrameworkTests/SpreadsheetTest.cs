﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{
    [TestClass()]
    public class SpreadsheetTest
    {
        [TestMethod]
        public void SpreadsheetGetDataSetFromSpreadsheetTest()
        {
            DataSet test = Convert.ToDataSet(new FileInfo(@"\\jvflntfps83\shared\Everyone\canderso\Framework Test\dataset test.xls"), false);

            DataTable sheet1 = test.Tables[0];
            DataTable sheet2 = test.Tables[1];

            Assert.AreEqual("a", sheet1.Rows[0].ItemArray[0].ToString());
            Assert.AreEqual("b", sheet1.Rows[0].ItemArray[1].ToString());
            Assert.AreEqual("c", sheet1.Rows[0].ItemArray[2].ToString());

            Assert.AreEqual("d", sheet2.Rows[0].ItemArray[0].ToString());
            Assert.AreEqual("e", sheet2.Rows[0].ItemArray[1].ToString());
            Assert.AreEqual("f", sheet2.Rows[0].ItemArray[2].ToString());
        }
    }
}
