using System;
using System.Collections;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.OracleClient;
using EverBank.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DbCommand=EverBank.Data.Common.DbCommand;

namespace EverBank.Test
{
    /// <summary>
    ///This is a test class for DbConnectionTest and is intended
    ///to contain all DbConnectionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DbCommandTest
    {
        private string storedProcedureName = "storedProcedureName";
        private Hashtable parameters = new Hashtable {{"parameterName1", "parameterValue1"},                                                      
                                                      {"parameterName2", "parameterValue2"}};

        private string[] parameterNames = { "parameterName1", "parameterName2" };
        private object[] parameterValues = { "parameterValue1", "parameterValue2" };

        private string parameterName = "parameterName";
        private string parameterValue = "parameterValue";

        private static string serverName = "jvfsql2kdev";
        private static string userName = "msp";
        private static string password = "msp";
        private static string initialCatalog = "msp";

        private DbConnection connection = new SqlConnection(ConnectionString.SqlServer(serverName, initialCatalog, userName, password));

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void DbCommandHashtableConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, parameters);

            foreach (SqlParameter sqlParameter in command.Parameters)
            {
                Assert.IsTrue(parameters.ContainsKey(sqlParameter.ParameterName));
                Assert.AreEqual(parameters[sqlParameter.ParameterName], sqlParameter.Value);
            }
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void DbCommandArraysConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, parameterNames, parameterValues);

            for (int i = 0; i < command.Parameters.Count; i++)
            {
                Assert.AreEqual(parameterNames[i], command.Parameters[i].ParameterName);
                Assert.AreEqual(parameterValues[i], command.Parameters[i].Value);
            }
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException))]
        public void DbCommandArraysNullNamesConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, null, parameterValues);
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException))]
        public void DbCommandArraysNullParametersConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, parameterNames, null);
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void DbCommandArraysMismatchedArraysConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, parameterNames, new object[0]);
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException))]
        public void DbCommandNullConnectionConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, null);
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NotSupportedException))]
        public void DbCommandNonSqlConnectionConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, new OracleConnection());
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException))]
        public void DbCommandNullHashtableConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, null);
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException))]
        public void DbCommandNullOrEmptyStoredProcNameConstructorTest()
        {
            DbCommand command = new DbCommand(string.Empty);
        }


        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void DbCommandSingleStoredProcParameterConstructorTest()
        {
            DbCommand command = new DbCommand(storedProcedureName, connection, parameterName, parameterValue);

            Assert.AreEqual(parameterName, command.Parameters[0].ParameterName);
            Assert.AreEqual(parameterValue, command.Parameters[0].Value);

        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void DbCommandReaderCheckStateTest()
        {
            DbCommand command = new DbCommand();

            command.ExecuteReader();
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void DbCommandScalarOpenConnectionTest()
        {
            DbCommand command = new DbCommand();

            command.ExecuteScalar();
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void DbCommandNonQueryOpenConnectionTest()
        {
            DbCommand command = new DbCommand();

            command.ExecuteNonQuery();
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void DbCommandDataTableTest()
        {
            using (DbCommand command = new DbCommand("sp_GetMaxPifDate", connection))
            {
                DataTable table = command.ExecuteDataTable();

                string result = table.Rows[0].ItemArray[0].ToString();

                using (SqlCommand sqlCommand = new SqlCommand("sp_GetMaxPifDate", (SqlConnection) connection))
                {
                    string actual = sqlCommand.ExecuteScalar().ToString();

                    Assert.AreEqual(actual, result);
                }
            }
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void DbCommandExecuteScalarTest()
        {
            using (DbCommand command = new DbCommand("sp_GetMaxPifDate", connection))
            {
                string result = command.ExecuteScalar().ToString();

                using (SqlCommand sqlCommand = new SqlCommand("sp_GetMaxPifDate", (SqlConnection)connection))
                {
                    string actual = sqlCommand.ExecuteScalar().ToString();

                    Assert.AreEqual(actual, result);
                }
            }
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void DbCommandExecuteReaderTest()
        {
            string result;

            using (DbCommand command = new DbCommand("sp_GetMaxPifDate", connection))
            {
                using (DbDataReader reader = command.ExecuteReader())
                {
                    reader.Read();

                    result = reader[0].ToString();
                }
            }

            using (SqlCommand sqlCommand = new SqlCommand("sp_GetMaxPifDate", (SqlConnection) connection))
            {
                string actual = sqlCommand.ExecuteScalar().ToString();

                Assert.AreEqual(actual, result);
            }


        }
    }
}
