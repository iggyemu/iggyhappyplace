

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{
    [TestClass()]
    public class ConvertTests
    {
        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void ConvertToStringTest()
        {
            object testValue = "test";

            Assert.AreEqual(testValue.ToString(), Convert.ToString(testValue));

            Assert.AreEqual(string.Empty, Convert.ToString(null));
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void ConvertToDecimalTest()
        {
            decimal testValue = 4.23m;

            Assert.AreEqual(testValue, Convert.ToDecimal(testValue));

            Assert.AreEqual(testValue, Convert.ToDecimal("4.23"));

            Assert.AreEqual(0m, Convert.ToDecimal(null));

            Assert.AreEqual(0m, Convert.ToDecimal("test"));

            try
            {
                Convert.ToDecimal(null, true);
                Assert.Fail("Did not throw exception");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }

            try
            {
                Convert.ToDecimal("test" ,true);
                Assert.Fail("Did not throw exception");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }

            try
            {
                Convert.ToDecimal(string.Empty, true);
                Assert.Fail("Did not throw exception");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }

            try
            {
                Convert.ToDecimal(new List<string>(), true);
                Assert.Fail("Did not throw exception");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }
        }

        /// <summary>
        ///A test for DbConnection Constructor
        ///</summary>
        [TestMethod()]
        public void ConvertToDecimalStringTest()
        {
            object testValue = "4.23";

            Assert.AreEqual(testValue, Convert.ToDecimalString(testValue, true));

            Assert.AreEqual("0", Convert.ToDecimalString(string.Empty, true));

            Assert.AreEqual(string.Empty, Convert.ToDecimalString(string.Empty, false));

            Assert.AreEqual(string.Empty, Convert.ToDecimalString(null, false));

            Assert.AreEqual(testValue, Convert.ToDecimalString(testValue, false, Format.NumberFormat.FixedPoint));

            Assert.AreEqual("4.2300", Convert.ToDecimalString(testValue, false, Format.NumberFormat.FixedPoint, 4));

        }

        [TestMethod()]
        public void ConvertToDateTimeStringTest()
        {
            Assert.AreEqual(DateTime.Today.ToString("MM/dd/yyyy"), Convert.ToDateTimeString(DateTime.Today, "MM/dd/yyyy"));

            Assert.AreEqual(string.Empty, Convert.ToDateTimeString(null, "MM/dd/yyyy", true));

            Assert.AreEqual("04/23/2008", Convert.ToDateTimeString("04/23/2008", "MM/dd/yyyy"));

            Assert.AreEqual("04/23/2008", Convert.ToDateTimeString("4/23/08", "MM/dd/yyyy"));

            Assert.AreEqual(string.Empty, Convert.ToDateTimeString("test", "MM/dd/yyyy", true));

            try
            {
                Convert.ToDateTimeString(null, "MM/dd/yyyy") ;
                Assert.Fail("Should not make it this far.");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(NullReferenceException), ex.GetType());
            }

            try
            {
                Convert.ToDateTimeString("test", "MM/dd/yyyy");
                Assert.Fail("Should not make it this far.");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(FormatException), ex.GetType());
            }

        }

        [TestMethod()]
        public void ConvertToZonedTest()
        {
            Assert.AreEqual("42C", Convert.ToZonedString("4.23"));

            Assert.AreEqual("42L", Convert.ToZonedString("-4.23"));

            Assert.AreEqual("42C", Convert.ToZonedString(4.23));

            Assert.AreEqual("42L", Convert.ToZonedString(-4.23));

            Assert.AreEqual("{", Convert.ToZonedString(0));

            try
            {
                Convert.ToZonedString(string.Empty);
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }

            try
            {
                Convert.ToZonedString(null);
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }

            try
            {
                Convert.ToZonedString("test");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(InvalidOperationException), ex.GetType());
            }
        }

        [TestMethod()]
        public void ConvertZonedToDecimalTest()
        {
            Assert.AreEqual(4.23m, Convert.ToDecimal("4.2C", 2));

            Assert.AreEqual(-4.23m, Convert.ToDecimal("4.2L", 2));

            Assert.AreEqual(4.23m, Convert.ToDecimal("42C", 2));

            Assert.AreEqual(-4.23m, Convert.ToDecimal("42L", 2));

            Assert.AreEqual(423m, Convert.ToDecimal("42C", 0));

            Assert.AreEqual(-423m, Convert.ToDecimal("42L", 0));
        }
    }
}
