﻿using System;
using System.IO;
using System.Security.Principal;
using EverBank.Net.Mail;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EverBank.Test
{
    /// <summary>
    ///This is a test class for MailMessageTest and is intended
    ///to contain all MailMessageTest Unit Tests
    ///</summary>
    [TestClass]
    public class MailMessageTest
    {
        private string body = "Mail Body";
        private string fromAddress = "christopher.anderson@EverBank.com";
        private string subject = "Mail Subject";
        private string toAddress = "christopher.anderson@EverBank.com";

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void MailMessageConstructorTest()
        {
            var target = new MailMessage(fromAddress, toAddress, subject, body);
            Assert.AreEqual(target.From.Address, fromAddress);
            Assert.AreEqual(target.To[0].Address, toAddress);
            Assert.AreEqual(target.Subject, subject);
            Assert.AreEqual(target.Body, body);
        }

        /// <summary>
        ///A test for Send
        ///</summary>
        [TestMethod]
        public void MailMessageSendTest()
        {
            try
            {
                string subject = "EverBank.Net.MailMessage.Send() Test";
                string body = "Test successful\r\n\r\n" + WindowsIdentity.GetCurrent().Name + "\r\n\r\n" +
                              DateTime.Now.ToLongTimeString();
                var target = new MailMessage(fromAddress, toAddress, subject, body);
                target.Send();
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.Fail("MailMessage failed to send.");
            }
        }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void MailMessageConstructor_CCSenderTrueTest()
        {
            bool ccSender = true;
            var target = new MailMessage(fromAddress, toAddress, subject, body, ccSender);
            Assert.AreEqual(target.From.Address, fromAddress);
            Assert.AreEqual(target.To[0].Address, toAddress);
            Assert.AreEqual(target.Subject, subject);
            Assert.AreEqual(target.Body, body);
            Assert.AreEqual(target.CC[0].Address, fromAddress);
        }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void MailMessageConstructor_CCSenderFalseTest()
        {
            bool ccSender = false;
            var target = new MailMessage(fromAddress, toAddress, subject, body, ccSender);
            Assert.AreEqual(target.From.Address, fromAddress);
            Assert.AreEqual(target.To[0].Address, toAddress);
            Assert.AreEqual(target.Subject, subject);
            Assert.AreEqual(target.Body, body);
            Assert.AreEqual(target.CC.Count, 0);
        }

        /// <summary>
        ///A test for MailMessage Constructor
        ///</summary>
        [TestMethod]
        public void MailMessageConstructor_ArrayOfRecipientsWithAttachmentsTest()
        {
            string file1 = string.Empty;
            string file2 = string.Empty;

            try
            {
                file1 = Path.GetTempFileName();
                file2 = Path.GetTempFileName();
                var toAddresses = new[] {"To1@Testing", "To2@Testing"};
                bool ccSender = false;
                var attachments = new[] {file1, file2};
                var target = new MailMessage(fromAddress, toAddresses, subject, body, ccSender, attachments);
                Assert.AreEqual(target.From.Address, fromAddress);
                Assert.AreEqual(target.To[0].Address, toAddresses[0]);
                Assert.AreEqual(target.To[1].Address, toAddresses[1]);
                Assert.AreEqual(target.Subject, subject);
                Assert.AreEqual(target.Body, body);
                Assert.AreEqual(target.CC.Count, 0);
                target.Dispose();
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                File.Delete(file1);
                File.Delete(file2);
            }
        }

        /// <summary>
        ///A test for ArrayToCommaString
        ///</summary>
        [TestMethod]
        [DeploymentItem("EverBank.dll")]
        public void MailMessageArrayToCommaStringTest()
        {
            var inputValues = new[] {fromAddress, toAddress};
            string expected = fromAddress + "," + toAddress;
            string actual;
            actual = string.Join(",", inputValues);
            Assert.AreEqual(expected, actual);
        }
    }
}