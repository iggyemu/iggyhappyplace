﻿using System;

namespace Ditech
{
    public partial class Format
    {
        /// <summary>
        /// Formats a number into bytes
        /// </summary>
        public string Bytes(long byteCount)
        {
            const int scale = 1024;
            string[] orders = new string[] {"GB", "MB", "KB", "Bytes"};
            long max = (long)Math.Pow(scale, orders.Length-1);
            foreach (string order in orders)
            {
                if (byteCount > max)
                    return string.Format("{0:#0.00} {1}", decimal.Divide(byteCount, max), order);

                max /= scale;
            }
            return "0 Bytes";
        }
    }
}