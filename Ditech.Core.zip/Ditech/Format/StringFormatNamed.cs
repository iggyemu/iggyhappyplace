﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Ditech
{
    public static class StringFormatNamed
    {
        public static string FormatNamed<T>(this Dictionary<string, T> values, string formatString)
        {
            Regex re = new Regex("{(.+?)[:}]");
            MatchCollection matches = re.Matches(formatString);
            object[] fmtValues = new object[matches.Count];
            string fixedFmtString = formatString;
            for (int mn = matches.Count - 1; mn >= 0; mn--)
            {
                Match m = matches[mn];
                string key = m.Value.Substring(1, m.Value.Length - 2);
                fixedFmtString = fixedFmtString.Substring(0, m.Index + 1) + mn.ToString() +
                                 fixedFmtString.Substring(m.Index + m.Length - 1);
                fmtValues[mn] = values[key];
            }

            return string.Format(fixedFmtString, fmtValues);
        }
    }
}
