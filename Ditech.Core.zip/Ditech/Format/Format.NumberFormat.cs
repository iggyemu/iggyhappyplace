using System;

namespace Ditech
{
    /// <summary>
    /// Contains enums for formatting strings.
    /// </summary>
    public partial class Format
    {
        #region NumberFormat enum

        /// <summary>
        /// Standard numeric format strings are used to format common numeric types. 
        /// </summary>
        public enum NumberFormat
        {
            /// <summary>
            /// The number is converted to a string that represents a currency amount.
            /// </summary>
            Currency,
            /// <summary>
            /// This format is supported only for integral types. The number is converted to a string of decimal digits (0-9), prefixed by a minus sign if the number is negative. 
            /// </summary>
            Decimal,
            /// <summary>
            /// The number is converted to a string of the form "-ddd.ddd" where each 'd' indicates a digit (0-9). The string starts with a minus sign if the number is negative.  A default of two digits after the decimal point is used.
            /// </summary>
            FixedPoint,
            /// <summary>
            /// The number is converted to the most compact of either fixed-point or scientific notation.
            /// </summary>
            General,
            /// <summary>
            /// This format is supported only for integral types. The number is converted to a string of hexadecimal digits. 
            /// </summary>
            Hexidecimal,
            /// <summary>
            /// The number is converted to a string of the form "-d,ddd,ddd.ddd", where '-' indicates a negative number symbol if required, 'd' indicates a digit (0-9), ',' indicates a thousand separator between number groups, and '.' indicates a decimal point symbol.
            /// </summary>
            Number,
            /// <summary>
            /// The number is converted to a string that represents a percent.  The converted number is multiplied by 100 in order to be presented as a percentage. 
            /// </summary>
            Percent,
            /// <summary>
            /// This format is supported only for the Single and Double types. The round-trip specifier guarantees that a numeric value converted to a string will be parsed back into the same numeric value.
            /// </summary>
            RoundTrip,
            /// <summary>
            /// The number is converted to a string of the form "-d.dddE+ddd" or "-d.ddde+ddd", where each 'd' indicates a digit (0-9). A default of six digits after the decimal point is used.
            /// </summary>
            Scientific
        }

        #endregion

        internal static string NumberFormatString(NumberFormat numberFormat)
        {
            return NumberFormatString(numberFormat, -1);
        }

        internal static string NumberFormatString(NumberFormat numberFormat, int decimalPlaces)
        {
            string result;

            switch (numberFormat)
            {
                case NumberFormat.Currency:
                    result = "C";
                    break;
                case NumberFormat.Decimal:
                    result = "D";
                    break;
                case NumberFormat.FixedPoint:
                    result = "F";
                    break;
                case NumberFormat.General:
                    result = "G";
                    break;
                case NumberFormat.Hexidecimal:
                    result = "X";
                    break;
                case NumberFormat.Number:
                    result = "N";
                    break;
                case NumberFormat.Percent:
                    result = "P";
                    break;
                case NumberFormat.RoundTrip:
                    result = "R";
                    break;
                case NumberFormat.Scientific:
                    result = "E";
                    break;
                default:
                    throw new NotImplementedException("This enum has no handler.");
            }

            if (decimalPlaces > -1)
            {
                result += decimalPlaces;
            }

            return result;
        }
    }
}