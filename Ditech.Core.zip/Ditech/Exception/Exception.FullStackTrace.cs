﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech
{
    /// <summary>
    /// System.Exception extension methods
    /// </summary>
    public static partial class ExceptionExtensions
    {
        /// <summary>
        /// Retrieves full stack trace from inner exceptions
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="maxDepth"></param>
        /// <returns></returns>
        public static string FullStackTrace(this Exception exception, int maxDepth = 10)
        {
            StringBuilder stackTraceStringBuilder = new StringBuilder();
            int innerExceptionCount = 0;

            stackTraceStringBuilder.AppendLine(string.Format("Exception Type: {0}", exception.GetType()));
            stackTraceStringBuilder.AppendLine(string.Format("Message: {0}", exception.Message));
            stackTraceStringBuilder.AppendLine();
            stackTraceStringBuilder.AppendLine(exception.StackTrace);

            while (exception.InnerException != null && innerExceptionCount < maxDepth)
            {
                exception = exception.InnerException;

                stackTraceStringBuilder.AppendLine();
                stackTraceStringBuilder.AppendLine(string.Format("Inner Exception Type: {0}", exception.GetType()));
                stackTraceStringBuilder.AppendLine(string.Format("Message: {0}", exception.Message));
                stackTraceStringBuilder.AppendLine();
                stackTraceStringBuilder.AppendLine(exception.StackTrace);

                innerExceptionCount++;
            }

            return stackTraceStringBuilder.ToString();
        }
    }
}
