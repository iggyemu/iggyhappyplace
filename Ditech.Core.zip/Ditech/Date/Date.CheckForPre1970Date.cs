using System;

namespace Ditech
{
    /// <summary>
    /// A utility class containing methods for manipulating dates.
    /// </summary>
    public static partial class Date
    {
        private static DateTime CheckForPre1970Date(this DateTime date, int yearLength)
        {
            while (date < new DateTime(1970, 1, 1) && yearLength < 4)
            {
                date = date.AddYears(100);
            }
            return date;
        }
    }
}