using System;

namespace Ditech
{
    public static partial class Date
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Calculates the difference between two dates.
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="timeSpanType">Type of the date.</param>
        /// <returns>Int representing the difference between the dates. </returns>
        /// <exception cref="ArgumentException"><c>ArgumentException</c> is returned if a TimeSpanType is passsed that wasn't accounted for.</exception>
        public static int Difference(DateTime startDate, DateTime endDate, TimeSpanType timeSpanType)
        {
            var timeSpan = endDate - startDate;
            int result;

            switch (timeSpanType)
            {
                case TimeSpanType.Years:
                    result = endDate.Year - startDate.Year;
                    break;
                case TimeSpanType.Months:
                    result = (12 * (endDate.Year - startDate.Year)) + endDate.Month - startDate.Month;
                    break;
                case TimeSpanType.Days:
                    result = timeSpan.Days;
                    break;
                case TimeSpanType.Hours:
                    result = (Difference(startDate, endDate, TimeSpanType.Days) * 24) + timeSpan.Hours;
                    break;
                case TimeSpanType.Minutes:
                    result = (Difference(startDate, endDate, TimeSpanType.Hours) * 60) + timeSpan.Minutes;
                    break;
                case TimeSpanType.Seconds:
                    result = (Difference(startDate, endDate, TimeSpanType.Minutes) * 60) + timeSpan.Seconds;
                    break;
                case TimeSpanType.Milliseconds:
                    result = (Difference(startDate, endDate, TimeSpanType.Seconds) * 1000) + timeSpan.Milliseconds;
                    break;
                default:
                    throw new ArgumentException("Invalid TimeSpanType Passed.");
            }

            return result;
        }


        /// <summary>
        /// Calculates the difference between two dates.
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="timeSpanType">Type of the date.</param>
        /// <param name="compareDatesOnly">if set to <c>true</c> [compare dates only].</param>
        /// <returns>Int representing the difference between the dates. </returns>
        /// <exception cref="ArgumentException"><c>ArgumentException</c> is returned if a TimeSpanType is passsed that wasn't accounted for.</exception>
        public static int Difference(DateTime startDate, DateTime endDate, TimeSpanType timeSpanType,
                                     bool compareDatesOnly)
        {
            startDate = DateTime.Parse(startDate.ToShortDateString());
            endDate = DateTime.Parse(endDate.ToShortDateString());

            return Difference(startDate, endDate, timeSpanType);
        }

        #endregion�Methods�
    }
}