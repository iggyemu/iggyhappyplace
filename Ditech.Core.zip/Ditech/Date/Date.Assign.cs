﻿using System;
using System.ComponentModel;

namespace Ditech
{
    public static partial class Date
    {
        /// <summary>
        /// Assigns the specified raw value.
        /// </summary>
        /// <param name="rawValue">The raw value.</param>
        /// <returns>Returns date object.</returns>
        [Obsolete("Use Ditech.Convert.ToNullableDateTime instead.")]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public static DateTime? Assign(string rawValue)
        {
            DateTime? result = null;

            DateTime date;

            if (DateTime.TryParse(rawValue, out date))
            {
                result = date;
            }

            return result;
        }
    }
}