﻿using System;
using System.ComponentModel;

namespace Ditech
{
    public partial class Date
    {
        public class Range
        {
            /// <summary>
            /// 
            /// </summary>
            public Range()
            {

            }
            /// <summary>
            /// 
            /// </summary>
            /// <param name="start"></param>
            /// <param name="end"></param>
            public Range(DateTime start, DateTime end)
            {
                this.StartingDate = start;
                this.EndingDate = end;
            }
            /// <summary>
            /// 
            /// </summary>
            public DateTime StartingDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public DateTime EndingDate { get; set; }
        }
    }
}