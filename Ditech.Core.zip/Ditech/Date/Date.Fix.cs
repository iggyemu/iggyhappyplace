﻿using System;

namespace Ditech
{
    public static partial class Date
    {
        /// <summary>
        /// Fixes invalid dates by finding the correct date (ex: 9/31 becomes 9/30).
        /// </summary>
        /// <param name="year">The year.</param>
        /// <param name="month">The month.</param>
        /// <param name="day">The day.</param>
        /// <returns>Returns date object.</returns>
        public static DateTime Fix(string year, string month, string day)
        {
            return FixNullable(year, month, day) ?? default(DateTime);
        }
    }
}