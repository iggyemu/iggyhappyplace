namespace Ditech
{
    public static partial class Date
    {
        #region�Enums�(1)�

        /// <summary>
        /// An enum containing a list of timespan types for use in the Difference method.
        /// </summary>
        public enum TimeSpanType
        {
            /// <summary>
            /// Years
            /// </summary>
            Years,
            /// <summary>
            /// Months
            /// </summary>
            Months,
            /// <summary>
            /// Days
            /// </summary>
            Days,
            /// <summary>
            /// Hours
            /// </summary>
            Hours,
            /// <summary>
            /// Minutes
            /// </summary>
            Minutes,
            /// <summary>
            /// Seconds
            /// </summary>
            Seconds,
            /// <summary>
            /// Milliseconds
            /// </summary>
            Milliseconds
        }

        #endregion�Enums�
    }
}