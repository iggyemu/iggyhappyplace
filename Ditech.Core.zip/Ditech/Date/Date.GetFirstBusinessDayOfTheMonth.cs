﻿using System;

namespace Ditech
{
    public static partial class Date
    {
        /// <summary>
        /// Gets the first business day of the month, according to the following rules:
        ///    If the reference day is Saturday or Sunday, add a day and check again. (Weekend)
        ///    If the reference day is January 1, add a day and check again.  (New Year's Day)
        ///    If the reference day is in the first 3 days of September, add a day and check again (Labor Day)
        ///    If the reference day is Tuesday through Friday, use it.
        /// The date passed into the method does not need to be the 1st of the month.  The method will start at the 1st regardless.
        /// </summary>
        /// <param name="baseDate">The date for which you want the first day of the month.</param>
        /// <returns>The first business day.</returns>
        public static DateTime GetFirstBusinessDayOfTheMonth(DateTime baseDate)
        {
            DateTime firstBusinessDateOfTheMonth = new DateTime(baseDate.Year, baseDate.Month, 1);

            while (firstBusinessDateOfTheMonth.IsWeekend() ||
                    (firstBusinessDateOfTheMonth.Month == 1 && firstBusinessDateOfTheMonth.Day == 1) ||
                    (firstBusinessDateOfTheMonth.Month == 9 && firstBusinessDateOfTheMonth.Day <= 3))
            {
                firstBusinessDateOfTheMonth = firstBusinessDateOfTheMonth.AddDays(1);
            }

            return firstBusinessDateOfTheMonth;
        }

    }
}
