﻿using System;

namespace Ditech
{
    public static partial class Date
    {
        /// <summary>
        /// Fixes invalid dates by finding the correct date (ex: 9/31 becomes 9/30).
        /// </summary>
        /// <param name="year">The year.</param>
        /// <param name="month">The month.</param>
        /// <param name="day">The day.</param>
        /// <returns>Returns date object.</returns>
        public static DateTime? FixNullable(string year, string month, string day)
        {
            DateTime? result = null;

            DateTime date;

            int monthNumber;
            int dayNumber;

            // return 0 values
            if (!int.TryParse(month, out monthNumber) || monthNumber <= 0)
            {
                return null;
            }

            // return 0 values
            if (!int.TryParse(day, out dayNumber) || dayNumber <= 0)
            {
                return null;
            }

            if (DateTime.TryParse(string.Format("{0}/{1}/{2}", month, day, year), out date))
            {
                result = date.CheckForPre1970Date(year.Length);
            }
            else
            {
                int monthValue;

                if (int.TryParse(month, out monthValue))
                {
                    // This code does not account for December rolling over to the next year.
                    // However, since December has 31 days, this should not present a problem.
                    if (DateTime.TryParse(string.Format("{0}/01/{1}", monthValue + 1, year), out date))
                    {
                        result = date.CheckForPre1970Date(year.Length).AddDays(-1);
                    }
                }
            }

            return result;
        }
    }
}