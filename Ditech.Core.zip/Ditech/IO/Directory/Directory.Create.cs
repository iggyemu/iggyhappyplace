namespace Ditech.IO
{
    /// <summary>
    /// A utility class containing methods to help with directory manipulation.
    /// </summary>
    public static partial class Directory
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Creates a directory at the specified path.  No action is taken if the directory already exists.
        /// </summary>
        /// <param name="path">The path.</param>
        public static void Create(string path)
        {
            if (!string.IsNullOrEmpty(path) && !System.IO.Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }
        }

        #endregion�Methods�
    }
}