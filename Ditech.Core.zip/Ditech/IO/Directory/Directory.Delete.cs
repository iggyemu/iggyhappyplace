namespace Ditech.IO
{
    public static partial class Directory
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Deletes the directory specified by the path.  No action is taken if the directory does not exist.
        /// </summary>
        /// <param name="path">The input path.</param>
        public static void Delete(string path)
        {
            if (System.IO.Directory.Exists(path))
            {
                foreach (var subDirectory in System.IO.Directory.GetDirectories(path))
                {
                    Delete(subDirectory);
                }

                foreach (var filePath in System.IO.Directory.GetFiles(path))
                {
                    File.Delete(filePath);
                }

                System.IO.Directory.Delete(path);
            }
        }

        #endregion�Methods�
    }
}