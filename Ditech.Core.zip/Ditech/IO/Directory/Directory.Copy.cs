using System;
using System.Collections.Generic;
using System.IO;

namespace Ditech.IO
{
    public static partial class Directory
    {
        #region�Methods�(3)�

        //�Public�Methods�(3)�

        /// <summary>
        /// Copies the directory recursively with the given filter patterns.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        /// <param name="filterList">The filters.</param>
        public static void Copy(string inputPath, string outputPath, string[] filterList)
        {
            if (Path.Type(inputPath) != Path.PathType.Directory)
            {
                throw new IOException("Input directory path is not valid: \"" + inputPath + "\"");
            }

            Console.WriteLine(inputPath);

            if (!outputPath.EndsWith(System.IO.Path.DirectorySeparatorChar.ToString()))
            {
                outputPath += System.IO.Path.DirectorySeparatorChar;
            }

            Create(outputPath);

            var fileList = new List<string>();
            var directoryList = new List<string>();

            foreach (var filter in filterList)
            {
                if (filter.IsNullOrEmpty(true))
                {
                    fileList.AddRange(System.IO.Directory.GetFiles(inputPath));
                    break;
                }

                fileList.AddRange(System.IO.Directory.GetFiles(inputPath, filter));
            }

            directoryList.AddRange(System.IO.Directory.GetDirectories(inputPath));

            //Copy Files
            foreach (var element in fileList)
            {
                Console.WriteLine(element);
                System.IO.File.Copy(element, outputPath + System.IO.Path.GetFileName(element), true);
            }

            //Copy SubDirectory
            foreach (var element in directoryList)
            {
                Copy(element, outputPath + System.IO.Path.GetFileName(element), filterList);
            }
        }

        /// <summary>
        /// Copies the directory recursively with the given filter pattern.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        /// <param name="filter">The filter.</param>
        public static void Copy(string inputPath, string outputPath, string filter)
        {
            Copy(inputPath, outputPath, new[] {filter});
        }

        /// <summary>
        /// Copy directory structure recursively.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        public static void Copy(string inputPath, string outputPath)
        {
            Copy(inputPath, outputPath, string.Empty);
        }

        #endregion�Methods�
    }
}