﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ditech.IO
{
    public static partial class Directory
    {
        /// <summary>
        /// Searches each directory from the searchPath to the root directory for the given filename. 
        /// The full path of each file found is returned.
        /// 
        /// <example>
        /// Search Path: C:\Path\To\My\Files
        /// File Name: myfile.txt
        /// 
        /// The following paths are checked:
        /// C:\Path\To\My\Files\myfile.txt
        /// C:\Path\To\My\myfile.txt
        /// C:\Path\To\myfile.txt
        /// C:\Path\myfile.txt
        /// C:\myfile.txt
        /// </example>
        /// </summary>
        /// <param name="searchPath"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static IEnumerable<string> SearchToRoot(string searchPath, string fileName)
        {
            var directory = new DirectoryInfo(searchPath);
            while (directory != null && directory.Exists)
            {
                var file = System.IO.Path.Combine(directory.FullName, fileName);
                if (System.IO.File.Exists(file)) yield return file;
                directory = directory.Parent;
            }
        }
    }
}
