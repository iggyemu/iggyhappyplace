﻿using System;
using System.IO;

namespace Ditech.IO
{
    public static partial class Directory
    {

        /// <summary>
        /// Gets the number of files in a directory.
        /// </summary>
        /// <param name="directory">The directory.</param>
        /// <param name="includeSubdirectories">if set to <c>true</c> [include subdirectories].</param>
        /// <param name="directorySearchPattern">The directory search pattern.</param>
        /// <param name="fileSearchPattern">The file search pattern.</param>
        /// <returns>Long value of the sum of file sizes.</returns>
        public static int FileCount(this DirectoryInfo directory, bool includeSubdirectories = true, string directorySearchPattern = "*", string fileSearchPattern = "*.*")
        {
            int fileCount = 0;

            fileCount += directory.GetFiles(fileSearchPattern).Length;

            if (includeSubdirectories)
            {
                foreach (var subdirectory in directory.GetDirectories(directorySearchPattern))
                {
                    fileCount += FileCount(subdirectory, true, directorySearchPattern, fileSearchPattern);
                }
            }

            return fileCount;
        }

        /// <summary>
        /// Gets the number of files in a directory.
        /// </summary>
        /// <param name="directory">The directory.</param>
        /// <param name="includeSubdirectories">if set to <c>true</c> [include subdirectories].</param>
        /// <param name="directorySearchPattern">The directory search pattern.</param>
        /// <param name="fileSearchPattern">The file search pattern.</param>
        /// <returns>Long value of the sum of file sizes.</returns>
        public static int FileCount(string directory, bool includeSubdirectories = true, string directorySearchPattern = "*", string fileSearchPattern = "*.*")
        {
            DirectoryInfo directoryInfo;
            try
            {
                directoryInfo = new DirectoryInfo(directory);
            }
            catch (Exception)
            {
                throw new DirectoryNotFoundException("An invalid directory name was passed.");
            }

            return FileCount(directoryInfo, includeSubdirectories, directorySearchPattern, fileSearchPattern);
        }
    }
}