﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ditech.IO
{
    public static partial class Directory
    {
        #region Methods (1)

        // Public Methods (1) 

        /// <summary>
        /// Gets the file from the specified directory path that was last modified today.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <returns></returns>
        public static string GetFile(string directoryPath)
        {
            return GetFile(directoryPath, string.Empty);
        }

        /// <summary>
        /// Gets the file from the specified directory path that was last modified today.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <param name="filter">The filter.</param>
        /// <returns></returns>
        public static string GetFile(string directoryPath, string filter)
        {
            return GetFile(directoryPath, filter, DateTime.Today);
        }

        /// <summary>
        /// Gets the file from the specified directory path that was last modified on the specified date.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <param name="filter">The filter.</param>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static string GetFile(string directoryPath, string filter, DateTime date)
        {
            var file = string.Empty;

            var fileList = GetFiles(directoryPath, filter);

            for (var i = fileList.Length - 1; i >= 0; i--)
            {
                if (System.IO.File.GetLastWriteTime(fileList[i]).Date == date.Date)
                {
                    file = fileList[i];
                    break;
                }
            }

            return file;
        }

        /// <summary>
        /// Gets the file from the specified directory path that was last modified on the specified date.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <param name="filter">The filter.</param>
        /// <param name="mostRecent">If true, get most recent file.  Else, get file modified today.</param>
        /// <param name="ignoreBlankFiles"></param>
        /// <returns></returns>
        public static string GetFile(string directoryPath, string filter, bool mostRecent, bool ignoreBlankFiles = false)
        {
            var file = string.Empty;

            if (mostRecent)
            {
                var fileList = GetFiles(directoryPath, filter);

                if (fileList.Length > 0)
                {
                    for (var i = fileList.Length - 1; i >= 0; i--)
                    {
                        file = fileList[i];

                        var fileInfo = new FileInfo(file);

                        if (fileInfo.Length != 0 || !ignoreBlankFiles)
                        {
                            break;
                        }
                    }
                }
            }
            else
            {
                file = GetFile(directoryPath, filter);
            }

            return file;
        }


        /// <summary>
        /// Gets the files, checking if the directory path exists first.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <param name="filter">The filter.</param>
        /// <returns></returns>
        public static string[] GetFiles(string directoryPath, string filter)
        {
            var fileList = new List<string>();

            if (System.IO.Directory.Exists(directoryPath))
            {
                fileList = string.IsNullOrEmpty(filter)
                               ? new List<string>(System.IO.Directory.GetFiles(directoryPath))
                               : new List<string>(System.IO.Directory.GetFiles(directoryPath, filter));
            }

            return fileList.ToArray();            
        }

        /// <summary>
        /// Gets the files, checking if the directory path exists first.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <returns></returns>
        public static string[] GetFiles(string directoryPath)
        {
            return GetFiles(directoryPath, string.Empty);
        }

        #endregion Methods
    }
}
