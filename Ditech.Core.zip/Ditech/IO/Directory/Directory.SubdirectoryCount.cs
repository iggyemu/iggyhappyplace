﻿using System;
using System.IO;

namespace Ditech.IO
{
    public static partial class Directory
    {

        /// <summary>
        /// Gets the number of subdirectories in a directory.
        /// </summary>
        /// <param name="directory">The directory.</param>
        /// <param name="includeSubdirectories">if set to <c>true</c> [include subdirectories].</param>
        /// <param name="directorySearchPattern">The directory search pattern.</param>
        /// <returns>Long value of the sum of file sizes.</returns>
        public static int SubdirectoryCount(this DirectoryInfo directory, bool includeSubdirectories = true, string directorySearchPattern = "*")
        {
            int subDirectoryCount = 0;

            subDirectoryCount += directory.GetDirectories(directorySearchPattern).Length;

            if (includeSubdirectories)
            {
                foreach (var subdirectory in directory.GetDirectories(directorySearchPattern))
                {
                    subDirectoryCount += SubdirectoryCount(subdirectory, true, directorySearchPattern);
                }
            }

            return subDirectoryCount;
        }

        /// <summary>
        /// Gets the number of subdirectories in a directory.
        /// </summary>
        /// <param name="directory">The directory.</param>
        /// <param name="includeSubdirectories">if set to <c>true</c> [include subdirectories].</param>
        /// <param name="directorySearchPattern">The directory search pattern.</param>
        /// <returns>Long value of the sum of file sizes.</returns>
        public static int SubdirectoryCount(string directory, bool includeSubdirectories = true, string directorySearchPattern = "*")
        {
            DirectoryInfo directoryInfo;
            try
            {
                directoryInfo = new DirectoryInfo(directory);
            }
            catch (Exception)
            {
                throw new DirectoryNotFoundException("An invalid directory name was passed.");
            }

            return SubdirectoryCount(directoryInfo, includeSubdirectories, directorySearchPattern);
        }
    }
}