namespace Ditech.IO
{
    public static partial class Directory
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Moves the directory specified  by the input path to the output path, deleting the output path if it exists before moving the contents.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        public static void Move(string inputPath, string outputPath)
        {
            Delete(outputPath);

            System.IO.Directory.Move(inputPath, outputPath);
        }

        #endregion�Methods�
    }
}