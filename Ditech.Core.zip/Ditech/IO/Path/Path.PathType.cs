namespace Ditech.IO
{
    public static partial class Path
    {
        #region�Enums�(1)�

        /// <summary>
        /// Gets the target of a given path.
        /// </summary>
        public enum PathType
        {
            /// <summary>
            /// The path is a directory.
            /// </summary>
            Directory,
            /// <summary>
            /// The path is a file.
            /// </summary>
            File,
            /// <summary>
            /// The path is neither a directory or a file.
            /// </summary>
            Invalid
        }

        #endregion�Enums�
    }
}