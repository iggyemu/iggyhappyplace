﻿using System.Runtime.InteropServices;
using System.Text;

namespace Ditech.IO
{
    public static partial class Path
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private static extern int GetShortPathName(
            [MarshalAs(UnmanagedType.LPTStr)] string path,
            [MarshalAs(UnmanagedType.LPTStr)] StringBuilder shortPath,
            int shortPathLength
            );

        public static string GetShortName(string path)
        {
            var stringBuilder = new StringBuilder(255);

            GetShortPathName(path, stringBuilder, stringBuilder.Capacity);

            return stringBuilder.ToString();
        }
    }
}
