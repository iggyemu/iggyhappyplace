namespace Ditech.IO
{
    /// <summary>
    /// A utility class to to help get information about file/folder paths.
    /// </summary>
    public static partial class Path
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Checks to see if a given path is a directory or file.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>PathType enum stating whether the path is a directory or a file.</returns>
        public static PathType Type(string path)
        {
            var result = PathType.Invalid;

            if (System.IO.Directory.Exists(path))
            {
                result = PathType.Directory;
            }
            else
            {
                if (System.IO.File.Exists(path))
                {
                    result = PathType.File;
                }
            }

            return result;
        }

        #endregion�Methods�
    }
}