﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text;

namespace Ditech.IO
{
    /// <summary>
    /// This class is used to access application-specific file storage on the local machine
    /// </summary>
    public class IsolatedFile : IDisposable
    {
		#region Enums (1) 

        /// <summary>
        /// The type of stream being initialized
        /// </summary>
        private enum StreamType
        {
            /// <summary>
            /// 
            /// </summary>
            StreamReader,
            /// <summary>
            /// 
            /// </summary>
            StreamWriter
        }

		#endregion Enums 

		#region Properties (2) 

        /// <summary>
        /// Gets or sets the reader.
        /// </summary>
        /// <value>The reader.</value>
        private StreamReader Reader { get; set; }

        /// <summary>
        /// Gets or sets the writer.
        /// </summary>
        /// <value>The writer.</value>
        private StreamWriter Writer { get; set; }

        private IsolatedStorageFile Storage { get; set; }

        private IsolatedStorageFileStream Stream { get; set; }

		#endregion Properties 

		#region Methods (3) 

		// Public Methods (2) 

        /// <summary>
        /// Gets a StreamReader object from isolated file storage.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns></returns>
        public StreamReader StreamReader(string fileName)
        {
            InitializeStream(fileName, StreamType.StreamReader);

            return Reader;
        }

        /// <summary>
        /// Gets a StreamWriter object from isolated file storage.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns></returns>
        public StreamWriter StreamWriter(string fileName)
        {
            InitializeStream(fileName, StreamType.StreamWriter);

            return Writer;
        }
		// Private Methods (1) 

        /// <summary>
        /// Initializes the stream.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="streamType">Type of the stream.</param>
        private void InitializeStream(string fileName, StreamType streamType)
        {
            Storage = IsolatedStorageFile.GetUserStoreForAssembly();
            Stream = new IsolatedStorageFileStream(fileName, FileMode.OpenOrCreate, Storage);

            switch (streamType)
            {
                case StreamType.StreamReader:
                    Reader = new StreamReader(Stream);
                    break;
                case StreamType.StreamWriter:
                    Writer = new StreamWriter(Stream);
                    break;
            }
        }

        /// <summary>
        /// Determines whether [is file available] [the specified file name].
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>
        /// 	<c>true</c> if [is file available] [the specified file name]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsFileAvailable(string fileName)
        {
            string[] fileNames;
            using (var storage = IsolatedStorageFile.GetUserStoreForAssembly())
            {
                fileNames = storage.GetFileNames(fileName);

                storage.Close();
                storage.Dispose();
            }

            return fileNames.Length > 0;
        }

		#endregion Methods 

        public void Dispose()
        {
            Stream.Close();
            Stream.Dispose();

            Storage.Close();
            Storage.Dispose();
        }
    }
}
