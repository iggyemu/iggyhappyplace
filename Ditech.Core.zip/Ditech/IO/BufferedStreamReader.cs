﻿using System;
using System.Collections.Generic;
using System.IO;


namespace Ditech.IO
{
    public class BufferedStreamReader : IDisposable
    {
        private readonly StreamReader _streamReader;
        private readonly Queue<string> _bufferedLines;

        public bool EndOfStream { get { return _streamReader.EndOfStream; } }

        public BufferedStreamReader(string fileName)
            : this(new StreamReader(fileName))
        {    
        }

        public BufferedStreamReader(StreamReader streamReader)
        {
            _streamReader = streamReader;
            _bufferedLines = new Queue<string>();
        }

        /// <summary>
        /// Preview next line from file
        /// </summary>
        /// <returns></returns>
        public string PeekLine()
        {
            string line;
            
            if (_bufferedLines.Count > 0)
            {
                line = _bufferedLines.Peek();
            }
            else
            {
                line = _streamReader.ReadLine();

                if (line != null)
                {
                    _bufferedLines.Enqueue(line);
                }
            }

            return line;
        }
        
        /// <summary>
        /// Preview next set of lines from file
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        public List<string> PeekLineBlock(int count)
        {
            //Find lines needed to read
            count = count - _bufferedLines.Count;

            //Buffer any additional lines
            for (int i = 0; i < count; i++)
            {
                string line = _streamReader.ReadLine();

                if (line != null)
                {
                    _bufferedLines.Enqueue(line);
                }
                else
                {
                    i = count;
                }
            }

            return new List<string>(_bufferedLines);
        }

        /// <summary>
        /// Read line from file
        /// </summary>
        /// <returns></returns>
        public string ReadLine()
        {
            return _bufferedLines.Count > 0 ? _bufferedLines.Dequeue() : _streamReader.ReadLine();
        }

        /// <summary>
        /// Read a line block from file
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        public List<string> ReadLineBlock(int count)
        {
            List<string> lines = PeekLineBlock(count);

            _bufferedLines.Clear();

            return lines;
        }

        public void Dispose()
        {
            _streamReader.Dispose();
        }
    }
}
