using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;

namespace Ditech.IO
{
    public static partial class File
    {
        #region�Methods�(5)�

        //�Public�Methods�(5)�

        /// <summary>
        /// Appends the file to the end of the existing file.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="fileToAppend">The file to append.</param>
        public static void Output(string outputPath, FileInfo fileToAppend)
        {
            Output(outputPath, new[] {Environment.NewLine, System.IO.File.ReadAllText(fileToAppend.FullName)}, true);
        }

        /// <summary>
        /// Outputs text to a file.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="textToWrite">The text to write.</param>
        /// <param name="append">if set to <c>true</c> [append], otherwise create a new file.</param>
        public static void Output(string outputPath, string textToWrite, bool append)
        {
            Output(outputPath, new[] {textToWrite}, append);
        }

        /// <summary>
        /// Outputs the lines to the output file.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="lines">The lines to output.</param>
        public static void Output(string outputPath, IEnumerable lines)
        {
            Output(outputPath, lines, false);
        }

        /// <summary>
        /// Outputs the lines to the output file.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="lines">The lines to output.</param>
        /// <param name="append">if set to <c>true</c> [append].</param>
        public static void Output(string outputPath, IEnumerable lines, bool append)
        {
            Output(outputPath, lines, append, string.Empty);
        }

        /// <summary>
        /// Outputs the lines to the output file.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="lines">The lines to output.</param>
        /// <param name="header">The header of the file.</param>
        /// <param name="append">if set to <c>true</c> [append].</param>
        public static void Output(string outputPath, IEnumerable lines, bool append, string header)
        {
            Directory.Create(System.IO.Path.GetDirectoryName(outputPath));

            using (var output = new StreamWriter(outputPath, append))
            {
                if (header != string.Empty)
                {
                    output.WriteLine(header);
                }

                foreach (var record in lines)
                {
                    output.WriteLine(record);
                }
            }
        }

        ///<summary>
        /// Outputs the data reader as a delimited file.
        ///</summary>
        ///<param name="outputPath">The output path.</param>
        ///<param name="reader">The data reader</param>
        ///<param name="delimiter">The delimiter, default is tab</param>
        ///<param name="includeHeaders">Include the headers if true, default is true</param>
        public static int Output(string outputPath, DbDataReader reader, string delimiter = "\t", bool includeHeaders = true)
        {
            var recordCount = 0;

            using (var output = new StreamWriter(outputPath))
            {
                if (includeHeaders)
                {
                    var header = new List<string>();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        header.Add(reader.GetName(i));
                    }

                    output.WriteLine(string.Join(delimiter, header.ToArray()));
                }

                while (reader.Read())
                {
                    var record = new List<string>();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        record.Add(Convert.ToString(reader[i]));
                    }

                    output.WriteLine(string.Join(delimiter, record.ToArray()));
                    recordCount++;
                }
            }

            return recordCount;
        }

        /// <summary>
        /// Exports DataTable to tab delimited text file.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="dataTable">The data table.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="outputHeaders">if set to <c>true</c> [output headers].</param>
        public static void Output(string outputPath, DataTable dataTable, string delimiter, bool outputHeaders)
        {
            var fileLines = new List<string>();

            if (outputHeaders)
            {
                var header = new List<string>();

                // Add a header to each column
                foreach (DataColumn column in dataTable.Columns)
                {
                    header.Add(column.ColumnName);
                }

                fileLines.Add(System.String.Join(delimiter, header.ToArray()));
            }

            foreach (DataRow row in dataTable.Rows)
            {
                var line = new List<string>();

                foreach (var value in row.ItemArray)
                {
                    line.Add(value.ToString());
                }

                fileLines.Add(System.String.Join(delimiter, line.ToArray()));
            }

            Output(outputPath, fileLines);
        }

        #endregion�Methods�
    }
}