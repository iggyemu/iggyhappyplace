﻿
using System;
using System.Runtime.InteropServices;

namespace Ditech.IO
{
    public static partial class File
    {
        [DllImport("Kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern bool CreateHardLink(string lpFileName, string lpExistingFileName, IntPtr lpSecurityAttributes);

        /// <summary>
        /// Creates a hard link
        /// 
        /// http://msdn.microsoft.com/en-us/library/windows/desktop/aa365006(v=vs.85).aspx
        /// </summary>
        /// <param name="sourceFile">The file to link</param>
        /// <param name="destFile">The path of the link</param>
        /// <returns>true if hard link was created successfully</returns>
        public static bool CreateHardLink(string sourceFile, string destFile)
        {
            return CreateHardLink(destFile, sourceFile, IntPtr.Zero);
        }
    }
}