﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.IO
{
   public static partial class File
    {
        #region Methods(1)

       /// <summary>
       ///  Checks to see if the provided file is empty
       /// </summary>
       /// <param name="fileInfo"></param>
       /// <returns></returns>
       public static bool IsEmpty(this FileInfo fileInfo)
       {
           bool result = false;
           if (System.IO.File.Exists(fileInfo.FullName))
           {
               if (fileInfo.Length == 0)
               {
                   result = true;
               }
                
            }
                   return result;
       }

        #endregion
    }
}
