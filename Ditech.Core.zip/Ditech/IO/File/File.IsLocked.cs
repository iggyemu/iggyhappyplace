﻿using System.IO;

namespace Ditech.IO
{
     /// <summary>
     /// A utility class containing methods to help with file manipulation.
     /// </summary>
     public static partial class File
     {
          /// <summary>
          /// This method will check to see if a file is writable.  Useful when determining if a write operation is happening.
          /// </summary>
          /// <param name="fileInfo"></param>
          public static bool IsLocked(this FileInfo fileInfo)
          {
               bool result = false;

               if (System.IO.File.Exists(fileInfo.FullName))
               {
                    FileStream stream = null;

                    try
                    {
                         stream = fileInfo.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                    }
                    catch (IOException)
                    {
                         result = true;
                    }
                    finally
                    {
                         if (stream != null)
                              stream.Close();
                    }
               }

               //file is not locked
               return result;
          }
     }
}