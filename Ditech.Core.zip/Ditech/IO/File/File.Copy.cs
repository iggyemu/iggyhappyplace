namespace Ditech.IO
{
    public static partial class File
    {
        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Copies the file in the input path to the output path.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        /// <param name="overwrite">if set to <c>true</c> [overwrite].</param>
        public static void Copy(string inputPath, string outputPath, bool overwrite)
        {
            inputPath.IsFilePath(true);

            Directory.Create(System.IO.Path.GetDirectoryName(outputPath));

            System.IO.File.Copy(inputPath, outputPath, overwrite);
        }

        /// <summary>
        /// Copies the file in the input path to the output path.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        public static void Copy(string inputPath, string outputPath)
        {
            Copy(inputPath, outputPath, false);
        }

        #endregion�Methods�
    }
}