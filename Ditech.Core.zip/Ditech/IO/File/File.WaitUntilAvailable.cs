﻿using System.IO;

namespace Ditech.IO
{
     /// <summary>
     /// A utility class containing methods to help with file manipulation.
     /// </summary>
     public static partial class File
     {
          /// <summary>
          /// Waits until the given file is available for writing.
          /// </summary>
          public static void WaitUntilAvailable(this FileInfo fileInfo)
          {
               while (fileInfo.IsLocked())
               {
                    // Wait for a second and try again.
                    System.Threading.Thread.Sleep(1000);
               }
          }
     }
}