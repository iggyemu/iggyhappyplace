namespace Ditech.IO
{
    public static partial class File
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Deletes the file specified by the path. No action is taken if the file is not found.
        /// </summary>
        /// <param name="path">The path.</param>
        public static void Delete(string path)
        {
            if (path.IsFilePath(false))
            {
                System.IO.File.Delete(path);
            }
        }

        #endregion�Methods�
    }
}