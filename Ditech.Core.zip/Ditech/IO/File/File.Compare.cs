using System;
using System.IO;
using System.Security.Cryptography;

namespace Ditech.IO
{
    /// <summary>
    /// A utility class containing methods to help with file manipulation.
    /// </summary>
    public static partial class File
    {
        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Checks to see if two files are the same.
        /// </summary>
        /// <param name="filePath1">The path of file 1.</param>
        /// <param name="filePath2">The path of file 2.</param>
        /// <returns>True if they're the same, otherwise false.</returns>
        public static bool Compare(string filePath1, string filePath2)
        {
            var result = false;

            if (System.IO.File.Exists(filePath1) && System.IO.File.Exists(filePath2))
            {
                var fileInfo1 = new FileInfo(filePath1);
                var fileInfo2 = new FileInfo(filePath2);

                if (fileInfo1.Length == fileInfo2.Length)
                {
                    using (var hash = HashAlgorithm.Create())
                    {
                        using (var fs1 = new FileStream(filePath1, FileMode.Open))
                        {
                            using (var fs2 = new FileStream(filePath2, FileMode.Open))
                            {
                                var hash1 = hash.ComputeHash(fs1);
                                var hash2 = hash.ComputeHash(fs2);

                                result = BitConverter.ToString(hash1).Equals(BitConverter.ToString(hash2));
                            }
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Checks to see if two files are the same.
        /// </summary>
        /// <param name="fileInfo1">The first file to check.</param>
        /// <param name="fileInfo2">The second file to check.</param>
        /// <returns>True if they're the same, otherwise false.</returns>
        public static bool Compare(FileInfo fileInfo1, FileInfo fileInfo2)
        {
            return Compare(fileInfo1.FullName, fileInfo2.FullName);
        }

        #endregion�Methods�
    }
}