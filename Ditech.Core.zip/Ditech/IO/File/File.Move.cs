namespace Ditech.IO
{
    public static partial class File
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Moves the file specified by the input path to the output path.  If a file already exists at the output path, the file is deleted.
        /// </summary>
        /// <param name="inputPath">The input path.</param>
        /// <param name="outputPath">The output path.</param>
        public static void Move(string inputPath, string outputPath)
        {
            inputPath.IsFilePath(true);

            Delete(outputPath);

            Directory.Create(System.IO.Path.GetDirectoryName(outputPath));

            System.IO.File.Move(inputPath, outputPath);
        }

        #endregion�Methods�
    }
}