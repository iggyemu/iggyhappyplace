﻿using System;
using System.Text;
using Ditech.Servicing.Data.Common;

namespace Ditech.Servicing
{
    /// <summary>
    /// Creates a new instance of the Log class.
    /// </summary>
    public partial class Log : Ditech.Log
    {
        private bool IntegratedAuthentication { get; set; }

        private string Parameters
        {
            get
            {
                var body = new StringBuilder("Logging class parameters:");
                body.AppendLine();
                body.AppendLine("Current Time: " + DateTime.Now);

                body.AppendLine("PROCESSID: " + EventID.Coalesce("[NULL]"));
                body.AppendLine("PROCESSUSER: " + ProcessUser.Coalesce("[NULL]"));
                body.AppendLine("PROCESSMACHINE: " + ProcessMachine.Coalesce("[NULL]"));
                body.AppendLine("PROCESSPATH: " + ProcessPath.Coalesce("[NULL]"));
                body.AppendLine("PROCESSNAME: " + ProcessName.Coalesce("[NULL]"));
                body.AppendLine("PROCESSVERSION: " + ProcessVersion.Coalesce("[NULL]"));
                body.AppendLine("PROCESSCLASS: " + ProcessClass.Coalesce("[NULL]"));
                body.AppendLine("PROCESSMETHOD: " + ProcessMethod.Coalesce("[NULL]"));
                body.AppendLine("PROCESSID: " + EventID.Coalesce("[NULL]"));
                body.AppendLine("OTHERINFO: " + OtherInfo.Coalesce("[NULL]"));
                body.AppendLine("SUCCESSRECORDS: " + SuccessRecords);
                body.AppendLine("FAILEDRECORDS: " + FailureRecords);
                body.AppendLine("ERRORCLASS: " + BaseClass.Coalesce("[NULL]"));
                body.AppendLine("ERRORMETHOD: " + BaseMethod.Coalesce("[NULL]"));

                if (FailureException != null)
                {
                    body.AppendLine("ERRORMESSAGE: " + FailureException.Message.Coalesce("[NULL]").Replace("\'", "\'\'"));
                    body.AppendLine("ERRORSTACKTRACE: " + FailureException.StackTrace.Coalesce("[NULL]").Replace("\'", "\'\'"));
                }

                return body.ToString();
            }
        }
    }
}