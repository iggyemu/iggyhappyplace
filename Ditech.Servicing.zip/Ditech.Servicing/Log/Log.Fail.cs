﻿using System;
using System.Configuration;
using Ditech.Data.Common;
using Ditech.Net.Mail;
using Ditech.Servicing.Data.Common;

namespace Ditech.Servicing
{
    /// <summary>
    /// Creates a new instance of the Log class.
    /// </summary>
    public partial class Log : Ditech.Log
    {
        // Public Methods (5) 

        /// <summary>
        /// Logs process failures
        /// </summary>
        /// <param name="ex">The exception.</param>
        public override void Fail(Exception ex)
        {
                //Logger.Fatal("Failed", ex);

                // Finds out from the stack who called the last function
                GetCallerInfo();

                FailureException = ex;

                // Establish the database connection
                //using (var connection = Connection.Create(ConnectionType, SqlDbName.Logging, IntegratedAuthentication))
                using (var connection = Connection.Create(ConfigurationManager.AppSettings["DatabaseServer"], ConfigurationManager.AppSettings["LoggingDatabase"], true))
                {
                    // Build the command
                    var command = new DbCommand("Log_ProcessFailure", connection);

                    command.AddWithValue("@PROCESSID", EventID);
                    command.AddWithValue("@ERRORCLASS", BaseClass);
                    command.AddWithValue("@ERRORMETHOD", BaseMethod);
                    command.AddWithValue("@ERRORMESSAGE", FailureException.Message.Replace("\'", "\'\'"));
                    command.AddWithValue("@ERRORSTACKTRACE", FailureException.StackTrace.Replace("\'", "\'\'"));
                    command.AddWithValue("@SUCCESSRECORDS", SuccessRecords);
                    command.AddWithValue("@FAILURERECORDS", FailureRecords);
                    command.AddWithValue("@OTHERINFO", OtherInfo);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
        }

        public void Fail(Exception ex, bool sendEmail)
        {
            if (sendEmail && !string.IsNullOrEmpty(Configuration.LogEmailRecipient))
            {
                Fail(ex, string.Empty, Configuration.LogEmailRecipient);
            }
            else
            {
                Fail(ex);
            }
        }

        /// <summary>
        /// Failures the specified ex.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <param name="additionalErrorInfo">The additional error info.</param>
        /// <param name="emailAddress">The email address that should receive the failure e-mail.</param>
        public void Fail(Exception ex, string additionalErrorInfo, string emailAddress = "")
        {
            Fail(ex, additionalErrorInfo,
                new[] {string.IsNullOrEmpty(emailAddress) ? Configuration.LogEmailRecipient : emailAddress});
        }

        /// <summary>
        /// Failures the specified ex.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <param name="additionalErrorInfo">The additional error info.</param>
        /// <param name="emailAddresses">the list of email addresses that should receive the failure e-mail.</param>
        public void Fail(Exception ex, string additionalErrorInfo, string[] emailAddresses)
        {
            Fail(ex);
            SendFailureEmail("MSP Process Failure Notification <do.not.reply@ditech.com>", additionalErrorInfo, emailAddresses);
        }
    }
}