using System;
using Ditech.Net.Mail;
using Ditech.Servicing.Data.Common;

namespace Ditech.Servicing
{
    /// <summary>
    /// Creates a new instance of the Log class.
    /// </summary>
    public partial class Log : Ditech.Log
    {
        //private static readonly ILog Logger = LogManager.GetLogger(typeof(Log));

        #region�Constructors�(2)�

        /// <summary>
        /// Initializes a new instance of the <see cref="Log"/> class.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="startClass">The startClass.</param>
        /// <param name="integratedAuthentication"> </param>
        public Log(string startClass = "", bool integratedAuthentication = true)
            : base(startClass)
        {
            IntegratedAuthentication = integratedAuthentication;

            EventID = Start();
        }

        #endregion�Constructors�
    }
}