﻿using System.Text;
using Ditech.Net.Mail;

namespace Ditech.Servicing
{
    /// <summary>
    /// Creates a new instance of the Log class.
    /// </summary>
    public partial class Log : Ditech.Log
    {
        /// <summary>
        /// Sends the failure email.
        /// </summary>
        /// <param name="senderAddress">The sender address.</param>
        /// <param name="notifyOperations">if set to <c>true</c> [notify operations].</param>
        /// <param name="additionalText">The additional text.</param>
        /// <param name="emailRecipients">The email recipients.</param>
        private void SendFailureEmail(string senderAddress, string additionalText,
                                      string[] emailRecipients)
        {

            var emailBody = new StringBuilder();

            emailBody.AppendLine(string.Format("Process ID: {0}", EventID));
            emailBody.AppendLine(string.Format("Operator Name: {0}", ProcessUser));
            emailBody.AppendLine(string.Format("Machine Name: {0}", ProcessMachine));
            emailBody.AppendLine(string.Format("Other Info: {0}", OtherInfo));
            emailBody.AppendLine(string.Format("Start Class: {0}", ProcessClass));
            emailBody.AppendLine(string.Format("Error Method: {0}", BaseMethod));
            emailBody.AppendLine(string.Format("Error Message: {0}", FailureException.Message));
            emailBody.AppendLine(string.Format("\r\n{0}\r\n", FailureException.FullStackTrace()));

            emailBody.Append(additionalText);

            var email = new MailMessage(senderAddress, emailRecipients,
                                        ProcessName + " (" + BaseClass + ") Failed!", emailBody.ToString(), false);

            email.Send(true);
        }
    }
}
