﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Servicing
{
    public class ProcessLog
    {
        public int ProcessId { get; set; }
        public string ProcessName { get; set; }
        public int ProcessHistoryId { get; set; }
        public string UpdatedDateTime { get; set; }
        public string EffectiveDate { get; set; }
        public string ExpectedTimeCutoff { get; set; }
        public string LastMSPRunDate { get; set; }
        public bool IsActive { get; set; }
    }
}
