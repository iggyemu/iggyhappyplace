﻿using System;
using System.Configuration;
using System.Text;
using Ditech.Data.Common;
using Ditech.Net.Mail;
using Ditech.Servicing.Data.Common;

namespace Ditech.Servicing
{
    /// <summary>
    /// Creates a new instance of the Log class.
    /// </summary>
    public partial class Log : Ditech.Log
    {
        /// <summary>
        /// Logs when a process ends.
        /// </summary>
        protected override void End()
        {
            OtherInfo = OtherInfo.Replace("\'", "\'\'");

            // Establish the database connection
            //using (var connection = Connection.Create(ConnectionType, SqlDbName.Logging, IntegratedAuthentication))
            using (
                var connection = Connection.Create(ConfigurationManager.AppSettings["DatabaseServer"],
                    ConfigurationManager.AppSettings["LoggingDatabase"]))
            {
                // Build the command
                var command = new DbCommand("Log_ProcessEnd", connection);

                command.AddWithValue("@PROCESSID", EventID);
                command.AddWithValue("@OTHERINFO", OtherInfo);
                command.AddWithValue("@SUCCESSRECORDS", SuccessRecords);
                command.AddWithValue("@FAILEDRECORDS", FailureRecords);

                // Execute the command
                command.ExecuteNonQuery();
            }
        }
    }
}