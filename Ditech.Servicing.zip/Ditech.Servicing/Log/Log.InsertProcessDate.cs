﻿using Ditech.Data.Common;
using Ditech.Servicing.Data.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Servicing
{
    public partial class Log : Ditech.Log
    {
        ///<summary>
        /// Logs a process with an effective date
        ///</summary>
        ///<param name="processName">The process name</param>
        ///<param name="date">The effective date of the process</param>
        ///<returns></returns>
        public static void InsertProcessDate(string processName, DateTime date)
        {
            InsertProcessDate(processName, date, Connection.Create(SqlDbName.MSP_APPLICATIONS));
        }

        ///<summary>
        /// Logs a process with an effective date
        ///</summary>
        ///<param name="processName">The process name</param>
        ///<param name="date">The effective date of the process</param>
        ///<param name="connection">The SQL database connection to use</param>
        ///<returns></returns>
        public static void InsertProcessDate(string processName, DateTime date, SqlConnection connection)
        {
            using (var command = new DbCommand("PROCESS_WATCHER.Insert_ProcessHistory", connection))
            {
                command.AddWithValue("@PROCESS_NAME", processName);
                command.AddWithValue("@EFFECTIVE_DATE", date);
                command.ExecuteNonQuery();
            }
        }
    }
}
