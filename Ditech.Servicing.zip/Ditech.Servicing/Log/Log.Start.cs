﻿using System.Configuration;
using Ditech.Data.Common;
using Ditech.Servicing.Data.Common;

namespace Ditech.Servicing
{
    /// <summary>
    /// Creates a new instance of the Log class.
    /// </summary>
    public partial class Log : Ditech.Log
    {
        /// <summary>
        /// Logs the start of the process.
        /// </summary>
        /// <returns>eventID of the process (used for updating the record to reflect success/failure)</returns>
        protected override string Start()
        {
            // Establish the database connection
            //using (var connection = Connection.Create(ConnectionType, SqlDbName.Logging, IntegratedAuthentication))
             using (var connection = Connection.Create(ConfigurationManager.AppSettings["DatabaseServer"], ConfigurationManager.AppSettings["LoggingDatabase"], true))
            {
                // Build the command
                var command = new DbCommand("Log_ProcessStart", connection);

                command.AddWithValue("@PROCESSUSER", ProcessUser);
                command.AddWithValue("@PROCESSMACHINE", ProcessMachine);
                command.AddWithValue("@PROCESSPATH", ProcessPath);
                command.AddWithValue("@PROCESSNAME", ProcessName);
                command.AddWithValue("@PROCESSVERSION", ProcessVersion);
                command.AddWithValue("@PROCESSCLASS", ProcessClass);
                command.AddWithValue("@PROCESSMETHOD", ProcessMethod);

                // Execute the command
                return Convert.ToString(command.ExecuteScalar());
            }
        }
    }
}