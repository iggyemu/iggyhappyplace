﻿using Ditech.Data.Common;
using Ditech.Servicing.Data.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Servicing
{
    public partial class Log : Ditech.Log
    {
        ///<summary>
        /// Gets most recent entries per process 
        ///</summary>
        ///<returns></returns>
        public static IEnumerable<ProcessLog> SelectRecentProcessLogs()
        {
            return SelectRecentProcessLogs(Connection.Create(SqlDbName.MSP_APPLICATIONS));
        }

        private static IEnumerable<ProcessLog> SelectRecentProcessLogs(SqlConnection connection, string processName)
        {
            List<ProcessLog> result = new List<ProcessLog>();

            using (var command = new DbCommand("PROCESS_WATCHER.Select_RecentProcessLogs", connection))
            {
                command.CommandTimeout = 500;

                if (!string.IsNullOrEmpty(processName))
                {
                    command.AddWithValue("@PROCESS_NAME", processName);
                }

                var reader = command.ExecuteReader();

				while (reader.HasRows)
                {
					while (reader.Read())
                    {
                        var processId = Convert.ToNullableInt(reader["ProcessId"]);
                        var name = Convert.ToString(reader["ProcessName"]);
                        var processHistoryId = Convert.ToNullableInt(reader["ProcessHistoryId"]);
                        var updatedDateTime = Convert.ToDateTimeString(reader["UpdatedDateTime"], Format.DateTimeFormat.FullDateTime);
						var effectiveDate = Convert.ToDateTimeString(reader["EffectiveDate"], Format.DateTimeFormat.FullDateTime);
                        var expectedTimeCutoff = Convert.ToDateTimeString(reader["ExpectedTimeCutoff"], Format.DateTimeFormat.FullDateTime);
                        var isActive = (bool)reader["IsActive"];

                        result.Add(new ProcessLog()
                            {
                                ProcessId = processId.Value,
                                ProcessName = name,
                                ProcessHistoryId = processHistoryId.Value,
                                UpdatedDateTime = updatedDateTime,
                                EffectiveDate = effectiveDate,
                                ExpectedTimeCutoff = expectedTimeCutoff,
                                IsActive = isActive
                            });
                    }

                    reader.NextResult();
                }
            }

            return result;
        }


        /// <summary>
        ///  Gets most recent entries per process 
        /// </summary>
        /// <param name="connection">The SQL database connection to use</param>
        /// <returns></returns>
        public static IEnumerable<ProcessLog> SelectRecentProcessLogs(SqlConnection connection)
        {
            return SelectRecentProcessLogs(connection, string.Empty);
        }

        /// <summary>
        ///  Gets most recent effective date for a particular process 
        /// </summary>
        /// <param name="connection">The SQL database connection to use</param>
        /// <param name="processName">The process name to target.</param>
        /// <returns></returns>
        public static DateTime? SelectRecentProcessDate(SqlConnection connection, string processName)
        {
            var log = SelectRecentProcessLogs(connection, processName).FirstOrDefault();

            DateTime? date = null;

            if (log != null)
            {
                date = Convert.ToNullableDateTime(log.EffectiveDate);
            }

            return date;
        }
    }
}
