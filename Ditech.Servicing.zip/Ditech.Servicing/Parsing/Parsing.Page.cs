

using System.Collections.Generic;
using System.IO;

namespace Ditech.Servicing
{
    /// <summary>
    /// Provides various utility functions for servicing data.
    /// </summary>
    public static partial class Parsing
    {
        public const string PageDelimiter = "~";

        /// <summary>
        /// Pages the specified input.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        public static string[] Page(StreamReader input)
        {
            var page = new List<string>();

            string line;

            while ((line = input.ReadLine()) != null)
            {
                if (line.StartsWith(PageDelimiter))
                {
                    break;
                }

                page.Add(line);
            }

            return page.ToArray();
        }

        /// <summary>
        /// Breaks the specified file into a list of string arrays
        /// </summary>
        /// <param name="file">The file.</param>
        /// <returns></returns>
        public static List<string[]> Pages(FileInfo file)
        {
            var reportFile = new List<string[]>();

            using (var input = new StreamReader(file.FullName))
            {
                while (!input.EndOfStream)
                {
                    var page = Page(input);

                    if (page.Length > 0)
                    {
                        reportFile.Add(page);
                    }
                }
            }

            return reportFile;
        }
    }
}