

using System;
using System.Globalization;
using System.IO;

namespace Ditech.Servicing
{
    /// <summary>
    /// Provides various utility functions for servicing data.
    /// </summary>
    public static partial class Parsing
    {
        #region�Methods�(2)�

        //�Public�Methods�(2)�

        /// <summary>
        /// Returns the report date from the LPS report file as string.
        /// </summary>
        /// <param name="reportPath">The report path.</param>
        /// <returns></returns>
        public static DateTime ReportDate(string reportPath)
        {
            return NullableReportDate(reportPath).Value;
        }


        /// <summary>
        /// Returns the report date from the LPS report file as string.
        /// </summary>
        /// <param name="reportPath">The report path.</param>
        /// <returns></returns>
        public static DateTime? NullableReportDate(string reportPath)
        {
            var fileName = new FileInfo(reportPath).Name;

            var rawDate = fileName.Substring(5, 8);

            DateTime? result = null;

            DateTime date;

            if (DateTime.TryParseExact(rawDate, "MMddyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None,
                                       out date))
            {
                result = date;
            }
            else
            {
                 if (DateTime.TryParseExact(fileName.Left(10), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None,
                                          out date))
                 {
                      result = date;
                 }               
            }

            return result;
            
        }

        #endregion�Methods�
    }
}