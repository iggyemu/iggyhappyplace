

using System;
using System.IO;

namespace Ditech.Servicing
{
    public static partial class Parsing
    {
        #region�Methods�(1)�

        //�Public�Methods�(1)�

        /// <summary>
        /// Verifies that the file has been modified today
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <param name="throwException">if set to <c>true</c> [throw exception].</param>
        /// <returns></returns>
        public static bool VerifyLastModifiedDate(string filePath, bool throwException)
        {
            var result = false;

            var file = new FileInfo(filePath);

            if (file.Exists)
            {
                var fileDate = file.LastWriteTime.Date;

                if (fileDate == DateTime.Now.Date)
                {
                    result = true;
                }
                else
                {
                    if (throwException)
                    {
                        throw new Exception(string.Format("{0} last modified on {1}", filePath, fileDate));
                    }
                }
            }
            else
            {
                if (throwException)
                {
                    throw new Exception(string.Format("File does not exist: {0}", filePath));
                }
            }

            return result;
        }

        #endregion�Methods�
    }
}