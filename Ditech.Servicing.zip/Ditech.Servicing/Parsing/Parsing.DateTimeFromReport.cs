

using System;
using System.Linq;

namespace Ditech.Servicing
{
    /// <summary>
    /// Provides various utility functions for servicing data.
    /// </summary>
    public partial class Parsing
    {
        #region�Methods�(3)

        //�Public�Methods�(3)�


        /// <summary>
        /// Gets the fidelity date from report.
        /// </summary>
        /// <param name="rawDate">The raw date.</param>
        /// <returns></returns>
        public static DateTime DateTimeFromReport(string rawDate)
        {
            return DateTime.Parse(DateTimeFromReportAsString(rawDate, true));
        }

        /// <summary>
        /// Gets the fidelity date from report.
        /// </summary>
        /// <param name="rawDate">The raw date.</param>
        /// <returns></returns>
        public static DateTime? NullableDateTimeFromReport(string rawDate)
        {
            DateTime? result = null;

            DateTime date;

            if (DateTime.TryParse(DateTimeFromReportAsString(rawDate), out date))
            {
                result = date;
            }

            return result;
        }

        /// <summary>
        /// Gets the fidelity date from report.
        /// </summary>
        /// <param name="rawDate">The raw date.</param>
        /// <param name="throwError">if set to <c>true</c> [throw error].</param>
        /// <returns></returns>
        public static string DateTimeFromReportAsString(string rawDate, bool throwError)
        {
            rawDate = rawDate.Remove(new[] {'-', '/'});

            if (rawDate.ToCharArray().Any(x => !Char.IsDigit(x)))
            {
                rawDate = string.Empty;
            }

            var month = rawDate.Mid(0, 2);
            var day = rawDate.Mid(2, 2);
            var year = rawDate.Length == 8 ? rawDate.Mid(4, 4) : rawDate.Mid(4, 2);

            if (year == string.Empty)
            {
                year = day;
                day = "01";
            }

            var date = Date.FixNullable(year, month, day);

            if (date != null)
            {
                rawDate = date.Value.ToShortDateString();
            }
            else
            {
                if (throwError)
                {
                    throw new Exception("Cannot parse string \"" + rawDate + "\" to a DateTime object.");
                }
            }

            return rawDate;
        }

        /// <summary>
        /// Gets the fidelity date from report.
        /// </summary>
        /// <param name="rawDate">The raw date.</param>
        /// <returns></returns>
        public static string DateTimeFromReportAsString(string rawDate)
        {
            return DateTimeFromReportAsString(rawDate, false);
        }

        #endregion�Methods
    }
}