

using System.IO;

namespace Ditech.Servicing
{
    /// <summary>
    /// Provides various utility functions for servicing data.
    /// </summary>
    public static partial class Parsing
    {
        /// <summary>
        /// Gets the name of the report.
        /// </summary>
        /// <param name="reportFile">The report file.</param>
        /// <returns></returns>
        public static string ReportName(string reportFile)
        {
            var result = string.Empty;

            var fileName = Path.GetFileNameWithoutExtension(reportFile);

            var splitFileName = fileName.Split(new[] {' '});

            if (splitFileName.Length > 1)
            {
                result = splitFileName[1];
            }

            return result;
        }
    }
}