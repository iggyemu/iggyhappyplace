

using System;
using System.Text;
using EverBank.Data.Common;
using EverBank.Net.Mail;
using EverBank.Servicing.Data.Common;
using DbConnection=EverBank.Servicing.Data.Common.DbConnection;

namespace EverBank.Servicing
{
    public class Logging : EverBank.Logging
    {
        private ConnectionType connectionType = ConnectionType.Development;

        public Logging() : this(true)
        {
            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Logging"/> class.
        /// </summary>
        /// <param name="isProduction">if set to <c>true</c> [is production].</param>
        public Logging(bool isProduction)
        {
            if (isProduction)
            {
                connectionType = ConnectionType.Production;
            }

            EventID = LogProcessStart();
        }


        #region Methods (3) 


		// Public Methods (2) 

        /// <summary>
        /// Logs when a process ends.
        /// </summary>
        protected override void LogProcessEnd()
        {
            OtherInfo = OtherInfo.Replace("\'", "\'\'");

            // Establish the database connection
            using (var connection = new DbConnection(connectionType, DataType.Logging))
            {
                // Build the command
                var command = new DbCommand("sp_LogProcessEnd", connection);

                command.AddWithValue("@PROCESSID", EventID);
                command.AddWithValue("@OTHERINFO", OtherInfo);
                command.AddWithValue("@SUCCESSRECORDS", SuccessRecords);
                command.AddWithValue("@FAILEDRECORDS", FailureRecords);

                // Execute the command
                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Logs process failures
        /// </summary>
        /// <param name="ex">The exception.</param>
        public override void LogProcessFailure(Exception ex)
        {
            // Finds out from the stack who called the last function
            GetCallerInfo();

            FailureException = ex;

            // Establish the database connection
            using (var connection = new DbConnection(connectionType, DataType.Logging))
            {
                // Build the command
                var command = new DbCommand("sp_LogProcessFailure", connection);

                command.AddWithValue("@PROCESSID", EventID);
                command.AddWithValue("@ERRORCLASS", BaseClass);
                command.AddWithValue("@ERRORMETHOD", BaseMethod);
                command.AddWithValue("@ERRORMESSAGE", FailureException.Message.Replace("\'", "\'\'"));
                command.AddWithValue("@ERRORSTACKTRACE", FailureException.StackTrace.Replace("\'", "\'\'"));
                command.AddWithValue("@SUCCESSRECORDS", SuccessRecords);
                command.AddWithValue("@FAILURERECORDS", FailureRecords);
                command.AddWithValue("@OTHERINFO", OtherInfo);

                // Execute the command
                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Logs process failures
        /// </summary>
        /// <param name="ex">The exception.</param>
        /// <param name="emailAddress">The email address.</param>
        /// <param name="additionalErrorInfo">The additional error information.</param>
        /// <param name="notifyOperations">if set to <c>true</c> [notify operations].</param>
        public void LogProcessFailure(Exception ex, string emailAddress, string additionalErrorInfo,
                                      bool notifyOperations)
        {
            LogProcessFailure(ex, new[] {emailAddress}, additionalErrorInfo, notifyOperations);
        }

        /// <summary>
        /// Logs process failures
        /// </summary>
        /// <param name="ex">The exception.</param>
        /// <param name="emailAddresses">The email addresses.</param>
        /// <param name="additionalErrorInfo">The additional error information.</param>
        /// <param name="notifyOperations">if set to <c>true</c> [notify operations].</param>
        public void LogProcessFailure(Exception ex, string[] emailAddresses, string additionalErrorInfo,
                                      bool notifyOperations)
        {
            LogProcessFailure(ex);

            SendFailureEmail(LoggingResource.OperationsEmail, additionalErrorInfo, emailAddresses, notifyOperations);
        }

        /// <summary>
        /// Logs the process failure.
        /// </summary>
        /// <param name="ex">The exception.</param>
        /// <param name="sendNotice">if set to <c>true</c> [send email].</param>
        public void LogProcessFailure(Exception ex, bool sendNotice)
        {          
            if (sendNotice)
            {
                // Send an e-mail to alert the the process failed
                string[] emailRecipients = LoggingResource.FailureRecipients.Split(new[] {';'}, StringSplitOptions.RemoveEmptyEntries);

                LogProcessFailure(ex, emailRecipients, string.Empty, true);
            }
            else
            {
                LogProcessFailure(ex);
            }
        }


		// Protected Methods (1) 

        /// <summary>
        /// Logs the start of the process.
        /// </summary>
        /// <returns>eventID of the process (used for updating the record to reflect success/failure)</returns>
        protected override string LogProcessStart()
        {
            // Establish the database connection
            using (var connection = new DbConnection(connectionType, DataType.Logging))
            {
                // Build the command
                var command = new DbCommand("sp_LogProcessStart", connection);

                command.AddWithValue("@PROCESSUSER", ProcessUser);
                command.AddWithValue("@PROCESSMACHINE", ProcessMachine);
                command.AddWithValue("@PROCESSPATH", ProcessPath);
                command.AddWithValue("@PROCESSNAME", ProcessName);
                command.AddWithValue("@PROCESSVERSION", ProcessVersion);
                command.AddWithValue("@PROCESSCLASS", ProcessClass);
                command.AddWithValue("@PROCESSMETHOD", ProcessMethod);

                // Execute the command
                return Convert.ToString(command.ExecuteScalar());
            }
        }


        /// <summary>
        /// Sends the failure email.
        /// </summary>
        /// <param name="senderAddress">The sender address.</param>
        /// <param name="additionalText">The additional text.</param>
        /// <param name="emailRecipients">The email recipients.</param>
        /// <param name="notifyOperations">if set to <c>true</c> [notify operations].</param>
        private void SendFailureEmail(string senderAddress, string additionalText, string[] emailRecipients,
                                      bool notifyOperations)
        {
            var emailBody = new StringBuilder(string.Format(
                                                            "Full details available at: http://z-amc2157/Operations/ProcessLogProd.asp?ID={0}\r\n\r\n",
                                                            EventID));

            emailBody.AppendLine(string.Format("Process ID: {0}", EventID));
            emailBody.AppendLine(string.Format("Operator Name: {0}", ProcessUser));
            emailBody.AppendLine(string.Format("Machine Name: {0}", ProcessMachine));
            emailBody.AppendLine(string.Format("Start Class: {0}", ProcessClass));
            emailBody.AppendLine(string.Format("Error Method: {0}", BaseMethod));
            emailBody.AppendLine(string.Format("Error Message: {0}", FailureException.Message));
            emailBody.AppendLine(string.Format("\r\n{0}\r\n", FailureException.StackTrace));

            emailBody.Append(additionalText);

            var email = new MailMessage(senderAddress, emailRecipients,
                                                ProcessName + " (" + BaseClass + ") Failed!", emailBody.ToString(),
                                                notifyOperations);

            email.Send();
        }

        #endregion Methods 

    }
}
