

using System;
using System.ComponentModel;

namespace Ditech.Servicing.Net.FTP
{
    /// <summary>
    /// FTP Client class.  Inherits from Ditech.Net.FTP.FtpClient.  Constructor allows creation from FtpCredentials enum.
    /// </summary>
    public class FtpClient : Ditech.Net.FTP.FtpClient
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FtpClient"/> class.
        /// </summary>
        /// <param name="ftpCredentials">The FTP credentials.</param>
        public FtpClient(FtpCredentials ftpCredentials)
        {
            try
            {
                UserName = FtpResource.ResourceManager.GetString(ftpCredentials.ToString("G") + "Login");
                Password = FtpResource.ResourceManager.GetString(ftpCredentials.ToString("G") + "Password");
                ServerName = FtpResource.ResourceManager.GetString(ftpCredentials.ToString("G") + "Server");
                ServerPath = FtpResource.ResourceManager.GetString(ftpCredentials.ToString("G") + "Path");
            }
            catch (Exception)
            {
                throw new InvalidEnumArgumentException("Invalid enum value passed.");
            }
        }
    }
}