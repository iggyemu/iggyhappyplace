﻿namespace Ditech.Servicing.Net.FTP
{
    /// <summary>
    /// Available accounts for FTP connections.
    /// </summary>
    public enum FtpCredentials
    {
        Test
        // Create your own FTP credential enum here and add them to the resource file
    }
}