﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Ditech.Data.Common;
using Ditech.Net.Mail;
using Ditech.Servicing.Data.Common;

namespace Ditech.Servicing.Net.Mail
{
    ///<summary>
    /// Used to create new instances of the MailMessage class using servicing specific data
    ///</summary>
    public static class Email
    {
        /// <param name="fromAddress">From address.</param>
        /// <param name="appId">The app ID used to retrieve the recipient list</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        /// <param name="dbConnection">Existing database connection, if null a new connection is created.</param>
        /// <param name="attachment">The attachment.</param>
        public static MailMessage Create(string fromAddress, int appId, string subject, string body, string attachment, bool ccSender = false, SqlConnection dbConnection = null)
        {
            return Create(fromAddress, appId, subject, body, ccSender, dbConnection,
                          attachment == null ? null : new[] {attachment});
        }

        /// <param name="fromAddress">From address.</param>
        /// <param name="appId">The app ID used to retrieve the recipient list</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        /// <param name="dbConnection">Existing database connection, if null a new connection is created.</param>
        /// <param name="attachments">The attachments.</param>
        public static MailMessage Create(string fromAddress, int appId, string subject, string body, bool ccSender = false, SqlConnection dbConnection = null,
                           string[] attachments = null)
        {
            var newConnectionCreated = Initialize(ref dbConnection, ref attachments);

            var message = CreateMailMessageInstance(fromAddress, appId, subject, body, ccSender, dbConnection, attachments);

            DisposeConnection(dbConnection, newConnectionCreated);

            return message;
        }

        private static void DisposeConnection(SqlConnection dbConnection, bool newConnectionCreated)
        {
            if (newConnectionCreated)
            {
                dbConnection.Dispose();
            }
        }

        /// <param name="fromAddress">From address.</param>
        /// <param name="appId">The app ID used to retrieve the recipient list</param>
        /// <param name="subject">The subject.</param>
        /// <param name="body">The body.</param>
        /// <param name="ccSender">if set to <c>true</c> [cc sender].</param>
        /// <param name="dbConnection">Existing database connection, if null a new connection is created.</param>
        /// <param name="attachments">The attachments.</param>
        public static MailMessage Create(int appId, bool ccSender = false, SqlConnection dbConnection = null,
                           string[] attachments = null)
        {
            return Create(string.Empty, appId, string.Empty, string.Empty, ccSender, dbConnection, attachments);
        }

        public static MailMessage Create(string appName, SqlConnection dbConnection = null, string[] attachments = null)
        {
            var newConnectionCreated = Initialize(ref dbConnection, ref attachments);

            var message = CreateMailMessageInstance(string.Empty, -1, string.Empty, string.Empty, false, dbConnection, attachments, appName);
            
            DisposeConnection(dbConnection, newConnectionCreated);

            return message; 
        }

        private static bool Initialize(ref SqlConnection dbConnection, ref string[] attachments)
        {
            var newConnectionCreated = false;

            if (dbConnection == null)
            {
                dbConnection = Connection.Create(SqlDbName.MSP_APPLICATIONS);
                newConnectionCreated = true;
            }

            if (attachments == null)
            {
                attachments = new string[0];
            }
            return newConnectionCreated;
        }

        private static MailMessage CreateMailMessageInstance(string fromAddress, int appId, string subject, string body, bool ccSender, SqlConnection dbConnection,
                           string[] attachments, string appName = "")
        {
            var toList = new List<string>();
            var ccList = new List<string>();
            var bccList = new List<string>();

            var storedProcName = string.IsNullOrEmpty(appName)
                                     ? "MSP_APPLICATIONS.EMAIL.Select_EmailAddressForApp"
                                     : "MSP_APPLICATIONS.EMAIL.Select_EmailAddressForAppName";

            using (var command = new DbCommand(storedProcName, dbConnection))
            {
                if (string.IsNullOrEmpty(appName))
                {
                    command.AddWithValue("@APP_ID", appId);
                }
                else
                {
                    command.AddWithValue("@APP_DESCRIPTION", appName);
                }

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var emailAddress = Convert.ToString(reader["EMAIL_ADDRESS"]).Trim();
                        var cc = (bool) reader["CC"];
                        var bcc = (bool) reader["BCC"];

                        if (!string.IsNullOrEmpty(appName) && appId < 0)
                        {
                            appId = (int)Convert.ToDecimal(reader["APP_ID"]);
                        }

                        if (cc)
                        {
                            ccList.Add(emailAddress);
                        }
                        else
                        {
                            if (bcc)
                            {
                                bccList.Add(emailAddress);
                            }
                            else
                            {
                                toList.Add(emailAddress);
                            }
                        }
                    }
                }
            }

            using (var command = new DbCommand("MSP_APPLICATIONS.EMAIL.Select_EmailDetails", dbConnection))
            {
                command.AddWithValue("@APP_ID", appId);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var databaseSender = Convert.ToString(reader["SENDER"]).Trim();
                        var databaseSubject = Convert.ToString(reader["SUBJECT"]).Trim();
                        var databaseBody = Convert.ToString(reader["BODY"]).Trim();

                        fromAddress = databaseSender.Coalesce(fromAddress);
                        subject = databaseSubject.Coalesce(subject);
                        body = databaseBody.Coalesce(body);
                    }
                }
            }

            var message = new MailMessage(fromAddress, toList, subject, body, ccSender, attachments);

            foreach (var email in ccList)
            {
                message.CC.Add(email);
            }

            foreach (var email in bccList)
            {
                message.Bcc.Add(email);
            }

            return message;
        }
    }
}
