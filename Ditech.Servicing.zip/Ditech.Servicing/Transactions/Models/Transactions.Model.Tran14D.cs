﻿
namespace Ditech.Servicing.Transactions.Models
{
   public partial class TransactionModels
    {
        public class Tran14DModel
        {
            public string RequestType { get; set; }
            public int  LoanNumber { get; set; }
            public string LetterId { get; set; }
            public string Collections { get; set; }
            public string PrintTape { get; set; }
        }
    }
}
