﻿namespace Ditech.Servicing.Transactions.Models
{
    public partial class TransactionModels
    {
        public class Tran084c7Model
        {
            public string LoanNumber { get; set; }
            public string QueueDropDate { get; set; }
            public string LossMitigationIndicator { get; set; }
            public string InvestorDelinquencyStatus { get; set; }
            public string InvestorDelinquencyReason { get; set; }
            public string OriginalHouseholdExpense { get; set; }
            public string OriginalOccupancyStatus { get; set; }
            public string CurtailmentInterestFlag { get; set; }
            public string Balance { get; set; }
            public string CustodianCode { get; set; }
            public string CreditDecisionByLender { get; set; }
            public string OriginalPropertyValue { get; set; }
            public string OriginalSelfEmployed { get; set; }

        }

        public class Tran084cHModel
        {
            public string LoanNumber { get; set; }
            public string Chapter7Discharge { get; set; }
            public string DischargeDate { get; set; }
            public string FirstLegalActionDate { get; set; }
            public string ChargeOffDate { get; set; }
            public string ChargeOffBalance { get; set; }
            public string LoanComplianceCode { get; set; }
            public string BorrowerRelationCode { get; set; }
            public string CoBorrowerRelationCode { get; set; }
            public string BorrowerConsumerInformationCodeOne { get; set; }
            public string BorrowerConsumerInformationCodeTwo { get; set; }
            public string CoBorrowerConsumerInformationCodeOne { get; set; }
            public string CoBorrowerconsumerInformationCodeTwo { get; set; }
            public string NegativeNotice { get; set; }
            public string MortgagorLanguagePreference { get; set; }
            public string VADefaultReaon { get; set; }
            public string FannieMaeStatusEffectiveDate { get; set; }
            public string FannieMaeExpectedCompletionDate { get; set; }
            public string K4Segment { get; set; }
            public string MortgagorCBRIndicatorSwitch { get; set; }
            public string CoBorrowerCBRIndicatorSwitch { get; set; }


        }
    }
}