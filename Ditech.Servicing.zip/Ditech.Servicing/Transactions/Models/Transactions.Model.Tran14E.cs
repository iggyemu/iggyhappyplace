﻿namespace Ditech.Servicing.Transactions.Models
{
   public partial class TransactionModels
    {
       public class Tran14EModel
       {
           public int LoanNumber { get; set; }
           public string ActionCode { get; set; }
           public string RequesterId { get; set; }
           public string LetterId { get; set; }
           public string LetterVersion { get; set; }
           public string LetterDescription { get; set; }

       }
   } 
}
