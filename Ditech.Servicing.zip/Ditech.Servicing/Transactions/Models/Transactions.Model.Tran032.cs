﻿namespace Ditech.Servicing.Transactions.Models
{
    public partial class TransactionModels
    {
        public class Tran032Model
        {
            public string LoanNumber { get; set; }
            public string LateChargeCount { get; set; }
            public string LateChargeCountAdjustment { get; set; }
            public string PaymentRecordTable { get; set; }
            public string ReasonForLateChargeAdjustment { get; set; }
            public string ReferenceDate { get; set; }
            public string FeeCode { get; set; }
            public string FeeAmount { get; set; }
            public string ElocFeeSubcode { get; set; }
        }
    }
}