﻿namespace Ditech.Servicing.Transactions.Models
{
    public partial class TransactionModels
    {
        public class Tran03RModel
        {
            public string LoanNumber { get; set; } 

            public string ChangedBy { get; set; } 


            public string StopExpirationDate { get; set; }  

            public string ProcessStop { get; set; }  

            public string ProcessStopReasonCode { get; set; }  


            public string BadCheckStop { get; set; }  

            public string BadCheckStopReasonCode { get; set; }  

            public string PaidInFullStop { get; set; }  

            public string PaidInFullStopReasonCode { get; set; }  

            public string ForeclosureStop { get; set; }  

            public string ForeclosureStopReasonCode { get; set; }  

            public string NoNoticeCode { get; set; }  

            public string NoNoticeStopReasonCode { get; set; }  

            public string NoAnalysisStop { get; set; }  

            public string NoAnalysisStopReasonCode { get; set; }  

            public string AAndHFlag { get; set; }  

            public string AAndHFlagReasonCode { get; set; }  

            public string LifeFlag { get; set; } 

            public string LifeFlagReasonCode { get; set; }  

            public string DisbursementStop { get; set; }  

            public string DisbursementStopReasonCode { get; set; }  

            public string LateChargeAssessmentStop { get; set; }  

            public string LateChargeStopReasonCode { get; set; }  

            public string PayoffPendingDisbursementStop { get; set; }  

            public string PayoffPendingDisbursementStopReasonCode { get; set; }  

            public string ArmUpdateStop { get; set; }  

            public string ArmUpdateStopReasonCode { get; set; }  

            public string ArmNoticeStop { get; set; }  

            public string ArmNoticeStopReasonCode { get; set; } 

            public string ElocAdvanceStop { get; set; }  

            public string ElocAdvanceStopReasonCode { get; set; }  

            public string ElocDisputedFlag { get; set; }  

            public string ElocDisputedFlagReasonCode { get; set; }  

            public string OptOutStop { get; set; }  

            public string OptOutStopReasonCode { get; set; }  
        }
    }
}