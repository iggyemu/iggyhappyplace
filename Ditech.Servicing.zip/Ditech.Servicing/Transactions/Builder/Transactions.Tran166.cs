﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 166 - Escrow Analysis - Delete (D-011)
        /// Transaction 166 deletes the information carried for a specific disbursement item from the escrow analysis information in the master file. 
        /// This item is identified by the type of disbursement, the escrow payee sequence, and the escrow payee code. This information can be obtained from the trial analysis reports P-172, P-472, and S-274, if available.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="fromTypeDisbursement">(14-16) This field is required. Use this field with FROM SEQ NUMBER and FROM PAYEE, to determine which disbursement item is being deleted from the escrow analysis information.</param>
        /// <param name="fromSeqNumber">(17-18) This field is required. Use this field with FROM TYPE DISBURSEMENT and FROM PAYEE to determine which disbursement item is being deleted from the escrow analysis information.</param>
        /// <param name="fromPayee">(19-28) This field is required. Use this field with FROM TYPE DISBURSEMENT and FROM SEQ NUMBER to determine which disbursement item is being deleted from the escrow analysis information.</param>
        /// <param name="toTypeDisbursement">(29-31) This field is optional. It indicates the type of mortgage insurance or tax disbursement of the item being changed. If the disbursement type in the master file and the FROM TYPE DISB. field is correct, this field may be left blank. After maintenance, the new disbursement type, sequence number, and payee code is used to identify this disbursement item. A description of the disbursement type should be present in the analysis description headers on the header file. See transaction 00B.</param>
        /// <param name="toSequenceNumber">(32-33) This field is optional. For disbursement type 310, this field is used to distinguish MIP payments (to FHA) from PMI payments. For disbursement types 311 through 329, it is used to distinguish between multiple tax bills from the same authority when the tax amounts or billing periods are unequal. If the escrow payee sequence number in the master file and the FROM SEQUENCE NO. field is correct. This field may be left blank. After maintenance, the new disbursement type, sequence number, and payee code is used to identify this disbursement item.</param>
        /// <param name="toPayee">(34-43) This field is optional. It identifies the organization to whom this disbursement is due. It is used with the TO TYPE DISB. field and the TO SEQ. NO. field, to identify this disbursement item being added to the escrow analysis information in the master file. An escrow payee header should be present on the header file for this payee code (see transactions CH1, CH2/CH3, and CH4) if the system is to print the check when the disbursement is made.</param>
        /// <param name="term">(44-45) This field is optional. It indicates the number of months between bills for this disbursement item. For example, for a quarterly bill paid at equal intervals for equal amounts, one escrow analysis item is set up with a term of 03 months. For quarterly bills paid at unequal intervals or for unequal amounts, four analysis items are set up, each with a term of 12 months. The term is used in updating the disbursement due date when a disbursement (transactions 310 through 329) is made for this item. The disbursement term is also used by the escrow analysis programs when calculating how much escrow should be collected with each mortgage payment.</param>
        /// <param name="dueDate">(46-49) This field is optional. It indicates the date on which the next disbursement for this item is due. It is used by the escrow analysis programs when calculating how much escrow should be collected with each mortgage payment and to determine if a sufficient escrow balance exists. When the disbursement (transaction 310 through 329) is made for this item, its due date in the master file is advanced by the term.</param>
        /// <param name="disbursementAmount">(50-58) This field is optional. It indicates the anticipated amount of the next disbursement for this escrow analysis item. This amount is used by the escrow analysis programs in calculating how much escrow should be collected with each mortgage payment. When the disbursement (transactions 310 through 329) is made, the actual amount disbursed replaces the disbursement amount for this item in the master file.</param>
        /// <param name="billCode">(59) This field is optional. It is used to determine the status of this disbursement item. When a disbursement (transactions 310 through 329) for this item is applied and the disbursement due date is advanced, the bill code in the master file is set to 2. If the disbursement does not apply, the bill code is set to 1.</param>
        /// <param name="newLoanCode">(60) This field is optional. It indicates whether the next disbursement (transactions 311 through 329) for this analysis item should replace the disbursement amount if it is less than the amount indicated in the master file. On a new loan, the first through fourth tax bills may be for less than the full taxing period. Therefore, the amount carried in the master file should not be replaced by this partial amount.</param>
        /// <param name="unevenTaxCode">(61) This field is optional. It groups tax buckets with the same type disbursement paid to the same tax authority at even or uneven intervals for even or uneven amounts. Uneven tax groups with the same type disbursement require different uneven tax codes. Use a unique code for each land parcel being taxed.</param>
        /// <returns>Transaction 166</returns>
        public static string Tran166(string loanNumber, string fromTypeDisbursement = "", string fromSeqNumber = "", string fromPayee = "",
                                        string toTypeDisbursement = "", string toSequenceNumber = "", string toPayee = "", string term = "", string dueDate = "", string disbursementAmount = "", string billCode = "", string newLoanCode = "", string unevenTaxCode = "")
        {
            string transaction;

            try
            {
                var transactionName = "166";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "fromTypeDisbursement", fromTypeDisbursement);
                CheckRequiredField(transactionName, "fromSeqNumber", fromSeqNumber);
                CheckRequiredField(transactionName, "fromPayee", fromPayee);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(fromTypeDisbursement.Trim().PadRight(3)); // 14-16: FROM TYPE DISBURSEMENT
                tranBuilder.Append(fromSeqNumber.Trim().PadRight(2)); // 17-18: FROM SEQ NUMBER
                tranBuilder.Append(fromPayee.Trim().PadRight(10)); // 19-28: FROM PAYEE
                tranBuilder.Append(toTypeDisbursement.Trim().PadRight(3)); // 29-31: TO TYPE DISBURSEMENT
                tranBuilder.Append(LeftZeroFillOptionalField(toSequenceNumber.Trim(), 2)); // 32-33: TO SEQUENCE NUMBER
                tranBuilder.Append(toPayee.Trim().PadRight(10)); // 34-43: TO PAYEE
                tranBuilder.Append(LeftZeroFillOptionalField(term, 2)); // 44-45: TERM
                tranBuilder.Append(FormatDate(dueDate, "MMyy")); // 46-49: DUE DATE
                tranBuilder.Append(FormatMoney(disbursementAmount, true, false, 9)); // 50-58: DISBURSEMENT AMOUNT
                tranBuilder.Append(billCode.Trim().PadRight(1)); // 59: BILL CODE
                tranBuilder.Append(newLoanCode.Trim().PadRight(1)); // 60: NEW LOAN CODE
                tranBuilder.Append(unevenTaxCode.Trim().PadRight(1)); // 61: UNEVEN TAX CODE
                tranBuilder.Append(' ', 19); // 62-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
