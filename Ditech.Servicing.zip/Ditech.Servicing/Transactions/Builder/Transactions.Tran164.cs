﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 164 - Escrow Analysis - Delete (D-011)
        /// Transaction 164 deletes the information carried for a specific disbursement item from the escrow analysis information in the master file. 
        /// This item is identified by the type of disbursement, the escrow payee sequence, and the escrow payee code. This information can be obtained from the trial analysis reports P-172, P-472, and S-274, if available.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="fromTypeDisbursement">(14-16) This field is required. Use this field with FROM SEQ NUMBER and FROM PAYEE, to determine which disbursement item is being deleted from the escrow analysis information.</param>
        /// <param name="fromSeqNumber">(17-18) This field is required. Use this field with FROM TYPE DISBURSEMENT and FROM PAYEE to determine which disbursement item is being deleted from the escrow analysis information.</param>
        /// <param name="fromPayee">(19-28) This field is required. Use this field with FROM TYPE DISBURSEMENT and FROM SEQ NUMBER to determine which disbursement item is being deleted from the escrow analysis information.</param>
        /// <param name="initialEscrowStatement">(72) This field is conditional. It updates the PMI-INIT-STMT-CODE in the master file whenever the system processes a transaction 164 from the MIPC screen in the Mortgage Insurance Workstation. The system fills the field with "T"; you cannot make an entry in this field.</param>
        /// <returns>Transaction 164</returns>
        public static string Tran164(string loanNumber, string fromTypeDisbursement = "", string fromSeqNumber = "", string fromPayee = "",
                                       string initialEscrowStatement = "")
        {
            string transaction;

            try
            {
                var transactionName = "164";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "fromTypeDisbursement", fromTypeDisbursement);
                CheckRequiredField(transactionName, "fromSeqNumber", fromSeqNumber);
                CheckRequiredField(transactionName, "fromPayee", fromPayee);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(fromTypeDisbursement.Trim().PadRight(3)); // 14-16: FROM TYPE DISBURSEMENT
                tranBuilder.Append(fromSeqNumber.Trim().PadRight(2)); // 17-18: FROM SEQ NUMBER
                tranBuilder.Append(fromPayee.Trim().PadRight(10)); // 19-28: FROM PAYEE
                tranBuilder.Append(' ', 43); // 29-71: RESERVED
                tranBuilder.Append(initialEscrowStatement.Trim().PadRight(1)); // 72: INITIAL ESCROW STATEMENT
                tranBuilder.Append(' ', 8); // 73-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
