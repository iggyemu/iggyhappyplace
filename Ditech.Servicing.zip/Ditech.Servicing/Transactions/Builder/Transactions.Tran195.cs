#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 195 - Cleared Check (D-046).
        /// Use transaction 195 for different functions depending on which bank reconciliation system you use.
        /// </summary>
        /// <param name="checkNumber">(7-12) This field is required. Use the check number to match the check record in the Z-9AA/T-64K history file. </param>
        /// <param name="checkDate">(13-18) This field is conditional. If you enter the date, it must match the check record in the Z-9AA/T-64K history file. The matching record is deleted from the Z-9AA file and the status of the record kept in the T-64K file is updated to pending cleared or pending voided as appropriate. </param>
        /// <param name="payee">(19-23) This field is required. Use the payee code of the bank account to match the check record in the Z-9AA/T-64K history file. </param>
        /// <param name="checkAmount">(24-34) This field is required. Use the amount to match the check record in the Z-9AA/T-64K history file. </param>
        /// <param name="statusSW">(42) This field is optional. This field flags a check as cleared, voided, or outstanding. </param>
        /// <param name="accountNumber">(43-59) This field is optional. It indicates the account number.</param>
        /// <param name="investorCode">(76-78) This field is optional. This field identifies the investor related with the check, EFT, or wire, if there is one. </param>
        /// <param name="manualSystemCheckIndicator">(79) This field is conditional. It is required when a previous transaction 195 (D-046) was used on the check, wire, or EFT. This field indicates the type of check that is being submitted by number. It was either a system-generated check or a manually written check. </param>
        /// <returns>Transaction 195</returns>
        public static string Tran195(string checkNumber, string checkDate, string payee, string checkAmount,
                                     string statusSW, string accountNumber, string investorCode,
                                     string manualSystemCheckIndicator)
        {
            string transaction;

            try
            {
                var transactionName = "195";

                CheckRequiredField(transactionName, "checkNumber", checkNumber);
                CheckRequiredField(transactionName, "payee", payee);
                CheckRequiredField(transactionName, "checkAmount", checkAmount);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(checkNumber.Trim().PadLeft(6, '0')); // 7-12: CHECK NUMBER
                tranBuilder.Append(FormatDate(checkDate.Trim())); // 13-18: CHECK DATE
                tranBuilder.Append(payee.Trim().PadRight(5)); // 19-23: PAYEE
                tranBuilder.Append(FormatMoney(checkAmount.Trim(), true, true, 11)); // 24-34: CHECK AMOUNT
                tranBuilder.Append(' ', 7); // 35-41: RESERVED
                tranBuilder.Append(statusSW.Trim().PadRight(1)); // 42: STATUS SW
                tranBuilder.Append(accountNumber.Trim().PadRight(17)); // 43-59: ACCOUNT NUMBER
                tranBuilder.Append(' ', 16); // 60-75: RESERVED
                tranBuilder.Append(investorCode.Trim().PadRight(3)); // 76-78: INVESTOR CODE
                tranBuilder.Append(manualSystemCheckIndicator.Trim().PadRight(1)); // 79: MANUAL/SYSTEM CHECK INDICATOR
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 22); // 81-102: EMPTY SPACE
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}