#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 02F - Co-Borrower Name and Address (D-279)
        /// Use transaction 02F to enter up to nine additional co-borrower name and address combinations for a loan.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="borrowerNumber">(14) This field is conditional. This field is used to identify the co-borrower SSN/TIN combination of multiple co-borrowers. This field is required if you enter information in the FORMATTED NAME #2 field.</param>
        /// <param name="coBorrowersFormattedName">(16-45) This field is required. It is the full name of the co-borrower in last, first, middle name format.</param>
        /// <param name="formattedName2">(46-75) This field is optional. This field displays the name of any additional co-borrower formatted names.</param>
        /// <returns>Transaction 02F Card 1</returns>
        public static string Tran02Fc1(string loanNumber, string borrowerNumber, string coBorrowersFormattedName,
                                       string formattedName2)
        {
            string transaction;

            try
            {
                var transactionName = "02F-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "coBorrowersFormattedName", coBorrowersFormattedName);

                if (IsAvailable(formattedName2) && !IsAvailable(borrowerNumber))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: borrowerNumber cannot be blank when formattedName2 has a value.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(borrowerNumber.PadRight(1)); // 14: BORROWER NUMBER
                tranBuilder.Append("1"); // 15: CARD CODE
                tranBuilder.Append(coBorrowersFormattedName.PadRight(30)); // 16-45: CO-BORROWER'S FORMATTED NAME
                tranBuilder.Append(formattedName2.PadRight(30)); // 46-75: FORMATTED NAME #2
                tranBuilder.Append(' ', 5); // 76-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 02F - Co-Borrower Name and Address (D-279)
        /// Use transaction 02F to enter up to nine additional co-borrower name and address combinations for a loan.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="borrowerNumber">(14) This field is conditional. This field is used to identify the co-borrower SSN/TIN combination of multiple co-borrowers. This field is required if you enter information in the FORMATTED NAME #2 field.</param>
        /// <param name="street">(16-45) This field is required. This field records the street address for the co-borrower in the CO-BORROWER FORMATTED NAME field.</param>
        /// <param name="borrowerSsn_Tin">(46-55) This field is optional. This field contains the co-mortgagor social security number or the federal tax ID number assigned by the IRS.</param>
        /// <param name="name2Ssn_Tin">(56-65) This field is optional. This field contains any additional co-mortgagor social security numbers or the federal tax ID number assigned by the IRS.</param>
        /// <param name="borrEcoa">(76) This field is optional. It indicates the relationship of the mortgagor to the account and designates the type of account.</param>
        /// <param name="name2Ecoa">(77) This field is optional. It indicates the second co-borrower's relationship to the account.</param>
        /// <param name="borrCbr">(78) This field is optional. It indicates if the co-borrower is subject to be reported to the credit bureau repositories.</param>
        /// <param name="name2Cbr">(79) This field is optional. It indicates if the second co-borrower is subject to be reported to the credit bureau repositories.</param>
        /// <returns>Transaction 02F Card 3</returns>
        public static string Tran02Fc3(string loanNumber, string borrowerNumber, string street, string borrowerSsn_Tin,
                                       string name2Ssn_Tin, string borrEcoa, string name2Ecoa, string borrCbr,
                                       string name2Cbr)
        {
            string transaction;

            try
            {
                var transactionName = "02F-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "street", street);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(borrowerNumber.PadRight(1)); // 14: BORROWER NUMBER
                tranBuilder.Append("3"); // 15: CARD CODE
                tranBuilder.Append(street.PadRight(30)); // 16-45: STREET
                tranBuilder.Append(FormatSsnTin(borrowerSsn_Tin)); // 46-55 BORROWER SSN/TIN
                tranBuilder.Append(FormatSsnTin(name2Ssn_Tin)); // 56-65: NAME 2 SSN/TIN
                tranBuilder.Append(' ', 10); // 66-75: RESERVED
                tranBuilder.Append(borrEcoa.PadRight(1)); // 76: BORR ECOA
                tranBuilder.Append(name2Ecoa.PadRight(1)); // 77: NAME 2 ECOA
                tranBuilder.Append(borrCbr.PadRight(1)); // 78: BORR CBR
                tranBuilder.Append(name2Cbr.PadRight(1)); // 79: NAME 2 CBR
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 02F - Co-Borrower Name and Address (D-279)
        /// Use transaction 02F to enter up to nine additional co-borrower name and address combinations for a loan.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="borrowerNumber">(14) This field is conditional. This field is used to identify the co-borrower SSN/TIN combination of multiple co-borrowers. This field is required if you enter information in the FORMATTED NAME #2 field.</param>
        /// <param name="city">(16-36) This field is required. This field records the co-borrower's city for postal delivery purposes.</param>
        /// <param name="state">(37-38) This field is required. This field records the U.S. postal service abbreviation for the postal delivery state of the co-mortgagor.</param>
        /// <param name="zipCode">(39-43) This field is required. This field records the five-digit postal delivery zip code of the co-mortgagor.</param>
        /// <param name="zipSuffix">(44-47) This field is required. This field records the four-digit zip code suffix for the co-mortgagor.</param>
        /// <param name="carrierRouteSort">(48-51) This field is optional. This field records the four-character postal carrier route code for the co-mortgagor.</param>
        /// <param name="foreignAddressIndicator">(52) This field is optional. This field indicates that the address is in a foreign country and that the validation of the U.S. state abbreviation should not be done and that this loan is reported to the IRS as a foreign address.This field is optional. This field indicates that the address is in a foreign country and that the validation of the U.S. state abbreviation should not be done and that this loan is reported to the IRS as a foreign address.</param>
        /// <param name="telephoneNumber">(54-67) This field is optional. This field is used to enter the co-borrower's telephone number and extension.</param>
        /// <returns>Transaction 02F Card 4</returns>
        public static string Tran02Fc4(string loanNumber, string borrowerNumber, string city, string state,
                                       string zipCode, string zipSuffix, string carrierRouteSort,
                                       string foreignAddressIndicator, string telephoneNumber)
        {
            string transaction;

            try
            {
                var transactionName = "02F-4";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "city", city);

                if (!IsAvailable(foreignAddressIndicator) && !IsAvailable(state))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: State is required if foreignAddressIndicator is left blank.",
                                      transactionName, loanNumber));
                }

                CheckRequiredField(transactionName, "zipCode", zipCode);
                CheckRequiredField(transactionName, "zipSuffix", zipSuffix);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(borrowerNumber.Trim().PadRight(1)); // 14: BORROWER NUMBER
                tranBuilder.Append("4"); // 15: CARD CODE
                tranBuilder.Append(city.Trim().PadRight(21)); // 16-36: CITY
                tranBuilder.Append(state.Trim().PadRight(2)); // 37-38: STATE
                tranBuilder.Append(FormatZipCode(zipCode.Trim())); // 39-43: ZIP CODE
                tranBuilder.Append(zipSuffix.Trim().PadLeft(4, '0')); // 44-47: ZIP SUFFIX (+ 4)
                tranBuilder.Append(carrierRouteSort.Trim().PadRight(4)); // 48-51: CARRIER ROUTE SORT
                tranBuilder.Append(foreignAddressIndicator.Trim().PadRight(1)); // 52: FOREIGN ADDRESS INDICATOR
                tranBuilder.Append(' '); // 53: RESERVED
                tranBuilder.Append(telephoneNumber.Trim().PadRight(14)); // 54-67: TELEPHONE NUMBER
                tranBuilder.Append(' ', 13); // 68-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}