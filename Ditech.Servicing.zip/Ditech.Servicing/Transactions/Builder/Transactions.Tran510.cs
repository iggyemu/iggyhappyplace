#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 510 - Expanded Name and Address (D-021)
        /// Use transaction 510 to enter the expanded six-line name and address fields at loan setup. You can use this transaction to set up other master file data, such as abbreviated names, social security numbers, telephone numbers, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mortgagorFormattedName">(15-44) This field is required. It is the full name of the mortgagor in last, first, middle name format.</param>
        /// <param name="mortgagorAbbreviatedNameInitials">(45-46) This field is optional. It indicates the mortgagor's first and middle initials. Use this field for reporting when the space available cannot accommodate the billing name. Also use this field as a sort for indexes.</param>
        /// <param name="mortgagorAbbreviatedNameShortName">(47-54) This field is required. It indicates the mortgagor's abbreviated name. Use this field for reporting when the space available cannot accommodate the billing name. Also use this field as a sort for indexes.</param>
        /// <param name="mortgagorSsnOrTaxID">(57-66) This field is required. It indicates the mortgagor's abbreviated name. Use this field for reporting when the space available cannot accommodate the billing name. Also use this field as a sort for indexes.</param>
        /// <param name="ssnTinCode">(67) This field is conditional. This field is required if you enter the MORTGAGOR SSN OR TAX ID (1: 57-66) field. It indicates whether the number entered in the MORTGAGOR SSN OR TAX ID field is an SSN or TIN.</param>
        /// <param name="assumptionDate">(68-73) This field is optional. It indicates the date a loan assumption was effective.</param>
        /// <param name="assumptionCode">(76) This field is optional. It indicates whether the loan is assumable.</param>
        /// <returns>Transaction 510 Card 1</returns>
        public static string Tran510c1(string loanNumber, string mortgagorFormattedName,
                                       string mortgagorAbbreviatedNameInitials, string mortgagorAbbreviatedNameShortName,
                                       string mortgagorSsnOrTaxID, string ssnTinCode, string assumptionDate,
                                       string assumptionCode)
        {
            string transaction;

            try
            {
                var transactionName = "510-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "mortgagorFormattedName", mortgagorFormattedName);
                CheckRequiredField(transactionName, "mortgagorAbbreviatedNameShortName",
                                   mortgagorAbbreviatedNameShortName);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('1'); // 14: CARD CODE
                tranBuilder.Append(mortgagorFormattedName.Trim().PadRight(30)); // 15-44: MORTGAGOR FORMATTED NAME
                tranBuilder.Append(mortgagorAbbreviatedNameInitials.Trim().PadRight(2));
                // 45-46: MORTGAGOR ABBREVIATED NAME (INITIALS)
                tranBuilder.Append(mortgagorAbbreviatedNameShortName.Trim().PadRight(8));
                // 47-54: MORTGAGOR ABBREVIATED NAME (SHORT NAME)
                tranBuilder.Append(' ', 2); // 55-56: RESERVED
                tranBuilder.Append(FormatSsnTin(mortgagorSsnOrTaxID.Trim(), ssnTinCode.Trim()));
                // 57-66: MORTGAGOR SSN OR TAX ID
                tranBuilder.Append(ssnTinCode.Trim().PadRight(1)); // 67: SSN/TIN CODE
                tranBuilder.Append(FormatDate(assumptionDate.Trim())); // 68-73: ASSUMPTION DATE
                tranBuilder.Append(' ', 2); // 74-75: RESERVED
                tranBuilder.Append(assumptionCode.Trim().PadRight(1));
                tranBuilder.Append(' ', 4); // 77-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 510 - Expanded Name and Address (D-021)
        /// Use transaction 510 to enter the expanded six-line name and address fields at loan setup. You can use this transaction to set up other master file data, such as abbreviated names, social security numbers, telephone numbers, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="coMortgagorFormattedName">(15-44) This field is optional. It is the full name of the co-mortgagor in last, first, middle name format.</param>
        /// <param name="coMortgagorAbbreviatedNameInitials">(45-46) This field is optional. It indicates the co-mortgagor's first and middle initials. Use this field for reporting when the space available cannot accommodate the billing name. Also use this field as a sort for indexes.</param>
        /// <param name="coMortgagorAbbreviatedNameShortName">(47-54) This field is optional. It indicates the co-mortgagor's abbreviated name. Use this field for reporting when the space available cannot accommodate the billing name. Also use this field as a sort for indexes.</param>
        /// <param name="coMortgagorSsnOrTaxID">(57-66) This field is optional. It indicates the co-mortgagor's social security number (SSN) or federal tax ID number (TIN) assigned by the IRS.</param>
        /// <param name="ssnTinCode">(67) This field is conditional. This field is required if you enter the MORTGAGOR SSN OR TAX ID (1: 57-66) field. It indicates whether the number entered in the MORTGAGOR SSN OR TAX ID field is an SSN or TIN.</param>
        /// <param name="transferDeedDate">(68-73) This field is optional. It indicates the date of the deed that transferred ownership of the property from a previous assumption.</param>
        /// <returns>Transaction 510 Card 2</returns>
        public static string Tran510c2(string loanNumber, string coMortgagorFormattedName,
                                       string coMortgagorAbbreviatedNameInitials,
                                       string coMortgagorAbbreviatedNameShortName, string coMortgagorSsnOrTaxID,
                                       string ssnTinCode, string transferDeedDate)
        {
            string transaction;

            try
            {
                var transactionName = "510-2";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('2'); // 14: CARD CODE
                tranBuilder.Append(coMortgagorFormattedName.Trim().PadRight(30)); // 15-44: COMORTGAGOR FORMATTED NAME
                tranBuilder.Append(coMortgagorAbbreviatedNameInitials.Trim().PadRight(2));
                // 45-46: COMORTGAGOR ABBREVIATED NAME (INITIALS)
                tranBuilder.Append(coMortgagorAbbreviatedNameShortName.Trim().PadRight(8));
                // 47-54: COMORTGAGOR ABBREVIATED NAME (SHORT NAME)
                tranBuilder.Append(' ', 2); // 55-56: RESERVED
                tranBuilder.Append(FormatSsnTin(coMortgagorSsnOrTaxID.Trim(), ssnTinCode));
                // 57-66: COMORTGAGOR SSN OR TAX ID
                tranBuilder.Append(ssnTinCode.Trim().PadRight(1)); // 67: SSN/TIN CODE
                tranBuilder.Append(FormatDate(transferDeedDate.Trim())); // 68-73: TRANSFER DEED DATE
                tranBuilder.Append(' ', 7); // 74-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 510 - Expanded Name and Address (D-021)
        /// Use transaction 510 to enter the expanded six-line name and address fields at loan setup. You can use this transaction to set up other master file data, such as abbreviated names, social security numbers, telephone numbers, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mailingAddress3">(15-44) This field is optional. It indicates an auxiliary street address, an additional mortgagor name, or any additional information that aids in mail delivery. An additional mortgagor name entered is retained as name and address information only.</param>
        /// <param name="telephoneNumber">(45-54) This field is optional. It indicates the mortgagor's primary telephone number.</param>
        /// <param name="lifeCode">(55) This field is optional. It indicates whether the mortgagor can be solicited for life insurance coverage.</param>
        /// <param name="aAndHCode">(56) This field is optional. It indicates whether the mortgagor can be solicited for accident and health (A&amp;H) insurance coverage.</param>
        /// <param name="billMode">(57) This field is optional. It indicates the method used to bill the mortgagor for payments.</param>
        /// <param name="interestOnEscrowIndicator">(58) This field is optional. If you enter information in this field, you must also enter information in the MORTGAGOR SSN OR TAX ID field on this transaction and transaction 010, New Loan Data - Name and Address (D-021). It indicates the type of escrow balance that accrues interest.</param>
        /// <param name="flood_EarthquakeInsuranceCode">(59) This field is optional. It indicates whether flood and/or earthquake insurance is required for the loan.</param>
        /// <param name="employeeCode">(60) This field is optional. It indicates whether the mortgagor is employed by the servicer.</param>
        /// <returns>Transaction 510 Card 3</returns>
        public static string Tran510c3(string loanNumber, string mailingAddress3, string telephoneNumber,
                                       string lifeCode, string aAndHCode, string billMode,
                                       string interestOnEscrowIndicator, string flood_EarthquakeInsuranceCode,
                                       string employeeCode)
        {
            string transaction;

            try
            {
                var transactionName = "510-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('3'); // 14: CARD CODE
                tranBuilder.Append(mailingAddress3.Trim().PadRight(30)); // 15-44: MAILING ADDRESS 3
                tranBuilder.Append(LeftZeroFillOptionalField(telephoneNumber.Trim(), 10)); // 45-54: TELEPHONE NUMBER
                tranBuilder.Append(lifeCode.Trim().PadRight(1)); // 55: LIFE CODE
                tranBuilder.Append(aAndHCode.Trim().PadRight(1)); // 56: A&H CODE
                tranBuilder.Append(billMode.Trim().PadRight(1)); // 57: BILL MODE
                tranBuilder.Append(interestOnEscrowIndicator.Trim().PadRight(1)); // 58: INTEREST ON ESCROW INDICATOR
                tranBuilder.Append(flood_EarthquakeInsuranceCode.Trim().PadRight(1));
                // 59: FLOOD/EARTHQUAKE INSURANCE CODE
                tranBuilder.Append(employeeCode.Trim().PadRight(1)); // 60: EMPLOYEE CODE
                tranBuilder.Append(' ', 20); // 61-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 510 - Expanded Name and Address (D-021)
        /// Use transaction 510 to enter the expanded six-line name and address fields at loan setup. You can use this transaction to set up other master file data, such as abbreviated names, social security numbers, telephone numbers, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mailingAddress4">(15-44) This field is optional. It indicates an auxiliary street address, an additional mortgagor name, or any additional information that aids in mail delivery. An additional mortgagor name entered is retained as name and address information only.</param>
        /// <returns>Transaction 510 Card 4</returns>
        public static string Tran510c4(string loanNumber, string mailingAddress4)
        {
            string transaction;

            try
            {
                var transactionName = "510-4";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('4'); // 14: CARD CODE
                tranBuilder.Append(mailingAddress4.Trim().PadRight(30)); // 15-44: MAILING ADDRESS 3
                tranBuilder.Append(' ', 36); // 61-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 510 - Expanded Name and Address (D-021)
        /// Use transaction 510 to enter the expanded six-line name and address fields at loan setup. You can use this transaction to set up other master file data, such as abbreviated names, social security numbers, telephone numbers, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mailingAddress5">(15-44) This field is required. It indicates the primary postal delivery address.</param>
        /// <param name="secondTelephoneNumber">(45-54) This field is optional. It indicates a second telephone number for the mortgagor or co-mortgagor.</param>
        /// <param name="locationCode">(55) This field is optional. It indicates the location (business, relative, etc.) of the second telephone number.</param>
        /// <returns>Transaction 510 Card 5</returns>
        public static string Tran510c5(string loanNumber, string mailingAddress5, string secondTelephoneNumber,
                                       string locationCode)
        {
            string transaction;

            try
            {
                var transactionName = "510-5";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('5'); // 14: CARD CODE
                tranBuilder.Append(mailingAddress5.Trim().PadRight(30)); // 15-44: MAILING ADDRESS 3
                tranBuilder.Append(LeftZeroFillOptionalField(secondTelephoneNumber.Trim(), 10));
                // 45-54: SECOND TELEPHONE NUMBER
                tranBuilder.Append(locationCode.Trim().PadRight(1)); // 55: LOCATION CODE (for second telephone number)
                tranBuilder.Append(' ', 25); // 56-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 510 - Expanded Name and Address (D-021)
        /// Use transaction 510 to enter the expanded six-line name and address fields at loan setup. You can use this transaction to set up other master file data, such as abbreviated names, social security numbers, telephone numbers, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="cityName">(15-35) This field is required. It indicates the name of the city for postal delivery purposes.</param>
        /// <param name="state">(36-37) This field is conditional. It indicates the U.S. Postal Service abbreviation for the postal delivery state or U.S. possession. If you type 1 in the FOREIGN ADDRESS INDICATOR field, the system does not validate this field.</param>
        /// <param name="zipCode">(38-42) This field is optional. It indicates the postal delivery zip code.</param>
        /// <param name="zipSuffix">(43-46) This field is optional. It indicates the zip code suffix.</param>
        /// <param name="carrierRoute">(47-50) This field is optional. It indicates the postal carrier route code.</param>
        /// <param name="foreignAddressIndicator">(51) This field is conditional. It indicates whether the address is in a foreign country and is to be reported to the IRS as a foreign address. The system does not validate the STATE field for a foreign address.</param>
        /// <returns>Transaction 510 Card 6</returns>
        public static string Tran510c6(string loanNumber, string cityName, string state, string zipCode,
                                       string zipSuffix, string carrierRoute, string foreignAddressIndicator)
        {
            string transaction;

            try
            {
                var transactionName = "510-6";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "cityName", cityName);

                if (!IsAvailable(foreignAddressIndicator) && !IsAvailable(state))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: State (36-37) cannot be empty if foreign address indicator (51) is not equal to 1.",
                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('6'); // 14: CARD CODE
                tranBuilder.Append(cityName.Trim().PadRight(21)); // 15-35: CITY NAME
                tranBuilder.Append(state.Trim().PadRight(2)); // 36-37: STATE
                tranBuilder.Append(FormatZipCode(zipCode.Trim())); // 38-42: ZIP CODE
                tranBuilder.Append(LeftZeroFillOptionalField(zipSuffix.Trim(), 4)); // 43-46: ZIP SUFFIX
                tranBuilder.Append(carrierRoute.Trim().PadRight(4)); // 47-50: CARRIER ROUTE
                tranBuilder.Append(foreignAddressIndicator.Trim().PadRight(1)); // 51: FOREIGN ADDRESS INDICATOR
                tranBuilder.Append(' ', 29); // 52-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}