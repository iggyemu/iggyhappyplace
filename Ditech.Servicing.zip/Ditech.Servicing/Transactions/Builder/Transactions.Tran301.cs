#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transactions 301-307 - Special Escrow Disbursements (D-010)
        /// You can use transactions 301-307 to process special escrow disbursements for unscheduled escrow related items. Since these disbursements are usually one time bills, fees, and refunds, it may not be necessary to create a permanent escrow header for these types of disbursements.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="grossDisbursement">(14-22) This field is required. It determines the amount of the disbursement. If you indicate a disbursement discount in the DISBURSEMENT DISCOUNT field on tax disbursement transactions 311 through 329, then the system subtracts it from 100 percent and the result is multiplied by the gross disbursement to calculate the net disbursement of the actual amount disbursed. If you do not enter a disbursement discount, the gross disbursement equals the net disbursement. The net disbursement is the disbursement amount in the escrow analysis fields of the master record.</param>
        /// <param name="description">(23-35) This field is optional. On machine disbursements, this field describes the specific disbursement for documentary purposes only. It is not carried in the system beyond this point.</param>
        /// <param name="checkNumber">(36-40) This field is optional. It determines whether the system should print a disbursement check.</param>
        /// <param name="checkDate">(41-44) This field is conditional. It is required for hand-written checks (manual disbursements). For machine disbursements, the system uses the run date for the checks printed. It specifies the month and day that the check was written.</param>
        /// <param name="bank">(45-47) This field is optional. It indicates the investor code. You can use this field to help ensure disbursement for the correct account and to compare the investor code with the master record. If you enter the investor code, it must match the bank (investor code) in the master record. Normally, this field is used only on manual disbursements.</param>
        /// <param name="dueDate">(48-51) This field is conditional. It is required for transaction 310 through 355. For transactions 310 through 329, this field must match the disbursement due date for this escrow analysis item. For transactions 351-355, it must match the hazard insurance premium due date.</param>
        /// <param name="escrowPayeeSequenceNumber">(52-53) This field is conditional. It is required for transactions 310 through 329. Use this field with the TRANSACTION and ESCROW PAYEE CODE fields to determine which escrow analysis field the system should update. It must match the escrow payee sequence number of the corresponding escrow analysis item in the master record (see transaction 165 [D-011]). For transactions 301-307, refer to the documentation for miscellaneous disbursement transactions for more information.</param>
        /// <param name="escrowPayeeCode">(54-63) This field is conditional. It verifies that payment was made to the proper payee as indicated in the master record. All machine disbursements must have an escrow payee header on file for the payee on the disbursement transaction in order to generate a valid check. (See transactions CH1 [D-015] through CH4 [D-015] for information about the escrow headers.) All manual disbursements should have an escrow payee header on file for IRS withholding purposes.</param>
        /// <param name="disbursementDiscount">(64-66) This field is optional. Use this field for taxes (transactions 311 through 329) on which discounts are given for early payment. The system multiplies the full tax amount in the GROSS DISBURSEMENT field by the discount percent and then subtracts it from the GROSS DISBURSEMENT field to calculate the net disbursement.</param>
        /// <param name="termOfDisbursement">(67-68) This field is conditional. It is required for transactions 310 through 329, and it replaces the disbursement term for this escrow analysis item. It replaces the term of the disbursement in the master record. For transactions 351 through 355, it replaces the term of the premium for this hazard insurance policy.</param>
        /// <param name="overRide">(69) This field is optional. Use this field to bypass testing for certain conditions that would normally cause the system to reject the disbursement transaction.</param>
        /// <param name="hazardCode">(70) This field is optional. Use this field on hazard disbursement transactions 351 through 355 to determine how this disbursement updates the hazard information for this policy in the master record.</param>
        /// <param name="personalRealEstateTaxCode">(71) This field is optional. Use this field when you pay both real estate and personal property taxes to a taxing authority, but you do not receive both bills at the same time.</param>
        /// <param name="installFlag">(73) This field is optional. Use this field only on hazard transactions 351 through 355 for multiyear installment policies. It indicates whether to update the down payment or multi-installment data.</param>
        /// <param name="separateCheck">(75) This field is optional. Use it to request a separate check for a disbursement. The system usually combines the disbursements into one check for the same transaction code within a given batch and payee. You do not need to enter this field when the mortgagor is the payee because a separate check is always produced in that situation.</param>
        /// <param name="suspenseDescription">(76) This field determines whether to print the description FUNDS DISBURSED FROM SUSPENSE ACCOUNT on the checks written by S203 for suspense disbursements.</param>
        /// <param name="pmiCancelSwitch">(78) This field is conditional. This field is required if you add, maintain or clear the CANCELLATION DATE field through batch process. It indicates whether the system updated the CANCELLATION DATE field or if it needs to calculate and update the field. The system generates the value in this field or you may delete it. The value in this field updates the CANCELLATION-DATE field in the master file.</param>
        /// <param name="fiveTwentyThree">(79) This field is conditional. It is required if a specific disbursement check or check voucher information should be directed to external output files #0523 and #1385 or external output files #2188, #2189, #2190, and #2191.</param>
        /// <returns>Transaction 301</returns>
        public static string Tran301(string loanNumber, string grossDisbursement, string description, string checkNumber,
                                     string checkDate, string bank, string dueDate, string escrowPayeeSequenceNumber,
                                     string escrowPayeeCode, string disbursementDiscount, string termOfDisbursement,
                                     string overRide, string hazardCode, string personalRealEstateTaxCode,
                                     string installFlag, string separateCheck, string suspenseDescription,
                                     string pmiCancelSwitch, string fiveTwentyThree)
        {

            return Tran301_355("301", loanNumber, grossDisbursement, description, checkNumber,
                               checkDate, bank, dueDate, escrowPayeeSequenceNumber,
                               escrowPayeeCode, disbursementDiscount, termOfDisbursement,
                               overRide, hazardCode, personalRealEstateTaxCode,
                               installFlag, separateCheck, suspenseDescription,
                               pmiCancelSwitch, fiveTwentyThree);
        }
    }
}