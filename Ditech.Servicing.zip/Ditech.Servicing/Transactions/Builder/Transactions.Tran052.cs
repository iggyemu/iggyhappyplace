#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 052 - Payment Factors (D-021).
        /// Transaction 052 (D-021) is required to add a loan to the master file. Transaction 052, along with transaction 050 (D-021), enters the regular payment elements. You may make corrections to this data with transaction 053 (D-005). To set up a second mortgage as a piggyback, use transaction 053 (D-037).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="firstPI"> (19-27) This field is required. It indicates a portion of the regular payment applied to the principal and interest, or principal, depending on the distribution type. If you enter this field, the system updates the FIRST-P-I field in the master file..</param>
        /// <param name="pmtPeriod">(28-29) This field is required. It indicates the number of payments to be made per year. If you enter this field, the system updates the PMT-PERIOD field in the master file.</param>
        /// <param name="firstDistType">(30) This field is required. It indicates the application of principal and interest. If you enter this field, the system updates the DIST-TYPE field in the master file.</param>
        /// <param name="firstAnnualInt">(31-37) This field is required. It indicates the annual rate of interest that is charged on the outstanding mortgage balance. If you enter this field, the system updates the ANNUAL-INT field in the master file.</param>
        /// <param name="hudPart">(53-57) This field is optional. It indicates the portion of the total monthly payment that is paid by HUD on section 235 loans. Use transaction 121 (D-040) to add HUD billing information (P-176 history file). This may be done the same day the new loan is added. If you enter this field, the system updates the HUD-PART field in the master file.</param>
        /// <param name="hudFee">(58-60) This field is optional. It indicates the monthly fee paid by HUD for servicing section 235 loans. If you enter this field, the system updates the 235-FEE field in the master file.</param>
        /// <param name="replacementReserveType">(61) This field is optional. It indicates the type of replacement reserve deposit, if any. If you enter this field, the system updates the REP-RES-TP field in the master file.</param>
        /// <param name="replacementReserve">(62-68) This field is optional. It indicates the portion of the regular total payment that is collectible with each payment (replacement reserve type 1), or the amount of the required replacement reserve balance (replacement reserve type 2). If you enter this field, the system updates the REP-RES field in the master file.</param>
        /// <param name="transactionTotal">(69-77) This field is required. It is a crossfoot field used by edit program E-005 to help prevent erroneous data from being entered into the monetary fields of this transaction.</param>
        /// <param name="piValidityCheckOverride">(78) This field enables override of system P&amp;I validity logic when the difference between the calculated and the entered P&amp;I is outside of tolerance.</param>
        /// <returns>Transaction 052</returns>
        public static string Tran052(string loanNumber, string firstPI, string pmtPeriod, string firstDistType,
                                     string firstAnnualInt, string hudPart, string hudFee, string replacementReserveType,
                                     string replacementReserve, string transactionTotal, string piValidityCheckOverride)
        {
            string transaction;

            try
            {
                var transactionName = "052";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField("052", "firstPI", firstPI);
                CheckRequiredField("052", "firstDistType", firstDistType);
                CheckRequiredField("052", "firstAnnualInt", firstAnnualInt);
                CheckRequiredField("052", "transactionTotal", transactionTotal);


                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(' ', 5); // 14-18: RESERVED
                tranBuilder.Append(FormatMoney(firstPI.Trim(), true, true, 9)); // 19-27: FIRST P&I
                tranBuilder.Append(pmtPeriod.Trim().PadRight(2)); // 28-29: PMT-PERIOD
                tranBuilder.Append(firstDistType.Trim().PadRight(1)); // 30: FIRST DIST TYPE
                tranBuilder.Append(FormatPercent(firstAnnualInt.Trim(), 7)); // 31-37: FIRST ANNUAL INT
                tranBuilder.Append(' ', 15); // 38-52: RESERVED
                tranBuilder.Append(FormatMoney(hudPart.Trim(), true, false, 5)); // 53-57: HUD PART
                tranBuilder.Append(FormatMoney(hudFee.Trim(), true, false, 3)); // 58-60: HUD FEE
                tranBuilder.Append(replacementReserveType.Trim().PadRight(1)); // 61: REPLACEMENT RESERVE TYPE
                tranBuilder.Append(FormatMoney(replacementReserve.Trim(), true, false, 7));
                // 62-68: REPLACEMENT RESERVE
                tranBuilder.Append(FormatMoney(transactionTotal.Trim(), true, true, 9)); // 69-77: TRANSACTION TOTAL
                tranBuilder.Append(piValidityCheckOverride.Trim().PadRight(1)); // 78: P&I VALIDITY CHECK OVERRIDE
                tranBuilder.Append(' ', 2); // 79-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}