#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 01D - Collection Notes Upload Long Format (D-314).
        /// Transaction 01D (D-314) updates the Collection Comment file. This transaction enters free-form response comments. See transaction 01C (D-314) for information on short-format responses.
        /// </summary>
        /// <param name="loanNumber">(7-19) This field is required. It identifies the loan number.</param>
        /// <param name="contactDate">(20-25) This field is required. It identifies the date the last contact was made in the format MMDDYY.</param>
        /// <param name="employeeID">(26-28) This field is required. It contains the ID of the employee who made the contact.</param>
        /// <param name="longDescription">(30-73) This field is required. It contains the free-form response comments.</param>
        /// <param name="sequenceCode">(78-80) This field is required. It indicates whether or not the free-form comments are greater than 44 characters and indicates whether comments continue on card 2. To link the multiple card code 1s together and to specify the order in which the long comments are to appear on the comments file, the autodialer must enter the sequence number (001, 002, 003) in the last three positions of the 01D transaction. Card codes 1 and 2 can also be linked if the autodialer enters the same sequence number in these positions.</param>
        /// <returns>Transaction 01D Record</returns>
        public static string Tran01Dc1(string loanNumber, string contactDate, string employeeID, string longDescription,
                                       string sequenceCode)
        {
            string transaction;

            try
            {
                var transactionName = "01D";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "contactDate", contactDate);
                CheckRequiredField(transactionName, "employeeID", employeeID);
                CheckRequiredField(transactionName, "longDescription", longDescription);
                CheckRequiredField(transactionName, "sequenceCode", sequenceCode);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(loanNumber.PadRight(13)); // 7-19: LOAN NUMBER
                tranBuilder.Append(FormatDate(contactDate.Trim())); // 20-25: CONTACT DATE
                tranBuilder.Append(employeeID.Trim().PadRight(3)); // 26-28: EMPLOYEE ID
                tranBuilder.Append("1"); // 29: CARD CODE
                tranBuilder.Append(longDescription.Trim().PadRight(44)); // 30-73: LONG DESCRIPTION
                tranBuilder.Append(' ', 4); // 74-77: RESERVED
                tranBuilder.Append(sequenceCode.Trim().PadRight(3)); // 78-80: SEQUENCE CODE

                transaction = tranBuilder.ToString();

                if (transaction.Length != 80)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 01D - Collection Notes Upload Long Format (D-314).
        /// Transaction 01D (D-314) updates the Collection Comment file. This transaction enters free-form response comments. See transaction 01C (D-314) for information on short-format responses.
        /// </summary>
        /// <param name="loanNumber">(7-19) This field is required. It identifies the loan number.</param>
        /// <param name="contactDate">(20-25) This field is required. It identifies the date the last contact was made in the format MMDDYY.</param>
        /// <param name="employeeID">(26-28) This field is required. It contains the ID of the employee who made the contact.</param>
        /// <param name="remindAmount">(30-36) This field is optional. It contains either the amount of the next promise due on an active repay plan or the amount of the next payment due.</param>
        /// <param name="remindDate">(37-42) This field is optional. It contains either the date of the next promise due on an active repay plan or the due date of the next payment in the format MMDDYY.</param>
        /// <param name="contactTime">(43-46) This field is optional. It identifies the time of the contact in the format HHMM.</param>
        /// <param name="sequenceCode">(78-80) This field is required. It indicates whether or not the free-form comments are greater than 44 characters and indicates whether comments continue on card 2. To link the multiple card code 1s together and to specify the order in which the long comments are to appear on the comments file, the autodialer must enter the sequence number (001, 002, 003) in the last three positions of the 01D transaction. Card codes 1 and 2 can also be linked if the autodialer enters the same sequence number in these positions.</param>        
        /// <returns>Transaction 01D Record</returns>
        public static string Tran01Dc2(string loanNumber, string contactDate, string employeeID, string remindAmount,
                                       string remindDate, string contactTime, string sequenceCode)
        {
            string transaction;

            try
            {
                var transactionName = "01D";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "contactDate", contactDate);
                CheckRequiredField(transactionName, "employeeID", employeeID);
                CheckRequiredField(transactionName, "sequenceCode", sequenceCode);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(loanNumber.PadRight(13)); // 7-19: LOAN NUMBER
                tranBuilder.Append(FormatDate(contactDate.Trim())); // 20-25: CONTACT DATE
                tranBuilder.Append(employeeID.Trim().PadRight(3)); // 26-28: EMPLOYEE ID
                tranBuilder.Append("2"); // 29: CARD CODE
                tranBuilder.Append(FormatMoney(remindAmount.Trim(), true, false, 7)); // 30-36: REMIND AMOUNT
                tranBuilder.Append(FormatDate(remindDate.Trim())); // 37-42: REMIND DATE
                tranBuilder.Append(LeftZeroFillOptionalField(contactTime.Trim(), 4)); // 43-46: CONTACT TIME
                tranBuilder.Append(' ', 31); // 47-77: RESERVED
                tranBuilder.Append(sequenceCode.Trim().PadRight(3)); // 78-80: SEQUENCE CODE

                transaction = tranBuilder.ToString();

                if (transaction.Length != 80)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 01D - Collection Notes Upload Long Format (D-314).
        /// Transaction 01D (D-314) updates the Collection Comment file. This transaction enters free-form response comments. See transaction 01C (D-314) for information on short-format responses.
        /// </summary>
        /// <param name="loanNumber">(7-19) This field is required. It identifies the loan number.</param>
        /// <param name="contactDate">(20-25) This field is required. It indicates the date contact was made with the mortgagor. Entry: Type the date in the MMDDYY format.</param>
        /// <param name="contactTime">(26-31) This field is required. It indicates the time contact was made with the mortgagor. Entry: Type the time in the HHMMSS format.</param>
        /// <param name="userId">(32-34) This field is required. It contains the ID of the employee who made the contact.</param>
        /// <param name="sequenceCode">(35-37) This field is required. This field indicates the order in which comments are stored when two or three 01D transactions are submitted. Entry: Type one of the following codes.</param>
        /// <param name="contactCode">(38-40) This field is optional. It indicates the contact code for this comment. Contact codes are user-defined on the Contact/Response/Reason screen (DLQK) in the Collection Workstation.</param>
        /// <param name="responseCode">(41-43) This field is optional. It indicates the response code for this comment. Response codes are user-defined on the DLQK screen.</param>
        /// <param name="reasonCode">(44-46) This field is optional. It indicates the reason code for this comment. Reason codes are user-defined on the DLQK screen.</param>
        /// <param name="forbearanceAmount">(51-57) This field is optional. It indicates the forbearance amount that the mortgagor promised to send.</param>
        /// <param name="remindDate">(58-63) This field is optional. It indicates the future date the mortgagor promised to send funds or the date on which this loan should reappear in the queue.</param>
        /// <param name="longDescription">(76-126) This field is conditional. It is required if the SEQUENCE CODE field (1: 35-37) equals 002 or 003. This field indicates the free-form comment about this loan.</param>
        /// <param name="productiveContact">(127) This field is optional. It indicates whether this is a productive comment. A right party contact is a productive communication with the mortgagor resulting in an attempt to resolve the delinquency. Use this code to track delinquent Freddie Mac loans.</param>
        /// <param name="priority">(128) This field is optional. It indicates whether the comment in the LONG DESCRIPTION field (1: 76-126) is a priority comment.</param>
        /// <param name="reportExclude">(129) This field is optional. It indicates whether to exclude this comment from reports that contain comments from the comment file.</param>
        /// <returns>Transaction 01D Record</returns>
        public static string Tran01D(string loanNumber, string contactDate = "", string contactTime = "", string userId = "", string sequenceCode = "", string contactCode = "", string responseCode = "", string reasonCode = "", string forbearanceAmount = "", string remindDate = "", string longDescription = "", string productiveContact = "", string priority = "", string reportExclude = "")
        {
            string transaction;

            try
            {
                var transactionName = "01D";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "contactDate", contactDate);
                CheckRequiredField(transactionName, "contactTime", contactTime);
                CheckRequiredField(transactionName, "sequenceCode", sequenceCode);

                if (sequenceCode == "001")
                {
                    if (!IsAvailable(userId))
                    {
                        throw new Exception(
                            string.Format(
                                "{0}: {1}: User ID required when sequence code is 001.",
                                transactionName, loanNumber));
                    }
                }
                else
                {
                    if (!IsAvailable(longDescription))
                    {
                        throw new Exception(
                            string.Format(
                                "{0}: {1}: Long description is required when sequence code is not 001.",
                                transactionName, loanNumber));
                    }

                    if (IsAvailable(contactCode) || IsAvailable(responseCode) || IsAvailable(reasonCode) ||
                        IsAvailable(forbearanceAmount) || IsAvailable(remindDate) || IsAvailable(productiveContact) ||
                        IsAvailable(priority) || IsAvailable(reportExclude))
                    {
                        throw new Exception(
                            string.Format(
                                "{0}: {1}: 1022 - USR ID, CT CD, RP CD, RN CD, FORB AMT, REMIND, PRD CON, PRI CD, RPT EXC FIELDS NOT PERMITTED ON SEQ CARD 002/003",
                                transactionName, loanNumber));
                    }
                }

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(loanNumber.PadRight(13)); // 7-19: LOAN NUMBER
                tranBuilder.Append(FormatDate(contactDate.Trim())); // 20-25: CONTACT DATE
                tranBuilder.Append(LeftZeroFillOptionalField(contactTime.Trim(), 6)); // 26-31: CONTACT TIME
                tranBuilder.Append(userId.Trim().PadRight(3)); // 32-34: USER ID
                tranBuilder.Append(sequenceCode.Trim().PadRight(3)); // 35-37: SEQUENCE CODE
                tranBuilder.Append(contactCode.Trim().PadRight(3)); // 38-40: CONTACT CODE
                tranBuilder.Append(responseCode.Trim().PadRight(3)); // 41-43: RESPONSE CODE
                tranBuilder.Append(reasonCode.Trim().PadRight(3)); // 44-46: REASON CODE
                tranBuilder.Append(' ', 4); // 47-50: RESERVED
                tranBuilder.Append(FormatMoney(forbearanceAmount.Trim(), true, false, 7)); // 51-57: FOREBEARANCE AMOUNT
                tranBuilder.Append(FormatDate(remindDate.Trim())); // 58-63: REMIND DATE
                tranBuilder.Append(' ', 12); // 64-75: RESERVED
                tranBuilder.Append(longDescription.Trim().PadRight(51)); // 76-126: LONG DESCRIPTION
                tranBuilder.Append(productiveContact.Trim().PadRight(1)); // 127: PRODUCTIVE CONTACT
                tranBuilder.Append(priority.Trim().PadRight(1)); // 128: PRIORITY
                tranBuilder.Append(reportExclude.Trim().PadRight(1)); // 129: REPORT EXCLUDE
                tranBuilder.Append(' ', 11); // 130-140: RESERVED
                

                transaction = tranBuilder.ToString();

                if (transaction.Length != 140)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}