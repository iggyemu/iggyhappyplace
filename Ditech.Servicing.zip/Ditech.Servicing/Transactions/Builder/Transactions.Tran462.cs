#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 462 - User Data Area: Maintenance (D-077).
        /// Use transaction 462 to modify information in the user data area of the master.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="dateFld3">(14-19) This field is to be used for a date.</param>
        /// <param name="dateFld4">(20-25) This field is to be used for a date.</param>
        /// <param name="pos6Fld2">(26-31) This field is to be used for 6 characters or less of alphanumeric data. </param>
        /// <param name="pos1Fld4">(32) This field is to be used for one character of alphanumeric data.</param>
        /// <param name="pos1Fld5">(33) This field is to be used for one character of alphanumeric data.</param>
        /// <param name="pos1Fld6">(34) This field is to be used for one character of alphanumeric data.</param>
        /// <param name="pos15Fld2">(35-49) This field is to be used for fifteen characters or less of alphanumeric data.</param>
        /// <param name="pos2Fld4">(50-51) This field is to be used for two characters or less of alphanumeric data.</param>
        /// <param name="pos2Fld5">(52-53) This field is to be used for two characters or less of alphanumeric data.</param>
        /// <param name="pos2Fld6">(54-55) This field is to be used for two characters or less of alphanumeric data.</param>
        /// <param name="pos3Fld3">(56-58) This field is to be used for three characters or less of alphanumeric data. </param>
        /// <param name="pos3Fld4">(59-61) This field is to be used for three characters or less of alphanumeric data.</param>
        /// <param name="percentFld2">(62-64) This field is to be used for a percent value.</param>
        /// <param name="pos9Num2">(65-73) This field is used for nine positions of numeric data.</param>
        /// <param name="pos7Num2">(74-80) This field is used for seven positions of numeric data. </param>
        /// <returns>Transaction 462</returns>
        public static string Tran462(string loanNumber, string dateFld3 = "", string dateFld4 = "", string pos6Fld2 = "",
                                     string pos1Fld4 = "", string pos1Fld5 = "", string pos1Fld6 = "", string pos15Fld2 = "",
                                     string pos2Fld4 = "", string pos2Fld5 = "", string pos2Fld6 = "", string pos3Fld3 = "", string pos3Fld4 = "",
                                     string percentFld2 = "", string pos9Num2 = "", string pos7Num2 = "")
        {
            string transaction;

            try
            {
                var transactionName = "462";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append(FormatDate(dateFld3.Trim())); // (14-19) (PAS) Date-Fld-3
                tranBuilder.Append(FormatDate(dateFld4.Trim())); // (20-25) (PAS) Date-Fld-4
                tranBuilder.Append(pos6Fld2.Trim().PadRight(6)); // (26-31) 6-Pos-Fld-2
                tranBuilder.Append(pos1Fld4.Trim().PadRight(1)); // (32) 1-Pos-Fld-4
                tranBuilder.Append(pos1Fld5.Trim().PadRight(1)); // (33) 1-Pos-Fld-5
                tranBuilder.Append(pos1Fld6.Trim().PadRight(1)); // (34) 1-Pos-Fld-6
                tranBuilder.Append(pos15Fld2.Trim().PadRight(15)); // (35-49) (PAS) 15-Pos-Fld-2
                tranBuilder.Append(pos2Fld4.Trim().PadRight(2)); // (50-51) 2-Pos-Fld-4
                tranBuilder.Append(pos2Fld5.Trim().PadRight(2)); // (52-53) 2-Pos-Fld-5
                tranBuilder.Append(pos2Fld6.Trim().PadRight(2)); //  (54-55) 2-Pos-Fld-6
                tranBuilder.Append(pos3Fld3.Trim().PadRight(3)); // (56-58) (PAS) 3-Pos-Fld-3
                tranBuilder.Append(pos3Fld4.Trim().PadRight(3)); // (59-61) (PAS) 3-Pos-Fld-4
                tranBuilder.Append(FormatPercent(percentFld2.Trim(), 3)); // (62-64) Percent-Fld-2
                tranBuilder.Append(LeftZeroFillOptionalField(pos9Num2.Trim(), 9)); // (65-73) (LZF) 9-Pos-Num-2
                tranBuilder.Append(LeftZeroFillOptionalField(pos7Num2.Trim(), 7)); // (74-80) (LZF) 7-Pos-Num-2
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }
    }
}