#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {

        /// <summary>
        /// Backward compatibility
        /// Transaction 0FD - Flood Mapping Data Add (D-021).
        /// Use transaction 0FD to add Flood Mapping Data information to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="processorID">(16-18) This field is required. This field identifies who is adding the flood mapping data fields to the master.</param>
        /// <param name="communityDate">(19-24) This field is optional. This field is the date the community began participation in the Flood Mapping Program.</param>
        /// <param name="flood_Program">(25) This field is required. This field indicates the type of Flood Program.</param>
        /// <param name="loma_r">(26) This field is required. This field indicates whether the changes to the flood data are due to a Letter of Modification Amendment or to a Revision.</param>
        /// <param name="determineDate">(27-32) This field is optional. This field is the determination date of the Loma-R or flood zone.</param>
        /// <param name="contractType">(33) This field is optional. This field indicates the type of contract with the compliance company.</param>
        /// <param name="communityNo">(34-39) This field is optional. This field is the community number in which the property is located on the FIRM (Flood Insurance Rate Map).</param>
        /// <param name="panelNo">(40-43) This field is optional. This field is the panel number on the FIRM.</param>
        /// <param name="suffix_no">(44) This field is optional. This field is the suffix number on the FIRM.</param>
        /// <returns>Transaction 0FD Card 1</returns>
        public static string Tran0FDc1(string loanNumber = "", string processorID = "", string communityDate = "", string flood_Program = "",
                                       string loma_r = "", string determineDate = "", string contractType = "", string communityNo = "",
                                       string panelNo = "", string suffix_no = "")
        {
            return Tran0FDc1(loanNumber, "A", processorID, communityDate, flood_Program,
                             loma_r, determineDate, contractType, communityNo,
                             panelNo, suffix_no);
        }

        /// <summary>
        /// Transaction 0FD - Flood Mapping Data (D-021).
        /// Use transaction 0FD to Add, Change or Delete Flood Mapping Data information to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="actionCode">(15) This field is required. Use this field to add, change, or delete the flood mapping data fields in the master. The value D is only allowed on card code 1. Card code 2 is not needed to delete all flood data master fields. No other fields should be filled on the delete transaction (other than required fields).</param>
        /// <param name="processorID">(16-18) This field is required. This field identifies who is adding the flood mapping data fields to the master.</param>
        /// <param name="communityDate">(19-24) This field is optional. This field is the date the community began participation in the Flood Mapping Program.</param>
        /// <param name="flood_Program">(25) This field is required. This field indicates the type of Flood Program.</param>
        /// <param name="loma_r">(26) This field is required. This field indicates whether the changes to the flood data are due to a Letter of Modification Amendment or to a Revision.</param>
        /// <param name="determineDate">(27-32) This field is optional. This field is the determination date of the Loma-R or flood zone.</param>
        /// <param name="contractType">(33) This field is optional. This field indicates the type of contract with the compliance company.</param>
        /// <param name="communityNo">(34-39) This field is optional. This field is the community number in which the property is located on the FIRM (Flood Insurance Rate Map).</param>
        /// <param name="panelNo">(40-43) This field is optional. This field is the panel number on the FIRM.</param>
        /// <param name="suffix_no">(44) This field is optional. This field is the suffix number on the FIRM.</param>
        /// <returns>Transaction 0FD Card 1</returns>
        public static string Tran0FDc1(string loanNumber = "", string actionCode = "", string processorID = "", string communityDate = "", string flood_Program = "",
                                       string loma_r = "", string determineDate = "", string contractType = "", string communityNo = "",
                                       string panelNo = "", string suffix_no = "")
        {
            string transaction;

            try
            {
                var transactionName = "0FD-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "processorID", processorID);
                CheckRequiredField(transactionName, "actionCode", actionCode);
                if (actionCode.ToUpper() == "A")
                {
                    CheckRequiredField(transactionName, "flood_program", flood_Program);
                    CheckRequiredField(transactionName, "loma_r", loma_r);
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('1'); // 14: CARD CODE
                tranBuilder.Append(actionCode); // 15: ACT CODE
                tranBuilder.Append(processorID.Trim().PadRight(3)); // 16-18: PROCESSOR ID
                tranBuilder.Append(FormatDate(communityDate.Trim())); // 19-24: COMMUNITY DATE
                tranBuilder.Append(flood_Program.Trim().PadRight(1)); // 25: FLOOD-PROGRAM
                tranBuilder.Append(loma_r.Trim().PadRight(1)); // 26 LOMA-R
                tranBuilder.Append(FormatDate(determineDate.Trim())); // 27-32: DETERMINE DATE
                tranBuilder.Append(contractType.Trim().PadRight(1)); // 33: CONTRACT TYPE
                tranBuilder.Append(communityNo.Trim().PadRight(6)); // 34-39: COMMUNITY NO
                tranBuilder.Append(panelNo.Trim().PadRight(4)); // 40-43: PANEL NO
                tranBuilder.Append(suffix_no.Trim().PadRight(1)); // 44: SUFFIX-NO
                tranBuilder.Append(' ', 36); // 45-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Backward compatibility
        /// Transaction 0FD - Flood Mapping Data Add (D-021).
        /// Use transaction 0FD to add Flood Mapping Data information to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="processorID">(16-18) This field is required. This field identifies who is adding the flood mapping data fields in the master.</param>
        /// <param name="zone">(19-21) This field is optional. This field is the zone in which the property is located on the FIRM.</param>
        /// <param name="zoneInd">(22) This field is optional. This field indicates whether the property is in a partial zone.</param>
        /// <param name="firmDate">(23-28) This field is optional. This field is the effective date of the FIRM panel.</param>
        /// <param name="mapperInit">(29-31) This field is optional. This field indicates the mapper's initials.</param>
        /// <param name="cmpco">(32-36) This field is optional. This field identifies the compliance company contracted by the servicer to map the property.</param>
        /// <param name="mapco">(37-41) This field is optional. This field identifies the company contracted by the compliance company to map the property.</param>
        /// <param name="fee">(42-46) This field is optional. This field is the dollar amount of the fee charged for the mapping contract with the compliance company.</param>
        /// <param name="cert_no">(47-60) This field is optional. This field is the number assigned by the compliance company when the property is mapped.</param>
        /// <param name="cbra_date">(61-66) This field is optional. It indicates the effective date of the Coastal Barrier Resources Area (CBRA). MMDDYY</param>
        /// <returns>Transaction 0FD Card 2</returns>
        public static string Tran0FDc2(string loanNumber = "", string processorID = "", string zone = "", string zoneInd = "",
                                       string firmDate = "", string mapperInit = "", string cmpco = "", string mapco = "", string fee = "",
                                       string cert_no = "", string cbra_date = "")
        {
            return Tran0FDc2(loanNumber, "A", processorID, zone, zoneInd,
                                       firmDate, mapperInit, cmpco, mapco, fee,
                                       cert_no, cbra_date);

        }

        /// <summary>
        /// Transaction 0FD - Flood Mapping Data (D-021).
        /// Use transaction 0FD to Add or Change Flood Mapping Data information to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="actionCode">(15) This field is required. Use this field to add or change the flood mapping data fields in the master. Entry: Type one of the following codes: Code	Description A	Add flood mapping data fields to the master for the first time. C	Change existing flood mapping data fields in the master.</param>
        /// <param name="processorID">(16-18) This field is required. This field identifies who is adding the flood mapping data fields in the master.</param>
        /// <param name="zone">(19-21) This field is optional. This field is the zone in which the property is located on the FIRM.</param>
        /// <param name="zoneInd">(22) This field is optional. This field indicates whether the property is in a partial zone.</param>
        /// <param name="firmDate">(23-28) This field is optional. This field is the effective date of the FIRM panel.</param>
        /// <param name="mapperInit">(29-31) This field is optional. This field indicates the mapper's initials.</param>
        /// <param name="cmpco">(32-36) This field is optional. This field identifies the compliance company contracted by the servicer to map the property.</param>
        /// <param name="mapco">(37-41) This field is optional. This field identifies the company contracted by the compliance company to map the property.</param>
        /// <param name="fee">(42-46) This field is optional. This field is the dollar amount of the fee charged for the mapping contract with the compliance company.</param>
        /// <param name="cert_no">(47-60) This field is optional. This field is the number assigned by the compliance company when the property is mapped.</param>
        /// <param name="cbra_date">(61-66) This field is optional. It indicates the effective date of the Coastal Barrier Resources Area (CBRA). MMDDYY</param>
        /// <returns>Transaction 0FD Card 2</returns>
        public static string Tran0FDc2(string loanNumber = "", string actionCode = "", string processorID = "", string zone = "", string zoneInd = "",
                                       string firmDate = "", string mapperInit = "", string cmpco = "", string mapco = "", string fee = "",
                                       string cert_no = "", string cbra_date = "")
        {
            string transaction;

            try
            {
                const string transactionName = "0FD-2";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "processorID", processorID);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('2'); // 14: CARD CODE
                tranBuilder.Append(actionCode); // 15: ACT CODE
                tranBuilder.Append(processorID.Trim().PadRight(3)); // 16-18: PROCESSOR ID
                tranBuilder.Append(zone.Trim().PadRight(3)); // 19-21: ZONE
                tranBuilder.Append(zoneInd.Trim().PadRight(1)); // 22: ZONE IND
                tranBuilder.Append(FormatDate(firmDate.Trim())); // 23-28: FIRM DATE
                tranBuilder.Append(mapperInit.Trim().PadRight(3)); // 29-31: MAPPER INIT
                tranBuilder.Append(cmpco.Trim().PadRight(5)); // 32-36: CMPCO
                tranBuilder.Append(mapco.Trim().PadRight(5)); // 37-41: MAPCO
                tranBuilder.Append(FormatMoney(fee.Trim(), true, false, 5)); // 42-46: FEE
                tranBuilder.Append(cert_no.Trim().PadRight(14)); // 47-60: CERT-NO
                tranBuilder.Append(cbra_date.Trim().PadLeft(6)); // 61-66: CBRA DATE
                tranBuilder.Append(' ', 14); // 67-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}