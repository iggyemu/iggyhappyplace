﻿using System;
using System.Text;

namespace Ditech.Servicing.Transactions
{
   public partial class Transactions
    {
       public static string Tran713(string loanNumber = "", string depositAmount = "", string corporateAdvancePayee = "",
                                    string recoverableNonRecoverable = "", string reasonCode = "", string originalPayee = "",
                                    string processor = "", string bankruptcySuspenseSwitch = "",string corporateAdvanceOriginalDisbursementDate = "", string obligor = "",
                                    string overRide = "")
       {
           string transaction;

           var transactionName = "713";
           CheckValidLoanNumber(transactionName,loanNumber);
           CheckRequiredField(transactionName,"Deposit Amount",depositAmount);
           CheckRequiredField(transactionName,"Corporate Advance Payee", corporateAdvancePayee);
           CheckRequiredField(transactionName,"Recoverable NonRecoverable",recoverableNonRecoverable);
           
               var tranClient = transactionName + CLIENT_NUMBER;
               var tranBuilder = new StringBuilder();

               tranBuilder.Append(tranClient); // 1-6 CLIENT
               tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN NUMBER
               tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(depositAmount),9)); //  14-22 DEPOSIT AMOUNT
               tranBuilder.Append(corporateAdvancePayee.PadRight(5)); // 23-27 CORPORATE ADVANCE PAYEE
               tranBuilder.Append(recoverableNonRecoverable.PadRight(1)); // 28 RECOVERABLE/NONRECOVERABLE
               tranBuilder.Append(reasonCode.PadRight(4)); // 29-32 REASON CODE
               tranBuilder.Append(originalPayee.PadRight(10)); // 33-42 ORIGINAL PAYEE
               tranBuilder.Append(' ', 1); // 43 RESERVED
               tranBuilder.Append(processor.IsNullOrEmpty(true) ? "TSD" : processor); // 44-46 PROCESSOR
               tranBuilder.Append(bankruptcySuspenseSwitch.PadRight(1)); // 47 BANKRUPTCY SUSPENSE SWITCH
               tranBuilder.Append(!corporateAdvanceOriginalDisbursementDate.IsNullOrEmpty(true)
                   ? Convert.ToDateTimeString(corporateAdvanceOriginalDisbursementDate, "MMddyy")
                   : " ".PadRight(6)); // 48-53 CORPORATE ADVANCE ORIGINAL DISBURSEMENT DATE
               tranBuilder.Append(obligor.PadRight(6)); // 54-59 OBLIGOR
               tranBuilder.Append(' ', 20); // 60-79 RESERVED
               tranBuilder.Append(overRide.PadRight(1)); // 80 OVERRIDE
               tranBuilder.Append(' ', 9); // 81-89 RESERVED
               tranBuilder.Append(loanNumber.PadLeft(13, '0')); // 90-102 LOAN NUMBER

               if (tranBuilder.Length != 102)
               {
                   throw new Exception(string.Format("{0}: Line length mismatch: {1}",transactionName,tranBuilder));
               }

               tranBuilder.AppendLine();
               transaction = tranBuilder.ToString();
           
          
           return transaction;
       }
    }
}
