﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 059 - Optional Insurance (D-075).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effectiveDate">(14-17) Conditional. If an effective date exists, then the planDueDate field must be empty. If the date is less than the next mortgage payment, then leave blank.</param>
        /// <param name="couponCode">(18) Optional. The number of coupons to prepare, if any.  Defaults to 1 if empty.</param>
        /// <param name="actionCode">(19) Required. Represents the action to take. Defaults to A if empty.</param>
        /// <param name="planId">(20-21) Required. Type of insurance coverage on the loan. </param>
        /// <param name="premiumAmount">(22-26) Conditional. This field is required if a value exists for effectiveDate.  Indicates the dollar amount of the current insurance premium.</param>
        /// <param name="terminateDate">(27-30) Optional. If a date is entered, then it should be one month greater than the last acceptable premium due date.</param>
        /// <param name="firstCertificateName">(31-42) Optional. The first certificate number assigned by the insurance carrier.</param>
        /// <param name="secondCertificateName">(43-54) Optional. The second certificate number assigned by the insurance carrier.</param>
        /// <param name="planDueDate">(55-58) Conditional. If a date is entered for planDueDate, then effectiveDate must be left empty. If the date is is greater than the next payment date of the loan, then the system will NOT update the pending optional insurance.  Only use this for exceptional conditions.  Under normal circumstances, effectiveDate should suffice.</param>
        /// <param name="planIdCount">(59-60 Conditional. Required if a value was entered in the PLAN ID field. </param>
        /// <param name="singleJointType">(61) Conditional.  Do not enter if you type a value in the BILL SYNC REQUEST field; otherwise, required.</param>
        /// <param name="startDate">(62-67) Conditoinal. Required when adding a product.</param>
        /// <param name="initialPremium">(70-74) Conditional. Required if the INIT PREM field on the OCPH screen equals Y.  This field indicates the initial premium amount for the product.</param>
        /// <returns>Transaction 059</returns>
        public static string Tran059(string loanNumber = "", string effectiveDate = "", string couponCode = "1",
                                     string actionCode = "A", string planId = "", string premiumAmount = "",
                                     string terminateDate = "", string firstCertificateName = "", string secondCertificateName = "",
                                     string planDueDate = "",string planIdCount = "",string singleJointType = "",string startDate = "",
                                     string initialPremium = "")
        {
            string transaction;

            
                const string transactionName = "059";
                const string tranClient = transactionName + CLIENT_NUMBER;

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "planID", planId);

                if (IsAvailable(effectiveDate) && IsAvailable(planDueDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Either effectiveDate or planDueDate must be present, but not both.",
                            transactionName, loanNumber));
                }

                if (IsAvailable(effectiveDate) && !IsAvailable(premiumAmount))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: premiumAmount must be present if effectiveDate is present.",
                            transactionName, loanNumber));
                }
                
                
                

                StringBuilder tranBuilder = new StringBuilder();
                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN
                tranBuilder.Append(effectiveDate.Trim().PadRight(4)); // 14-17 EFFECTIVE DATE
                tranBuilder.Append(couponCode.Trim().PadRight(1)); // 18 COUPON CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 19 ACTION CODE
                tranBuilder.Append(planId.Trim().PadRight(2)); // 20-21 PLAN ID
                tranBuilder.Append(Convert.ToZonedString(premiumAmount.Trim()).PadRight(5)); // 22-26 PREMIUM AMOUNT
                tranBuilder.Append(terminateDate.PadRight(4)); // 27-30 TERMINATE DATE
                tranBuilder.Append(firstCertificateName.Trim().PadRight(12)); // 31-42 FIRST CERTIFICATE NUMBER
                tranBuilder.Append(secondCertificateName.Trim().PadRight(12)); // 43-54 SECOND CERTIFICATE NUMBER
                tranBuilder.Append(planDueDate.PadRight(4)); // 55-58 PLAN DUE DATE
                tranBuilder.Append(planIdCount.Trim().PadRight(2)); // 59-60 PLAN ID CONT
                tranBuilder.Append(singleJointType.PadRight(1)); // 61 SINGLE JOINT TYPE
                tranBuilder.Append(startDate.PadRight(6)); // 62-67 START DATE
                tranBuilder.Append(initialPremium.Trim().PadRight(7)); // 68-74 INIT PREM
                tranBuilder.Append(" ".PadRight(5)); // 75-79 RESERVED
                tranBuilder.Append("1"); // 80 CARD CODE
                tranBuilder.Append(" ".PadRight(9)); // RESERVED 
                tranBuilder.Append(loanNumber.PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

                

                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}",transactionName,tranBuilder));
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();
            
            return transaction;
        }
    }
}
