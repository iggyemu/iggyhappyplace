#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 402 - User Data Area: Maintenance (D-077).
        /// Use transaction 402 to modify information in the user data area of the master.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="dateFld1">(14-19) This field is to be used for a date.</param>
        /// <param name="dateFld2">(20-25) This field is to be used for a date.</param>
        /// <param name="pos6Fld1">(26-31) This field is to be used for six characters or less of alphanumeric data.</param>
        /// <param name="pos1Fld1">(32) This field is to be used for one character of alphanumeric data. </param>
        /// <param name="pos1Fld2">(33) This field is to be used for one character of alphanumeric data. </param>
        /// <param name="pos1Fld3">(34) This field is to be used for one character of alphanumeric data. </param>
        /// <param name="pos15Fld1">(35-49) This field is to be used for 15 characters or less of alphanumeric data. </param>
        /// <param name="pos2Fld1">(50-51) This field is to be used for two characters or less of alpha- numeric data. </param>
        /// <param name="pos2Fld2">(52-53) This field is to be used for two characters or less of alphanumeric data. </param>
        /// <param name="pos2Fld3">(54-55) This field is to be used for two characters or less of alpha- numeric data. </param>
        /// <param name="pos3Fld1">(56-58) This field is to be used for three characters or less of alphanumeric data. </param>
        /// <param name="pos3Fld2">(59-61) This field is to be used for three characters or less of alphanumeric data. </param>
        /// <param name="percentFld1">(62-64) This field is to be used for a percent value. </param>
        /// <param name="pos9Num1">(65-73) This field is used for nine positions of numeric data. </param>
        /// <param name="pos7Num1">(74-80) This field is used for seven positions of numeric data. </param>
        /// <returns>Transaction 402</returns>
        public static string Tran402(string loanNumber, string dateFld1 = "", string dateFld2 = "", string pos6Fld1 = "",
                                     string pos1Fld1 = "", string pos1Fld2 = "", string pos1Fld3 = "", string pos15Fld1 = "",
                                     string pos2Fld1 = "", string pos2Fld2 = "", string pos2Fld3 = "", string pos3Fld1 = "", string pos3Fld2 = "",
                                     string percentFld1 = "", string pos9Num1 = "", string pos7Num1 = "")
        {
            string transaction;

            try
            {
                var transactionName = "402";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*     "); // 7-12: LOAN
                tranBuilder.Append(' '); // 13: CHECK DIGIT
                tranBuilder.Append(FormatDate(dateFld1.Trim())); // (14-19) (PAS) DATE-FLD-1
                tranBuilder.Append(FormatDate(dateFld2.Trim())); // (20-25) (PAS) DATE-FLD-2
                tranBuilder.Append(pos6Fld1.Trim().PadRight(6)); // (26-31) (PAS) 6-POS-FLD-1 
                tranBuilder.Append(pos1Fld1.Trim().PadRight(1)); // (32) 1-POS-FLD-1
                tranBuilder.Append(pos1Fld2.Trim().PadRight(1)); // (33) 1-POS-FLD-2
                tranBuilder.Append(pos1Fld3.Trim().PadRight(1)); // (34) 1-POS-FLD-3
                tranBuilder.Append(pos15Fld1.Trim().PadRight(15)); // (35-49) (PAS) 15-POS-FLD-1
                tranBuilder.Append(pos2Fld1.Trim().PadRight(2)); // (50-51) 2-POS-FLD-1
                tranBuilder.Append(pos2Fld2.Trim().PadRight(2)); // (52-53) 2-POS-FLD-2
                tranBuilder.Append(pos2Fld3.Trim().PadRight(2)); // (54-55) 2-POS-FLD-3
                tranBuilder.Append(pos3Fld1.Trim().PadRight(3)); // (56-58) (PAS) 3-POS-FLD-1
                tranBuilder.Append(pos3Fld2.Trim().PadRight(3)); // (59-61) (PAS) 3-POS-FLD-2
                tranBuilder.Append(FormatPercent(percentFld1.Trim(), 3)); //  (62-64) (PAS) PERCENT-FLD-1
                tranBuilder.Append(LeftZeroFillOptionalField(pos9Num1.Trim(), 9)); // (65-73) (LZF) 9-POS-NUM-1 
                tranBuilder.Append(LeftZeroFillOptionalField(pos7Num1.Trim(), 7)); // (74-80) (LZF) 7-POS-NUM-1
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102 EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}