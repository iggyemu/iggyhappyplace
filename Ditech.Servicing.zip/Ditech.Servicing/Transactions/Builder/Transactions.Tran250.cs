﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 250 - Ledger/Master Record Request (D-007)
        /// Use transaction 250 (D-007) to request, on a loan number basis, a ledger history and/or master record information for a particular loan.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="cardCode">(14) This field is required. It indicates the card code.</param>
        /// <param name="requestedBy"> (15-17) This field is optional. It indicates the requester's initials. The value entered is moved from input on schedule and used to sort requests by requester.</param>
        /// <returns>Transaction 022 Card 3</returns>
        public static string Tran250(string loanNumber, string cardCode, string requestedBy)
        {
            string transaction;

            try
            {
                var transactionName = "250-" + cardCode;

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(cardCode); // 14: CARD CODE
                tranBuilder.Append(requestedBy.Trim().PadLeft(3)); // 15-17: REQUESTED BY
                tranBuilder.Append(' ', 63); // 18-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}