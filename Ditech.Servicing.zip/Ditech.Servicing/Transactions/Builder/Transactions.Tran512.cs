﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        ///  Transaction 512 - Expanded Name and Address - Maintenance (D-001)
        /// Use transaction 512 to enter the expanded six-line name and address fields, if needed, at the same time you enter transaction 012 (D-001). When you enter transaction 012, the system updates the four lines of the billing name and address field and four lines of the new, expanded, six-line name and address field.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mailingAddress3">(15-44) This field is optional. It indicates an auxiliary street address, an additional mortgagor name, or any additional information that aids in mail delivery. An additional mortgagor name entered is retained as name and address information only.</param>
        /// <param name="primaryTelephoneNumber">(45-54) This field is optional. It updates the mortgagor's telephone number at the primary residence in the master file. </param>
        /// <param name="billMode">This field is optional.  It indicates the method used by the borrower to remit payment.</param>
        /// <returns>Transaction 512 Card 3</returns>
        public static string Tran512c3(string loanNumber = "", string mailingAddress3 = "", string primaryTelephoneNumber = "", string billMode = "")
        {
            string transaction;

            
                var transactionName = "512-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('3'); // 14: CARD CODE
                tranBuilder.Append(mailingAddress3.Trim().PadRight(30)); // 15-44: MAILING ADDRESS 3
                tranBuilder.Append(LeftZeroFillOptionalField(primaryTelephoneNumber.Trim(), 10)); // 45-54: TELEPHONE NUMBER
                tranBuilder.Append(' ', 2); // 55-56 Reserved
                tranBuilder.Append(billMode.PadRight(1)); //57 Bill Mode
                tranBuilder.Append(' ', 23); // 58-80 Reserved
                tranBuilder.Append(' ', 9); // 81-89 Empty Space
                tranBuilder.Append(loanNumber.PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER

                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();
            
            

            return transaction;
        }

       


        /// <summary>
        ///  Transaction 512 - Expanded Name and Address - Maintenance (D-001)
        /// Use transaction 512 to enter the expanded six-line name and address fields, if needed, at the same time you enter transaction 012 (D-001). When you enter transaction 012, the system updates the four lines of the billing name and address field and four lines of the new, expanded, six-line name and address field.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mailingAddress4">(15-44) This field is optional. It indicates an auxiliary street address, an additional mortgagor name, or any additional information that aids in mail delivery. An additional mortgagor name entered is retained as name and address information only.</param>
        /// <returns>Transaction 512 Card 4</returns>
        public static string Tran512c4(string loanNumber = "", string mailingAddress4 = "")
        {
            string transaction;

                var transactionName = "512-4";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('4'); // 14: CARD CODE
                tranBuilder.Append(mailingAddress4.Trim().PadRight(30)); // 15-44: MAILING ADDRESS 4
                tranBuilder.Append(' ', 36); // 45-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER


                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();
            
            return transaction;
        }

        /// <summary>
        ///  Transaction 512 - Expanded Name and Address - Maintenance (D-001)
        /// Use transaction 512 to enter the expanded six-line name and address fields, if needed, at the same time you enter transaction 012 (D-001). When you enter transaction 012, the system updates the four lines of the billing name and address field and four lines of the new, expanded, six-line name and address field.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mailingAddress5">(15-44) This field is required. It indicates the primary postal delivery address.</param>
        /// <param name="secondTelephoneNumber">(45-54) This field is optional. It indicates a second telephone number for the mortgagor or co-mortgagor.</param>
        /// <param name="locationCode">(55) This field is optional. It indicates the location (business, relative, etc.) of the second telephone number.</param>
        /// <returns>Transaction 512 Card 5</returns>
        public static string Tran512c5(string loanNumber = "", string mailingAddress5 = "", string secondTelephoneNumber = "",
                                       string locationCode = "")
        {
            string transaction;

            
                var transactionName = "512-5";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('5'); // 14: CARD CODE
                tranBuilder.Append(mailingAddress5.Trim().PadRight(30)); // 15-44: MAILING ADDRESS 5
                tranBuilder.Append(LeftZeroFillOptionalField(secondTelephoneNumber.Trim(), 10)); // 45-54: SECOND TELEPHONE NUMBER
                tranBuilder.Append(locationCode.Trim().PadRight(1)); // 55: LOCATION CODE (for second telephone number)
                tranBuilder.Append(' ', 25); // 56-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER


                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();

            
            return transaction;
        }

        /// <summary>
        ///  Transaction 512 - Expanded Name and Address - Maintenance (D-001)
        /// Use transaction 512 to enter the expanded six-line name and address fields, if needed, at the same time you enter transaction 012 (D-001). When you enter transaction 012, the system updates the four lines of the billing name and address field and four lines of the new, expanded, six-line name and address field.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="cityName">(15-35) This field is required. It indicates the name of the city for postal delivery purposes.</param>
        /// <param name="state">(36-37) This field is conditional. It indicates the U.S. Postal Service abbreviation for the postal delivery state or U.S. possession. If you type 1 in the FOREIGN ADDRESS INDICATOR field, the system does not validate this field.</param>
        /// <param name="zipCode">(38-42) This field is optional. It indicates the postal delivery zip code.</param>
        /// <param name="zipSuffix">(43-46) This field is optional. It indicates the zip code suffix.</param>
        /// <param name="carrierRoute">(47-50) This field is optional. It indicates the postal carrier route code.</param>
        /// <param name="foreignAddressIndicator">(51) This field is conditional. It indicates whether the address is in a foreign country and is to be reported to the IRS as a foreign address. The system does not validate the STATE field for a foreign address.</param>
        /// <param name="irsCountyCode">(70-71) This field is conditional.  IT contains an IRS-defined code for the county of the borrower's mailing address</param>
        /// <param name="provinceCode">(72-73) This field is conditional.  It is required if the IRS COUNTY CODE field equals CA; otherwise, leave blank.  It contains a code that indicates the province for Canadian mailing address.</param>
        /// <returns>Transaction 512 Card 6</returns>
        public static string Tran512c6(string loanNumber = "", string cityName = "", string state = "", string zipCode = "",
                                       string zipSuffix = "", string carrierRoute = "", string foreignAddressIndicator = "", string irsCountyCode = "",string provinceCode = "")
        {
            string transaction;

            
                var transactionName = "512-6";

                CheckValidLoanNumber(transactionName, loanNumber);

                //CheckRequiredField(transactionName, "cityName", cityName);

                //if (!IsAvailable(foreignAddressIndicator) && !IsAvailable(state))
                //{
                //    throw new Exception(
                //        string.Format(
                //            "{0}: {1}: State (36-37) cannot be empty if foreign address indicator (51) is not equal to 1.",
                //            transactionName, loanNumber));
                //}
                if(!IsAvailable(provinceCode) && irsCountyCode == "CA")
                {
                    throw new Exception("Province Code is required if the Irs County Code equals CA");
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append('6'); // 14: CARD CODE
                tranBuilder.Append(cityName.Trim().PadRight(21)); // 15-35: CITY NAME
                tranBuilder.Append(state.Trim().PadRight(2)); // 36-37: STATE
                tranBuilder.Append(FormatZipCode(zipCode.Trim())); // 38-42: ZIP CODE
                tranBuilder.Append(FormatFieldValueRemoval(zipSuffix, 4)); // 43-46: ZIP SUFFIX
                tranBuilder.Append(carrierRoute.Trim().PadRight(4)); // 47-50: CARRIER ROUTE
                tranBuilder.Append(foreignAddressIndicator.Trim().PadRight(1)); // 51: FOREIGN ADDRESS INDICATOR
                tranBuilder.Append(' ', 18); // 52-69: RESERVED
                tranBuilder.Append(irsCountyCode.PadRight(2)); // 70-71 IRS COUNTY CODE
                tranBuilder.Append(provinceCode.PadRight(2)); // 72-73 PROVINCE CODE
                tranBuilder.Append(' ', 7); //  74-80 RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER

                if (tranBuilder.Length != 102)

                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                }
                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();

           

            return transaction;
        }
    }
}
