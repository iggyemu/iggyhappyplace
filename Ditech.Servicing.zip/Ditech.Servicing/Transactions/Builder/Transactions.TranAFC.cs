﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction AFC - PMI Automatic Termination Status (D-344)
        /// You can use transaction AFC to update the termination status of loans the system selected for automatic PMI termination during the first monthly cycle. After the first processing cycle, the system stores the selected loans in the utility file for processing throughout the month. The system prints a listing of selected loans on report S-5PU.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="selectionCode">(16-18) This field is required. It indicates the selection code that appears on report P-4PM.</param>
        /// <param name="processorId">(19-23) This field is required. It indicates the three-character alphanumeric processor ID.</param>
        /// <param name="pmiCancellationTerminationStatusCodeFirstPosition">(19-23) This field is required. It indicates the five-character alphanumeric PMI cancellation/termination status code.  You can only update position 19. Use this position to place or remove hold processing for automatic PMI termination.</param>
        /// <returns>Transaction AFC</returns>
        public static string TranAFC(string loanNumber, string selectionCode, string processorId, string pmiCancellationTerminationStatusCodeFirstPosition)
        {
            string transaction;

            try
            {
                var transactionName = "AFC";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "selectionCode", selectionCode);
                CheckRequiredField(transactionName, "processorId", processorId);
                CheckRequiredField(transactionName, "pmiCancellationTerminationStatusCodeFirstPosition", pmiCancellationTerminationStatusCodeFirstPosition);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(selectionCode.Trim().PadRight(2)); // 7-8: SELECTION CODE
                tranBuilder.Append("*".PadRight(7)); // 9-15: LOAN
                tranBuilder.Append(processorId.Trim().PadRight(3)); // 16-18: PROCESSOR ID
                tranBuilder.Append(pmiCancellationTerminationStatusCodeFirstPosition.Trim().PadRight(1)); // 19: PMI CANCELLATION/TERMINATION STATUS CODE FIRST POSITION
                tranBuilder.Append(new string(' ', 4)); // 20-23: PMI CANCELLATION/TERMINATION STATUS CODE POSITIONS 2-5
                tranBuilder.Append(' ', 66); // 24-89: RESERVED
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
