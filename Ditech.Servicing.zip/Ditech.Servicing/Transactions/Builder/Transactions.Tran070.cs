
using System;
using System.Text;


namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 070 - Predistributed Payments (D-028).
        /// Use transaction 070 for payments that cannot be applied with normal application methods and for the application of odd interest for capitalized loans.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="paymentEffDate">(16-21) This field is optional. It indicates the effective date of the payment.</param>
        /// <param name="adjustmentIndicator1098">(22) This field is conditional. It indicates whether the system automatically creates an adjustment to your 1098 form, or creates an "updated only" adjustment. If you select to only update an adjustment, the system overrides the automatic 1098 update option set on the YEH3 header screen in the Year-end Workstation. This allows you to perform maintenance on a loan for more than one day and send the 1098 statement to a print spool or data tape when you complete all maintenance for a loan number.</param>
        /// <param name="sameDay">(23) This field is optional. It indicates if you want to reapply payments to correct loan numbers on the same day you reverse the misapplications. Otherwise, leave this field blank. You might encounter situations in which you cannot use the same-day process and must cause the system to produce a check.</param>
        /// <param name="suspReasCd">(32-35) This field is optional. It indicates the reason that you placed funds in suspense.</param>
        /// <param name="elocSubCode">(38) This field applies only if you are installed on the Equity Line of Credit enhancement (IP 1423). This field is required. It is part of a two-part code that includes the FEE CODE field (1: 38).</param>
        /// <param name="corporateAdvancePayee">(39-43) This field is conditional. It is required if you enter a code in the CORPORATE ADVANCE REASON CODE field (*: 44-47) and an * (asterisk) in the FEE CODE field (1: 38). It indicates the corporate advance payee code that the system uses when it generates an automatic corporate advance to satisfy a short payment or a repayment. You must set up a remittance header for the payee code on the Remittance Header Setup + Maintenance screen (INR1) in the Investor Setup Workstation.</param>
        /// <param name="corporateAdvanceReasonCode">(44-47) This field is conditional. It is required if you enter a code in the CORPORATE ADVANCE PAYEE field (*: 39-43) and an * (asterisk) in the FEE CODE field (1: 38). It indicates the reason code associated with the corporate advance funding or the repayment of the corporate advance. These codes are defined on the DISB/DEPO Reason Codes screen (DDCC) and are viewable on the Reason Code display window (RECD) in the Corporate Advance Workstation.</param>
        /// <returns>Transaction 070 Card Star</returns>
        public static string Tran070cStar(string loanNumber, string paymentEffDate = "", string adjustmentIndicator1098 = "",
                                          string sameDay = "", string suspReasCd = "", string elocSubCode = "",
                                          string corporateAdvancePayee = "", string corporateAdvanceReasonCode = "")
        {
            string transaction;

            
                var transactionName = "070";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(corporateAdvancePayee) && !IsAvailable(corporateAdvanceReasonCode))
                {
                    throw new Exception(
                        "corporateAdvanceReasonCode must be available when corporateAdvancePayee is available!");
                }

                if (IsAvailable(corporateAdvanceReasonCode) && !IsAvailable(corporateAdvancePayee))
                {
                    throw new Exception(
                        "corporateAdvancePayee must be available when corporateAdvanceReasonCode is available!");
                }

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("*"); // 14: CARD CODE
                tranBuilder.Append(' '); // 15: RESERVED
                tranBuilder.Append(FormatDate(paymentEffDate)); // 16-21: PAYMENT-EFF-DATE
                tranBuilder.Append(adjustmentIndicator1098.PadRight(1)); // 22: 1098 ADJUSTMENT INDICATOR
                tranBuilder.Append(sameDay.PadRight(1)); // 23: SAME DAY
                tranBuilder.Append(' ', 8); // 24-31: RESERVED
                tranBuilder.Append(suspReasCd.PadRight(4)); // 32-35: SUSP-REAS-CD
                tranBuilder.Append(' ', 2); // 36-37: RESERVED
                tranBuilder.Append(elocSubCode.PadRight(1)); // 38: ELOC SUBCODE
                tranBuilder.Append(corporateAdvancePayee.PadRight(5)); // 39-43: CORPORATE ADVANCE PAYEE
                tranBuilder.Append(corporateAdvanceReasonCode.PadRight(4)); // 44-47: CORPORATE ADVANCE REASON CODE
                tranBuilder.Append(' ', 33); // 48-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER

                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                }

            tranBuilder.AppendLine();
            transaction = tranBuilder.ToString();

                return transaction;
        }

        /// <summary>
        /// Transaction 070 - Predistributed Payments (D-028).
        /// Use transaction 070 for payments that cannot be applied with normal application methods and for the application of odd interest for capitalized loans.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="overRide">(14) This field is optional. It indicates the process stops for the system to override.</param>
        /// <param name="numberOfPayments">(15) This field is required. It indicates the number of payments included in this transaction. The number of payments must not be greater than one. This field updates the next payment due date and next payment number.</param>
        /// <param name="interest">(16-23) This field is optional. It indicates the amount to be distributed to interest. This field cannot equal zero if PRINCIPAL is not zero. It is added to interest paid year-to-date.</param>
        /// <param name="secondMortgageIndicator">(24) This field is optional. It indicates the payment is a piggyback second mortgage payment only. It determines the portion of the record to update.</param>
        /// <param name="principal">(25-31) This field is optional. It indicates the amount to be distributed to principal. It is subtracted from the principal balance and added to the principal paid year-to-date. If you use this field, the transaction must contain interest. Principal without interest indicates curtailments or curtailment reversals for which you use transaction 073 (D-029)or 547/548 (D-257).</param>
        /// <param name="escrow">(32-37) This field is optional. It indicates the amount distributed to escrow. It is added to the escrow balance. Report P-101 displays this fee in the FEES PAID column with fee code equal to a pound sign (#). Report P-102 shows this fee as an adjustment to service fee at the loan level on a separate line and flags it as SUB SERV FEE.</param>
        /// <param name="feeCode">(38) This field is conditional. It indicates the adjusted fee. It is required if you enter an amount in the FEE AMOUNT field (1: 39-43).</param>
        /// <param name="feeAmount">(39-43) This field is conditional. It is required if you entered a code in the FEE CODE field (1: 38). It indicates the amount of the fee corresponding to the value that you entered in the FEE CODE field.</param>
        /// <param name="life">(44-48) This field is optional. It indicates the amount of life distribution. (Single payments total premium only.) It is applied to life insurance.</param>
        /// <param name="aAndH">(49-53) This field is optional. It indicates the amount for accident and health distribution (single payments total premium only). It is applied towards A&amp;H insurance.</param>
        /// <param name="miscellaneous">(54-58) This field is optional. It indicates the amount for miscellaneous distribution.</param>
        /// <param name="replacementReserve">(59-64) This field is optional. It indicates the amount distributed to replacement reserve. It is added to the replacement reserve balance.</param>
        /// <param name="suspense">(65-72) This field is optional. It indicates the amount distributed to (+) suspense or the amount derived from (-) suspense. A negative amount reduces the suspense balance, and a positive amount increases the suspense balance.</param>
        /// <param name="amountReceived">(73-80) This field is required. It indicates the total of funds reflected in this transaction. Use this field for crossfooting.</param>
        /// <returns>Transaction 070 Card 1</returns>
        public static string Tran070c1(string loanNumber, string overRide = "", string numberOfPayments = "", string interest = "",
                                       string secondMortgageIndicator = "", string principal = "", string escrow = "", string feeCode = "",
                                       string feeAmount = "", string life = "", string aAndH = "", string miscellaneous = "",
                                       string replacementReserve = "", string suspense = "", string amountReceived = "")
        {
            string transaction;

            var transactionName = "070-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(feeCode) && !IsAvailable(feeAmount))
                {
                    throw new Exception(string.Format("{0}: {1}: feeAmount is required if feeCode is available.",
                                                      transactionName, loanNumber));
                }

                if (IsAvailable(feeAmount) && !IsAvailable(feeCode))
                {
                    throw new Exception(string.Format("{0}: {1}: feeCode is required if feeAmount is available.",
                                                      transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(overRide.Trim().PadRight(1)); // 14: OVERRIDE
                tranBuilder.Append(numberOfPayments.Trim().PadRight(1)); // 15: NUMBER OF PAYMENTS
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(interest.Trim(), string.Empty, true, true, true), 8)); // 16-23: INTEREST
                tranBuilder.Append(secondMortgageIndicator.Trim().PadRight(1)); // 24: 2ND MORTGAGE INDICATOR
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(principal.Trim(), string.Empty, true, true, true), 7)); // 25-31: PRINCIPAL
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(escrow.Trim(), string.Empty, true, true, true), 6)); // 32-37: ESCROW
                tranBuilder.Append(feeCode.Trim().PadRight(1)); // 38: FEE CODE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(feeAmount.Trim(), string.Empty, true, true, true), 5)); // 39-43: FEE AMOUNT
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(life.Trim(), string.Empty, true, true, true), 5)); // 44-48: LIFE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(aAndH.Trim(), string.Empty, true, true, true), 5)); // 49-53: A&H
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(miscellaneous.Trim(), string.Empty, true, true, true), 5)); // 54-58: MISCELLANEOUS
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(replacementReserve.Trim(), string.Empty, true, true, true), 6));
                // 59-64: REPLACEMENT RESERVE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(suspense.Trim(), string.Empty, true, true, true), 8)); // 65-72: SUSPENSE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(amountReceived.Trim(), string.Empty, true, true, true), 8)); // 73-80: AMOUNT RECEIVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER


                if (tranBuilder.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                tranBuilder.AppendLine();
                
                transaction = tranBuilder.ToString();
            
            
            return transaction;
        }
    }
}