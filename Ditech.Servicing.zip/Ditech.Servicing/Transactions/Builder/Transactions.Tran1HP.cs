﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        private const string hmpDateFormat = "yyMMdd";

        /// <summary>
        ///  Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD). 
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>/ 
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="suppressComments">(22) This field is required. It indicates whether to display the comment entered for this change on the SER Process Notes screen (SERN) in the Customer Service Workstation.</param>
        /// <param name="processedBy">(23-25) This field is required. It identifies the user ID of the person entering the record.</param>
        /// <param name="processedDate">(26-31) This field indicates the date that this record was added, changed or deleted.</param>
        /// <param name="modAgmt">(32) This field is conditional. It is required if the ACTION CODE field (1: 21) equals A. This field indicates whether there is a modification agreement on file for the loan.</param>
        /// <param name="modifyCode">(33-37) This field is conditional. It is required if the ACTION CODE field (1: 21) equals A. This field indicates the comment code that was established on the Modification Reason Code Header screen (MRCH) in the MSP Info Tracking Workstation.</param>
        /// <param name="recorded">(39) This field is required. It indicates whether the loan has been recorded.</param>
        /// <param name="principalBalanceBefore">(40-50) This field is optional. It indicates the BEFORE value for the loan's principal balance.</param>
        /// <param name="principalBalanceAfter">(51-61) This field is optional. It indicates the AFTER value for the loan's principal balance.</param>
        /// <param name="creditLmtBefore">(62-70) This field is optional. It indicates the BEFORE value for the loan's credit line limit amount.</param>
        /// <param name="creditLmtAfter">(71-79) This field is optional. It indicates the AFTER value for the loan's credit line limit amount.</param>
        /// <returns>Transaction 1HP Card 1</returns>
        /// ///
        public static string Tran1HPc1(string loanNumber = "", string effDate = "", string actionCode = "", string suppressComments = "", string processedBy = "", string processedDate = "", string modAgmt = "", string modifyCode = "", string recorded = "", string principalBalanceBefore = "", string principalBalanceAfter = "", string creditLmtBefore = "", string creditLmtAfter = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-1";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);
                CheckRequiredField(transactionName, "suppressComments", suppressComments);
                CheckRequiredField(transactionName, "processedBy", processedBy);
                CheckRequiredField(transactionName, "recorded", recorded);

                if (actionCode.Trim().ToUpper() == "A")
                {
                    if (!IsAvailable(modAgmt))
                    {
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when Action Code is set to A.",
                                          transactionName, loanNumber, "modAgmt"));
                    }

                    if (!IsAvailable(modifyCode))
                    {
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when Action Code is set to A.",
                                          transactionName, loanNumber, "modifyCode"));
                    }
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("1"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(suppressComments.Trim().PadRight(1)); // 22: SUPPRESS COMMENTS
                tranBuilder.Append(processedBy.Trim().PadRight(3)); // 23-25: PROCESSED BY
                tranBuilder.Append(FormatDate(processedDate.Trim(), hmpDateFormat)); // 26-31: PROCESSED DATE
                tranBuilder.Append(modAgmt.Trim().PadRight(1)); // 32: MOD AGMT
                tranBuilder.Append(modifyCode.Trim().PadRight(5)); // 33-37: MODIFY CODE
                tranBuilder.Append(' '); // 38: RESERVED
                tranBuilder.Append(recorded.Trim().PadRight(1)); // 39: RECORDED
                tranBuilder.Append(FormatMoney(principalBalanceBefore.Trim(), true, false, 11)); // 40-50: PRINCIPAL BALANCE BEFORE
                tranBuilder.Append(FormatMoney(principalBalanceAfter.Trim(), true, false, 11)); // 51-61: PRINCIPAL BALANCE AFTER
                tranBuilder.Append(FormatMoney(creditLmtBefore.Trim(), false, false, 9)); // 62-70: CREDIT LMT BEFORE
                tranBuilder.Append(FormatMoney(creditLmtAfter.Trim(), false, false, 9)); // 71-79: CREDIT LMT AFTER
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return  transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="origMortgageBefore">(22-30) This field is optional. It indicates the BEFORE value for the loan's original mortgage amount.</param>
        /// <param name="origMortgageAfter">(31-39) This field is optional. It indicates the AFTER value for the loan's original mortgage amount.</param>
        /// <param name="maturityDateBefore">(40-45) This field is optional. It indicates the BEFORE value for the loan's maturity date.</param>
        /// <param name="maturityDateAfter">(46-51) This field is optional. It indicates the AFTER value for the loan's maturity date.</param>
        /// <param name="dueDateBefore">(52-57) This field is optional. It indicates the BEFORE value for the loan's due date.</param>
        /// <param name="dueDateAfter">(58-63) This field is optional. It indicates the AFTER value for the loan's due date.</param>
        /// <param name="intRateBefore">(64-70) This field is optional. It indicates the BEFORE value for the loan's interest rate.</param>
        /// <param name="intRateAfter">(71-77) This field is optional. It indicates the AFTER value for the loan's interest rate.</param>
        /// <returns>Transaction 1HP Card 2</returns>
        public static string Tran1HPc2(string loanNumber = "", string effDate = "", string actionCode = "", string origMortgageBefore = "", string origMortgageAfter = "", string maturityDateBefore = "", string maturityDateAfter = "", string dueDateBefore = "", string dueDateAfter = "", string intRateBefore = "", string intRateAfter = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-2";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("2"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(origMortgageBefore.Trim(), false, false, 9)); // 22-30: ORIG MORTGAGE BEFORE
                tranBuilder.Append(FormatMoney(origMortgageAfter.Trim(), false, false, 9)); // 31-39: ORIG MORTGAGE AFTER
                tranBuilder.Append(FormatDate(maturityDateBefore.Trim(), hmpDateFormat)); // 40-45: MATURITY DATE BEFOREE
                tranBuilder.Append(FormatDate(maturityDateAfter.Trim(), hmpDateFormat)); // 46-51: MATURITY DATE AFTER
                tranBuilder.Append(FormatDate(dueDateBefore.Trim(), hmpDateFormat)); // 52-57: DUE DATE BEFORE
                tranBuilder.Append(FormatDate(dueDateAfter.Trim(), hmpDateFormat)); // 52-57: DUE DATE AFTER
                tranBuilder.Append(FormatPercent(intRateBefore.Trim(), 7)); // 64-70: INT RATE BEFORE
                tranBuilder.Append(FormatPercent(intRateAfter.Trim(), 7)); // 71-77: INT RATE AFTER
                tranBuilder.Append(' ', 3); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="interest">(22-31) This field is optional. It indicates the capitalized interest amount for the loan.</param>
        /// <param name="escrow">(32-41) This field is optional. It indicates the capitalized escrow amount for the loan.</param>
        /// <param name="lateChg">(42-51) This field is optional. It indicates the capitalized late charge amount for the loan.</param>
        /// <param name="fees">(52-61) This field is optional. It indicates the capitalized fees amount for the loan.</param>
        /// <param name="corpAdv">(62-71) This field is optional. It indicates the capitalized corporate advance amount for the loan.</param>
        /// <returns>Transaction 1HP Card 3</returns>
        /// ///
        public static string Tran1HPc3(string loanNumber = "", string effDate = "", string actionCode = "", string interest = "", string escrow = "", string lateChg = "", string fees = "", string corpAdv = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-3";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("3"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(Convert.ToZonedString(interest.Trim()).PadLeft(10, '0')); // 22-31: INTEREST
                tranBuilder.Append(Convert.ToZonedString(escrow.Trim()).PadLeft(10, '0'));  // 32-41: ESCROW
                tranBuilder.Append(Convert.ToZonedString(lateChg.Trim()).PadLeft(10, '0')); // 42-51: LATE CHG
                tranBuilder.Append(Convert.ToZonedString(fees.Trim()).PadLeft(10, '0')); // 52-61: FEES
                tranBuilder.Append(Convert.ToZonedString(corpAdv.Trim()).PadLeft(10, '0')); // 62-71: CORP ADV
                tranBuilder.Append(' ', 9); // 72-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="piPaymentBefore">(22-30) This field is optional. It indicates the BEFORE value for the monthly payment amount.</param>
        /// <param name="piPaymentAfter">(31-39) This field is optional. It indicates the AFTER value for the monthly payment amount.</param>
        /// <param name="marginBefore">(40-46) This field is optional. It indicates the BEFORE value for the loan's margin.</param>
        /// <param name="marginAfter">(47-53) This field is optional. It indicates the AFTER value for the loan's margin.</param>
        /// <param name="curtailmentAmt">(54-63) This field is optional. It indicates the curtailment amount for the loan.  </param>
        /// <param name="other">(64-73) This field is optional. It indicates a capitalized amount other than those already listed. A negative amount indicates a write-off.</param>
        /// <param name="comments">(74-80) This field is optional. It indicates any free-form comments concerning this history record. If the SUPPRESS COMMENTS field (1: 22) equals N, this comment is displayed on the SER Process Notes screen (SERN) in the Customer Service Workstation.</param>
        /// <returns>Transaction 1HP Card 4</returns>
        /// ///
        public static string Tran1HPc4(string loanNumber = "", string effDate = "", string actionCode = "", string piPaymentBefore = "", string piPaymentAfter = "", string marginBefore = "", string marginAfter = "", string curtailmentAmt = "", string other = "", string comments = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-4";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("4"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(piPaymentBefore.Trim(), true, false, 9)); // 22-30: P&I PAYMENT BEFORE
                tranBuilder.Append(FormatMoney(piPaymentAfter.Trim(), true, false, 9)); // 31-39: P&I PAYMENT AFTER
                tranBuilder.Append(FormatPercent(marginBefore.Trim(), 7)); // 40-46: MARGIN BEFORE
                tranBuilder.Append(FormatPercent(marginAfter.Trim(), 7)); // 47-53: MARGIN AFTER
                tranBuilder.Append(FormatMoney(curtailmentAmt.Trim(), true, false, 10)); // 54-63: CURTAILMENT AMT
                tranBuilder.Append(FormatMoney(other.Trim(), true, false, 10)); // 64-73: OTHER
                tranBuilder.Append(comments.Trim().PadRight(7)); // 74-80: COMMENTS
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="comments">(22-79) This field is optional. It indicates any free-form comments concerning this history record. If the SUPPRESS COMMENTS field (1: 22) equals N, this comment is displayed on the SER Process Notes screen (SERN) in the Customer Service Workstation.</param>
        /// <returns>Transaction 1HP Card 5</returns>
        /// ///
        public static string Tran1HPc5(string loanNumber = "", string effDate = "", string actionCode = "", string comments = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-5";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("5"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(comments.Trim().PadRight(58)); // 22-79: COMMENTS
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="solicType">(22) This field is optional. It indicates the type of modification solicitation provided to the mortgagor.</param>
        /// <param name="solicDate">(23-28) This field is optional. It indicates the date that the mortgagor is solicited for a loan modification option.</param>
        /// <param name="immDflt">(29) This field is optional. It indicates whether the borrower met qualifications for modification through imminent default.</param>
        /// <param name="dbtCnsl">(30) This field is optional. It indicates whether the borrower agreed to HUD counseling as a condition of the loan modification.</param>
        /// <param name="progTpCmp">(31-34) This field is optional. It indicates the program type or campaign.</param>
        /// <param name="aprvModYn">(35) This field is optional. It indicates whether the servicer has obtained the required party's approval of the loan modification.</param>
        /// <param name="aprvModDate">(36-41) This field is optional. It indicates the date the servicer officially approved the loan modification.</param>
        /// <param name="compDate">(42-47) This field is optional. It indicates the date the modification agreement is prepared (the rate locked date).</param>
        /// <param name="recDate">(48-53) This field is optional. It indicates the recording date of the loan modification agreement.</param>
        /// <param name="DeniedDate">(54-59) This field is optional. It indicates the date the modification is denied. </param>
        /// <param name="deniedRsn">(60-61) This field is optional. It indicates the reason for the loan modification.</param>
        /// <param name="propertyValue">(62-69) This field is optional. It indicates the property value used to support the loan modification.</param>
        /// <returns>Transaction 1HP Card 6</returns>
        /// ///
        public static string Tran1HPc6(string loanNumber = "", string effDate = "", string actionCode = "", string solicType = "", string solicDate = "", string immDflt = "", string dbtCnsl = "", string progTpCmp = "", string aprvModYn = "", string aprvModDate = "", string compDate = "", string recDate = "", string DeniedDate = "", string deniedRsn = "", string propertyValue = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-6";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("6"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(solicType.Trim().PadRight(1)); // 22: SOLIC TYPE
                tranBuilder.Append(FormatDate(solicDate.Trim(), hmpDateFormat)); // 23-28: SOLIC DATE
                tranBuilder.Append(immDflt.Trim().PadRight(1)); // 29: IMM DFLT
                tranBuilder.Append(dbtCnsl.Trim().PadRight(1)); // 30: DBT CNSL
                tranBuilder.Append(progTpCmp.Trim().PadRight(4)); // 31-34: PROG TP/CMP
                tranBuilder.Append(aprvModYn.Trim().PadRight(1)); // 35: APRV MOD Y/N
                tranBuilder.Append(FormatDate(aprvModDate.Trim(), hmpDateFormat)); // 36-41: APRV MOD DATE
                tranBuilder.Append(FormatDate(compDate.Trim(), hmpDateFormat)); // 42-47: COMP DATE
                tranBuilder.Append(FormatDate(recDate.Trim(), hmpDateFormat)); // 48-53: REC DATE
                tranBuilder.Append(FormatDate(DeniedDate.Trim(), hmpDateFormat)); // 54-59: DENIED DATE
                tranBuilder.Append(deniedRsn.Trim().PadRight(2)); // 60-61: DENIED RSN
                tranBuilder.Append(FormatMoney(propertyValue.Trim(), false, false, 8)); // 62-69: PROPERTY VALUE
                tranBuilder.Append(' ', 11); // 70-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="propValDate">(22-27) This field is optional. It indicates the date of the property value that supports the loan modification.</param>
        /// <param name="anlyType">(28-29) This field is optional. It indicates the type of value analysis.</param>
        /// <param name="netPvDate">(30-35) This field is optional. It indicates the date net present value (NPV) test was performed.</param>
        /// <param name="netPvResults">(36) This field is optional. It indicates the results of the NPV test, positive or negative.</param>
        /// <param name="preModNpvAmt">(37-46) This field is optional. It indicates the premodification dollar amount provided by the NPV model.</param>
        /// <param name="foreclosureNpvAmt">(47-56) This field is optional. It indicates the NPV amount if a foreclosure is completed.</param>
        /// <param name="modifiedNpvAmt">(57-66) This field is optional. It indicates the NPV amount if a loan modification is completed.</param>
        /// <param name="frontEndDti">(67-71) This field is optional. It indicates the front-end debt to income (DTI) ratio (total monthly housing expense divided by monthly income) used to qualify the modification.</param>
        /// <returns>Transaction 1HP Card 7</returns>
        /// ///
        public static string Tran1HPc7(string loanNumber = "", string effDate = "", string actionCode = "", string propValDate = "", string anlyType = "", string netPvDate = "", string netPvResults = "", string preModNpvAmt = "", string foreclosureNpvAmt = "", string modifiedNpvAmt = "", string frontEndDti = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-7";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("7"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatDate(propValDate.Trim(), hmpDateFormat)); // 22-27: PROP VAL DATE
                tranBuilder.Append(anlyType.Trim().PadRight(2)); // 28-29: ANLY TYPE
                tranBuilder.Append(FormatDate(netPvDate.Trim(), hmpDateFormat)); // 30-35: NET PV DATE
                tranBuilder.Append(netPvResults.Trim().PadRight(1)); // 36: NET PV RESULTS
                tranBuilder.Append(FormatMoney(preModNpvAmt.Trim(), true, false, 10)); // 37-46: PRE-MOD NPV AMT
                tranBuilder.Append(FormatMoney(foreclosureNpvAmt.Trim(), true, false, 10)); // 47-56: FORECLOSURE NPV AMT
                tranBuilder.Append(FormatMoney(modifiedNpvAmt.Trim(), true, false, 10)); // 57-66: MODIFIED NPV AMT
                tranBuilder.Append(FormatMoney(frontEndDti.Trim(), true, false, 5)); // 67-71: FRONT-END DTI
                tranBuilder.Append(' ', 9); // 72-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="frontEndWIrr">(22-26) This field is optional. It indicates the front-end debt-to-income (DTI) ratio as determined after an interest rate reduction.</param>
        /// <param name="feDtWIrrTe">(27-31) This field is optional. It indicates the front-end DTI ratio as determined after an interest rate reduction and term extension.</param>
        /// <param name="feDtWIrrTePf">(32-26) This field is optional. It indicates the front-end DTI ratio as determined after an interest rate reduction and term extension and principal forbearance.</param>
        /// <param name="backEndDti">(37-41) This field is optional. It indicates the back-end DTI ratio used to qualify the modification.</param>
        /// <param name="tmInd">(42) This field is optional. It indicates whether the loan went through a trial payment period (to ensure the borrower's creditworthiness) preceding the actual change to the loan terms by a modification agreement.</param>
        /// <param name="trialModStart">(43-48) This field is optional. It indicates the date on which the modification trial payment period begins for the loan.</param>
        /// <param name="trialModEnd">(49-54) This field is optional. It indicates the date on which the modification trial payment period ends for the loan.</param>
        /// <param name="numPmts">(55-56) This field is optional. It indicates the trial period requirements for the number of on-time payments required. </param>
        /// <param name="rslt">(57) This field is optional. It indicates the disposition of the trial period. </param>
        /// <param name="trialModPmtAmt">(58-67) This field is optional. It indicates the trial period requirements for the payment amount required during the trial period.</param>
        /// <param name="trialModPiAmt">(68-77) This field is optional. It indicates the amount of principal and interest (P&I) during the trial period.</param>
        /// <returns>Transaction 1HP Card 8</returns>
        /// ///
        public static string Tran1HPc8(string loanNumber = "", string effDate = "", string actionCode = "", string frontEndWIrr = "", string feDtWIrrTe = "", string feDtWIrrTePf = "", string backEndDti = "", string tmInd = "", string trialModStart = "", string trialModEnd = "", string numPmts = "", string rslt = "", string trialModPmtAmt = "", string trialModPiAmt = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-8";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("8"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(frontEndWIrr.Trim(), true, false, 5)); // 22-26: FRONT END W/IRR
                tranBuilder.Append(FormatMoney(feDtWIrrTe.Trim(), true, false, 5)); // 27-31: FE DT W/IRR-TE
                tranBuilder.Append(FormatMoney(feDtWIrrTePf.Trim(), true, false, 5)); // 32-36: FE DT W/IRR-TE-PF
                tranBuilder.Append(FormatMoney(backEndDti.Trim(), true, false, 5, true)); // 37-41: BACK END DTI
                tranBuilder.Append(tmInd.Trim().PadRight(1)); // 42: TM IND
                tranBuilder.Append(FormatDate(trialModStart.Trim(), hmpDateFormat)); // 43-48: TRIAL MOD START
                tranBuilder.Append(FormatDate(trialModEnd.Trim(), hmpDateFormat)); // 49-54: TRIAL MOD END
                tranBuilder.Append(FormatMoney(numPmts, false, false, 2)); // 55-56: NUM PMTS
                tranBuilder.Append(rslt.Trim().PadRight(1)); // 57: RSLT
                tranBuilder.Append(FormatMoney(trialModPmtAmt.Trim(), true, false, 10)); // 58-67: TRIAL MOD PMT-AMT
                tranBuilder.Append(FormatMoney(trialModPiAmt.Trim(), true, false, 10)); // 68-77: TRIAL MOD P&I AMT
                tranBuilder.Append(' ', 3); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="postModSvcFee">(22-29) This field is optional. It indicates the servicing fee percentage after the loan modification.</param>
        /// <param name="escrowShortage">(30-39) This field is optional. It indicates the amount of the escrow shortage after consideration for capitalization of escrow advances and payment received during the trial period.</param>
        /// <param name="escrowRepayAmt">(40-49) This field is optional. It indicates the monthly amount collected from the borrower as part of the modified PITIAS payment to repay the escrow shortage.</param>
        /// <param name="currentMktRate">(50-56) This field is optional. It indicates the current market rate in effect as of the preparation date of the modification agreement.</param>
        /// <param name="fullyIndxArmRate">(57-63) This field is optional. It indicates the fully indexed rate on an ARM loan calculated as of the date the modification agreement is prepared.</param>
        /// <param name="eligPlan">(64-67) This field is optional. It indicates the incentive program that applies for successful implementation of the loan modification program.</param>
        /// <param name="moAcruAmount">(68-77) This field is optional. It indicates the monthly accrual amount for borrower or servicer incentive payments.</param>
        /// <returns>Transaction 1HP Card 9</returns>
        /// ///
        public static string Tran1HPc9(string loanNumber = "", string effDate = "", string actionCode = "", string postModSvcFee = "", string escrowShortage = "", string escrowRepayAmt = "", string currentMktRate = "", string fullyIndxArmRate = "", string eligPlan = "", string moAcruAmount = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-9";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("9"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatPercent(postModSvcFee, 8)); // 22-29: POST MOD SVC FEE
                tranBuilder.Append(FormatMoney(escrowShortage.Trim(), true, false, 10)); // 30-39: ESCROW SHORTAGE
                tranBuilder.Append(FormatMoney(escrowRepayAmt.Trim(), true, false, 10)); // 40-49: ESCROW REPAY AMT
                tranBuilder.Append(FormatPercent(currentMktRate, 7)); // 50-56: CUR MKT RATE
                tranBuilder.Append(FormatPercent(fullyIndxArmRate, 7)); // 57-63: FULLY INDX ARM RATE
                tranBuilder.Append(eligPlan.Trim().PadRight(4)); // 64-67: ELIG PLAN
                tranBuilder.Append(FormatMoney(moAcruAmount.Trim(), true, false, 10)); // 68-77: MO ACRU AMOUNT
                tranBuilder.Append(' ', 3); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="anivDate">(22-27) This field is optional. It indicates the anniversary date for application of incentive payments.</param>
        /// <param name="deferredPrincipal">(28-37) This field is optional. It indicates the deferred principal amount included in the loan modification.</param>
        /// <param name="contributionsByOther">(38-47) This field is optional. It indicates the amounts other parties contributed, such as hazard insurance claims.</param>
        /// <returns>Transaction 1HP Card A</returns>
        /// ///
        public static string Tran1HPcA(string loanNumber = "", string effDate = "", string actionCode = "", string anivDate = "", string deferredPrincipal = "", string contributionsByOther = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-A";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("A"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatDate(anivDate.Trim(), hmpDateFormat)); // 22-27: ANIV DATE
                tranBuilder.Append(FormatMoney(deferredPrincipal.Trim(), true, false, 10)); // 28-37: DEFERRED PRINCIPAL
                tranBuilder.Append(FormatMoney(contributionsByOther.Trim(), true, false, 10)); // 38-47: CONTRIBUTIONS BY OTHERS
                tranBuilder.Append(' ', 33); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="stpFlg">(22) This field is optional. It indicates when the terms of the modification agreement call for the interest rate to step up over time.</param>
        /// <param name="maxRate">(23-29) This field is optional. In the case of a step rate agreement, this field indicates the maximum interest rate to which the loan may step up. This is also known as the market rate in effect when the modification agreement is prepared.</param>
        /// <param name="maxRateDate">(30-35) This field is optional. In the case of a step rate agreement, this field indicates the date on which the maximum interest rate will be reached.</param>
        /// <param name="numStps">(36-37) This field is optional. It indicates the number of increases in the interest rate (steps) required to reach the maximum interest rate.</param>
        /// <param name="step1EffDate">(38-43) This field is optional. It indicates the payment effective date for the first interest rate (step) increase.</param>
        /// <param name="step1Rate">(44-50) This field is optional. It indicates the interest rate in effect for the first step.</param>
        /// <param name="step1PI">(51-60) This field is optional. It indicates the fully amortizing P&I payment in effect for the first step.</param>
        /// <param name="step2EffDate">(61-66) This field is optional. It indicates the payment effective date for the second interest rate (step) increase.</param>
        /// <param name="step2Rate">(67-73) This field is optional. It indicates the interest rate in effect for the second step</param>
        /// <returns>Transaction 1HP Card B</returns>
        public static string Tran1HPcB(string loanNumber = "", string effDate = "", string actionCode = "", string stpFlg = "", string maxRate = "", string maxRateDate = "", string numStps = "", string step1EffDate = "", string step1Rate = "", string step1PI = "", string step2EffDate = "", string step2Rate = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-B";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("B"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(stpFlg.Trim().PadRight(1)); // 22: STP FLG
                tranBuilder.Append(FormatPercent(maxRate.Trim(), 7)); // 23-29: MAX RATE
                tranBuilder.Append(FormatDate(maxRateDate.Trim(), hmpDateFormat)); // 30-35: MAX RATE DATE
                tranBuilder.Append(FormatMoney(numStps.Trim(), false, false, 2)); // 36-37: NUM STPS
                tranBuilder.Append(FormatDate(step1EffDate.Trim(), hmpDateFormat)); // 38-43: EFF DATE
                tranBuilder.Append(FormatPercent(step1Rate.Trim(), 7)); // 44-50: STEP1 RATE
                tranBuilder.Append(FormatMoney(step1PI.Trim(), true, false, 10)); // 51-60: P-I
                tranBuilder.Append(FormatDate(step2EffDate.Trim(), hmpDateFormat)); // 61-66: EFF DATE
                tranBuilder.Append(FormatPercent(step2Rate.Trim(), 7)); // 67-73: STEP2 RATE
                tranBuilder.Append(' ', 7); // 74-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="step2PI">(22-31) This field is optional. It indicates the fully amortizing P&I payment in effect for the second step.</param>
        /// <param name="step3EffDate">(32-37) This field is optional. It indicates the payment effective date for the third interest rate (step) increase.</param>
        /// <param name="step3Rate">(38-44) This field is optional. It indicates the interest rate in effect for the third step.</param>
        /// <param name="step3PI">(45-54) This field is optional. It indicates the fully amortizing P&I payment in effect for the third step.</param>
        /// <param name="step4EffDate">(55-60) This field is optional. It indicates the payment effective date for the fourth interest rate (step) increase.</param>
        /// <param name="step4Rate">(61-67) This field is optional. It indicates the interest rate in effect for the fourth step.</param>
        /// <param name="step4PI">(68-77) This field is optional. It indicates the fully amortizing P&I payment in effect for the fourth step.</param>
        /// <returns>Transaction 1HP Card C</returns>
        public static string Tran1HPcC(string loanNumber = "", string effDate = "", string actionCode = "", string step2PI = "", string step3EffDate = "", string step3Rate = "", string step3PI = "", string step4EffDate = "", string step4Rate = "", string step4PI = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-C";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("C"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(step2PI.Trim(), true, false, 10)); // 22-31: P-I
                tranBuilder.Append(FormatDate(step3EffDate.Trim(), hmpDateFormat)); // 32-37: EFF DATE
                tranBuilder.Append(FormatPercent(step3Rate.Trim(), 7)); // 38-44: STEP3 RATE
                tranBuilder.Append(FormatMoney(step3PI.Trim(), true, false, 10)); // 45-54: P-I
                tranBuilder.Append(FormatDate(step4EffDate.Trim(), hmpDateFormat)); // 55-60: EFF DATE
                tranBuilder.Append(FormatPercent(step4Rate.Trim(), 7)); // 61-67: STEP4 RATE
                tranBuilder.Append(FormatMoney(step4PI.Trim(), true, false, 10)); // 68-77: P-I
                tranBuilder.Append(' ', 3); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="step5EffDate">(22-27) This field is optional. It indicates the payment effective date for the fifth interest rate (step) increase.</param>
        /// <param name="step5Rate">(28-34) This field is optional. It indicates the interest rate in effect for the fifth step.</param>
        /// <param name="step5Pi">(35-44) This field is optional. It indicates the fully amortizing P&I payment in effect for the fifth step.</param>
        /// <param name="step6EffDate">(45-50) This field is optional. It indicates the payment effective date for the sixth interest rate (step) increase.</param>
        /// <param name="step6Rate">(51-57) This field is optional. It indicates the interest rate in effect for the sixth step.</param>
        /// <param name="step6Pi">(58-67) This field is optional. It indicates the fully amortizing P&I payment in effect for the sixth step.</param>
        /// <returns>Transaction 1HP Card D</returns>
        public static string Tran1HPcD(string loanNumber = "", string effDate = "", string actionCode = "", string step5EffDate = "", string step5Rate = "", string step5Pi = "", string step6EffDate = "", string step6Rate = "", string step6Pi = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-D";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("D"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatDate(step5EffDate.Trim(), hmpDateFormat)); // 22-27: EFF DATE
                tranBuilder.Append(FormatPercent(step5Rate.Trim(), 7)); // 28-34: STEP5 RATE
                tranBuilder.Append(FormatMoney(step5Pi.Trim(), true, false, 10)); // 35-44: P-I
                tranBuilder.Append(FormatDate(step6EffDate.Trim(), hmpDateFormat)); // 45-50: EFF DATE
                tranBuilder.Append(FormatPercent(step6Rate.Trim(), 7)); // 51-57: STEP6 RATE
                tranBuilder.Append(FormatMoney(step6Pi.Trim(), true, false, 10)); // 58-67: P-I
                tranBuilder.Append(' ', 13); // 68-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="step7EffDate">(22-27) This field is optional. It indicates the payment effective date for the seventh interest rate (step) increase.</param>
        /// <param name="step7Rate">(28-34) This field is optional. It indicates the interest rate in effect for the seventh step.</param>
        /// <param name="step7Pi">(35-44) This field is optional. It indicates the fully amortizing P&I payment in effect for the seventh step.</param>
        /// <param name="step8EffDate">(45-50) This field is optional. It indicates the payment effective date for the eigth interest rate (step) increase.</param>
        /// <param name="step8Rate">(51-57) This field is optional. It indicates the interest rate in effect for the eigth step.</param>
        /// <param name="step8Pi">(58-67) This field is optional. It indicates the fully amortizing P&I payment in effect for the eigth step.</param>
        /// <returns>Transaction 1HP Card E</returns>
        public static string Tran1HPcE(string loanNumber = "", string effDate = "", string actionCode = "", string step7EffDate = "", string step7Rate = "", string step7Pi = "", string step8EffDate = "", string step8Rate = "", string step8Pi = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-E";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("E"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatDate(step7EffDate.Trim(), hmpDateFormat)); // 22-27: EFF DATE
                tranBuilder.Append(FormatPercent(step7Rate.Trim(), 7)); // 28-34: STEP5 RATE
                tranBuilder.Append(FormatMoney(step7Pi.Trim(), true, false, 10)); // 35-44: P-I
                tranBuilder.Append(FormatDate(step8EffDate.Trim(), hmpDateFormat)); // 45-50: EFF DATE
                tranBuilder.Append(FormatPercent(step8Rate.Trim(), 7)); // 51-57: STEP6 RATE
                tranBuilder.Append(FormatMoney(step8Pi.Trim(), true, false, 10)); // 58-67: P-I
                tranBuilder.Append(' ', 13); // 68-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="loanToValueBefore">(22-26) This field is optional. It indicates the loan to value ratio before the loan modification.</param>
        /// <param name="loanToValueAfter">(27-31) This field is optional. It indicates the loan to value ratio after the loan modification.</param>
        /// <param name="totalMonthlyPaymentBefore">(32-41) This field is optional. It indicates the total monthly payment before the loan modification.</param>
        /// <param name="totalMonthlyPaymentAfter">(42-51) This field is optional. It indicates the total monthly payment after the loan modification.</param>
        /// <param name="escrowBefore">(52-61) This field is optional. It indicates the escrow payment before the loan modification became effective.</param>
        /// <param name="escrowAfter">(62-71) This field is optional. It indicates the escrow payment after the loan modification.</param>
        /// <param name="prodTypeBefore">(72-73) This field is optional. It indicates the user-defined product type before the modification as defined in the TP field on the Modification Product Types work window on the Descriptions Header Menu screen (SAF2) in the MSP Info Tracking Workstation.</param>
        /// <param name="prodTypeAfter">(74-75) This field is optional. It indicates the user-defined product type after the modification as defined in the TP field on the Modification Product Types work window.</param>
        /// <returns>Transaction 1HP Card G</returns>
        /// ///
        public static string Tran1HPcG(string loanNumber = "", string effDate = "", string actionCode = "", string loanToValueBefore = "", string loanToValueAfter = "", string totalMonthlyPaymentBefore = "", string totalMonthlyPaymentAfter = "", string escrowBefore = "", string escrowAfter = "", string prodTypeBefore = "", string prodTypeAfter = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-G";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("G"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(loanToValueBefore.Trim(), true, false, 5)); // 22-26: LOAN TO VALUE: BEFORE
                tranBuilder.Append(FormatMoney(loanToValueAfter.Trim(), true, false, 5)); // 27-31: LOAN TO VALUE: AFTER
                tranBuilder.Append(FormatMoney(totalMonthlyPaymentBefore.Trim(), true, false, 10)); // 32-41: TOTAL MONTHLY PAYMENT: BEFORE
                tranBuilder.Append(FormatMoney(totalMonthlyPaymentAfter.Trim(), true, false, 10)); // 42-51: TOTAL MONTHLY PAYMENT: AFTER
                tranBuilder.Append(FormatMoney(escrowBefore.Trim(), true, false, 10)); // 52-61: ESCROW: BEFORE
                tranBuilder.Append(FormatMoney(escrowAfter.Trim(), true, false, 10)); // 62-71: ESCROW: AFTER
                tranBuilder.Append(prodTypeBefore.Trim().PadLeft(2, '0')); // 72-73: PROD TYPE: BEFORE
                tranBuilder.Append(prodTypeAfter.Trim().PadLeft(2, '0')); // 74-75: PROD TYPE: AFTER    
                tranBuilder.Append(' ', 5); // 76-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="remainingTermBefore">(22-24) This field is optional. It indicates the remaining loan term before the loan modification.</param>
        /// <param name="remainingTermAfter">(25-27) This field is optional. It indicates the remaining loan term after the loan modification.</param>
        /// <param name="amortTermBefore">(28-30) This field is optional. It indicates the amortization term before the loan modification.</param>
        /// <param name="amortTermAfter">(31-33) This field is optional. It indicates the amortization term after the loan modification.</param>
        /// <returns>Transaction 1HP Card H</returns>
        /// ///
        public static string Tran1HPcH(string loanNumber = "", string effDate = "", string actionCode = "", string remainingTermBefore = "", string remainingTermAfter = "", string amortTermBefore = "", string amortTermAfter = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-H";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("H"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(remainingTermBefore.Trim(), false, false, 3)); // 22-24: REMAINING TERM: BEFORE
                tranBuilder.Append(FormatMoney(remainingTermAfter.Trim(), false, false, 3)); // 25-27 REMAINING TERM: AFTER
                tranBuilder.Append(FormatMoney(amortTermBefore.Trim(), false, false, 3)); // 28-30: AMORT-TERM: BEFORE
                tranBuilder.Append(FormatMoney(amortTermAfter.Trim(), false, false, 3)); // 31-33: AMORT-TERM: AFTER
                tranBuilder.Append(' ', 47); // 34-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 1HP - Loan Modifications History (D-385).
        /// Transaction 1HP is used to add, update and delete history records through the stand-alone Modification History detail screen (MODD).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="effDate">(14-19) This field is required. It indicates the date the history record is added.</param>
        /// <param name="actionCode">(21) This field is required. It indicates the type of action to be performed on the loan record.</param>
        /// <param name="capitalizedAmountTotal">(22-33) This field is optional.  It is the capitalized amount total.</param>
        /// <returns>Transaction 1HP Card I</returns>
        /// ///
        public static string Tran1HPcI(string loanNumber = "", string effDate = "", string actionCode = "", string capitalizedAmountTotal = "")
        {
            string transaction;

            try
            {
                var transactionName = "1HP-I";

                CheckRequiredField(transactionName, "effDate", effDate);
                CheckRequiredField(transactionName, "actionCode", actionCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(effDate.Trim(), hmpDateFormat)); // 14-19: EFF DATE
                tranBuilder.Append("I"); // 20: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 21: ACTION CODE
                tranBuilder.Append(FormatMoney(capitalizedAmountTotal.Trim(), true, false, 12)); // 22-33: CAPITALIZED AMOUNT: TOTAL
                tranBuilder.Append(' ', 47); // 34-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}