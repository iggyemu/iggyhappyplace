#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 08A - FNMA/FHLMC GSE Loan Master Data (D-267).
        /// Transaction 08A maintains loan master fields for Fannie Mae/Freddie Mac government-sponsored enterprise (GSE) data.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="yearBuilt">(16-19) This field is optional. It indicates the year, including the century, that the property was built. When you enter this field, the system updates the CENT-YR-BUILT field in the master file.</param>
        /// <param name="fannieMaeSpecialFeatures5">(20-22) These fields are optional. Each contains special codes Fannie Mae assigned to specific loans. Transactions 084 (D-148) or A05 (D-002) contain Fannie Mae Special Features 1 through 4.</param>
        /// <param name="fannieMaeSpecialFeatures6">(23-25) These fields are optional. Each contains special codes Fannie Mae assigned to specific loans. Transactions 084 (D-148) or A05 (D-002) contain Fannie Mae Special Features 1 through 4.</param>
        /// <param name="freddieMacSpecialCharacteristics1">(26-28) Each of these six optional fields contains special codes Freddie Mac assigned to specific loans.</param>
        /// <param name="freddieMacSpecialCharacteristics2">(29-31) Each of these six optional fields contains special codes Freddie Mac assigned to specific loans.</param>
        /// <param name="freddieMacSpecialCharacteristics3">(32-34) Each of these six optional fields contains special codes Freddie Mac assigned to specific loans.</param>
        /// <param name="freddieMacSpecialCharacteristics4">(35-37) Each of these six optional fields contains special codes Freddie Mac assigned to specific loans.</param>
        /// <param name="freddieMacSpecialCharacteristics5">(38-40) Each of these six optional fields contains special codes Freddie Mac assigned to specific loans.</param>
        /// <param name="freddieMacSpecialCharacteristics6">(41-43) Each of these six optional fields contains special codes Freddie Mac assigned to specific loans.</param>
        /// <param name="noteDate">(44-49) This field is optional. It indicates the date on the mortgage note. It must be on or after the application date.</param>
        /// <param name="numberOfBedroomsPerUnit1">(51) This field is optional. It indicates the number of bedrooms for unit one.</param>
        /// <param name="numberOfBedroomsPerUnit2">(53) This field is optional. It indicates the number of bedrooms for unit two.</param>
        /// <param name="numberOfBedroomsPerUnit3">(55) This field is optional. It indicates the number of bedrooms for unit three.</param>
        /// <param name="numberOfBedroomsPerUnit4">(57) This field is optional. It indicates the number of bedrooms for unit four.</param>
        /// <param name="numberOfBorrowers">(59-60) This field is optional. It indicates the number of borrowers on a single loan.</param>
        /// <param name="firstTimeHomeBuyer">(61) This field is optional. It indicates whether a loan is being issued to a first-time homebuyer.</param>
        /// <param name="monthlyHousingExpense">(66-70) This field is optional. It indicates the amount in dollars needed each month to meet housing expenses for the borrowers primary residence.</param>
        /// <param name="monthlyDebtExpense">(75-79) This field is optional. It indicates the amount in dollars the borrower spends each month on debts.</param>
        /// <returns>Transaction 08A Card A</returns>
        public static string Tran08AcA(string loanNumber, string yearBuilt, string fannieMaeSpecialFeatures5,
                                       string fannieMaeSpecialFeatures6, string freddieMacSpecialCharacteristics1,
                                       string freddieMacSpecialCharacteristics2,
                                       string freddieMacSpecialCharacteristics3,
                                       string freddieMacSpecialCharacteristics4,
                                       string freddieMacSpecialCharacteristics5,
                                       string freddieMacSpecialCharacteristics6, string noteDate,
                                       string numberOfBedroomsPerUnit1, string numberOfBedroomsPerUnit2,
                                       string numberOfBedroomsPerUnit3, string numberOfBedroomsPerUnit4,
                                       string numberOfBorrowers, string firstTimeHomeBuyer, string monthlyHousingExpense,
                                       string monthlyDebtExpense)
        {
            string transaction;

            try
            {
                var transactionName = "08A-A";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(' '); // 14: RESERVED
                tranBuilder.Append("A"); // 15: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(yearBuilt.Trim(), 4)); // 16-19: YEAR BUILT
                tranBuilder.Append(LeftZeroFillOptionalField(fannieMaeSpecialFeatures5.Trim(), 3));
                // 20-22: FANNIE MAE SPECIAL FEATURES (#5)
                tranBuilder.Append(LeftZeroFillOptionalField(fannieMaeSpecialFeatures6.Trim(), 3));
                // 23-25: FANNIE MAE SPECIAL FEATURES (#6)
                tranBuilder.Append(LeftZeroFillOptionalField(freddieMacSpecialCharacteristics1.Trim(), 3));
                // 26-28: FREDDIE MAC SPECIAL CHARACTERISTICS (#1) 
                tranBuilder.Append(LeftZeroFillOptionalField(freddieMacSpecialCharacteristics2.Trim(), 3));
                // 29-31: FREDDIE MAC SPECIAL CHARACTERISTICS (#2) 
                tranBuilder.Append(LeftZeroFillOptionalField(freddieMacSpecialCharacteristics3.Trim(), 3));
                // 32-34: FREDDIE MAC SPECIAL CHARACTERISTICS (#3) 
                tranBuilder.Append(LeftZeroFillOptionalField(freddieMacSpecialCharacteristics4.Trim(), 3));
                // 35-37: FREDDIE MAC SPECIAL CHARACTERISTICS (#4) 
                tranBuilder.Append(LeftZeroFillOptionalField(freddieMacSpecialCharacteristics5.Trim(), 3));
                // 38-40: FREDDIE MAC SPECIAL CHARACTERISTICS (#5) 
                tranBuilder.Append(LeftZeroFillOptionalField(freddieMacSpecialCharacteristics6.Trim(), 3));
                // 41-43: FREDDIE MAC SPECIAL CHARACTERISTICS (#6) 
                tranBuilder.Append(FormatDate(noteDate.Trim())); // 44-49: NOTE DATE 
                tranBuilder.Append(' '); // 50: RESERVED
                tranBuilder.Append(numberOfBedroomsPerUnit1.Trim().PadRight(1)); // 51: NUMBER OF BEDROOMS PER UNIT 1
                tranBuilder.Append(' '); // 52: RESERVED
                tranBuilder.Append(numberOfBedroomsPerUnit2.Trim().PadRight(1)); // 53: NUMBER OF BEDROOMS PER UNIT 2
                tranBuilder.Append(' '); // 54: RESERVED
                tranBuilder.Append(numberOfBedroomsPerUnit3.Trim().PadRight(1)); // 55: NUMBER OF BEDROOMS PER UNIT 3
                tranBuilder.Append(' '); // 56: RESERVED
                tranBuilder.Append(numberOfBedroomsPerUnit4.Trim().PadRight(1)); // 57: NUMBER OF BEDROOMS PER UNIT 4
                tranBuilder.Append(' '); // 58: RESERVED
                tranBuilder.Append(LeftZeroFillOptionalField(numberOfBorrowers.Trim(), 2));
                // 59-60: NUMBER OF BORROWERS
                tranBuilder.Append(firstTimeHomeBuyer.Trim().PadRight(1)); // 61: FIRST TIME HOME BUYER 
                tranBuilder.Append(' ', 4); // 62-65: RESERVED
                tranBuilder.Append(FormatMoney(monthlyHousingExpense.Trim(), false, false, 5));
                // 66-70: MONTHLY HOUSING EXPENSE
                tranBuilder.Append(' ', 4); // 71-74: RESERVED
                tranBuilder.Append(FormatMoney(monthlyDebtExpense.Trim(), false, false, 5));
                // 75-79: MONTHLY DEBT EXPENSE
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}