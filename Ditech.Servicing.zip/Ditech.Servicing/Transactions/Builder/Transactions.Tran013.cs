#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 013 - Short Name and Code Maintenance (D-031).  
        /// Use transaction 013 (D-031) to enter or change basic billing information on the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="zipCode">(61-65) This field is optional. It indicates the zip code of the billing address, as assigned by the United States Postal Service. This replaces the zip code in the master file.</param>
        /// <param name="abbreviatedName">(66-75) This field is optional. Use the shortened name and initials in reporting when there is not enough room for the billing name. You can also use them in sorting indices. This replaces the abbreviated name in the master file.</param>
        /// <param name="ahFlag">(76) This field is optional. It allows or prevents this loan from being solicited for accident and health insurance coverage. You cannot add A&amp;H insurance to a loan with an A&amp;H flag of 9. This field replaces the A&amp;H flag in the master file.</param>
        /// <param name="lifeFlag">(77) This field is optional. It allows or prevents this loan from being solicited for life insurance coverage. You cannot add life insurance to a loan with a life flag of 9. This field replaces the life flag in the master file.</param>
        /// <param name="billMode">(78) This field is optional. It indicates the type of payment advice given the mortgagor or the corporation to which a loan belongs. This field replaces the bill mode in the master file.</param>
        /// <param name="employeeFlag">(79) This field is optional. It indicates whether the mortgagor is an employee of the servicer. Use this field also for sorting P-412. This field replaces the employee code in the master file.</param>
        /// <returns>Transaction 013 Card 2</returns>
        public static string Tran013c2(string loanNumber, string zipCode, string abbreviatedName, string ahFlag,
                                       string lifeFlag, string billMode, string employeeFlag)
        {
            string transaction;

            try
            {
                var transactionName = "013-2";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("2"); // 14: CARD CODE
                tranBuilder.Append(' ', 46); // 15-60: RESERVED
                tranBuilder.Append(FormatZipCode(zipCode.Trim())); // 61-65: ZIP CODE
                tranBuilder.Append(abbreviatedName.Trim().PadRight(10)); // 66-75: ABBREVIATED NAME
                tranBuilder.Append(ahFlag.Trim().PadRight(1)); // 76: A&H FLAG                     
                tranBuilder.Append(lifeFlag.Trim().PadRight(1)); // 77: LIFE FLAG         
                tranBuilder.Append(billMode.Trim().PadRight(1)); // 78: BILL MODE
                tranBuilder.Append(employeeFlag.Trim().PadRight(1)); // 79: EMPLOYEE FLAG
                tranBuilder.Append(' ', 1); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}