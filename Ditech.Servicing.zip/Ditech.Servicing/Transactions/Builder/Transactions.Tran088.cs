#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 088 - Late Charge Data for New Loans (D-021).
        /// Transaction 088 (D-021) Use transaction 088 to set up the late charge fields for new loans.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="lateChargeCode">(14) This field is required. It indicates the method for calculating late charges when they are assessed. This field is moved from input.</param>
        /// <param name="lateChargeFactor">(15-19) This field is required. If the late charge code equals A, B, C, G, or H, this field contains the percentage used to calculate the late charge. If the late charge code equals D, E, or F, this field contains the fixed dollar amount to be used for the late charge assessment. This field is moved from input.</param>
        /// <param name="minimumAmount">(20-23) This field is conditional. It indicates the minimum dollar amount that can be assessed as a late charge for the loan. If the late charge calculated using the percentage in the late charge factor is less than this amount, the minimum amount is used as the late charge assessed. This field is required for loans with a late charge code equal to A, B, C, G, or H. This field is moved from input.</param>
        /// <param name="maximumAmount">(24-29) This field is conditional. It indicates the maximum dollar amount that can be assessed as a late charge for the loan. If the late charge calculated using the percentage in the late charge factor is greater than this amount, the maximum amount is used as the late charge assessed. This field is required for loans with a late charge code equal to A, B, C, G, or H. This field is moved from input.</param>
        /// <param name="maximumRate">(30-34) This field is conditional. It contains the percentage used to determine the maximum limit of the late charge that may be assessed. The maximum limit is calculated as a percentage of P&amp;I, total payment, or principal balance, depending on the value of late charge code.</param>
        /// <param name="graceDays">(35-37) This field is optional. It contains the number of days that a loan may be delinquent before the system assesses late charges. This field is moved from input.</param>
        /// <param name="comparisonLateChargePercentage">(38-42) This field is optional. The loan's outstanding principal balance is multiplied by the contents of this field. The result of that multiplication is compared to the regularly calculated late charge amount, and the lesser of the two amounts is considered the calculated late charge.</param>
        /// <param name="lesser_GreaterValue">(43) This field is optional. Use it to specify if you want the calculated late charge to be the lesser or greater amount of the comparison late charge percentage.</param>
        /// <returns>Transaction 088</returns>
        public static string Tran088(string loanNumber, string lateChargeCode, string lateChargeFactor,
                                     string minimumAmount, string maximumAmount, string maximumRate, string graceDays,
                                     string comparisonLateChargePercentage, string lesser_GreaterValue)
        {
            string transaction;

            try
            {
                var transactionName = "088";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "lateChargeCode", lateChargeCode);
                CheckRequiredField(transactionName, "lateChargeFactor", lateChargeFactor);

                if (lateChargeCode.Trim() == "A" ||
                    lateChargeCode.Trim() == "B" ||
                    lateChargeCode.Trim() == "C" ||
                    lateChargeCode.Trim() == "G" ||
                    lateChargeCode.Trim() == "H")
                {
                    if (!IsAvailable(minimumAmount))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when lateChargeCode is set to A, B, C, G, or H.",
                                          transactionName, loanNumber, "minimumAmount"));

                    if (!IsAvailable(maximumAmount))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when lateChargeCode is set to A, B, C, G, or H.",
                                          transactionName, loanNumber, "maximumAmount"));
                }

                if (lateChargeCode.Trim() == "D" ||
                    lateChargeCode.Trim() == "E" ||
                    lateChargeCode.Trim() == "F")
                {
                    if (!IsAvailable(maximumRate))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when lateChargeCode is set to D, E, or F.",
                                          transactionName, loanNumber, "maximumRate"));
                }

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(lateChargeCode.Trim().PadRight(1)); // 14: LATE CHARGE CODE
                tranBuilder.Append(FormatPercent(lateChargeFactor.Trim(), 5)); // 15-19: LATE CHARGE FACTOR
                tranBuilder.Append(FormatMoney(minimumAmount.Trim(), true, false, 4)); // 20-23: MINIMUM AMOUNT
                tranBuilder.Append(FormatMoney(maximumAmount.Trim(), true, false, 6)); // 24-29: MAXIMUM AMOUNT
                tranBuilder.Append(FormatPercent(maximumRate.Trim(), 5)); // 30-34: MAXIMUM RATE
                tranBuilder.Append(LeftZeroFillOptionalField(graceDays.Trim(), 3)); // 35-37: GRACE DAYS
                tranBuilder.Append(FormatPercent(comparisonLateChargePercentage.Trim(), 5));
                // 38-42: COMPARISON LATE CHARGE PERCENTAGE
                tranBuilder.Append(lesser_GreaterValue.Trim().PadRight(1)); // 43: LESSER/GREATER VALUE
                tranBuilder.Append(' ', 37); // 44-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}