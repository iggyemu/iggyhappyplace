#region

using System;
using System.Text;
using Ditech.Servicing.Transactions.Models;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions : TransactionModels
    {
		#region�Methods�(9)�

		//�Public�Methods�(9)�

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="primeRateCode">(15-16) This field is optional. It identifies the loan as a prime rate loan. It is valid only for clients using the Prime Rate Loan enhancement.</param>
        /// <param name="billingDays">(17-18) This field is optional. It determines the number of days prior to the due date that a payment is produced. If the bill mode equals 5, this field determines the number of days prior to the due date that the bill is produced. If left blank, the default is 10 days.</param>
        /// <param name="propertyType">(19-21) This field is optional. It indicates the type of property securing the loan.</param>
        /// <param name="firstPaymentDueDate">(22-27) This field is optional. It indicates the due date of the first payment for a loan.</param>
        /// <param name="acquisitionDate">(28-33) This field is optional. It indicates the date of the loan acquisition. It is used by the year-end subsystem and report T-37C to exclude payment activity processed prior to acquisition reporting. If you enter this field, you must also enter an acquisition reporting flag. Refer to card 2, position 40, YEAR-END ACQUISITION REPORTING.</param>
        /// <param name="exemptCode1098">(34) This field is optional. It contains an exemption code that provides flexibility in reporting mortgage interest to mortgagors through annual statements and to the IRS through the IRS 1098 tape.</param>
        /// <param name="propertyTypeCode">(35) This field is optional. It indicates the type of property being mortgaged and is used for FHLBB and Freddie Mac MIDANET I reporting.</param>
        /// <param name="loanPurposeCode">(36) This field is optional. It establishes the loan purpose for HMDA, Freddie Mac, and Fannie Mae reporting.</param>
        /// <param name="ownershipTypeCode">(37) This field is optional. It establishes the type of ownership for MIDANET I reporting.</param>
        /// <param name="developmentTypeCode">(38) This field is optional. It establishes the type of housing development for MIDANET I reporting.</param>
        /// <param name="nonConformingLoanFlag">(39) This field indicates whether this loan is a nonconforming loan.</param>
        /// <param name="subsidiaryCode">(40) This field indicates whether this loan has been made to a related corporate entity.</param>
        /// <param name="acquisitionPrincipalBalance">(41-51) This field is optional. This field indicates the loan principal balance at the time the client acquired the loan.</param>
        /// <param name="ssnVerifyCode">(52) This field is optional. It records the number of P-40M requests produced for this loan. This field automatically updates by one each time a request is produced, but you may also manually update it.</param>
        /// <param name="reminderDays">(53-54) This field is optional. This field indicates whether a 10-day delinquency notice (P-197) should be automatically sent to the mortgagor or whether it should be blocked.</param>
        /// <param name="finalNoticeDays">(55-56) This field is optional. It indicates whether a 30-day delinquency notice (P-199) should be automatically sent to the mortgagor or whether it should be blocked.</param>
        /// <param name="ssnVerifyDate">(57-62) This field is optional. It records the date of the latest entry in the SSN VERIFY CODE field (1: 52). It is automatically updated each time the system processes a P-40M request, but you may manually update it.</param>
        /// <param name="ssnCertifyCode">(63) This field is optional. It records the latest response to P-40M requests, and you must update it manually. A blank in this field indicates that no response has been recorded.</param>
        /// <param name="ssnCertifyDate">(64-69) This field is optional. It records the date of the latest entry in the SSN CERTIFY CODE field (1: 63). It is automatically updated each time the SSN CERTIFY CODE field is updated, but you may update it manually.</param>
        /// <param name="fnmaProjectType">(70) This field is optional. It indicates the Fannie Mae project approval type for condominiums or co-ops and reports on Fannie Mae 2005 submission form (T-67Q) and magnetic tape.</param>
        /// <param name="irsPurposeCode">(71) This field is optional. It is user-defined and identifies mortgages incurred after 1987 for a purpose other than the purchase of a personal residence.</param>
        /// <param name="escrowDueFromClosing">(72-79) This field is optional. It records the initial escrow deposit amount collected at closing.</param>
        /// <param name="constructionLoanType">(80) This field is conditional. It is required to set up a construction loan. It identifies the loan as being for construction only or for the construction phase of a loan that will roll over to a permanent loan.</param>
        /// <returns>Transaction 084 Card 1</returns>
        public static string Tran084c1(string loanNumber, string primeRateCode, string billingDays, string propertyType,
                                       string firstPaymentDueDate, string acquisitionDate, string exemptCode1098,
                                       string propertyTypeCode, string loanPurposeCode, string ownershipTypeCode,
                                       string developmentTypeCode, string nonConformingLoanFlag, string subsidiaryCode,
                                       string acquisitionPrincipalBalance, string ssnVerifyCode, string reminderDays,
                                       string finalNoticeDays, string ssnVerifyDate, string ssnCertifyCode,
                                       string ssnCertifyDate, string fnmaProjectType, string irsPurposeCode,
                                       string escrowDueFromClosing, string constructionLoanType)
        {
            string transaction;

            try
            {
                var transactionName = "084-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(primeRateCode.PadRight(2)); // 15-16: PRIME RATE CODE
                tranBuilder.Append(LeftZeroFillOptionalField(billingDays, 2)); // 17-18: BILLING DAYS
                tranBuilder.Append(propertyType.PadRight(3)); // 19-21: PROPERTY TYPE
                tranBuilder.Append(FormatDate(firstPaymentDueDate)); // 22-27: 1ST PAYMENT DUE DATE
                tranBuilder.Append(FormatDate(acquisitionDate)); // 28-33: ACQUISITION DATE
                tranBuilder.Append(exemptCode1098.PadRight(1)); // 34: 1098 EXEMPT CODE
                tranBuilder.Append(propertyTypeCode.PadRight(1)); // 35: PROPERTY TYPE CODE
                tranBuilder.Append(loanPurposeCode.PadRight(1)); // 36: LOAN PURPOSE CODE
                tranBuilder.Append(ownershipTypeCode.PadRight(1)); // 37: OWNERSHIP TYPE CODE
                tranBuilder.Append(developmentTypeCode.PadRight(1)); // 38: DEVELOPMENT TYPE CODE
                tranBuilder.Append(nonConformingLoanFlag.PadRight(1)); // 39: NONCONFORMING LOAN FLAG
                tranBuilder.Append(subsidiaryCode.PadRight(1)); // 40: SUBSIDIARY CODE
                tranBuilder.Append(FormatMoney(acquisitionPrincipalBalance, true, false, 11));
                // 41-51: ACQUISITION PRINCIPAL BALANCE
                tranBuilder.Append(ssnVerifyCode.PadRight(1)); // 52: SSN VERIFY CODE
                tranBuilder.Append(reminderDays.PadRight(2)); // 53-54 REMINDER DAYS
                tranBuilder.Append(finalNoticeDays.PadRight(2)); // 55-56: FINAL NOTICE DAYS
                tranBuilder.Append(FormatDate(ssnVerifyDate)); // 57-62: SSN VERIFY DATE
                tranBuilder.Append(ssnCertifyCode.PadRight(1)); // 63: SSN CERTIFY CODE
                tranBuilder.Append(FormatDate(ssnCertifyDate)); // 64-69: SSN CERTIFY DATE
                tranBuilder.Append(fnmaProjectType.PadRight(1)); // 70: FNMA PROJECT TYPE
                tranBuilder.Append(irsPurposeCode.PadRight(1)); // 71: IRS PURPOSE CODE
                tranBuilder.Append(FormatMoney(escrowDueFromClosing, true, false, 8)); // 72-79: ESCROW DUE FROM CLOSING
                tranBuilder.Append(constructionLoanType.PadRight(1)); // 80: CONSTRUCTION LOAN TYPE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="userBillingTable">(15-34) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic.</param>
        /// <param name="stopBillingFlag">(35) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic.</param>
        /// <param name="billingCycle">(36-38) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic.</param>
        /// <param name="fnmaPlanNumber">(39-43) This field is optional. It identifies the number Fannie Mae has assigned to the program plan under which the loan was originated.</param>
        /// <param name="fhlmcReducedDocumentCode">(44) This field is optional. It enables lenders to track those loans originated under a Freddie Mac reduced document loan program.</param>
        /// <param name="recourseFlag">(45) This field is optional. It identifies loans sold or purchased with recourse.</param>
        /// <param name="recourseDate">(46-49) This field is optional. It contains the date at which the recourse provision expires.</param>
        /// <param name="accrualInterestRate">(50-56) This field is optional. It indicates the interest rate used in accrual reporting if different from the master file interest rate.</param>
        /// <param name="adpCode">(57-59) This field is optional. The information entered in this field is reported on HUD 92068-A SFDMS reports in the ADP code field. If ADP is not present on the master file, the FHA section number prints. HUD SFDMS reports are the only HUD reports that use this field. Other HUD reports use the section number. Refer to the most recent HUD-428 publication for a complete list of ADP code assignments.</param>
        /// <param name="payoffEffectiveDate">(60-65) This field is optional. It indicates the date through which the system calculates the payoff interest for a loan.</param>
        /// <param name="oldLoanNumberStopDate">(66-71) This field is optional. It indicates the date when the old loan number will no longer exist in the old loan number index.</param>
        /// <param name="classCode">(72-73) This field is optional. Use this field to classify loans for delinquency processing.</param>
        /// <param name="collectorDays">(74-76) This field is optional. It indicates how many days past the due date before the system selects the loan for delinquency processing.</param>
        /// <param name="firstDueDateOverride">(77) This field is optional. It indicates whether the 1ST DUE DATE and the DUE DATE are maintained together or one after the other. If you update this field, you should also update the 1ST DUE DATE field on card 1 of transaction 084 and the DUE DATE ADJ field on transaction 043 (D-006).</param>
        /// <param name="reasonableCauseCode">(78) This field is optional. It is a user-defined code that indicates your company's response to the IRS B notice received on this loan. Define the codes on the RCH1 screen in the Info Tracking Workstation.</param>
        /// <param name="suppressPrintYearEndStatement">(79) This field is optional. It indicates whether I-723 prints the statement generated in year-end. If this field is set to a user-defined value, I-723 does not print the statement and does not send the statement record to the MICR data tape (vendor tape). All other processing of the statement records occurs normally. Define the codes entered in this field on the SPIR screen in the MSP Info Tracking Workstation.</param>
        /// <param name="produceDetailHistory">(80) This field is optional. It is a code that indicates whether a detail history is desired for a given loan out of year-end processing.</param>
        /// <returns>Transaction 084 Card 3</returns>
        public static string Tran084c3(string loanNumber, string userBillingTable, string stopBillingFlag,
                                       string billingCycle, string fnmaPlanNumber, string fhlmcReducedDocumentCode,
                                       string recourseFlag, string recourseDate, string accrualInterestRate,
                                       string adpCode,
                                       string payoffEffectiveDate, string oldLoanNumberStopDate, string classCode,
                                       string collectorDays, string firstDueDateOverride, string reasonableCauseCode,
                                       string suppressPrintYearEndStatement, string produceDetailHistory)
        {
            string transaction;

            try
            {
                var transactionName = "084-3";

                transaction = Tran014c3(loanNumber.Trim(), userBillingTable.Trim(), stopBillingFlag.Trim(),
                                        billingCycle.Trim(), fnmaPlanNumber.Trim(),
                                        fhlmcReducedDocumentCode.Trim(), recourseFlag.Trim(), recourseDate.Trim(),
                                        adpCode.Trim(),
                                        payoffEffectiveDate.Trim(), oldLoanNumberStopDate.Trim(), classCode.Trim(),
                                        collectorDays.Trim(),
                                        reasonableCauseCode.Trim(), suppressPrintYearEndStatement.Trim(),
                                        produceDetailHistory.Trim());
                transaction =
                    string.Format("{0}{1}{2}{3}{4}{5}",
                                  transactionName.Substring(0, 3),
                                  transaction.Substring(3, 46),
                                  FormatPercent(accrualInterestRate.Trim(), 7),
                                  transaction.Substring(56, 21),
                                  firstDueDateOverride.Trim().PadRight(1),
                                  transaction.Substring(78));

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="escrowActivitityStatementDate">(15-21) This field is optional. It indicates the last time the activity statement was produced (Fidelity National Information Services [FIS] input only).</param>
        /// <param name="couponTapeDate">(22-27) The field is updated when bills are produced. The optional subsystems #149 and #296 use this field to determine the beginning history date.</param>
        /// <param name="autoNewOrderProcessingCode">(28-30) This field is used for audit purposes only.  See the NORM CODE field on transactions 119 (D-021) and 119 (D-218).</param>
        /// <param name="interestOnlyEndDate">(31-36) This field is optional. It is the date on which the payment of interest-only ends so that the mortgage begins to amortize with the first payment due after this date.</param>
        /// <param name="mortgageInsuranceAdjustorFlag">(37) This field is optional. It indicates that additional protection under the mortgage insurance coverage is required due to negative amortization.</param>
        /// <param name="freddieMacServicingTransfer">(38) This field is optional. It indicates the loan-level flag that allows the selection of individual loans for reporting on the Servicing Transfer Report Form 981A.</param>
        /// <param name="additionalTaxParcelsFlag">(39) This field is optional. It updates the loan-level flag that indicates whether additional tax parcels are present.</param>
        /// <param name="vaLoanIdNumber">(40-52) This field is optional. It includes a 12-digit, standardized number used for loan-level reporting to the Veterans Administration and the system-maintained VA loan ID switch.</param>
        /// <param name="noPurgeFlag">(53) This field is optional. It prevents the loan from being purged by I-7RS at year-end, or by I-7MD at May month-end.</param>
        /// <param name="purgeYear">(54-55) This field is optional. It is the year when the loan will purge at year-end if the NO PURGE FLAG (5: 53) is set. The loan purges only if all other purge criteria have been met.</param>
        /// <param name="escrowDocumentType">(56-57) This field is optional. It defines the document type used for escrow analysis calculations.</param>
        /// <param name="initialStatementCode">(58) This field is conditional. It identifies loans requiring an initial escrow statement or escrow history or projection.</param>
        /// <param name="initialEscrowStatementDate">(59-64) This field is conditional. It identifies when the system will produce an initial statement for a loan. If the INITIAL STATEMENT CODE field (5: 58) is 9, this date indicates the date the statement was created.</param>
        /// <param name="documentMinimumBalance">(65-69) This field is optional. It represents the number of escrow payments to be held in the account for a loan to reach its low point.</param>
        /// <param name="escrowComputationDate">(70-73) This field displays the month and year in which the next escrow computation year is scheduled to begin.</param>
        /// <param name="password">(74) This field is optional and is assigned by Fidelity National Information Services (FIS).</param>
        /// <param name="sellID">(75) This field is optional. It indicates if you have designated this loan for Countrywide Funding. Designating this loan enables Countrywide Funding to access master file information about this loan.</param>
        /// <param name="quarterlyBilling">(76) This field is optional. It indicates that this loan is set up for quarterly billing.</param>
        /// <param name="ebppCode">(79-80) This field is optional. It indicates that the loan is set up for EBPP.</param>
        /// <returns>Transaction 084 Card  5</returns>
        public static string Tran084c5(string loanNumber, string escrowActivitityStatementDate = "", string couponTapeDate = "",
                                       string autoNewOrderProcessingCode = "", string interestOnlyEndDate = "",
                                       string mortgageInsuranceAdjustorFlag = "", string freddieMacServicingTransfer = "",
                                       string additionalTaxParcelsFlag = "", string vaLoanIdNumber = "", string noPurgeFlag = "",
                                       string purgeYear = "", string escrowDocumentType = "", string initialStatementCode = "",
                                       string initialEscrowStatementDate = "", string documentMinimumBalance = "",
                                       string escrowComputationDate = "", string password = "", string sellID = "",
                                       string quarterlyBilling = "", string ebppCode = "")
        {
            string transaction;

            try
            {
                var transactionName = "084-5";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (initialStatementCode == "9" && !IsAvailable(escrowComputationDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: escrowComputationDate is required when initialStatementCode is 9.",
                                      transactionName, loanNumber));
                }

                if (IsAvailable(initialEscrowStatementDate) && !IsAvailable(initialStatementCode))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: initialStatementCode is required when initialEscrowStatementDate is present.",
                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                var i = tranBuilder.Length;

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("5"); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(escrowActivitityStatementDate.Trim(), 7));
                // 15-21: ESCROW ACTIVITY STATEMENT DATE 
                tranBuilder.Append(FormatDate(couponTapeDate.Trim())); // 22-27: COUPON-TAPE-DATE
                tranBuilder.Append(autoNewOrderProcessingCode.Trim().PadRight(3));
                // 28-30: AUTO-NEW-ORDER-PROCESSING-CODE
                tranBuilder.Append(FormatDate(interestOnlyEndDate.Trim())); // 31-36: INTEREST ONLY END DATE
                tranBuilder.Append(mortgageInsuranceAdjustorFlag.Trim().PadRight(1));
                // 37: MORTGAGE INSURANCE ADJUSTOR FLAG
                tranBuilder.Append(freddieMacServicingTransfer.Trim().PadRight(1));
                // 38: FREDDIE MAC SERVICING TRANSFER
                tranBuilder.Append(additionalTaxParcelsFlag.Trim().PadRight(1)); // 39: ADDITIONAL TAX PARCELS FLAG
                tranBuilder.Append(vaLoanIdNumber.Trim().PadRight(13)); // 40-52: VA LOAN ID NUMBER
                tranBuilder.Append(noPurgeFlag.Trim().PadRight(1)); // 53: NO PURGE FLAG
                tranBuilder.Append(LeftZeroFillOptionalField(purgeYear.Trim(), 2)); // 54-55: PURGE YEAR
                tranBuilder.Append(escrowDocumentType.Trim().PadRight(2)); // 56-57: ESCROW DOCUMENT TYPE
                tranBuilder.Append(initialStatementCode.Trim().PadRight(1)); // 58: INITIAL STATEMENT CODE
                tranBuilder.Append(FormatDate(initialEscrowStatementDate.Trim()));
                // 59-64: INITIAL ESCROW STATEMENT DATE
                tranBuilder.Append(LeftZeroFillOptionalField(documentMinimumBalance.Trim(), 5));
                // 65-69: DOCUMENT MINIMUM BALANCE
                tranBuilder.Append(LeftZeroFillOptionalField(escrowComputationDate.Trim(), 4));
                // 70-73: ESCROW COMPUTATION DATE
                tranBuilder.Append(password.Trim().PadRight(1)); // 74: PASSWORD
                tranBuilder.Append(sellID.Trim().PadRight(1)); // 75: SELL ID
                tranBuilder.Append(quarterlyBilling.Trim().PadRight(1)); // 76: QUARTERLY BILLING
                tranBuilder.Append(' ', 2); // 77-78: RESERVED
                tranBuilder.Append(ebppCode.Trim().PadRight(2)); // 79-80: EBPP CODE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="currentAppraisalDate">(19-24) This field is optional. It indicates the date that the property for this loan was appraised.</param>
        /// <param name="currentLandAppraisal">(36-46) This field is optional. It indicates the current appraisal value of the land.</param>
        /// <param name="originalLandOnlyAppraisal">(47-57) This field is optional. It indicates the original appraisal value of the land.</param>
        /// <param name="loanModificationType">(73) This field is conditional. It is required if you enter a loan modification date. This field indicates the type of loan modification completed, approved, or authorized.</param>
        /// <param name="loanModificationDate">(74-79) This field is conditional. It is required if you enter a loan modification type. This field indicates the date the loan modification was completed, approved, or authorized. The date can be a past, present or future date.</param>
        /// <param name="restructuredFlag">(80) This field is optional. It indicates restructured loans that are bank owned and being reported to the Federal Financial Institutions Examination Council (FFIEC).</param>
        /// <returns>Transaction 084 Card  6</returns>
        public static string Tran084c6(string loanNumber, string currentAppraisalDate = "", string currentLandAppraisal = "", string originalLandOnlyAppraisal = "", string loanModificationType = "", string loanModificationDate = "", string restructuredFlag = "")
        {
            string transaction;

            try
            {
                var transactionName = "084-6";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(loanModificationType) && !IsAvailable(loanModificationDate))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: investorDelinquencyDate is required when investorDelinquencyType is present.",
                            transactionName, loanNumber));
                }

                if (IsAvailable(loanModificationDate) && !IsAvailable(loanModificationType))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: investorDelinquencyType is required when investorDelinquencyDate is present.",
                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("6"); // 14: CARD CODE
                tranBuilder.Append(' ', 4); // 15-18: RESERVED
                tranBuilder.Append(FormatDate(currentAppraisalDate.Trim())); // 19-24: CURRENT APPRAISAL DATE
                tranBuilder.Append(' '); // 25: RESERVED
                tranBuilder.Append(' ', 9); // 26-34: RESERVED
                tranBuilder.Append(' '); // 35: RESERVED
                tranBuilder.Append(FormatMoney(currentLandAppraisal, false, false, 11)); // 36-46: CURRENT LAND APPRAISAL
                tranBuilder.Append(FormatMoney(originalLandOnlyAppraisal, false, false, 11)); // 47-57: ORIGINAL LAND ONLY APPRAISAL
                tranBuilder.Append(' ', 15); // 58-72: RESERVED
                tranBuilder.Append(loanModificationType.Trim().PadRight(1)); // 73: LOAN MODIFICATION TYPE
                tranBuilder.Append(FormatDate(loanModificationDate.Trim())); // 74-79: LOAN MODIFICATION DATE
                tranBuilder.Append(restructuredFlag.Trim().PadRight(1)); // 80: RESTRUCTURED-FLAG
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="queueDropDate">(16-21) This is the date through which a loan will be dropped from an active suspense queue.</param>
        /// <param name="pmspOllwSw">(22) This is a system-generated Online LetterWriter switch that indicates whether a letter was produced from the Suspense Processing Screen (PMSP) in the Cashiering Workstation.</param>
        /// <param name="lossMitigationIndicator">(23) This field is optional. Use it for tracking any loan that is in workout.</param>
        /// <param name="investorDelinquencyStatus">(24-25) This field is conditional. It is required if you make an entry in the INVESTOR DELINQUENCY REASON field (7: 26-28). It indicates the delinquency status for a specific loan you want to report.</param>
        /// <param name="investorDelinquencyReason">(26-28) This field is conditional. It is required if you make an entry in the INVESTOR DELINQUENCY STATUS field (7: 24-25). It indicates the reason for delinquency of a specific loan.</param>
        /// <param name="investorDelincquencyReportDate">(30-35) This field indicates the date on which the T-3FN report was last generated. No entry. This field is system-filled.</param>
        /// <param name="originalHouseholdExpense">(36-42) This field is optional. It indicates the amount of household expenses used in the approval of the loan application.</param>
        /// <param name="originalOccupancyStatus">(43) This field is optional. It indicates the intended use of the property at the time the loan was originated.</param>
        /// <param name="curtailmentInterestFlag">(45) This field is optional. It indicates if a loan is allowed to have curtailment interest calculated.</param>
        /// <param name="balance">(46-56) This field is optional. It contains the amount of curtailment interest in the master. This field is calculated and updated automatically; however, you can also update this field manually.</param>
        /// <param name="custodianCode">(57) This field is conditional. It identifies the physical location of a loan package or documents.</param>
        /// <param name="creditDecisionByLender">(58) This field is optional. It indicates whether the credit decision on the loan was made by the lender when a loan was acquired by a third party. The HMDA subsystem uses it to determine HMDA Action Taken type for wholesale loans.</param>
        /// <param name="originalPropertyValue">(70-78) This field is optional. It indicates the appraised dollar value of the property when the loan was originated.</param>
        /// <param name="originalSelfEmployed">(79) This field is optional. It indicates whether the borrower was self-employed when the loan was originated.</param>
        /// <returns>Transaction 084 Card  7</returns>
        public static string Tran084c7(string loanNumber, string queueDropDate = "", string pmspOllwSw = "",
                                       string lossMitigationIndicator = "", string investorDelinquencyStatus = "",
                                       string investorDelinquencyReason = "", string investorDelincquencyReportDate = "",
                                       string originalHouseholdExpense = "", string originalOccupancyStatus = "",
                                       string curtailmentInterestFlag = "", string balance = "", string custodianCode = "",
                                       string creditDecisionByLender = "", string originalPropertyValue = "",
                                       string originalSelfEmployed = "")
        {
            string transaction;

            try
            {
                var transactionName = "084-7";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(investorDelinquencyStatus) && !IsAvailable(investorDelinquencyReason))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: investorDelinquencyReason is required when investorDelinquencyStatus is present.",
                            transactionName, loanNumber));
                }

                if (IsAvailable(investorDelinquencyReason) && !IsAvailable(investorDelinquencyStatus))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: investorDelinquencyStatus is required when investorDelinquencyReason is present.",
                            transactionName, loanNumber));
                }


                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("7"); // 14: CARD CODE
                tranBuilder.Append(' '); // 15: RESERVED
                tranBuilder.Append(FormatDate(queueDropDate.Trim())); // 16-21: QUEUE-DROP-DATE
                tranBuilder.Append(pmspOllwSw.Trim().PadRight(1)); // 22: PMSP-OLLW-SW
                tranBuilder.Append(lossMitigationIndicator.Trim().PadRight(1)); // 23: LOSS MITIGATION INDICATOR
                tranBuilder.Append(LeftZeroFillOptionalField(investorDelinquencyStatus.Trim(), 2));
                // 24-25: INVESTOR DELINQUENCY STATUS
                tranBuilder.Append(investorDelinquencyReason.Trim().PadRight(3)); // 26-28: INVESTOR DELINQUENCY REASON
                tranBuilder.Append(' '); // 29: RESERVED
                tranBuilder.Append(FormatDate(investorDelincquencyReportDate.Trim()));
                // 30-35: INVESTOR DELINQUENCY REPORT DATE
                tranBuilder.Append(LeftZeroFillOptionalField(originalHouseholdExpense.Trim(), 7));
                // 36-42: ORIGINAL HOUSEHOLD EXPENSE
                tranBuilder.Append(originalOccupancyStatus.Trim().PadRight(1)); // 43: ORIGINAL OCCUPANCY STATUS
                tranBuilder.Append(' '); // 44: RESERVED
                tranBuilder.Append(curtailmentInterestFlag.Trim().PadRight(1)); // 45: CURTAILMENT INTEREST FLAG
                tranBuilder.Append(LeftZeroFillOptionalField(balance.Trim(), 11));
                // 46-56: BALANCE
                tranBuilder.Append(custodianCode.Trim().PadRight(1)); // 57: CUSTODIAN CODE
                tranBuilder.Append(creditDecisionByLender.Trim().PadRight(1)); // 58: CREDIT DECISION BY LENDER
                tranBuilder.Append(' ', 11); // 59-69: RESERVED
                tranBuilder.Append(FormatMoney(originalPropertyValue.Trim(), false, false, 9));
                // 70-78: ORIGINAL PROPERTY VALUE
                tranBuilder.Append(originalSelfEmployed.Trim().PadRight(1)); // 79: ORIGINAL SELF-EMPLOYED
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <returns>Transaction 084 Card  7</returns>
        public static string Tran084c7(Tran084c7Model model)
        {
            string transaction;

               var transactionName = "084-7";

                CheckValidLoanNumber(transactionName,model.LoanNumber);

                if (IsAvailable(model.InvestorDelinquencyStatus) && !IsAvailable(model.InvestorDelinquencyReason))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: investorDelinquencyReason is required when investorDelinquencyStatus is present.",
                            transactionName,model.LoanNumber));
                }

                if (IsAvailable(model.InvestorDelinquencyReason) && !IsAvailable(model.InvestorDelinquencyStatus))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: investorDelinquencyStatus is required when investorDelinquencyReason is present.",
                            transactionName,model.LoanNumber));
                }


                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("7"); // 14: CARD CODE
                tranBuilder.Append(' '); // 15: RESERVED
                tranBuilder.Append(FormatDate(TrimAndPad(model.QueueDropDate,4))); // 16-21: QUEUE-DROP-DATE
                tranBuilder.Append(' '); // 22: PMSP-OLLW-SW
                tranBuilder.Append(TrimAndPad(model.LossMitigationIndicator,1)); // 23: LOSS MITIGATION INDICATOR
                tranBuilder.Append(TrimAndPad(model.InvestorDelinquencyStatus,2)); // 24-25: INVESTOR DELINQUENCY STATUS
                tranBuilder.Append(TrimAndPad(model.InvestorDelinquencyReason,3)); // 26-28: INVESTOR DELINQUENCY REASON
                tranBuilder.Append(' '); // 29: RESERVED
                tranBuilder.Append(' ', 6); // 30-35: INVESTOR DELINQUENCY REPORT DATE
                tranBuilder.Append(TrimAndPad(Convert.ToZonedString(model.OriginalHouseholdExpense),7)); // 36-42: ORIGINAL HOUSEHOLD EXPENSE
                tranBuilder.Append(TrimAndPad(model.OriginalOccupancyStatus,1)); // 43: ORIGINAL OCCUPANCY STATUS
                tranBuilder.Append(' '); // 44: RESERVED
                tranBuilder.Append(TrimAndPad(model.CurtailmentInterestFlag,1)); // 45: CURTAILMENT INTEREST FLAG
                tranBuilder.Append(TrimAndPad(Convert.ToZonedString(model.Balance), 11)); // 46-56: BALANCE
                tranBuilder.Append(TrimAndPad(model.CustodianCode,1)); // 57: CUSTODIAN CODE
                tranBuilder.Append(TrimAndPad(model.CreditDecisionByLender,1)); // 58: CREDIT DECISION BY LENDER
                tranBuilder.Append(' ', 11); // 59-69: RESERVED
                tranBuilder.Append(TrimAndPad(Convert.ToZonedString(model.OriginalPropertyValue),9)); // 70-78: ORIGINAL PROPERTY VALUE
                tranBuilder.Append(TrimAndPad(model.OriginalSelfEmployed,1)); // 79: ORIGINAL SELF-EMPLOYED
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(model.LoanNumber.Trim().PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER

                

                if (tranBuilder.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
            tranBuilder.AppendLine();
            transaction = tranBuilder.ToString();
            
            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="creditQualityOriginal">(15-19) This field is optional. This field indicates the mortgagor's credit quality, score, or rating at the time of origination.</param>
        /// <param name="creditQualityCurrent">(20-24) This field is optional. It indicates the mortgagor's most current credit quality, score, or rating.</param>
        /// <param name="creditQualityEntryDate">(25-30) This field is optional. This field indicates the date on which the current credit quality, score, or rating determination was made.</param>
        /// <param name="creditQualityAgent">(31-34) This field is optional. This field indicates the name of the credit agency or credit bureau that provided the credit quality, score, or rating.</param>
        /// <param name="creditQualityReasonCode">(35-36) This field is optional. This field indicates the reason for the credit quality, score, or rating.</param>
        /// <param name="ausSystem">(37-38) This field is optional. It is a user-defined code that identifies which automated underwriting system was used to deliver the loans to underwriting.</param>
        /// <param name="ausIdentificationKey">(39-53) This field is conditional. It is required if the user entered a value in the AUS SYSTEM field (A: 37-38). This user-defined code identifies loans submitted through an automated underwriting system for approval.</param>
        /// <param name="holdBillReceiptDate">(67-72) This field is optional. It indicates the date on which the bill/receipt process should resume. This field is available only if the bill mode is 8 or 9.</param>
        /// <param name="subprimeFlag">(73) This field is optional. It indicates whether the loan was considered a subprime loan at the time of origination.</param>
        /// <param name="riskGradeCurrent">(74) This field is optional. It indicates the current score assigned to the loan based upon the credit score and scoring model used.</param>
        /// <param name="vaLoanGuarantyPercent">(75-80) This field is optional. It indicates the percentage of the loan amount that the VA will reimburse the lender if the loan is a VA no-bid.</param>
        /// <returns>Transaction 084 Card  A</returns>
        public static string Tran084cA(string loanNumber, string creditQualityOriginal = "", string creditQualityCurrent = "",
                                       string creditQualityEntryDate = "", string creditQualityAgent = "",
                                       string creditQualityReasonCode = "", string ausSystem = "", string ausIdentificationKey = "",
                                       string holdBillReceiptDate = "", string subprimeFlag = "", string riskGradeCurrent = "",
                                       string vaLoanGuarantyPercent = "")
        {
            string transaction;

            try
            {
                var transactionName = "084";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(ausSystem) && !IsAvailable(ausIdentificationKey))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Aus Identification Key required when Aus System is present.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("A"); // 14: CARD CODE
                tranBuilder.Append(creditQualityOriginal.Trim().PadRight(5)); // 15-19: CREDIT QUALITY: ORIGINAL
                tranBuilder.Append(creditQualityCurrent.Trim().PadRight(5)); // 20-24: CREDIT QUALITY: CURRENT
                tranBuilder.Append(FormatDate(creditQualityEntryDate.Trim())); // 25-30: CREDIT QUALITY: ENTRY DATE
                tranBuilder.Append(creditQualityAgent.Trim().PadRight(4)); // 31-34: CREDIT QUALITY: AGENT
                tranBuilder.Append(creditQualityReasonCode.Trim().PadRight(2)); // 35-36: CREDIT QUALITY: REASON CODE
                tranBuilder.Append(ausSystem.Trim().PadRight(2)); // 37-38: AUS SYSTEM
                tranBuilder.Append(ausIdentificationKey.Trim().PadRight(15)); // 39-53: AUS IDENTIFICATION KEY
                tranBuilder.Append(' ', 13); // 39-53: RESERVED
                tranBuilder.Append(FormatDate(holdBillReceiptDate.Trim())); // 67-72: HOLD BILL RECEIPT DATE
                tranBuilder.Append(subprimeFlag.Trim().PadRight(1)); // 73: SUBPRIME FLAG
                tranBuilder.Append(riskGradeCurrent.Trim().PadRight(1)); // 74: RISK GRADE CURRENT
                tranBuilder.Append(FormatPercent(vaLoanGuarantyPercent.Trim(), 6)); // 75-80: VA LOAN GUARANTY PERCENT
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="borrower_mortgagorEmailAddress">(15-80) This field is optional. It indicates the primary borrower/mortgagor's e-mail address. If you enter this field, the system copies the address to the EMAIL-ADDRESS field in the customer profile header utility and sets the CUSTOMER-PROFILE-HDR field to 1 in the loan master.</param>
        /// <returns>Transaction 084 Card E</returns>
        public static string Tran084cE(string loanNumber, string borrower_mortgagorEmailAddress = "")
        {
            string transaction;

            try
            {
                var transactionName = "084";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("E"); // 14: CARD CODE
                tranBuilder.Append(borrower_mortgagorEmailAddress.Trim().PadRight(66));
                // 15-80: BORROWER/MORTGAGOR EMAIL ADDRESS
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="borrowerMorgatgagorFaxNumber">(15-24) This field is optional. It indicates the primary borrower/mortgagor�s fax number.</param>
        /// <param name="cancellationDate">(25-30) This field is conditional. If you add, change or clear this field, you must type # in the PMI CANCEL SW field (F: 65). It indicates the date on which the borrower may request cancellation of the mortgage insurance, subject to any investor requirements.</param>
        /// <param name="terminationDate">(31-36) This field is conditional. If you add, change or clear this field, you must type # in the PMI TERM SW field (F: 66). It indicates the date based upon the amortization schedule on which the private mortgage insurance must automatically be terminated if the borrower is current.</param>
        /// <param name="midPointDate">(37-42) This field is conditional. If you add, change or clear this field, you must type # in the PMI MIDPOINT SW field (F: 67). It indicates the date based upon the amortization schedule on which the loan is scheduled to pass the midpoint of the amortization schedule and the private mortgage insurance must be terminated.</param>
        /// <param name="highRiskIndicator">(43) This field is optional. It indicates that the loan was considered high risk at the time of closing. The values for this field are user-defined.</param>
        /// <param name="requestToCancelDate">(44-49) This field is optional. It indicates the date on which the servicer received the borrower�s request to cancel private mortgage insurance.</param>
        /// <param name="miType">(50) This field is optional. It indicates the type of mortgage insurance in place for the loan. The values for this field are user-defined.</param>
        /// <param name="processorId">(51-53) This field is optional. It indicates the processor ID of the person who last maintained the data.</param>
        /// <param name="mplPlanId">(54-57) This field is conditional. It is required when you want to associate a loan with an individual modified payment logic (MPL) plan. It indicates the plan you want to associate with this loan.</param>
        /// <param name="suspenseUnavailable">(58) This field is optional. It indicates whether suspense funds are available for use in modified payment processing. The system uses the field to prevent borrower incentive (BI) funds that are reversed or applied to suspense on a HAMP loan from being used to pay other amounts due during an automatic sweep of the suspense account.</param>
        /// <param name="resetLssDate">(59-62) This field is optional. Use it to reset the LSS DISB DATE (MFF #12445) field in the master file.</param>
        /// <param name="pmiGseReason">(63-64) This field is conditional. It indicates the required investor-defined reason code when you cancel PMI coverage.</param>
        /// <param name="pmiCancelSw">(65) This field is conditional. This field is required if you add, maintain or clear the CANCELLATION DATE field through batch process. It indicates whether the system updated the CANCELLATION DATE field or if it needs to calculate and update the field. The system generates the value in this field or you may delete it. The value in this field updates the CANCELLATION-DATE (MFF #13280) field in the master file.</param>
        /// <param name="pmiTermSw">(66) This field is conditional. This field is required if you add, maintain or clear the TERMINATION DATE field through batch process. It indicates whether the system updated the TERMINATION DATE field or if it needs to calculate and update the field. The system generates the value in this field or you may delete it. The value in this field updates the TERMINATION-DATE (MFF #13285) field in the master file.</param>
        /// <param name="pmiMidpointSw">(67) This field is conditional. This field is required if you add, maintain or clear the MIDPOINT DATE field through batch process. It indicates whether the system updated the MIDPOINT DATE field or if it needs to calculate and update the field. The system generates the value in this field or you may delete it. This field updates the MID-POINT-DATE (MFF #13290) field in the master file.</param>
        /// <param name="scorecardAccessCode">(68-69) This field is not used.</param>
        /// <param name="rpyPlnInd">(70-71) This field is optional. It indicates the type of repayment plan for the loan.</param>
        /// <param name="alternateClientHeaderCode">(73-77) This field is available if you are installed on IP 2043. This field is optional. It indicates the alternate client header ID the system uses when routing funds to payees set up on the Alternate Client Header screen (ALTH) in the Alternate Client Header Workstation instead of those payees indicated on the Client Header Maintenance screen (DEIE) in the MSP Mortgage Online Data Entry (MODE) system.</param>
        /// <returns>Transaction 084 Card  F</returns>
        public static string Tran084cF(string loanNumber, string borrowerMorgatgagorFaxNumber = "", string cancellationDate = "",
                                       string terminationDate = "", string midPointDate = "",
                                       string highRiskIndicator = "", string requestToCancelDate = "", string miType = "",
                                       string processorId = "", string mplPlanId = "", string suspenseUnavailable = "",
                                       string resetLssDate = "", string pmiGseReason = "", string pmiCancelSw = "", string pmiTermSw = "", 
                                       string pmiMidpointSw = "", string scorecardAccessCode = "", string rpyPlnInd = "", string alternateClientHeaderCode = "")
        {
            string transaction;

            try
            {
                var transactionName = "084";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(pmiCancelSw) && !IsAvailable(cancellationDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Cancellation Date required when PMI Cancel Sw is present.",
                                      transactionName, loanNumber));
                }

                if (IsAvailable(pmiTermSw) && !IsAvailable(terminationDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Termination Date required when PMI Term Sw is present.",
                                      transactionName, loanNumber));
                }

                if (IsAvailable(pmiMidpointSw) && !IsAvailable(midPointDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Midpoint Date required when PMI Midpoint Sw is present.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("F"); // 14: CARD CODE
                tranBuilder.Append(borrowerMorgatgagorFaxNumber.Trim().PadRight(10));
                    // 15-24: BORROWER/MORTGAGOR FAX NUMBER
                tranBuilder.Append(FormatDate(cancellationDate.Trim())); // 25-30: CANCELLATION DATE
                tranBuilder.Append(FormatDate(terminationDate.Trim())); // 31-36: TERMINATION DATE
                tranBuilder.Append(FormatDate(midPointDate.Trim())); // 37-42: MID POINT DATE
                tranBuilder.Append(highRiskIndicator.Trim().PadRight(1)); // 43: HIGH RISK INDICATOR
                tranBuilder.Append(FormatDate(requestToCancelDate.Trim())); // 44-49: REQUEST TO CANCEL DATE
                tranBuilder.Append(miType.Trim().PadRight(1)); // 50: MI TYPE
                tranBuilder.Append(processorId.Trim().PadRight(3)); // 51-53: PROCESSOR ID
                tranBuilder.Append(mplPlanId.Trim().PadRight(4)); // 54-57: MPL PLAN ID
                tranBuilder.Append(suspenseUnavailable.Trim().PadRight(1)); // 58: SUSPENSE UNAVAILABLE
                tranBuilder.Append(FormatDate(resetLssDate.Trim(), "MMyy")); // 59-62: RESET LSS DATE
                tranBuilder.Append(pmiGseReason.Trim().PadRight(2)); // 63-64: PMI GSE REASON
                tranBuilder.Append(pmiCancelSw.Trim().PadRight(1)); // 65: PMI CANCEL SW
                tranBuilder.Append(pmiTermSw.Trim().PadRight(1)); // 66: PMI TERM SW
                tranBuilder.Append(pmiMidpointSw.Trim().PadRight(1)); // 67: PMI MIDPOINT SW
                tranBuilder.Append(scorecardAccessCode.Trim().PadRight(2)); // 68-69: SCORECARD ACCESS CODE
                tranBuilder.Append(rpyPlnInd.Trim().PadRight(2)); // 70-71: RPY PLN IND
                tranBuilder.Append(' '); // 72: RESERVED
                tranBuilder.Append(alternateClientHeaderCode.Trim().PadRight(5)); // 73-77: ALTERNATE CLIENT HEADER CODE
                tranBuilder.Append(' ', 3); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        public static string Tran084cH(Tran084cHModel model)
        {
            string transaction;

            
                var transactionName = "084 - H";

                CheckValidLoanNumber(transactionName,model.LoanNumber);

            if (IsAvailable(model.ChargeOffDate) && !IsAvailable(model.ChargeOffBalance))
            {
                throw new Exception(string.Format("{0}: {1}: ,Charge off date is required if the charge off balance is present",transactionName,model.LoanNumber));
            }
            if (!IsAvailable(model.ChargeOffDate) && IsAvailable(model.ChargeOffBalance))
            {
                throw new Exception(string.Format("{0}: {1}: ,Charge off balance is required if the charge off date is present",transactionName,model.LoanNumber));
            }
            var tranClient = transactionName.Left(3) + CLIENT_NUMBER;
            var tranbuilder = new StringBuilder();
            tranbuilder.Append(tranClient); // 1-6 Transaction and Client Number
            tranbuilder.Append("*".PadRight(7)); // 7-13 Loan Number
            tranbuilder.Append("H"); // 14 Card Code
            tranbuilder.Append(TrimAndPad(model.Chapter7Discharge,1)); // 15 Chapter 7 Discharge
            tranbuilder.Append(FormatDate(TrimAndPad(model.DischargeDate,6))); // 16-21 Discharge Date
            tranbuilder.Append(FormatDate(TrimAndPad(model.FirstLegalActionDate,6))); // 22-27 1st Legal Action Date
            tranbuilder.Append(FormatDate(TrimAndPad(model.ChargeOffDate,6))); // 28-33 Charge off Date
            tranbuilder.Append(TrimAndPad(Convert.ToZonedString(model.ChargeOffBalance),11)); // 34-44 Charge off Balance
            tranbuilder.Append(TrimAndPad(model.LoanComplianceCode,2)); // 45-46 Loan Compliance Code
            tranbuilder.Append(TrimAndPad(model.BorrowerRelationCode,1)); // 47 Borrower Relation Code
            tranbuilder.Append(TrimAndPad(model.CoBorrowerRelationCode,1)); // 48 Co-Borrower Relation Code
            tranbuilder.Append(TrimAndPad(model.BorrowerConsumerInformationCodeOne,1)); // 49 Borrower Consumer Information Code 1
            tranbuilder.Append(TrimAndPad(model.BorrowerConsumerInformationCodeTwo,1)); // 50 Borrower Consumer Information Code 2
            tranbuilder.Append(TrimAndPad(model.CoBorrowerConsumerInformationCodeOne,1)); // 51 Co-Borrower Consumer Information Code 1
            tranbuilder.Append(TrimAndPad(model.CoBorrowerconsumerInformationCodeTwo,1)); // 52 Co-Borrower Consumer Information Code 2
            tranbuilder.Append(' ', 2); // 53-54 RESERVED
            tranbuilder.Append(' ', 6); // 55-60 Negative Notice
            tranbuilder.Append(TrimAndPad(model.MortgagorLanguagePreference,2)); // 61-62 Mortgagor Language Preference
            tranbuilder.Append(TrimAndPad(model.VADefaultReaon,3)); // 63-65 VA Default Reason
            tranbuilder.Append(FormatDate(TrimAndPad(model.FannieMaeStatusEffectiveDate,6))); // 66-71 Fannie Mae Status Effective Date
            tranbuilder.Append(FormatDate(TrimAndPad(model.FannieMaeExpectedCompletionDate,6))); // 72-77 Fannie Mae Expected Completion Date
            tranbuilder.Append(TrimAndPad(model.K4Segment,1)); // 78 K4 Segment
            tranbuilder.Append(TrimAndPad(model.MortgagorCBRIndicatorSwitch,1)); // 79 Mortgagor CBR Indicator Switch
            tranbuilder.Append(TrimAndPad(model.CoBorrowerCBRIndicatorSwitch,1)); // 80 Co-Mortgagor CBR Indicator Switch
            tranbuilder.Append(' ', 9); // 81-89 RESERVED
            tranbuilder.Append(model.LoanNumber.Trim().PadLeft(13,'0')); // 90-102 Expanded Loan Number
            
            if (tranbuilder.Length != 102)
            {
                throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranbuilder));
            }
            tranbuilder.AppendLine();
            transaction = tranbuilder.ToString();

            return transaction;

        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="coBorrowerRiskGrade">(37) This field indicates the risk grade based on the credit score information. This is a standard score agreed upon by multiple scoring agencies that only Freddie Mac uses.</param>
        /// <param name="imminentDefaultFlag">(38) This field is optional. It indicates whether the loan was in a state of imminent default.</param>
        /// <param name="ssriInd">(39-41) This field is optional.  It contains the indicator code tied to a loan that requires special servicing. This field must contain an indicator code set up on the SSR Indicator Codes screen (SSRI) in the Default Reporting Workstation or the transaction will fail.</param>
        /// <param name="modificationProgram">(42-45) This field is optional. It indicates the program under which the loan was modified. The value you type must correspond with the value in the CD field on the Modification Program Types work window in the MSP Info Tracking Workstation.</param>
        /// <param name="modificationStatus">(46-47) This field is conditional. It is required if the MODIFICATION STATUS DATE field is populated. It indicates the status of the loan modification.</param>
        /// <param name="modificationStatusDate">(48-53) This field is conditional. It is required if the MODIFICATION STATUS field is populated. This field indicates the date associated with the modification status. </param>
        /// <param name="modificationStatusReasonCode">(54-55) This field is optional. It indicates the reason the loan modification was cancelled, terminated, or denied. The value you type must correspond with the value in the CD field on the Modification Reason Codes work window in the MSP Info Tracking Workstation.</param>
        /// <param name="modificationUserId">(56-58) This field indicates the user ID of the individual who is updating the modification status, status date or status reason.</param>
        /// <param name="coBorrowerCreditQualityOriginal">(59-63) This field is optional. This field indicates the co-borrower's credit quality, score, or rating at the time of origination.</param>
        /// <param name="coBorrowerCreditQualityCurrent">(64-68) This field is optional. It indicates the co-borrower's most current credit quality, score, or rating.</param>
        /// <param name="coBorrowerCreditQualityCurrentDate">(69-74) This field indicates the determination date for the co-borrower's most current credit quality, score, or rating.</param>
        /// <param name="coBorrowerCreditQualityAgent">(75-78) This field indicates the name of the credit agency or credit bureau that provided the credit quality, score, or rating.</param>
        /// <param name="coBorrowerCreditQualityReasonCode">(79-80) This field indicates the reason for the credit quality, score, or rating.</param>
        /// <returns>Transaction 084 Card M</returns>
        public static string Tran084cM(string loanNumber, string coBorrowerRiskGrade = "", string imminentDefaultFlag = "", string ssriInd = "", string modificationProgram = "", string modificationStatus = "", string modificationStatusDate = "", string modificationStatusReasonCode = "", string modificationUserId = "", string coBorrowerCreditQualityOriginal = "", string coBorrowerCreditQualityCurrent = "", string coBorrowerCreditQualityCurrentDate = "", string coBorrowerCreditQualityAgent = "", string coBorrowerCreditQualityReasonCode = "")
        {
            string transaction;

            try
            {
                var transactionName = "084-M";

                CheckValidLoanNumber(transactionName, loanNumber);

                
                if (IsAvailable(modificationStatus) && !IsAvailable(modificationStatusDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Modification Status Date required when Modification Status is present.",
                                      transactionName, loanNumber));
                }

                if (!IsAvailable(modificationStatus) && IsAvailable(modificationStatusDate))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Modification Status required when Modification Status Date is present.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName.Left(3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("M"); // 14: CARD CODE
                tranBuilder.Append(' ', 22); // 15-36: RESERVED
                tranBuilder.Append(coBorrowerRiskGrade.Trim().PadRight(1)); // 37: CO-BORROWER RISK GRADE
                tranBuilder.Append(imminentDefaultFlag.Trim().PadRight(1)); // 38: IMMINENT DEFAULT FLAG
                tranBuilder.Append(ssriInd.Trim().PadRight(3)); // 39-41: SSRI-IND
                tranBuilder.Append(modificationProgram.Trim().PadRight(4)); // 42-45: MODIFICATION PROGRAM
                tranBuilder.Append(modificationStatus.Trim().PadRight(2)); // 46-47: MODIFICATION STATUS
                tranBuilder.Append(FormatDate(modificationStatusDate.Trim())); // 48-53: MODIFICATION STATUS DATE
                tranBuilder.Append(modificationStatusReasonCode.Trim().PadRight(2)); // 54-55: MODIFICATION STATUS REASON CODE
                tranBuilder.Append(modificationUserId.Trim().PadRight(3)); // 56-58: MODIFICATION USER ID
                tranBuilder.Append(coBorrowerCreditQualityOriginal.Trim().PadRight(5)); // 59-63: CO-BORROWER CREDIT QUALITY: ORIGINAL
                tranBuilder.Append(coBorrowerCreditQualityCurrent.Trim().PadRight(5)); // 64-68: CO-BORROWER CREDIT QUALITY: CURRENT
                tranBuilder.Append(FormatDate(coBorrowerCreditQualityCurrentDate.Trim())); // 69-74: CO-BORROWER CREDIT QUALITY: CURRENT DATE
                tranBuilder.Append(coBorrowerCreditQualityAgent.Trim().PadRight(4)); // 75-78: CO-BORROWER CREDIT QUALITY: AGENT
                tranBuilder.Append(coBorrowerCreditQualityReasonCode.Trim().PadRight(2)); // 79-80: CO-BORROWER CREDIT QUALITY: REASON CODE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 084 - Miscellaneous Master Data - Maintenance (D-148).
        /// Transaction 084 maintains various master file fields and other loan-level fields linked to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="eConsentIndicator">(15) This field is optional. It indicates whether the borrower consents to exclusive electronic presentment of the 1098 Mortgage Interest Statement.</param>
        /// <param name="eConsentDate">(16-21) This field is conditional. If you enter a value in the 1098 E-CONSENT: (Y/N) field, this field is required and cannot be greater than the current date. It indicates the date on which the borrower either gave or withdrew consent for electronic presentment of the 1098 Mortgage Interest Statement.</param>       
        /// <param name="coBorrowerSsnVerifyCode">(25) This field is optional. It records the number of 951/40M requests produced for this loan for the co-borrower. The value in this field automatically increases by one each time a request is produced, but you may also manually update it.</param>
        /// <param name="coBorrowerSsnVerifyDate">(26-31) This field is optional. It records the date of the latest entry in the CO-BORROWER SSN VERIFY CODE field (N: 25). The system automatically updates this field each time it processes a 951/40M request, but you may manually update it.</param>
        /// <param name="coBorrowerSsnCertifyCode">(32) This field is optional. It indicates the last response to the verification of the social security or tax ID number (951/40M requests) for the co-borrower. You must update it manually. You may set up user-defined certification code headers (code and corresponding description) via the Certification Code Header screen (SCH1) in the MSP Info Tracking Workstation.</param>
        /// <param name="coBorrowerSsnCertifyDate">(33-38) This field is optional. It records the date of the latest entry in the CO-BORROWER SSN CERTIFY CODE field (N: 32). The system automatically updates this field each time the CO-BORROWER SSN CERTIFY CODE field is updated, but you may update it manually.</param>
        /// <param name="certificationExpirationDate">(39-42) This field is optional. It indicates the date the certification expires of the latest entry in the SSN CERTIFY CODE field (1: 63). You must update it manually.</param>
        /// <param name="coBorrowerCertificationExpirationDate">(43-46) This field is optional. It indicates the date the certification expires of the latest entry in the CO-BORROWER SSN CERTIFY CODE field (N: 32). You must update it manually.</param>
        /// <param name="coborrReasonableCostCode">(47) This field is optional. It indicates the reason the IRS sends received reasonable cause notification. If the master file is updated, the value entered for reasonable cause is sent to the due diligence history. You may set up the reasonable cause headers (code and corresponding description) via the Reasonable Cause Header screen (RCH1 in the MSP Info Tracking Workstation.</param>
        /// <param name="cpnLast">(49-54) This field is available if you are installed on IP 2198. This field is optional. For consumer loans set for coupons, it indicates the date that a coupon book was last generated for the loan.</param>
        /// <param name="cpnNext">(55-60) This field is available if you are installed on IP 2198. This field is optional. For consumer loans set for coupons, it indicates the date that the next coupon book will be generated if the last coupon book did not include coupons through the loan�s maturity date. This date also represents the last due date of the previous book.</param>
        /// <param name="imminentDefaultIndicator">(61) This field is optional. It indicates the Imminent Default Indicator (IDI) score provided by Freddie Mac, a value that indicates the IDI has been requested, or a user-defined value.</param>
        /// <param name="imminentDefaultIndicatorDate">(62-67) This field is optional. It indicates the Imminent Default Indicator (IDI) score provided by Freddie Mac, a value that indicates the IDI has been requested, or a user-defined value.</param>
        /// <param name="highRiskAltACode">(68) This field is optional. It contains the user-defined code that indicates whether the loan is a high risk Alt-A loan.</param>
        /// <param name="ficoScore">(69-71) This field is optional. It indicates the FICO credit score used for the Imminent Default Indicator scoring request.</param>
        /// <param name="ficoDate">(72-77) This field is optional. It indicates the date associated with the credit score in the FICO SCORE field (N: 69-71).</param>
        /// <returns>Transaction 084 Card N</returns>
        public static string Tran084cN(string loanNumber, string eConsentIndicator = "", string eConsentDate = "", string coBorrowerSsnVerifyCode = "", string coBorrowerSsnVerifyDate = "", string coBorrowerSsnCertifyCode = "", string coBorrowerSsnCertifyDate = "", string certificationExpirationDate = "", string coBorrowerCertificationExpirationDate = "", string coborrReasonableCostCode = "", string cpnLast = "", string cpnNext = "", string imminentDefaultIndicator = "", string imminentDefaultIndicatorDate = "", string highRiskAltACode = "", string ficoScore = "", string ficoDate = "")
        {
            string transaction;

            try
            {
                var transactionName = "084-N";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Left(3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("N"); // 14: CARD CODE
                tranBuilder.Append(eConsentIndicator.Trim().PadRight(1)); // 15: 1098 E-CONSENT INDICATOR
                tranBuilder.Append(FormatDate(eConsentDate.Trim())); // 16-21: 1098 E-CONSENT DATE
                tranBuilder.Append(' ', 3); // 22-24: RESERVED
                tranBuilder.Append(coBorrowerSsnVerifyCode.Trim().PadRight(1)); // 25: CO-BORROWER SSN VERIFY CODE
                tranBuilder.Append(FormatDate(coBorrowerSsnVerifyDate.Trim())); // 26-31: CO-BORROWER SSN VERIFY DATE

                tranBuilder.Append(coBorrowerSsnCertifyCode.Trim().PadRight(1)); // 32: CO-BORROWER SSN CERTIFY CODE
                tranBuilder.Append(FormatDate(coBorrowerSsnCertifyDate.Trim())); // 33-38: CO-BORROWER SSN CERTIFY DATE

                tranBuilder.Append(FormatDate(certificationExpirationDate.Trim(), "MMyy")); // 39-42: CERTIFICATION EXPIRATION DATE
                tranBuilder.Append(FormatDate(coBorrowerCertificationExpirationDate.Trim(), "MMyy")); // 43-46: CO-BORR CERTIFICATION EXPIRATION DATE

                tranBuilder.Append(coborrReasonableCostCode.Trim().PadRight(1)); // 47: CO-BORR REASONABLE CAUSE CODE

                tranBuilder.Append(' '); // 48: RESERVED

                tranBuilder.Append(FormatDate(cpnLast.Trim())); // 49-54: CPN LAST
                tranBuilder.Append(FormatDate(cpnNext.Trim())); // 55-60: CPN NEXT

                tranBuilder.Append(imminentDefaultIndicator.Trim().PadRight(1)); // 61: IMMINENT DEFAULT INDICATOR
                tranBuilder.Append(FormatDate(imminentDefaultIndicatorDate.Trim())); // 62-67: IMMINENT DEFAULT INDICATOR DATE

                tranBuilder.Append(highRiskAltACode.Trim().PadRight(1)); // 68: HIGH RISK ALT-A CODE

                tranBuilder.Append(ficoScore.Trim().PadRight(1)); // 69-71: FICO SCORE
                tranBuilder.Append(FormatDate(ficoDate.Trim())); // 72-77: FICO DATE

                tranBuilder.Append(' ', 3); // 78-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


		#endregion�Methods�
    }
}