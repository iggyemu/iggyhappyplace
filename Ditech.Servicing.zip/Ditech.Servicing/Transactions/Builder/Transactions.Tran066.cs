﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates 066 - Special Escrow Deposit (D-013)
        /// Use transaction 066 to make deposits to escrow in circumstances for which no refund of an outstanding escrow balance is desired.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="escrowPaid">(14-20) This field is optional. It indicates the escrow amount. No refund of advances is made with this transaction. The amount in this field is added to the escrow balance.</param>
        /// <param name="totalPayment">(40-46) This field is required. It indicates the crossfoot amount obtained by adding the escrow paid and the suspense paid.</param>
        /// <param name="memoCode">(53) This field is optional. If you are using transaction 066 in a batch, this field indicates whether you want this transaction to provide information to P-1ER.</param>
        /// <param name="fromPayee">(54-63) This field is optional. The code indicates the payee from whom the escrow payment was received. If there is a matching payee code within the escrow payee header file, then the payee’s name and address are used for reporting. In order to offset a previous disbursement for year-end 1099-MISC reporting, you must enter the original payee in this field.</param>
        /// <param name="description">(64-80) This field is optional. It enables you to enter additional refund information, if desired.</param>
        /// <returns>Transaction 066</returns>
        public static string Tran066(string loanNumber = "", string escrowPaid = "", string totalPayment = "", string memoCode = "", string fromPayee ="", string description ="")
        {
            string transaction;

            try
            {
                var transactionName = "066";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "totalPayment", totalPayment);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(escrowPaid.Trim()), 7)); // 14-20: ESCROW PAID
                tranBuilder.Append(' ', 19); //  21-39: RESERVED
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(totalPayment.Trim()), 7)); // 40-46: TOTAL PAYMENT
                tranBuilder.Append(' ', 6); //  47-52: RESERVED
                tranBuilder.Append(memoCode.Trim().PadRight(1)); // 53: MEMO CODE
                tranBuilder.Append(fromPayee.Trim().PadRight(10)); // 54-63: FROM PAYEE
                tranBuilder.Append(description.Trim().PadRight(17)); // 64-80: DESCRIPTION
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
