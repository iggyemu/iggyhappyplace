﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 14E - Letterlog Update (D-281)
        /// Transaction 14E generates updates to the Online LetterWriter Letter Log from a third-party vendor.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="actionCode">(14) This field is required. It indicates the action you want to take.</param>
        /// <param name="requestId">(15-17) This field is required. It indicates the request ID.</param>
        /// <param name="letterId">(18-22) If you are installed on IP 1635, when your print vendor submits this transaction, the system reviews the LETTER ID field (1: 18-22) to determine whether this Online LetterWriter ID code matches an ID established on the XDCO screen DEMAND LETTER ID field. If the loan’s letter ID matches one listed on the XDCO screen, the system writes a detail event for the loan to the XDCH screen. See subsystem #445 for additional information.</param>
        /// <param name="letterVersion">(23-25) This field is required. It indicates the version of the letter that was mailed.</param>
        /// <param name="dateSent">(26-31) This field is required. It indicates the date the letter was mailed.</param>
        /// <param name="letterDescription">(32-51) This field is required. It indicates the description of the letter that was mailed.</param>
        /// <returns>Transaction 14E</returns>
        public static string Tran14E(string loanNumber, string actionCode, string requestId = "", string letterId = "", string letterVersion = "", string dateSent = "", string letterDescription = "")
        {
            string transaction;

            try
            {
                var transactionName = "14E";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "actionCode", actionCode);
                CheckRequiredField(transactionName, "requestId", requestId);
                CheckRequiredField(transactionName, "letterId", letterId);
                CheckRequiredField(transactionName, "letterVersion", letterVersion);
                CheckRequiredField(transactionName, "dateSent", dateSent);
                CheckRequiredField(transactionName, "letterDescription", letterDescription);
                

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN NUMBER
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 14: ACTION CODE
                tranBuilder.Append(requestId.Trim().PadRight(3)); // 15-17: REQ ID
                tranBuilder.Append(letterId.Trim().PadRight(5)); // 18-22: LETTER ID
                tranBuilder.Append(letterVersion.Trim().PadRight(3)); // 23-25: LETTER VERSION
                tranBuilder.Append(FormatDate(dateSent.Trim())); // 26-31: DATE SENT
                tranBuilder.Append(letterDescription.Trim().PadRight(20)); // 32-51: LETTER DESCRIPTION
                tranBuilder.Append(' ', 29); // 52-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
