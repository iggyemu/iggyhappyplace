#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        ///// <summary>
        ///// Transaction 01C - Collection Notes Upload Short Format (D-314).
        ///// Transaction 01C (D-314) updates the Collection Workstation comment file with response information. This transaction enters collection notes in a short format only.
        ///// </summary>
        ///// <param name="loanNumber">(7-19) This field is required. It identifies the loan number.</param>
        ///// <param name="contactDate">(20-25) This field is required. It identifies the date the last contact was made in the format MMDDYY.</param>
        ///// <param name="employeeID">(26-28) This field is required. It contains the ID of the employee who made the contact.</param>
        ///// <param name="remindAmount">(35-41) This field is optional. It contains either the amount of the next promise due on an active repay plan or the amount of the next payment due.</param>
        ///// <param name="remindDate">(42-47) This field is optional. It contains either the date of the next promise due on an active repay plan or the due date of the next payment in the format MMDDYY.</param>
        ///// <param name="contactCode">(48-50) This field is optional. It contains a three-character, user-defined contact code as defined on the DLQK screen in the Collection Workstation. You must enter a code in this field if the RESPONSE CODE and REASON CODE fields are blank.</param>
        ///// <param name="responseCode">(51-53) This field is optional. It contains the three-character, user-defined response code as defined on the DLQK screen in the Collection Workstation. This code identifies the response received from the collections contact. You must enter a code in this field if the CONTACT CODE and REASON CODE fields are blank.</param>
        ///// <param name="reasonCode">(54-56) This field is optional. It contains the three-character, user-defined reason code as defined on the DLQK screen in the Collection Workstation. This code identifies the reason for the delinquency. You must enter a code in this field if the CONTACT CODE and RESPONSE CODE fields are blank.</param>
        ///// <param name="contactTime">(57-60) This field is optional. It identifies the time of the contact in the format HHMM.</param>
        ///// <returns>Transaction 01C Record</returns>
        //public static string Tran01C(string loanNumber, string contactDate, string employeeID, string remindAmount = "",
        //                             string remindDate = "", string contactCode = "", string responseCode = "", string reasonCode = "",
        //                             string contactTime = "")
        //{
        //    string transaction;

        //    try
        //    {
        //        var transactionName = "01C";

        //        CheckValidLoanNumber(transactionName, loanNumber);
        //        CheckRequiredField(transactionName, "contactDate", contactDate);
        //        CheckRequiredField(transactionName, "employeeID", employeeID);


        //        var tranClient = transactionName + CLIENT_NUMBER;

        //        var tranBuilder = new StringBuilder();

        //        tranBuilder.Append(tranClient); // 1-6: CLIENT
        //        tranBuilder.Append(loanNumber.PadRight(13)); // 7-19: LOAN NUMBER
        //        tranBuilder.Append(FormatDate(contactDate.Trim())); // 20-25: CONTACT DATE
        //        tranBuilder.Append(employeeID.Trim().PadRight(3)); // 26-28: EMPLOYEE ID
        //        tranBuilder.Append(' ', 6); // 29-34: RESERVED
        //        tranBuilder.Append(FormatMoney(remindAmount.Trim(), true, false, 7)); // 35-41: REMIND AMOUNT
        //        tranBuilder.Append(FormatDate(remindDate.Trim())); // 42-47: REMIND DATE
        //        tranBuilder.Append(contactCode.Trim().PadRight(3)); // 48-50: CONTACT CODE
        //        tranBuilder.Append(responseCode.Trim().PadRight(3)); // 51-53: RESPONSE CODE
        //        tranBuilder.Append(reasonCode.Trim().PadRight(3)); // 54-56: REASON CODE
        //        tranBuilder.Append(LeftZeroFillOptionalField(contactTime.Trim(), 4)); // 57-60: CONTACT TIME
        //        tranBuilder.Append(' ', 20); // 61-80: RESERVED
        //        transaction = tranBuilder.ToString();

        //        if (transaction.Length != 80)
        //            throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction = "***** TRAN ERROR: " + ex.Message;
        //    }

        //    return transaction;
        //}

        /// <summary>
        /// Transaction 01C - Collection Notes Upload Short Format (D-314).
        /// Transaction 01C (D-314) updates the Collection Workstation comment file with response information. This transaction enters collection notes in a short format only.
        /// </summary>
        /// <param name="loanNumber">(7-19) This field is required. It identifies the loan number.</param>
        /// <param name="contactDate">(20-25) This field is required. It indicates the date contact was made with the mortgagor. Entry: Type the date in the MMDDYY format. </param>
        /// <param name="contactTime">(26-31) This field is required. It indicates the time contact was made with the mortgagor. Entry: Type the time in the HHMMSS format.</param>
        /// <param name="userId">(32-34) This field is required. It indicates the ID of the user entering the comment.</param>
        /// <param name="contactCode">(35-37) This field is optional. It indicates the contact code for this comment. Contact codes are user-defined on the Contact/Response/Reason screen (DLQK) in the Collection Workstation.</param>
        /// <param name="responseCode">(38-40) This field is optional. It indicates the response code for this comment. Response codes are user-defined on the DLQK screen.</param>
        /// <param name="reasonCode">(41-43) This field is optional. It indicates the reason code for this comment. Reason codes are user-defined on the DLQK screen.</param>
        /// <param name="forbearanceAmount">(44-50) This field is optional. It indicates the forbearance amount that the mortgagor promised to send.</param>
        /// <param name="remindDate">(51-56) This field is optional. It indicates the future date the mortgagor promised to send funds or the date on which this loan should reappear in the queue.</param>
        /// <returns>Transaction 01C Record</returns>
        public static string Tran01C(string loanNumber, string contactDate = "", string contactTime = "", string userId = "", string contactCode = "", string responseCode = "", string reasonCode = "", string forbearanceAmount = "",
                                     string remindDate = "")
        {
            string transaction;

            try
            {
                var transactionName = "01C";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "contactDate", contactDate);
                CheckRequiredField(transactionName, "contactTime", contactDate);
                CheckRequiredField(transactionName, "userId", userId);


                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(loanNumber.PadRight(13)); // 7-19: LOAN NUMBER
                tranBuilder.Append(FormatDate(contactDate.Trim())); // 20-25: CONTACT DATE
                tranBuilder.Append(LeftZeroFillOptionalField(contactTime.Trim(), 6)); // 26-31: CONTACT TIME
                tranBuilder.Append(userId.Trim().PadRight(3)); // 32-34: EMPLOYEE ID
                tranBuilder.Append(contactCode.Trim().PadRight(3)); // 35-37: CONTACT CODE
                tranBuilder.Append(responseCode.Trim().PadRight(3)); // 38-40: RESPONSE CODE
                tranBuilder.Append(reasonCode.Trim().PadRight(3)); // 41-43: REASON CODE
                tranBuilder.Append(FormatMoney(forbearanceAmount.Trim(), true, false, 7)); // 44-50: FOREBEARANCE AMOUNT
                tranBuilder.Append(FormatDate(remindDate.Trim())); // 51-56: REMIND DATE
                tranBuilder.Append(' ', 24); // 57-80: RESERVED
                transaction = tranBuilder.ToString();

                if (transaction.Length != 80)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
                }
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}