﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction CBD - Incentive Data Maintenance (D-392)
        /// Use transaction CBD to add and update mortgage loan incentive program (MLIP) information. You enter transaction CBD on the Loan Incentive Program screen (MLIP) in the MSP Info Tracking Workstation.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="userId">(15-17) This field is required. It identifies the person creating the transaction. The Loan Incentive Program screen (MLIP) in the MSP Info Tracking Workstation adds the user's security signon ID to any maintainence transaction.</param>
        /// <param name="moBia">(18-23) This field is optional. It indicates the monthly incentive amount the borrower is to earn through the incentive program.</param>
        /// <param name="biaToDate">(24-30) This field is optional. It indicates the total amount of incentive the borrower has accrued from the anniversary date to the current date.</param>
        /// <param name="biAniv">(31-36) This field is optional. It indicates the anniversary date of the incentive.</param>
        /// <returns>Transaction CBD</returns>
        public static string TranCBDc1(string loanNumber, string userId, string moBia, string biaToDate, string biAniv)
        {
            string transaction;

            try
            {
                var transactionName = "CBD";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField("CBD", "userId", userId);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(userId.Trim().PadRight(3)); // 15-17: USER ID
                tranBuilder.Append(FormatMoney(moBia, true, false, 6)); // 18-23: MO BIA
                tranBuilder.Append(FormatMoney(biaToDate, true, false, 7)); // 24-30: BIA TO-DATE
                tranBuilder.Append(FormatDate(biAniv.Trim())); // 31-36 BI ANIV
                tranBuilder.Append(' ', 44); // 37-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}