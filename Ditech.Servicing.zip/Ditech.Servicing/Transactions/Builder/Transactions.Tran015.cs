#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 015 - Tax Name and Address - New Loans (D-021)
        /// Use this transaction to enter the tax name and property address information into the master record.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="taxNameLastName">(15-28) This field is optional. It indicates the last name in which the property tax bills are issued for the current year. This should match, as nearly as possible, the last name as it appears on the tax rolls of the taxing authorities.</param>
        /// <param name="taxNameFirstNameAndInitial">(29-37) This field is optional. It indicates the name in which the property tax bills are issued for the current year. This should match, as nearly as possible, the first name and initial as they appear on the tax rolls of the taxing authorities.</param>
        /// <param name="pendingTaxNameLastName">(38-51) This field is optional. It indicates the last name in which the tax bills will be issued at some future date indicated in the YEAR APPLICABLE field (see tax name above). The system (U-870) automatically replaces the tax name with the pending tax name when the first mortgage payment during the year specified is processed.</param>
        /// <param name="pendingTaxNameFirstNameAndInitial">(52-60) This field is optional. It indicates the first name and initial in which the tax bills will be issued at some future date indicated in the YEAR APPLICABLE field (see tax name above).</param>
        /// <param name="yearApplicable">(61-62) This field is optional. It indicates the pending year applicable (see tax name above). The system (U-870) automatically replaces the tax name with the pending tax name when the first mortgage payment during the year specified is processed.</param>
        /// <returns>Transaction 015 Card 1</returns>
        public static string Tran015c1(string loanNumber, string taxNameLastName, string taxNameFirstNameAndInitial,
                                       string pendingTaxNameLastName, string pendingTaxNameFirstNameAndInitial,
                                       string yearApplicable)
        {
            string transaction;

            try
            {
                var transactionName = "015-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(taxNameLastName.Trim().PadRight(14)); // 15-28: TAX NAME: LAST NAME
                tranBuilder.Append(taxNameFirstNameAndInitial.Trim().PadRight(9));
                // 29-37: TAX NAME: FIRST NAME & INITIAL
                tranBuilder.Append(pendingTaxNameLastName.Trim().PadRight(14)); // 38-51: PENDING TAX NAME: LAST NAME
                tranBuilder.Append(pendingTaxNameFirstNameAndInitial.Trim().PadRight(9));
                // 52-60: PENDING TAX NAME: FIRST NAME & INITIAL
                tranBuilder.Append(LeftZeroFillOptionalField(yearApplicable.Trim(), 2)); // 61-62: YEAR APPLICABLE
                tranBuilder.Append(' ', 18); // 63-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 015 - Tax Name and Address - New Loans (D-021)
        /// Use this transaction to enter the tax name and property address information into the master record.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="propertyAddressNumber">(15-20) This field is optional. It indicates the street number of the address of the mortgagor's property as it is printed on the tax listings.</param>
        /// <param name="propertyAddressDirection">(21-22) This field is optional. It indicates the street direction of the address of the mortgagor's property as it is printed on the tax listings.</param>
        /// <param name="propertyAddressStreetName">(23-37) This field is optional. It indicates the street name of the address of the mortgagor's property as it is printed on the tax listings.</param>
        /// <param name="propertyAddressCity">(38-58) This field is optional. It indicates the city name of the address of the mortgagor's property as it is printed on the tax listings.</param>
        /// <param name="propertyAddressState">(59-60) This field is optional. It indicates the state name of the address of the mortgagor's property as it is printed on the tax listings.</param>
        /// <param name="propertyAddressPropertyZipCode">(61-65) This field is optional. It indicates the zip code of the address of the mortgagor's property as it is printed on the tax listings.</param>
        /// <param name="propertyInspectionService">(66-71) This field is optional. It indicates a particular inspection service header containing the company name and address of the service that performs the property inspections for the loan. If there is no header on file for the inspection service that is going to be used, refer to D-130 to set up an inspection service header with transaction HH2 (D-130).</param>
        /// <returns>Transaction 015 Card 2</returns>
        public static string Tran015c2(string loanNumber, string propertyAddressNumber, string propertyAddressDirection,
                                       string propertyAddressStreetName, string propertyAddressCity,
                                       string propertyAddressState, string propertyAddressPropertyZipCode,
                                       string propertyInspectionService)
        {
            string transaction;

            try
            {
                var transactionName = "015-2";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("2"); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(propertyAddressNumber.Trim(), 6));
                // 15-20: PROPERTY ADDRESS: NUMBER
                tranBuilder.Append(propertyAddressDirection.Trim().PadRight(2)); // 21-22: PROPERTY ADDRESS: DIRECTION
                tranBuilder.Append(propertyAddressStreetName.Trim().PadRight(15));
                // 23-37: PROPERTY ADDRESS: STREET NAME
                tranBuilder.Append(propertyAddressCity.Trim().PadRight(21)); // 38-58: PROPERTY ADDRESS: CITY
                tranBuilder.Append(propertyAddressState.Trim().PadRight(2)); // 59-60: PROPERTY ADDRESS: STATE
                tranBuilder.Append(FormatZipCode(propertyAddressPropertyZipCode.Trim()));
                // 61-65 PROPERTY ADDRESS: PROPERTY ZIP CODE
                tranBuilder.Append(propertyInspectionService.Trim().PadRight(6)); // 66-71: PROPERTY INSPECTION SERVICE
                tranBuilder.Append(' ', 9); // 72-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 015 - Tax Name and Address - New Loans (D-021)
        /// Use this transaction to enter the tax name and property address information into the master record.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="propertyStreetNumber">(15-20) This field is optional. It indicates the street property number.</param>
        /// <param name="propertyStreetDirection">(21-22) This field is optional. It indicates the street direction.</param>
        /// <param name="propertyStreetName">(23-42) This field is optional. It indicates the street name.</param>
        /// <param name="propertyCity">(43-63) This field is optional. It indicates the city name.</param>
        /// <param name="propertyState">(59-60) This field is optional. It indicates the state name.</param>
        /// <param name="propertyZipCode">(66-70) This field is optional. It indicates the zip code.</param>
        /// <param name="propertyZipCodeSuffix">(71-74) This field is optional. It indicates the +4 zip code suffix.</param>
        /// <param name="fipsState">(75-76) This field is system-generated. It is required for MERS processing. This field indicates the state code as defined in the Federal Information Processing Standards (FIPS) Publication 55-3.</param>
        /// <param name="fipsCounty">(77-79) This field is conditional. It is required for MERS processing. This field indicates the state code as defined in the Federal Information Processing Standards (FIPS) Publication 55-3.</param>
        /// <returns>Transaction 015 Card 4</returns>
        public static string Tran015c4(string loanNumber, string propertyStreetNumber, string propertyStreetDirection,
                                       string propertyStreetName, string propertyCity, string propertyState,
                                       string propertyZipCode, string propertyZipCodeSuffix, string fipsState,
                                       string fipsCounty)
        {
            string transaction;

            try
            {
                var transactionName = "015-4";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("4"); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(propertyStreetNumber.Trim(), 6));
                // 15-20: PROPERTY: STREET NUMBER
                tranBuilder.Append(propertyStreetDirection.Trim().PadRight(2)); // 21-22: PROPERTY: STREET DIRECTION
                tranBuilder.Append(propertyStreetName.Trim().PadRight(20)); // 23-42: PROPERTY ADDRESS: STREET NAME
                tranBuilder.Append(propertyCity.Trim().PadRight(21)); // 43-63: PROPERTY: CITY
                tranBuilder.Append(propertyState.Trim().PadRight(2)); // 64-65: PROPERTY: STATE
                tranBuilder.Append(FormatZipCode(propertyZipCode.Trim())); // 66-70: PROPERTY: ZIP CODE
                tranBuilder.Append(LeftZeroFillOptionalField(propertyZipCodeSuffix.Trim(), 4));
                // 71-74: PROPERTY: ZIP CODE SUFFIX
                tranBuilder.Append(fipsState.Trim().PadRight(2)); // 75-76: FIPS STATE
                tranBuilder.Append(fipsCounty.Trim().PadRight(3)); // 77-79: FIPS COUNTY
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}