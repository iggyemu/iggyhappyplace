#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 016 - Name and Address/SMSA - Add During Setup (D-021).  
        /// Use transaction 016 (D-017) cards 3 and 5 to modify or add this data to a loan already existing in the system.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="smsaCode"> (15-18) This field is conditional. It is required if CENSUS TRACT or OCCUPY CODE is present. </param>
        /// <param name="censusTract"> (19-24) This field is optional. It is used to provide the census tract code of loans originated or acquired in order to comply with the Home Mortgage Disclosure Act of 1975. </param>
        /// <param name="occupyCode"> (25) This field is conditional. It is required if SMSA CODE or CENSUS TRACT is present. This field is used to provide the geographical distribution of loans closed in order to comply with the Home Mortgage Disclosure Act of 1975. </param>
        /// <param name="branchCode"> (49-52) This field is optional. It indicates the identifying code for the branch office originating a loan. </param>
        /// <param name="builderBrokerCode"> (53-56) This field is optional. It identifies the builder or broker through which a loan originated. It is required only if spot/builder (field 20) equals 1. It is validated against the builder/broker header file. </param>
        /// <param name="productLineCode"> (57-59) This field is optional. It is a user-determined code that can be used to group loans by any criterion that the user requires. </param>
        /// <param name="pledgedLoanCode"> (60) This field is optional. It is a user-defined code indicating whether the loan was pledged as collateral. This code is linked to a specific collateral header that identifies the institution requiring the collateral. </param>
        /// <param name="currentOccupancyStatusCode"> (61) This field is optional. It indicates the current occupancy status of the property. Use this status code in reporting to HUD, VA, Freddie Mac, and so forth, when the current occupancy status of the subject property is requested. </param>
        /// <param name="organizationCode"> (62-65) This field is optional. It is used primarily by portfolio analysis reports to segregate loans by affiliated banks or other organizations. </param>
        /// <param name="pledgeType"> (66-67) This field is optional. It provides a means of further subdividing the loans within the pledging subsystem. This is used in conjunction with the pledge class and required by many FHLBB districts when reporting by tape. This field is also found in the collateral header.</param>
        /// <param name="pledgeClass"> (68-69) This field is optional. It is used to reclassify loans within pledge type. This code is also required by many FHLBB districts when reporting by tape. </param>
        /// <param name="pledgeIndex"> (70-72) This field is optional. It can be used to tie loans to ARM plan ID codes or global headers for pledging to FHLBB or other institutions. </param>
        /// <param name="maCode"> (73-77) This field is conditional. It is required if you enter information in the CENSUS TRACT field. This field indicates the U.S. Census Bureau Metropolitan Area Code used with census tract data to comply with HMDA regulations.  This field applies only for loans with reporting years of 2004 or later. </param>
        /// <returns>Transaction 016 Card 3</returns>
        public static string Tran016c3(string loanNumber, string smsaCode, string censusTract, string occupyCode,
                                       string branchCode, string builderBrokerCode, string productLineCode,
                                       string pledgedLoanCode, string currentOccupancyStatusCode,
                                       string organizationCode, string pledgeType, string pledgeClass,
                                       string pledgeIndex, string maCode)
        {
            string transaction;

            try
            {
                var transactionName = "016-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (!IsAvailable(smsaCode) && (IsAvailable(censusTract) || IsAvailable(occupyCode)))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: SMSA Code is required if census tract or occupy code is present.",
                                      transactionName, loanNumber));
                }

                if (!IsAvailable(occupyCode) && (IsAvailable(censusTract) || IsAvailable(smsaCode)))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Occupy Code is required if census tract or SMSA code is present.",
                                      transactionName, loanNumber));
                }

                // Removing ma code requirement since this only reports to loans with report years 2004 and later
                //if (!IsAvailable(maCode) && (IsAvailable(censusTract)))
                //{
                //    throw new Exception(string.Format("{0}: {1}: MA Code is required if census tract is present.", transactionName, loanNumber));
                //}

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("3"); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(smsaCode.Trim(), 4)); // 15-18: SMSA
                tranBuilder.Append(LeftZeroFillOptionalField(censusTract.Trim(), 6)); // 19-24: CENSUS TRACT
                tranBuilder.Append(occupyCode.Trim().PadRight(1)); // 25: OCCUPY CODE
                tranBuilder.Append(' ', 23); // 26-48: RESERVED
                tranBuilder.Append(branchCode.Trim().PadRight(4)); // 49-52: BRANCH CODE                      
                tranBuilder.Append(builderBrokerCode.Trim().PadRight(4)); // 53-56: BLDR/BRKR CODE         
                tranBuilder.Append(productLineCode.Trim().PadRight(3)); // 57-59: PRODUCT LINE CODE
                tranBuilder.Append(pledgedLoanCode.Trim().PadRight(1)); // 60: PLEDGED LOAN CODE
                tranBuilder.Append(currentOccupancyStatusCode.Trim().PadRight(1)); // 61: CURRENT OCCUPANCY STATUS CODE
                tranBuilder.Append(organizationCode.Trim().PadRight(4)); // 62-65: ORGANIZATION CODE
                tranBuilder.Append(LeftZeroFillOptionalField(pledgeType.Trim(), 2)); // 66-67: PLEDGE TYPE
                tranBuilder.Append(LeftZeroFillOptionalField(pledgeClass.Trim(), 2)); // 68-69: PLEDGE CLASS
                tranBuilder.Append(pledgeIndex.Trim().PadRight(3)); // 70-72: PLEDGE INDEX
                tranBuilder.Append(maCode.Trim().PadLeft(5)); // 73-77: MA CODE
                tranBuilder.Append(' ', 3); // 78-80 RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102 EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}