﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 012 updates fields holding data related to the mortgagor's name and address, without the activity produced by transaction 011 (D-001). There is limited flexibility if you want to enter nonstandard addresses. If you are entering transaction 012 to change the address, you must submit card 1 with the Billing Name and Billing Name 2 and card 2 with the Billing Address Line 1, Billing City, Billing State, and Zip Code or the transaction will not apply.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="billingName">(15-37) This field is required. It indicates the full name of the mortgagor for billing purposes.</param>
        /// <param name="billingName2">(38-60) This field is optional. It indicates the full name of a second individual for billing purposes.</param>
        /// <param name="assumptionDate">(61-66) This field is optional. It indicates the date a loan assumption was effective.</param>
        /// <param name="location">(67) This field is optional. It indicates the location (business, relative, etc.) of the second telephone number.</param>
        /// <param name="secondTelephoneNumber">(68-77) This field is optional. It indicates a second telephone number for the mortgagor or co-mortgagor. Include area code, no dashes or blanks.</param>
        /// <param name="modificationAgreementIndicator">(78) This field is optional. It indicates that a loan modification agreement was executed for the assumption. Unlike transaction 011 (D-001), no maintenance is sent to the HMDA history for reporting on S-5AW. If this loan needs to be added or deleted on the HMDA history, use the maintenance screens provided in the online HMDA Facility.</param>        
        /// <param name="nonAssumableLoanFlag">(79) This field is optional. It indicates whether the loan is assumable. If it is not assumable, the system rejects an assumption transaction (011) entered for the loan.</param>
        /// <returns>Transaction 012 Card 1</returns>
        public static string Tran012c1(string loanNumber, string billingName, string billingName2, string assumptionDate,
                                       string location, string secondTelephoneNumber, string modificationAgreementIndicator, string nonAssumableLoanFlag)
        {
            string transaction;

            try
            {
                var transactionName = "012-1";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Billing Name (15-37)", billingName);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(billingName.Trim().PadRight(23)); // 15-37: BILLING NAME
                tranBuilder.Append(billingName2.Trim().PadRight(23)); // 38-60: BILLING NAME 2
                tranBuilder.Append(FormatDate(assumptionDate.Trim())); // 61-66: ASSUMPTION DATE
                tranBuilder.Append(location.Trim().PadRight(1)); // 67: LOCATION CODE
                tranBuilder.Append(secondTelephoneNumber.Trim().PadRight(10)); // 68-77: SECOND TELEPHONE NUMBER
                tranBuilder.Append(modificationAgreementIndicator.Trim().PadRight(1)); // 78: MODIFICATION AGREEMENT INDICATOR
                tranBuilder.Append(nonAssumableLoanFlag.Trim().PadRight(1)); // 79: NON-ASSUMABLE LOAN FLAG
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 012 updates fields holding data related to the mortgagor's name and address, without the activity produced by transaction 011 (D-001). There is limited flexibility if you want to enter nonstandard addresses. If you are entering transaction 012 to change the address, you must submit card 1 with the Billing Name and Billing Name 2 and card 2 with the Billing Address Line 1, Billing City, Billing State, and Zip Code or the transaction will not apply.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="billingAddressLine1">(15-37) This field is required. It indicates the primary postal delivery address, such as street address, post office box, or rural route.</param>
        /// <param name="billingCity">(38-57) This field is required. It indicates the name of the city for postal delivery purposes.</param>
        /// <param name="foreignAddressIndicator">(58) This field is conditional. It updates the master file. It is required if the city is in a foreign country.</param>
        /// <param name="billingState">(59-60) This field is conditional. It updates the billing state in the master file.</param>
        /// <param name="zipCode">(61-65) This field is optional. It updates the zip code in the master file.</param>
        /// <param name="initials">(66-67) This field is optional. It indicates the initials used with the abbreviated name when there is not room to print the billing name; it is also used to sort indices. This replaces the initials in the master file.</param>
        /// <param name="abbreviatedName">(68-75) This field is optional. It indicates the abbreviated name used with the initials when there is not enough room to enter the full billing name; it is also used to sort indices. This replaces the abbreviated name in the master file.</param>
        /// <param name="ahFlag">(76) This field is optional. It allows or prevents this loan from being solicited for accident and health insurance coverage. This replaces the A&H flag in the master file.</param>
        /// <param name="lifeFlag">(77) This field is optional. It allows or prevents this loan from being solicited for life insurance coverage. This replaces the life flag in the master file.</param>
        /// <param name="billMode">(78) This field is optional. It indicates the type of payment advice given to the mortgagor or the corporation to which a loan belongs. This replaces the billing mode in the master file.</param>
        /// <param name="employeeFlag">(79) This field is optional. It indicates whether or not the mortgagor is an employee of the servicer.</param>
        /// <returns>Transaction 012 Card 2</returns>
        public static string Tran012c2(string loanNumber, string billingAddressLine1, string billingCity,
                                       string foreignAddressIndicator, string billingState, string zipCode,
                                       string initials, string abbreviatedName, string ahFlag,
                                       string lifeFlag, string billMode, string employeeFlag)
        {
            string transaction;

            try
            {
                var transactionName = "012-2";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Address Line 1 (15-37)", billingAddressLine1);
                CheckRequiredField(transactionName, "Billing City (38-57)", billingCity);

                CheckForeignAddressIndicatorAndState(transactionName, loanNumber, foreignAddressIndicator, billingState);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("2"); // 14: CARD CODE
                tranBuilder.Append(billingAddressLine1.Trim().PadRight(23)); // 15-37: ADDRESS LINE 1
                tranBuilder.Append(billingCity.Trim().PadRight(20)); // 38-57: BILLING CITY
                tranBuilder.Append(foreignAddressIndicator.Trim().PadRight(1)); // 58: FOREIGN ADDRESS INDICATOR
                tranBuilder.Append(billingState.Trim().PadRight(2)); // 59-60: BILLING STATE
                tranBuilder.Append(FormatZipCode(zipCode.Trim())); // 61-65: ZIP CODE
                tranBuilder.Append(initials.Trim().PadRight(2));
                // 66-67: MORTGAGOR ABBREVIATED NAME (INITIALS)
                tranBuilder.Append(abbreviatedName.Trim().PadRight(8));
                // 68-75: MORTGAGOR ABBREVIATED NAME (SHORT NAME)
                tranBuilder.Append(ahFlag.Trim().PadRight(1)); // 76: A&H CODE
                tranBuilder.Append(lifeFlag.Trim().PadRight(1)); // 77: LIFE CODE
                tranBuilder.Append(billMode.Trim().PadRight(1)); // 78: BILL MODE
                tranBuilder.Append(employeeFlag.Trim().PadRight(1)); // 79: BILL MODE
                tranBuilder.Append(new string(' ', 1)); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
