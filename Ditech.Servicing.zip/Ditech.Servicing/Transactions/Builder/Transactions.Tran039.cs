﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 039 - Single Year Policies.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="insuranceTypeCode">(14-16) This field is required. It indicates the hazard policy assigned to the loan. The system uses a transaction code equal to the insurance type to calculate the policy’s disbursements. The system moves the code from input to the master file. 351-Hazard insurance; 352-Flood insurance</param>
        /// <param name="agentCode">(17-21) This field is conditional. It is required if the value in the TYPE PAYMENT field is 1, 3, or 4. It indicates the code for the agent who wrote the hazard policy. The system uses this code to access the escrow header file. It prints the agent’s name and address on hazard insurance reports and on machine disbursement checks if the payment type for this policy indicates payment to the agent. The system adds the agent code to the master file.  Code values are supplied by the servicer - do not use 99999.  Entry: Type the agent code, left-justified.</param>
        /// <param name="companyCode">(22-26) This field is conditional. It is required if the value in the TYPE PAYMENT field is 2, 5, 6, or 7. It indicates the code for the insurance company that issued hazard insurance coverage. The system uses this field to access the escrow header file. The system prints the insurance company name and address on hazard insurance reports and on machine disbursement checks if the type payment for this policy indicates payment to the insurance company. The system adds the insurance company code to the master file.  Code values are servicer generated - do not use 99999.  Entry: Type the insurance company code, left-justified.</param>
        /// <param name="premiumDueDate">(27-30) This field is conditional. It is required if the value in the TYPE PAYMENT (1:55) field is 2, 5, 6, or 7. It indicates the date on which the next premium installment is due. The system normally advances the premium due date by the term of the premium whenever you enter a disbursement (transactions 351 - 355) for the policy. The system adds the premium due date to the master file. Entry: Type the due date in MMYY format..</param>
        /// <param name="expirationDate">(31-36) This field is conditional. It is required for policies with a value other than 8 in the TYPE PAYMENT field. It indicates the date on which the insurance policy expires. It is used to prevent the next entry of a new policy (transaction 039) of the insurance type form overlapping coverage. For continuous policies, the system advances this date by the term of the premium when you enter a disbursement (transactions 351 - 355) for this policy. The system adds the expiration date to the master file. Entry: Type the expiration date in MMDDYY format.</param>
        /// <param name="installment">(37-43) This field is conditional. It is not required for policies with a value of 7 or greater in the TYPE PAYMENT field. It indicates the amount to be paid when the next premium payment is due for this policy. The system updates this field when you enter a disbursement for this policy (transactions 351 - 355). The escrow analysis programs use the installment amount to calculate how much escrow should be collected with each mortgage payment. The system adds the installation amount to the master file. Entry: Type an amount, left-justified and zero-filled.</param>
        /// <param name="termOfPremium">(44-45) This field is conditional. It is required for policies with a value other than 8 in the TYPE PAYMENT field. This field indicates the number of months between insurance premium payments. The system uses the term of the premium to advance the expiration date (of a continuous policy) and to advance the premium due date whenever you enter a disbursement. The escrow analysis programs also use this field to calculate the amount of escrow to collect with each mortgage payment. The system adds this date to the master file. Entry: Type a two-digit value, left-justified and zero-filled. </param>
        /// <param name="coverageInDollars">(46-54) This field is optional. It indicates the dollar amount of the coverage provided by this policy. The system adds the coverage amount to the master file.  Entry: Type the dollar amount of coverage, left-justified and zero filled.</param>
        /// <param name="paymentType">(55) The field is optional. It indicates the status of the coverage requirement or the mode of payment for this policy. The system moves the type of payment from input to the master file.  Entry: Type one of the following codes. Code	Description 1	Annual premium, agent is payee. 2	Annual premium, insurance company is payee. 3	Continuous policy, agent is payee. 4	Premium other than annual, agent is payee. 5	Premium other than annual, insurance co. is payee. 6	Continuous policy, insurance company is payee. 7	Premium is paid by the mortgagor. 8	No coverage is required for this type of policy.</param>
        /// <param name="typeCoverage">(56) This field is optional. It indicates the kind of coverage provided by this policy. The system adds the coverage type to the master file. Entry: Type a servicer-assigned value, B through Z or 0 through 9.</param>
        /// <param name="policyNumber">(57-76) This field is conditional. It is required for policies with a value other than 8 in the TYPE PAYMENT field. It indicates the number assigned to the policy by the insurance company on issuance. The system adds the policy number to the master file.  Entry: Type the new policy number exactly as it should appear on the output.</param>
        ///  <param name="disbCode">(77) This field is optional. It indicates how you want to the system to generate records for report P-449.  Entry: Type one of the following codes.  Code	Description 1	Write a record to P-449 for this policy after the system moves the new information on the transaction to the master file. If the payee, loan number, and insurance type in this new record match those fields in a record already in the P-449 file, the system replaces the old P-449 record with the new one. Otherwise, the system adds the new record to the file, and deletes any disbursement for this loan and insurance type pending in P-449. 2	Write a delete record to P-449 for the policy of this insurance type in the master file. The payee code in the delete record is determined before any of the new information on the transaction is moved to the master file. 4	Same as code 1, but for multi-year insurance, the system uses the insurance company payee for the policy down payment disbursement.</param>
        ///  <param name="mortgageClause">(78) This field is optional. It indicates whether you want to generate the hazard endorsement letter (mortgage clause change notice).  Entry: Type C to generate the letter.</param>
        /// <returns>Transaction 039</returns>
        public static string Tran039(string loanNumber, string insuranceTypeCode,
                                        string agentCode, string companyCode, string premiumDueDate,
                                                                               string expirationDate, string installment,
                                                                               string termOfPremium, string coverageInDollars,
                                                                               string paymentType, string typeCoverage,
                                                                               string policyNumber, string disbCode, string mortgageClause)
        {
            string transaction;

            try
            {
                const string transactionName = "039";

                CheckValidLoanNumber(transactionName, loanNumber);


                const string tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(insuranceTypeCode.Trim().PadRight(3)); // (14-16) 
                tranBuilder.Append(agentCode.Trim().PadRight(5)); // (17-21)
                tranBuilder.Append(companyCode.Trim().PadRight(5)); // (22-26)
                tranBuilder.Append(premiumDueDate.Trim().PadRight(4)); // (27-30)
                tranBuilder.Append(expirationDate.Trim().PadRight(6)); // (31-36)
                tranBuilder.Append(installment.Trim().PadRight(7)); // (37-43)
                tranBuilder.Append(termOfPremium.Trim().PadRight(2)); // (44-45)
                tranBuilder.Append(coverageInDollars.Trim().PadRight(9)); // (46-54)
                tranBuilder.Append(paymentType.Trim().PadRight(1)); // (55)
                tranBuilder.Append(typeCoverage.Trim().PadRight(1)); // (56)
                tranBuilder.Append(policyNumber.Trim().PadRight(20)); // (57-76)
                tranBuilder.Append(disbCode.Trim().PadRight(1)); // (77)
                tranBuilder.Append(mortgageClause.Trim().PadRight(1)); // (78)
                tranBuilder.Append(' ', 2); // 79-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}