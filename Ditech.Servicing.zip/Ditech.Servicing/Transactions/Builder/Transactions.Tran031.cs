#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public  partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 031 - Stops &amp; Flags Maintenance (D-025).
        /// Use transaction 031 to set stops or flags on the loan record, signaling that conditions are present for which certain actions should not occur. For process stop 8, the stop file is updated at the edit level. For all other stops, the stop file is updated in report P-171. Except for process stop 8, stops entered today take effect tomorrow to keep the batch processing consistent with the lockbox.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="processStop">(14) This field is optional. It determines whether the system prevents normal payments from being applied by checking the stop file. The original value at loan setup time is zero. This indicates processing subject to other stops and conditions.</param>
        /// <param name="badCheckStop">(15) This field is optional. It determines whether the system prevents normal payments from being applied. The original value at loan setup time is zero, which indicates normal processing subject to other stops and conditions. If a bad check stop is present, the system rejects the loan from automatic drafting.</param>
        /// <param name="pifStop">(16) This field is optional. It determines whether the system prevents normal payments from being applied. The original value at loan setup time is zero, which indicates normal processing, subject to other stops and conditions.</param>
        /// <param name="foreclosureStop">(17) This field is optional. The foreclosure stop indicates the foreclosure status of the loan. The original value at loan setup is 0, which indicates normal processing, subject to other stops and conditions. If the foreclosure stop is not 0, the system prevents normal payments from being applied by checking the stop file. If a foreclosure stop is present, the system rejects the loan from automatic drafting.</param>
        /// <param name="noNoticeCode">(18) This field is optional. It determines whether notices are sent to the mortgagor on accounts for which you would otherwise send delinquent notices. The original value of a loan at loan set up is 0, which causes notices to be produced when requested (transactions 951/197, 951/198, and 951/199).</param>
        /// <param name="noAnalysisCode">(19) This field is optional. The no-analysis code controls escrow analysis on this loan.</param>
        /// <param name="ahFlag">(20) This field is optional. It determines whether the loan is solicited for accident and health insurance. When the underwriter has turned down the application, you can use this field to prevent further solicitation on this loan until a status change is made (transaction 031) or an ownership change is processed (transaction 011). The original value at loan setup time is 0.</param>
        /// <param name="lifeFlag">(21) This field is optional. It determines whether this loan is solicited for life insurance. The original value at loan setup time is 0.</param>
        /// <param name="disbursementStop">(22) This field is optional. It determines whether the system generates disbursements of escrow items from this account. It has no effect on the application of payments. The original value at the loan setup time is 0.</param>
        /// <param name="floodEarthquakeInsuranceCode">(23) This field is optional. This code indicates whether flood and/or earthquake insurance is required on this loan. If flood and/or earthquake insurance is required but this loan does not have appropriate coverage, the loan is listed on report P-453. The original value at loan setup time is 0.</param>
        /// <param name="lateChargeStop">(24) This field is optional. It determines whether the system assesses late charges regardless of whether the loan is delinquent.</param>
        /// <param name="payoffPendingDisbursementStop">(25) This field is optional. It determines whether the system processes hazard insurance and tax disbursements if the disbursement amount is greater than the escrow balance.</param>
        /// <param name="stopChangedBy">(26-28) This field is conditional. It indicates the user ID of the person making changes to the fields.</param>
        /// <param name="stopExpirationDate">(29-34) This field is conditional. It indicates the date that the values for certain fields are automatically selected by the system for removal (reset to zero) in the following MSP cycle. If the expiration date falls on a Saturday or on a Sunday (noncycle days), the loan is not selected until Mondays cycle and is then removed in Tuesdays cycle.</param>
        /// <param name="armUpdateStop">(35) This field is conditional. It determines whether an ARM loan updates or produces an ARM notice during the automatic calculation process.</param>
        /// <param name="armNoticeStop">(36) This field is conditional. It controls the production of Online LetterWriter ARM notices during the automatic calculation process.</param>
        /// <param name="payoffTrackingCode">(37-38) This field is optional. This code indicates the reason the loan is paid off.</param>
        /// <param name="windStormFlag">(39) This field is optional. It indicates whether windstorm coverage is required or if the borrower requested the coverage.</param>
        /// <param name="hazardInsuranceFlags">(40-41) This field is optional. It indicates whether hazard insurance coverage is required or if the borrower requested the coverage.</param>
        /// <param name="cbrCommentCode">(42-43) This two-position field is conditional. It identifies the code for additional special comment information regarding the status of the credit bureau report. This field is required if you enter a comment expiration date.</param>
        /// <param name="cbrCommentExpirationDate">(44-49) This field is optional if you enter a comment code. It indicates the date the special comment code expires for credit bureau reporting.</param>
        /// <param name="forcedCoverageIndicator">(51) This field is optional. It indicates whether you want to apply forced coverage insurance to this loan.</param>
        /// <param name="delinquencyCommentDate">(52-57) This field is optional. It indicates the date you entered the delinquency comment.</param>
        /// <param name="cbrOccuranceFirstDate">(58-63) This field indicates the date the loan first reported a credit bureau status code of 71.</param>
        /// <param name="elocAdvanceStop">(64) This field applies if you are installed on the Equity Line of Credit enhancement (IP 1423). It indicates a code that stops transaction 049 (D-320, nonstandard) from processing an equity line of credit (ELOC) advance.</param>
        /// <param name="elocDisputedFlag">(65) This field applies if you are installed on the Equity Line of Credit enhancement (IP 1423). It indicates if the borrower is disputing an ELOC bill statement.</param>
        /// <param name="optOutStop">(66) This field is optional. It determines whether this loan is solicited for any third-party products. The original value at the loan setup time is 0.</param>
        /// <param name="cbrIndicatorSwitch">(69) This field is optional. It indicates whether the loan is subject to credit bureau reporting (CBR). There are two types of codes: user-entered and system-generated.</param>
        /// <param name="cbrStatusCode">(70-71) This field is optional. It indicates the status of the loan as reported to the credit bureau. Use this field to enter status codes not calculated by the system. There are two types of codes: user-entered and system-generated.</param>
        /// <param name="foreclosureTrackingSwitch">(72) This field is optional. This code indicates that this loan is present in the Foreclosure Workstation. Any loan with this code not equal to spaces is retained in the year-end purge.</param>
        /// <param name="fnmaLrsActionCode">(73-74) The information in this field reflects the Fannie Mae laser reporting system (LRS) code and date, which are reported to Fannie Mae. This information pertains to all Fannie Mae loans.</param>
        /// <param name="fnmaLrsActionDate">(75-80) The information in this field reflects the Fannie Mae laser reporting system (LRS) code and date, which are reported to Fannie Mae. This information pertains to all Fannie Mae loans.</param>
        /// <returns>Transaction 031</returns>
        public static string Tran031(string loanNumber = "", string processStop = "", string badCheckStop = "", string pifStop = "",
                                     string foreclosureStop = "", string noNoticeCode = "", string noAnalysisCode = "", string ahFlag = "",
                                     string lifeFlag = "", string disbursementStop = "", string floodEarthquakeInsuranceCode = "",
                                     string lateChargeStop = "", string payoffPendingDisbursementStop = "", string stopChangedBy = "",
                                     string stopExpirationDate = "", string armUpdateStop = "", string armNoticeStop = "",
                                     string payoffTrackingCode = "", string windStormFlag = "", string hazardInsuranceFlags = "",
                                     string cbrCommentCode = "", string cbrCommentExpirationDate = "",
                                     string forcedCoverageIndicator = "", string delinquencyCommentDate = "",
                                     string cbrOccuranceFirstDate = "", string elocAdvanceStop = "", string elocDisputedFlag = "",
                                     string optOutStop = "", string cbrIndicatorSwitch = "", string cbrStatusCode = "",
                                     string foreclosureTrackingSwitch = "", string fnmaLrsActionCode = "",
                                     string fnmaLrsActionDate = "")
        {
            string transaction;

            
                const string transactionName = "031";

                CheckValidLoanNumber(transactionName, loanNumber);

                var allStops =
                    string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}", armNoticeStop.Trim(), armUpdateStop.Trim(),
                                  badCheckStop.Trim(), cbrIndicatorSwitch.Trim(), disbursementStop.Trim(),
                                  lateChargeStop.Trim(), noAnalysisCode.Trim(), noNoticeCode.Trim(),
                                  payoffPendingDisbursementStop.Trim(), processStop.Trim());

                if ((allStops.Length) > 1 && IsAvailable(stopExpirationDate))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Only one stop can be set per transaction if an expiration date is present.",
                            transactionName, loanNumber));
                }

                // Commented out due to user id possibly being included on another Tran031 transaction

                //if((!IsAvailable(stopChangedBy)  || !IsAvailable(stopExpirationDate)) && (IsAvailable(armNoticeStop) || IsAvailable(armUpdateStop) || IsAvailable(badCheckStop) || IsAvailable(cbrIndicatorSwitch) || IsAvailable(disbursementStop) || IsAvailable(lateChargeStop) || IsAvailable(noAnalysisCode) || IsAvailable(noNoticeCode) || IsAvailable(processStop)))
                //{
                //    throw new Exception(string.Format("{0}: {1}: User ID and expiration date must be present when setting stops.", transactionName, loanNumber));
                //}

                if (!IsAvailable(cbrCommentCode) && IsAvailable(cbrCommentExpirationDate))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: CBR comment code is required when comment expiration date is provided.",
                            transactionName, loanNumber));
                }

                const string tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(processStop.Trim().PadRight(1)); // 14: PROCESS STOP
                tranBuilder.Append(badCheckStop.Trim().PadRight(1)); // 15: BAD CHECK STOP
                tranBuilder.Append(pifStop.Trim().PadRight(1)); // 16: PIF STOP
                tranBuilder.Append(foreclosureStop.Trim().PadRight(1)); // 17: FORECLOSURE STOP
                tranBuilder.Append(noNoticeCode.Trim().PadRight(1)); // 18: NO NOTICE CODE
                tranBuilder.Append(noAnalysisCode.Trim().PadRight(1)); // 19: NO ANALYSIS CODE
                tranBuilder.Append(ahFlag.Trim().PadRight(1)); // 20: AH FLAG
                tranBuilder.Append(lifeFlag.Trim().PadRight(1)); // 21: LIFE FLAG
                tranBuilder.Append(disbursementStop.Trim().PadRight(1)); // 22: DISBURSEMENT STOP
                tranBuilder.Append(floodEarthquakeInsuranceCode.Trim().PadRight(1)); // 23: FLOOD/EARTHQUAKE INSURANCE CODE
                tranBuilder.Append(lateChargeStop.Trim().PadRight(1)); // 24: LATE CHARGE ASSESSMENT STOP
                tranBuilder.Append(payoffPendingDisbursementStop.Trim().PadRight(1)); // 25: PAYOFF PENDING DISBURSEMENT STOP
                tranBuilder.Append(stopChangedBy.Trim().PadRight(3)); // 26-28: STOP CHANGED BY
                tranBuilder.Append(FormatDate(stopExpirationDate.Trim())); // 29-34: STOP EXPIRATION DATE
                tranBuilder.Append(armUpdateStop.Trim().PadRight(1)); // 35: ARM UPDATE STOP
                tranBuilder.Append(armNoticeStop.Trim().PadRight(1)); // 36: ARM NOTICE STOP
                tranBuilder.Append(payoffTrackingCode.Trim().PadRight(2)); // 37-38: PAYOFF TRACKING CODE
                tranBuilder.Append(windStormFlag.Trim().PadRight(1)); // 39: WINDSTORM FLAG
                tranBuilder.Append(hazardInsuranceFlags.Trim().PadRight(2)); // 40-41: HAZARD INSURANCE FLAGS
                tranBuilder.Append(cbrCommentCode.Trim().PadRight(2)); // 42-43: CBR COMMENT CODE
                tranBuilder.Append(FormatDate(cbrCommentExpirationDate.Trim())); // 44-49: CBR COMMENT EXPIRATION DATE
                tranBuilder.Append(' '); // 50: RESERVED
                tranBuilder.Append(forcedCoverageIndicator.Trim().PadRight(1)); // 51: FORCED COVERAGE INDICATOR
                tranBuilder.Append(FormatDate(delinquencyCommentDate.Trim())); // 52-57: DELINQUENCY COMMENT DATE
                tranBuilder.Append(FormatDate(cbrOccuranceFirstDate.Trim())); // 58-63: CBR OCCURANCE FIRST DATE
                tranBuilder.Append(elocAdvanceStop.Trim().PadRight(1)); // 64: ELOC ADVANCE STOP
                tranBuilder.Append(elocDisputedFlag.Trim().PadRight(1)); // 65: ELOC DISPUTED FLAG
                tranBuilder.Append(optOutStop.Trim().PadRight(1)); // 66: OPT OUT STOP
                tranBuilder.Append(' ', 2); // 67-68: RESERVED
                tranBuilder.Append(cbrIndicatorSwitch.Trim().PadRight(1)); // 69: CBR INDICATOR SWITCH
                tranBuilder.Append(cbrStatusCode.Trim().PadRight(2)); // 70-71: CBR STATUS CODE
                tranBuilder.Append(foreclosureTrackingSwitch.Trim().PadRight(1)); // 72: FORECLOSURE TRACKING SWITCH
                tranBuilder.Append(fnmaLrsActionCode.Trim().PadRight(2)); // 73-74: FANNIE MAE LRS ACTION CODE
                tranBuilder.Append(FormatDate(fnmaLrsActionDate.Trim())); // 75-80: FANNIE MAE LRS ACTION DATE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13,'0')); // 90-102: EXPANDED LOAN NUMBER



                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
                } 

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();
            

            return transaction;
        }

       
    }
}