#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 04T - Equity Line of Credit Adjustments (D-319)
        /// Transaction 04T is available only if you are installed on the Equity Line of Credit enhancement (IP 1423). Use of this transaction should be approved at the appropriate supervisory level.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="actionCode">(15) This field is required. It indicates the action you want to take on the specified loan.</param>
        /// <param name="userID">(16-18) This field is required. It indicates the ID of the person entering this information.</param>
        /// <param name="elocStatus">(19) This field is required. It indicates whether the loan is active or inactive. It updates the EL-STATUS field in the master file. Refer to the ELOC STATUS field on the ELCU screen in the ELOC Workstation to determine the loan's status.</param>
        /// <param name="planCode">(20-23) This field is required. It indicates the ELOC plan you want to use to set up the specified loan. This field updates the PLAN-CODE field in the master file.</param>
        /// <param name="routingTransit">(24-32) This field is optional. It indicates the nine-digit routing transit number for the credit line. This number appears on ELOC checks.</param>
        /// <param name="bankAccountNumber">(33-42) This field is optional. It indicates the 10-digit bank account number assigned to the credit line for the specified loan. This number appears on ELOC checks.</param>
        /// <param name="bankPrefix">(43-45) This field is optional. It indicates the financial institution.</param>
        /// <param name="creditLineAmount">(46-54) This field is required. It indicates the maximum amount advanced to the borrower according to the original ELOC agreement.</param>
        /// <param name="elocTolerancePercent">(55-57) This field is conditional. If you enter information in this field, leave the ELOC TOLERANCE: $ field blank. Use this field when you want to enter the ELOC tolerance as a percentage. The system rejects all advances that would increase the balance by a percentage higher than the one entered in this field. This field updates the EL-CR-TOLERANCE-AMT field in the master file. This field indicates the percent by which the outstanding balance may exceed the line of credit.</param>
        /// <param name="elocToleranceDollars">(58-66) This field is conditional. If you enter information in this field, leave the ELOC TOLERANCE: % field blank. Use this field when you want to enter the ELOC tolerance as a dollar amount. The system rejects all advances that would increase the balance by a value higher than the one in this field. This field is applicable only when the tolerance percentage is blank. This field updates the EL-CR-TOLERANCE-AMT field in the master file.  The field indicates the dollar amount by which the outstanding balance may exceed the line of credit.</param>
        /// <param name="noOfSegments">(79) (IP 1871 only) This field is required. It indicates the number of segments established.</param>
        /// <param name="segmentNo">(80) (IP 1871 only) This field is conditional. It is required if the NO OF SEGMENTS (X: 79) field equals 1. It indicates which segment is being added.</param>
        /// <returns>Transaction 04T Card X</returns>
        public static string Tran04TcX(string loanNumber, string actionCode, string userID, string elocStatus,
                                       string planCode, string routingTransit, string bankAccountNumber,
                                       string bankPrefix, string creditLineAmount, string elocTolerancePercent,
                                       string elocToleranceDollars, string noOfSegments, string segmentNo)
        {
            string transaction;

            try
            {
                var transactionName = "04T-X";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "actionCode", actionCode);
                CheckRequiredField(transactionName, "userID", userID);
                CheckRequiredField(transactionName, "elocStatus", elocStatus);
                CheckRequiredField(transactionName, "planCode", planCode);
                CheckRequiredField(transactionName, "creditLineAmount", creditLineAmount);

                if (!IsAvailable(elocTolerancePercent) && !IsAvailable(elocToleranceDollars))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Either elocTolerancePercent or elocToleranceDollars must be present.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("X"); // 14: CARD CODE
                tranBuilder.Append(actionCode.PadRight(1)); // 15: ACTION CODE
                tranBuilder.Append(userID.PadRight(3)); // 16-18: USER ID
                tranBuilder.Append(elocStatus.PadRight(1)); // 19: ELOC STATUS
                tranBuilder.Append(planCode.PadRight(4)); // 20-23: PLAN CODE
                tranBuilder.Append(LeftZeroFillOptionalField(routingTransit, 9)); // 24-32: ROUTING TRANSIT
                tranBuilder.Append(LeftZeroFillOptionalField(bankAccountNumber, 10)); // 33-42: BANK ACCOUNT NUMBER
                tranBuilder.Append(LeftZeroFillOptionalField(bankPrefix, 3)); // 43-45: BANK PREFIX
                tranBuilder.Append(FormatMoney(creditLineAmount, false, true, 9)); // 46-54: CREDIT LINE AMOUNT
                tranBuilder.Append(FormatPercent(elocTolerancePercent, 3)); // 55-57: ELOC TOLERANCE: %
                tranBuilder.Append(FormatMoney(elocToleranceDollars, false, false, 9)); // 58-66: ELOC TOLERANCE: $
                tranBuilder.Append(' ', 12); // 67-78: RESERVED
                tranBuilder.Append(' '); // 79: NO OF SEGMENTS
                tranBuilder.Append(segmentNo.PadRight(1)); // 80: SEGMENT NO
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 04T - Equity Line of Credit Adjustments (D-319)
        /// Transaction 04T is available only if you are installed on the Equity Line of Credit enhancement (IP 1423). Use of this transaction should be approved at the appropriate supervisory level.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="actionCode">(15) This field is required. It indicates the action you want to take on the specified loan.</param>
        /// <param name="userID">(16-18) This field is required. It indicates the ID of the person entering this information.</param>
        /// <param name="minimumAdvance">(19-22) This field is required. It indicates the minimum amount allowed per single advance. The system rejects advances less than this amount.</param>
        /// <param name="nextCheckNumber">(27-30) This field is conditional; it is sometimes optional and sometimes not allowed. During loan setup it is optional. You cannot change existing check numbers. This field indicates the starting number of the next series of checks. After loan setup, the system assigns this number unless the original loan has been purchased or servicing transferred (represented by an acquisition type of 2 or 3). This field updates the NEXT-CHECK-NO field in the master file.</param>
        /// <param name="numberOfChecks">(31-32) This field is optional. It indicates the number of checks you want the system to produce.</param>
        /// <param name="odpDdaAcctNo">(54-63) This field is optional. It indicates the bank account number to which the ELOC advance for overdraft protection will be sent.</param>
        /// <param name="segmentNo">(80) This field is conditional. It is required if the NO OF SEGMENTS (X: 79) field equals 1. It indicates which segment is being added.</param>
        /// <returns>Transaction 04T Card Y</returns>
        public static string Tran04TcY(string loanNumber, string actionCode, string userID, string minimumAdvance,
                                       string nextCheckNumber, string numberOfChecks, string odpDdaAcctNo,
                                       string segmentNo)
        {
            string transaction;

            try
            {
                var transactionName = "04T-Y";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "actionCode", actionCode);
                CheckRequiredField(transactionName, "userID", userID);
                CheckRequiredField(transactionName, "minimumAdvance", minimumAdvance);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("Y"); // 14: CARD CODE
                tranBuilder.Append(actionCode.PadRight(1)); // 15: ACTION CODE
                tranBuilder.Append(userID.PadRight(3)); // 16-18: USER ID
                tranBuilder.Append(FormatMoney(minimumAdvance, false, true, 4)); // 19-22: MINIMUM ADVANCE
                tranBuilder.Append(' ', 4); // 23-26: NUMBER OF ADVANCES
                tranBuilder.Append(LeftZeroFillOptionalField(nextCheckNumber, 4)); // 27-30: NEXT CHECK NUMBER
                tranBuilder.Append(LeftZeroFillOptionalField(numberOfChecks, 2)); // 31-32: NUMBER OF CHECKS
                tranBuilder.Append(' ', 21); // 33-53: RESERVED
                tranBuilder.Append(LeftZeroFillOptionalField(odpDdaAcctNo, 10)); // 54-63: ODP DDA ACCT NO
                tranBuilder.Append(' ', 16); // 64-79: RESERVED
                tranBuilder.Append(segmentNo.PadRight(1)); // 80: SEGMENT NO
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 04T - Equity Line of Credit Adjustments (D-319)
        /// Transaction 04T is available only if you are installed on the Equity Line of Credit enhancement (IP 1423). Use of this transaction should be approved at the appropriate supervisory level.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="actionCode">(15) This field is required. It indicates the action you want to take on the specified loan.</param>
        /// <param name="lienUserID">(16-18) This field is required. It indicates the ID of the person entering lien the information.</param>
        /// <param name="lienPosition">(19-20) This field is conditional. It is required if the loan's hi-type is 3. The system automatically fills this field if the hi-type is 1. This field indicates the lien position of the specified ELOC loan.</param>
        /// <param name="elocPercent">(21-23) This field is required. It indicates the maximum percentage of the equity limit (LTV) allowed on ELOC loans secured by real estate. This field updates the EL-ELOC-PCT field in the master file.</param>
        /// <param name="securedFlag">(24) This field is required. It indicates if the loans tied to this plan code are secured by real estate property.</param>
        /// <param name="availableUserID">(25-27) This field is required. It indicates the ID of the person entering the available line of credit.</param>
        /// <param name="availableLineCalulationMethod">(28) This field is required. It tells the system how to calculate the available line of credit.</param>
        /// <param name="creditReviewFrequency">(29-31) This field is optional. It indicates the number of months between each credit review.</param>
        /// <param name="creditReviewDate">(32-37) This field is conditional. It is required if the CREDIT REVIEW FREQUENCY field contains a value. This field indicates the date of the first credit review after loan closing.</param>
        /// <param name="lastCreditReviewDate">(38-43) This field is conditional. It is required if the CREDIT REVIEW FREQUENCY field contains a value. This field indicates the date of the last credit review before the loan's maturity.</param>
        /// <param name="maximumIRAdvanceOption">(44) This field is required. It indicates whether or not you want the system to reject ELOC advances when the loan reaches the maximum interest rate you establish.</param>
        /// <param name="bankruptcyOption">(45) This field is required. It indicates whether you want the system to reject ELOC advances on a specific loan number or any loans linked to a specific loan that are flagged bankrupt.</param>
        /// <param name="year_endReportingSecured">(46) This field is conditional. It is required if the SECURED FLAG field contains Y. This field tells the system whether to report secured credit line loans to the IRS as mortgage loans.</param>
        /// <param name="year_endReportingUnsecured">(47) This field is conditional.  It is required if the SECURED FLAG field contains N. This field indicates whether to report unsecured credit line loans tied to this plan to the IRS as mortgage loans.</param>
        /// <param name="segmentNo">(80) This field is conditional. It is required if the NO OF SEGMENTS (X: 79) field equals 1. It indicates which segment is being added.</param>
        /// <returns>Transaction 04T Card Z</returns>
        public static string Tran04TcZ(string loanNumber, string actionCode, string lienUserID, string lienPosition,
                                       string elocPercent, string securedFlag, string availableUserID,
                                       string availableLineCalulationMethod, string creditReviewFrequency,
                                       string creditReviewDate, string lastCreditReviewDate,
                                       string maximumIRAdvanceOption, string bankruptcyOption,
                                       string year_endReportingSecured, string year_endReportingUnsecured,
                                       string segmentNo)
        {
            string transaction;

            try
            {
                var transactionName = "04T-Z";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "actionCode", actionCode);
                CheckRequiredField(transactionName, "lienUserID", lienUserID);
                CheckRequiredField(transactionName, "elocPercent", elocPercent);
                CheckRequiredField(transactionName, "securedFlag", securedFlag);
                CheckRequiredField(transactionName, "availableUserID", availableUserID);
                CheckRequiredField(transactionName, "availableLineCalulationMethod", availableLineCalulationMethod);
                CheckRequiredField(transactionName, "maximumIRAdvanceOption", maximumIRAdvanceOption);
                CheckRequiredField(transactionName, "bankruptcyOption", bankruptcyOption);

                if (IsAvailable(creditReviewFrequency))
                {
                    if (!IsAvailable(creditReviewDate))
                    {
                        throw new Exception(
                            string.Format(
                                "{0}: {1}: creditReviewDate is required when creditReviewFrequency has a value.",
                                transactionName, loanNumber));
                    }

                    if (!IsAvailable(lastCreditReviewDate))
                    {
                        throw new Exception(
                            string.Format(
                                "{0}: {1}: lastCreditReviewDate is required when creditReviewFrequency has a value.",
                                transactionName, loanNumber));
                    }
                }

                if (securedFlag.Trim() == "N" && !IsAvailable(year_endReportingUnsecured))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: year_endReportingUnsecured is required when securedFlag is set to 'N'.",
                            transactionName, loanNumber));
                }

                if (securedFlag.Trim() == "Y" && !IsAvailable(year_endReportingSecured))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: year_endReportingSecured is required when securedFlag is set to 'Y'.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("Z"); // 14: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 15: ACTION CODE
                tranBuilder.Append(lienUserID.Trim().PadRight(3)); // 16-18: LIEN USER ID
                tranBuilder.Append(LeftZeroFillOptionalField(lienPosition.Trim(), 2)); // 19-20: LIEN POSITION
                tranBuilder.Append(FormatPercent(elocPercent.Trim(), 3)); // 21-23: ELOC PERCENT
                tranBuilder.Append(securedFlag.Trim().PadRight(1)); // 24: SECURED FLAG
                tranBuilder.Append(availableUserID.Trim().PadRight(3)); // 25-27: AVAILABLE USER ID
                tranBuilder.Append(availableLineCalulationMethod.Trim().PadRight(1));
                // 28 AVAILABLE LINE CALCULATION METHOD
                tranBuilder.Append(LeftZeroFillOptionalField(creditReviewFrequency.Trim(), 3));
                // 29-31: CREDIT REVIEW FREQUENCY
                tranBuilder.Append(FormatDate(creditReviewDate.Trim())); // 32-37: CREDIT REVIEW DATE
                tranBuilder.Append(FormatDate(lastCreditReviewDate.Trim())); // 38-43: LAST CREDIT REVIEW DATE
                tranBuilder.Append(maximumIRAdvanceOption.Trim().PadRight(1)); // 44: MAXIMUM IR ADVANCE OPTION
                tranBuilder.Append(bankruptcyOption.Trim().PadRight(1)); // 45: BANKRUPTCY OPTION
                tranBuilder.Append(year_endReportingSecured.Trim().PadRight(1)); // 46: YEAR-END REPORTING: SECURED
                tranBuilder.Append(year_endReportingUnsecured.Trim().PadRight(1)); // 47: YEAR-END REPORTING: UNSECURED
                tranBuilder.Append(' ', 32); // 48-79: RESERVED
                tranBuilder.Append(segmentNo.Trim().PadRight(1)); // 80: SEGMENT NO
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}