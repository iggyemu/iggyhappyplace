﻿using System;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction used to record full payment on a loan.
        /// </summary>
        /// <param name="loanNumber">Required.  The loan number</param>
        /// <param name="subCode">Required.  A switch that indicates when a client processes a full-settlement, paid-in-full or partial-settlement in the month of December for a Ginnie Mae loan.</param>
        /// <param name="hiType">Required.  The type of mortgage loan.</param>
        /// <param name="interestPaidTo">Required.  Indicates when interest is to be paid. The system calculates the interest against the principal balance based on this date and compares the result with interest paid.</param>
        /// <param name="principalPaid">Required.  The amount paid on the loan principal.  This field reduces the principal balance.  A new balance should be reflected as zero.</param>
        /// <param name="interestPaid">Required.  The amount of interest paid on the loan.  This field increases the interest paid year-to-date.</param>
        /// <param name="replacementReserve">Optional.  Funds applied to or from the replacement reserve balance.</param>
        /// <param name="penaltyInterest">Optional.  The amount of penalty interest paid.</param>
        /// <param name="penaltyInterestServiceFee">Optional.  The amoount of the service fee that the servicer should collect.  This is deducted from penalty interest and not included in crossfoot.  If entered, the penalty interest service fee is deducted from the penalty interes, and the result is the amount credited to the penalty interest account.  The penalty interest service fee is included with the regular service fee.</param>
        /// <param name="escrowPaid">Optional.  The amount of escrow funds received.</param>
        /// <param name="suspense">Optional.  The amount of suspense monies being distributed.</param>
        /// <param name="amountReceived">Required.  A crossfoot of monetary amounts reflected on the transactions, excluding penalty interest service fee, if any</param>
        /// <returns></returns>
        public static string Tran081(string loanNumber = "", string subCode = "", string hiType = "", string interestPaidTo = "",
            string principalPaid = "", string interestPaid = "", string replacementReserve = "",
            string penaltyInterest = "", string penaltyInterestServiceFee = "",
            string escrowPaid = "", string suspense = "", string amountReceived = "")
        {


            string transaction;

            


                var transactionName = "081";
                
                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Sub Code", subCode);
                CheckRequiredField(transactionName, "Hi Type", hiType);
                CheckRequiredField(transactionName, "Interest Paid To", interestPaidTo);
                CheckRequiredField(transactionName, "Principal Paid", principalPaid);
                CheckRequiredField(transactionName, "Interest Paid", interestPaid);
                CheckRequiredField(transactionName, "Amount Received", amountReceived);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();
                tranBuilder.Append(tranClient); // 1-6 CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN NUMBER
                tranBuilder.Append(subCode); // 14 SUB CODE
                tranBuilder.Append(hiType); // 15 HI-TYPE
                tranBuilder.Append(interestPaidTo); // 16-21 INTEREST PAID TO 
                tranBuilder.Append(Convert.ToZonedString(principalPaid.Trim(),string.Empty,true,true,true).PadLeft(10, '0')); // 22-31 PRINCIPAL PAID
                tranBuilder.Append(Convert.ToZonedString(interestPaid.Trim(),string.Empty,true,true,true).PadLeft(7, '0')); // 32-38 INTEREST PAID
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(replacementReserve,string.Empty, true, true, true),7)); // 39-45 REPLACEMENT RESERVE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(penaltyInterest, string.Empty, true, true, true), 7)); // 46-52 PENALTY INTEREST
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(penaltyInterestServiceFee,string.Empty, true, true, true),5)); // 53-57 PENALTY INTEREST SERVICE FEE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(escrowPaid,string.Empty, true, true, true),7)); // 58-64 ESCROW PAID
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(suspense.Trim(),string.Empty, true, true, true), 9)); // 65-73 SUSPENSE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(amountReceived.Trim(),string.Empty, true, true, true),7)); // 74-80 AMOUNT RECEIVED
                tranBuilder.Append(' ', 9); // 81-89 RESERVED
                tranBuilder.Append(loanNumber.PadLeft(13, '0')); // 90-102 LOAN NUMBER

                if (tranBuilder.Length != 102)
                {
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}",transactionName,tranBuilder));
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();

            
            
            return transaction;
        }
    }
}
