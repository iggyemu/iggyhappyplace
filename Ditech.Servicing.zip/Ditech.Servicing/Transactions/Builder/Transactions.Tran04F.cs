#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 04F - Foreclosure Workstation Maintenance Update (D-313)
        /// Transaction 04F maintains the Foreclosure Workstation fields.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="foreclosureWorkstationCode"> (16) This field is optional. It indicates the status of the loan in the Foreclosure Workstation.</param>
        /// <param name="beginningForeclosureDate">(17-22) This field is conditional upon the code entered in the FORECLOSURE WORKSTATION CODE field. It indicates the date the loan was added to the Foreclosure Workstation.</param>
        /// <param name="foreclosureReinstatementDate">(23-28) This field is conditional upon the code entered in the FORECLOSURE WORKSTATION CODE field. It indicates the date the foreclosed loan was reinstated.</param>
        /// <param name="reoStatus">(29) This field is optional. It indicates the status of the property in the REO Workstation.</param>
        /// <param name="bankruptcyStatus">(30) This field is optional. It indicates the status of the loan in the Bankruptcy Workstation.</param>
        /// <param name="bankruptcyCreditBureauMortgagorCode">(31) This field is conditional upon the code entered in the BANKRUPTCY STATUS field. It indicates whether the mortgagor, co-mortgagor, or both are filing bankruptcy.</param>
        /// <param name="bankruptcyPropertyInspectionOrderFlag">(32) This field is not used.</param>
        /// <param name="bankruptcyStartDate">(33-38) This field is conditional upon the code entered in the BANKRUPTCY STATUS field. It indicates the date the loan was added to the Bankruptcy Workstation. This field is required if the BANKRUPTCY COMPLETE DATE is blank.</param>
        /// <param name="bankruptcyCompleteDate">(39-44) This field is conditional upon the code entered in the BANKRUPTCY STATUS field. It indicates the date the bankruptcy case was completed.</param>
        /// <param name="reoLastInvestorBillDate">(45-50) This field is optional. It indicates the date on which the investor was last billed for servicer advances.</param>
        /// <param name="reoLastInvestorBillAmount">(51-59) This field is optional. It indicates the amount of the last bill that was sent to the investor.</param>
        /// <param name="reoInvestorTotalBillAmount">(60-70) This field is optional. It indicates the total amount of all billings sent to the investor.</param>
        /// <param name="lossMitigationStatus">(80) This field is optional. It indicates the status of the loan in the Loss Mitigation Workstation.</param>
        /// <returns>Transaction 04F</returns>
        public static string Tran04F(string loanNumber, string foreclosureWorkstationCode,
                                     string beginningForeclosureDate, string foreclosureReinstatementDate,
                                     string reoStatus, string bankruptcyStatus,
                                     string bankruptcyCreditBureauMortgagorCode,
                                     string bankruptcyPropertyInspectionOrderFlag, string bankruptcyStartDate,
                                     string bankruptcyCompleteDate, string reoLastInvestorBillDate,
                                     string reoLastInvestorBillAmount, string reoInvestorTotalBillAmount,
                                     string lossMitigationStatus)
        {
            string transaction;

            try
            {
                var transactionName = "04F-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranBuilder = new StringBuilder();

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append(' ', 2); // 14-15: RESERVED
                tranBuilder.Append(foreclosureWorkstationCode.Trim().PadRight(1)); // 16: FORECLOSURE WORKSTATION CODE
                tranBuilder.Append(FormatDate(beginningForeclosureDate)); // 17-22: BEGINNING FORECLOSURE DATE
                tranBuilder.Append(FormatDate(foreclosureReinstatementDate)); // 23-28: FORECLOSURE REINSTATEMENT DATE
                tranBuilder.Append(reoStatus.Trim().PadRight(1)); // 29: REO STATUS
                tranBuilder.Append(bankruptcyStatus.Trim().PadRight(1)); // 30: BANKRUPTCY STATUS
                tranBuilder.Append(bankruptcyCreditBureauMortgagorCode.Trim().PadRight(1));
                // 31: BANKRUPTCY CREDIT BUREAU MORTGAGOR CODE
                tranBuilder.Append(bankruptcyPropertyInspectionOrderFlag.Trim().PadRight(1));
                // 32: BANKRUPTCY PROPERTY INSPECTION ORDER FLAG
                tranBuilder.Append(FormatDate(bankruptcyStartDate)); // 33-38: BANKRUPTCY START DATE
                tranBuilder.Append(FormatDate(bankruptcyCompleteDate)); // 39-44: BANKRUPTCY COMPLETE DATE
                tranBuilder.Append(FormatDate(reoLastInvestorBillDate)); // 45-50: REO LAST INVESTOR BILL DATE
                tranBuilder.Append(FormatMoney(reoLastInvestorBillAmount.Trim(), true, false, 9));
                // 51-59: REO LAST INVESTOR BILL AMOUNT
                tranBuilder.Append(FormatMoney(reoInvestorTotalBillAmount.Trim(), true, false, 11));
                // 60-70: REO INVESTOR TOTAL BILL AMOUNT
                tranBuilder.Append(' ', 9); // 71-79: RESERVED
                tranBuilder.Append(lossMitigationStatus.Trim().PadRight(1)); // 80: LOSS MITIGATION STATUS
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}