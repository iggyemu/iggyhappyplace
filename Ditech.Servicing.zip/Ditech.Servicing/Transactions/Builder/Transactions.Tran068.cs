﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates 068 - Escrow Advance Refund Request (D-013)
        /// Use transaction 068 to generate a refund of escrow advances. MSP refunds the advance amount to the extent of the escrow advance balance or the escrow balance, whichever is less.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <returns>Transaction 068</returns>
        public static string Tran068(string loanNumber = "")
        {
            string transaction;

            try
            {
                var transactionName = "068";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(' ', 67); //  14-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
