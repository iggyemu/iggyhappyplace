#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 020 - Loan Dates and Origination Data (D-021).  
        /// Use transaction 020 to enter origination data, the type of the loan, the mortgagor's regular payment amount, and the mortgagor's telephone number.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="loanClosingDate">(14-19) This field is conditional. It is required if this loan is not an acquired or a transferred loan. This field indicates the date of the mortgage (loan closing date) for all non-HUD 235 loans. For HUD 235 loans, it contains the date the first payment is due (which is used in the Formula II calculation). This field moves from the input to the loan date in the master record. If there is no interest due entered on transaction 042 (D-021), and the type of acquisition is equal to 1, this date is used to calculate the interest due. </param>
        /// <param name="paymentDueDate">(20-25) This field is required. It indicates the date on which the next mortgage payment is due. This date automatically advances when a mortgage payment is applied, based on the payment frequency in the master record. This field moves from the input to the payment due date in the master record. </param>
        /// <param name="loanMaturityDate">(26-31) This field is required. It indicates the date final payment is due on the loan. This field moves from the input to the maturity date in the master record. </param>
        /// <param name="loanTerm">(32-34) This field is required. It indicates the number of months in the full term of the loan. This field moves from the input to the loan term in the master record. </param>
        /// <param name="nextPaymentNumber">(35-37) This field is required. It indicates the next scheduled principal payment on the loan. This field moves from the input to the next payment number in the master record, except for portfolio transfers and purchases. </param>
        /// <param name="originalMortgageAmount">(38-46) This field is required. It indicates the dollar amount of the note. This field moves from the input to the original mortgage amount in the master record. </param>
        /// <param name="office">(47-48) This field is required. It indicates the originating office or servicing branch. This field moves from the input to the office (area, branch, zone) in the master record. </param>
        /// <param name="typeOfAcquisition">(49) This field is required. It indicates codes for the manner in which the loan was added to the portfolio. This field moves from the input to the type of acquisition in the master record. </param>
        /// <param name="typeOfLoan">(50-51) This field is required. It indicates the type of mortgage and loan. This field moves from the input to the type of loan in the master record. The classification and description for each position in this field are given below. </param>
        /// <param name="telephoneNumber">(52-61) This field is optional. It indicates the mortgagor's telephone number. This field moves from the input to the telephone number in the master record. </param>
        /// <param name="man">(62) This field is required. It indicates the man code that assigns loans to collectors and allows various sort sequences on collection and hazard reports. This field moves from the input to the man code in the master file. </param>
        /// <param name="numberOfUnits">(63) This field is optional. It indicates the number of units for reporting to Fannie Mae. The field moves from the input to number of units in the master record. </param>
        /// <param name="netPayment">(64-72) This field is required. It indicates the total amount due from the mortgagor as a regular payment on the loan. </param>
        /// <param name="couponMonth">(74-75) This field is optional. It indicates the month from which coupons are to be produced. </param>
        /// <param name="capitalizedLoanFlag">(76) This field is optional. It indicates that the loan is a capitalized loan. The field moves from the input to the capitalized loan flag in the master record. </param>
        /// <param name="interestIndicator">(77) This field is optional. It indicates how interest is earned. This field moves from the input to the interest indicator in the master record. </param>
        /// <param name="productLineCode">(78-80) This field is optional. It is a user-defined field that groups loans by any criterion the user requires. This field moves from the input to the product line code in the master record. </param>
        /// <returns>Transaction 020</returns>
        public static string Tran020(string loanNumber, string loanClosingDate, string paymentDueDate,
                                     string loanMaturityDate, string loanTerm, string nextPaymentNumber,
                                     string originalMortgageAmount, string office, string typeOfAcquisition,
                                     string typeOfLoan, string telephoneNumber, string man, string numberOfUnits,
                                     string netPayment, string couponMonth, string capitalizedLoanFlag,
                                     string interestIndicator, string productLineCode)
        {
            string transaction;

            try
            {
                var transactionName = "020";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "paymentDueDate", paymentDueDate.Trim());
                CheckRequiredField(transactionName, "loanMaturityDate", loanMaturityDate.Trim());
                CheckRequiredField(transactionName, "loanTerm", loanTerm.Trim());
                CheckRequiredField(transactionName, "nextPaymentNumber", nextPaymentNumber.Trim());
                CheckRequiredField(transactionName, "originalMortgageAmount", originalMortgageAmount.Trim());
                CheckRequiredField(transactionName, "office", office.Trim());
                CheckRequiredField(transactionName, "typeOfLoan", typeOfLoan.Trim());
                CheckRequiredField(transactionName, "man", man.Trim());
                CheckRequiredField(transactionName, "netPayment", netPayment.Trim());

                if (!IsAvailable(loanClosingDate.Trim()) && typeOfAcquisition == "1")
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Loan closing date is required when loan is not acquired or transferred.",
                            transactionName, loanNumber));

                var tranClient = transactionName.Trim() + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(loanClosingDate.Trim())); // 14-19: LOAN CLOSING DATE
                tranBuilder.Append(FormatDate(paymentDueDate.Trim())); // 20-25: PAYMENT DUE DATE
                tranBuilder.Append(FormatDate(loanMaturityDate.Trim())); // 26-31: LOAN MATURITY DATE
                tranBuilder.Append(loanTerm.Trim().PadLeft(3, '0')); // 32-34: LOAN TERM
                tranBuilder.Append(nextPaymentNumber.Trim().PadLeft(3, '0')); // 35-37 NEXT PAYMENT NUMBER
                tranBuilder.Append(FormatMoney(originalMortgageAmount.Trim(), false, true, 9));
                // 38-46: ORIGINAL MORTGAGE AMOUNT                 
                tranBuilder.Append(office.Trim().PadRight(2)); //  47-48: OFFICE
                tranBuilder.Append(typeOfAcquisition.Trim().PadRight(1)); // 49: TYPE OF ACQUISITION
                tranBuilder.Append(typeOfLoan.Trim().PadRight(2)); // 50-51: TYPE OF LOAN
                tranBuilder.Append(telephoneNumber.Trim().PadRight(10)); // 52-61 TELEPHONE NUMBER
                tranBuilder.Append(man.Trim().PadRight(1)); // 62: MAN
                tranBuilder.Append(numberOfUnits.Trim().PadRight(1)); // 63: NUMBER OF UNITS
                tranBuilder.Append(FormatMoney(netPayment.Trim(), true, true, 9)); // 64-72: NET PAYMENT
                tranBuilder.Append(' ', 1); // 73: RESERVED
                tranBuilder.Append(couponMonth.Trim().PadLeft(2, '0')); // 74-75: COUPON MONTH
                tranBuilder.Append(capitalizedLoanFlag.Trim().PadRight(1)); // 76: CAPITALIZED LOAN FLAG
                tranBuilder.Append(interestIndicator.Trim().PadRight(1)); // 77: INTEREST INDICATOR
                tranBuilder.Append(productLineCode.Trim().PadRight(3)); // 78-80: PRODUCT LINE CODE
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102 EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}