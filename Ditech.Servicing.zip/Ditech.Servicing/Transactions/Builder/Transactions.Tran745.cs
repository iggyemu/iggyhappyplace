﻿using System;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 745 - Restricted Corporate Advance Adjustments (D-258)
        /// Transaction 745 adjusts the corporate advance mortgagor recoverable, third-party recoverable, or non-recoverable balances.You may treat the balance to be adjusted as a positive or negative balance.
        /// </summary>
        /// <param name="loanNumber">Required.  This field identifies the loan.</param>
        /// <param name="corporateAdvanceAdjustment">Required.  It adjusts the corporate advance mortgagor recoverable, third-party recoverable, or non-recoverable balance in the master file.</param>
        /// <param name="recoverableNonRecoverableIndicator">Required.  It indicates which balance needs adjustment.</param>
        /// <param name="reason">Required.  It is a free-form field that notes the reason for the adjustment to the balance</param>
        /// <param name="processor">Required.  It identifies the person making the adjustment.  This appears on the loan ledger history.</param>
        /// <param name="corporateAdvancePayee">Conditional.  It indicates the corporate advance payee to be adjusted.  If a value appears in the MEMO ITEM SWITCH field, then you must enter a value in this field.</param>
        /// <param name="memoItemSwitch">Conditional.  It indicates whether or not the system processes the adjustments made to the corporate advance payee balance.  If a value appears in the CORPORATE ADVANCE PAYEE field, then you must enter a value in this field.</param>
        /// <param name="corporateAdvancePayeeReasonCode">Optional.  It contains a user-defined code indicating the reason for the adjustment transaction.</param>
        /// <param name="corporateAdvanceOriginalDisbursementDate">Optional.  It indicates the repayment date of the outstanding corporate advance disbursements.  Use this field when you intend to match this adjustment transaction with a specific disbursement transaction.  
        ///                                                        To use this field the third position of the CORPORATE ADVANCE PAYEE field must be an R or T.</param>
        /// <param name="originalPayee">Optional.  It tracks the repayment of outstanding corporate advance disbursements.  This payee should be the same escrow payee used for the original disbursement in order to provide an audit trail of what disbursements have been repaid.</param>
        /// <param name="obligor">Conditional.  It is required for third party recoverable adjustments and optional on recoverable or non-recoverable adjustments.  It indicates the entity or individual, other than the mortgagor or co-mortgagor, responsible for repayment of a corporate advance.</param>
        /// <param name="overRide">Optional.  It indicates whether to override the exlamation point (!) process stop.  This process stop causes the system to reject this transaction at the update level.  This system-defined stop is set up on the SAF1 screen in the MSP Info Tracking Workstation.</param>
        /// <exception cref="Exception"></exception>
        /// <returns></returns>
        public static string Tran745(string loanNumber = "", string corporateAdvanceAdjustment = "",
                                     string recoverableNonRecoverableIndicator = "", string reason = "", string processor = "",
                                     string corporateAdvancePayee = "", string memoItemSwitch = "", string corporateAdvancePayeeReasonCode = "",
                                     string corporateAdvanceOriginalDisbursementDate = "",
                                     string originalPayee = "", string obligor = "", string overRide = "")
        
        {
            string transaction = "";

           
                var transactionName = "745";

                CheckValidLoanNumber(transactionName,loanNumber);
                
                CheckRequiredField(transactionName, "corporateAdvanceAdjustment", corporateAdvanceAdjustment);
                CheckRequiredField(transactionName,"recoverableNonRecoverableIndicator",recoverableNonRecoverableIndicator);
                CheckRequiredField(transactionName,"reason",reason);
                
                if (IsAvailable(corporateAdvancePayee) && (!IsAvailable(memoItemSwitch) || (memoItemSwitch != "N" && memoItemSwitch != "Y")))
                {
                    throw new Exception("Memo Item Switch is required and must be equal to 'Y' or 'N' if Corporate Advance Payee is supplied.");
                }
                if (!IsAvailable(corporateAdvancePayee) && IsAvailable(memoItemSwitch))
                {
                    throw new Exception("Corporate Advance Payee is required if Memo Item Switch is supplied.");
                }
               
                
                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient);  // 1-6 CLIENT
                tranBuilder.Append("*".PadRight(7));  // 7-13 LOAN NUMBER
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(corporateAdvanceAdjustment,string.Empty, true, true,true), 9)); // 14-22 CORPORATE ADVANCE ADJUSTMENT
                tranBuilder.Append(recoverableNonRecoverableIndicator.PadRight(1)); // 23 RECOVERABLE/NON-RECOVERABLE INDICATOR
                tranBuilder.Append(reason.PadRight(16)); // 24-39 REASON
                tranBuilder.Append(processor.PadRight(3)); // 40-42 PROCESSOR
                tranBuilder.Append(corporateAdvancePayee.PadRight(5)); // 43-47 CORPORATE ADVANCE PAYEE
                tranBuilder.Append(memoItemSwitch.PadRight(1)); // 48 MEMO ITEM SWITCH
                tranBuilder.Append(corporateAdvancePayeeReasonCode.PadRight(4)); // 49-52 CORPORATE ADVANCE PAYEE REASON CODE
                tranBuilder.Append(' ',1); // 53 RESERVED
                tranBuilder.Append(!corporateAdvanceOriginalDisbursementDate.IsNullOrEmpty(true)  // 54-59 CORPORATE ADVANCE ORIGINAL DISBURSEMENT DATE
                    ? Convert.ToDateTimeString(corporateAdvanceOriginalDisbursementDate, "MMddyy").PadRight(6) 
                    : corporateAdvanceOriginalDisbursementDate.PadRight(6));
                tranBuilder.Append(originalPayee.PadRight(10)); // 60-69 ORIGINAL PAYEE
                tranBuilder.Append(obligor.PadRight(6)); // 70-75 OBLIGOR
                tranBuilder.Append(' ', 4); // 76-79 RESERVED
                tranBuilder.Append(overRide.PadRight(1)); // 80 OVERRIDE
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

                if (tranBuilder.Length != 102)
                {
                    //throw new Exception($"{transactionName}: Line length mismatch: {tranBuilder}");
                    throw new Exception("{transactionName}: Line length mismatch: {tranBuilder}");
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();

            

            return transaction;
        }

        public static string Tran745(object tran745Ojbect)
        {

            var transaction = string.Empty;



            return transaction;
        }
    }
}
