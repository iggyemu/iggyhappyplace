#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 042 - Principal, Interest, and Discount Data (D-021).
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="hiType">(14) This field is required. Piggyback or hi-type 2 loans are not allowed.</param>
        /// <param name="principalBalance">(15-25) This field is required. It contains the principal balance of the mortgage remaining to be paid.</param>
        /// <param name="discountPercent">(33-41) This field is optional. It contains the discount percent, which is used with the principal balance to calculate the discount amount at the time of purchase.</param>
        /// <param name="interestDue">(42-48) This field is optional. It contains the amount of interest that is due with the first payment in addition to the regular payment as a result of the loan closing on a date other than the due date. If this field is left blank and if the acquisition code in the master file equals 1, the interest will be computed automatically from the loan closing date to the payment due date. If present on input, this field is moved to the INTEREST DUE field in the master file.</param>
        /// <param name="tranTotal">(49-59) This field is optional. This is a crossfoot field used by edit program E-006 to help prevent incorrect data from being entered into the monetary fields of this transaction.</param>
        /// <param name="constructionCode">(67) This field is optional. It indicates whether the property securing the loan contains existing construction or is a newly constructed dwelling. This information determines what appears in either the NEW PROPERTY or EXISTING PROPERTY fields on S-241.</param>
        /// <param name="discountAmortizationCode">(68) This field is optional. It indicates the method used to amortize the discount.</param>
        /// <param name="discountAmortizationMonths">(67-71) This field is conditional. Enter information in this field only if the discount amortization code is an A or C. It designates the number of months to amortize the discount.</param>
        /// <param name="stopAccrualDays">(76-78) This field is optional. It allows loan-level control of the accrual period desired. This is the number of days measured from the date interest is paid to the loan. This field value is also used to indicate the number of days interest is to be accrued when the loan is designated (either by user input or system change) as non-accrual.</param>
        /// <param name="accrualStatus">(80) This field is optional. Use it to indicate the current accrual status of the loan; that is, accrual or non-accrual.</param>
        /// <returns>Transaction 042</returns>
        public static string Tran042(string loanNumber, string hiType, string principalBalance, string discountPercent,
                                     string interestDue, string tranTotal, string constructionCode,
                                     string discountAmortizationCode, string discountAmortizationMonths,
                                     string stopAccrualDays, string accrualStatus)
        {
            string transaction;

            try
            {
                var transactionName = "042";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Hi-Type (14)", hiType);
                CheckRequiredField(transactionName, "Principal Balance (15-25)", principalBalance);

                if ((discountAmortizationCode == "A" || discountAmortizationCode == "C") &&
                    string.IsNullOrEmpty(discountAmortizationMonths))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Discount amortization months (69-71) cannot be empty if discount amortization code (68) is A or C.",
                            transactionName, loanNumber));
                }

                var tranClient = "042" + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: HI TYPE
                tranBuilder.Append(FormatMoney(principalBalance.Trim(), true, true, 11)); // 15-25: PRINCIPAL BALANCE
                tranBuilder.Append(' ', 7); // 26-32: RESERVED
                tranBuilder.Append(FormatPercent(discountPercent.Trim(), 9)); // 33-41 DISCOUNT PERCENT
                tranBuilder.Append(FormatMoney(interestDue.Trim(), true, false, 7)); // 42-48: INTEREST DUE
                tranBuilder.Append(FormatMoney(tranTotal.Trim(), true, false, 11)); // 49-59: TRAN TOTAL
                tranBuilder.Append(' ', 7); // 60-66: RESERVED
                tranBuilder.Append(constructionCode.Trim().PadRight(1)); // 67: CONSTRUCTION CODE
                tranBuilder.Append(discountAmortizationCode.Trim().PadRight(1)); // 68: DISCOUNT AMORTIZATION CODE
                tranBuilder.Append(discountAmortizationMonths.Trim().PadLeft(3)); // 69-71: DISCOUNT AMORTIZATION MONTHS
                tranBuilder.Append(' ', 4); // 72-75: RESERVED
                tranBuilder.Append(stopAccrualDays.Trim().PadLeft(3)); // 76-78: STOP ACCRUAL DAYS
                tranBuilder.Append(' ', 1); // 79: RESERVED
                tranBuilder.Append(accrualStatus.Trim().PadRight(1)); // 80: ACCRUAL STATUS
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE 
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}