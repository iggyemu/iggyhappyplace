#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 049 - Equity Line of Credit Principal Advances/Reversals (D-320)
        /// Transaction 049 is available only if you are installed on the Equity Line of Credit enhancement (IP 1423). Use of this transaction should be approved at the appropriate supervisory level.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="hiType">(15) This field is required. It indicates if the ELOC loan is a first or second mortgage. </param>
        /// <param name="principalAdvance_Reversal">(16-26) This field is required. It indicates the amount of advance or reversal applied to the outstanding principal balance.</param>
        /// <param name="checkNumber">(27-30) This field is required. It indicates the check number or other source of the draw associated with this principal advance.</param>
        /// <param name="payeeDescription">(31-55) This field is conditional. It is required if the CHECK NUMBER field equals ODP. It indicates additional information about the payee. If the CHECK NUMBER field equals ODP, this field also indicates the overdraft protection bank account number.</param>
        /// <param name="payee">(56-70) This field is required. It indicates the name of the person or organization to whom the advance was paid.</param>
        /// <param name="overrideCode">(71) This field is conditional. It is required to process a loan with the conditions listed below. Otherwise, leave this field blank and the system will reject the transaction for any of the below conditions.</param>
        /// <param name="paymentReserveFlag">(72) This field is optional. It indicates the transaction is for a payment reserve advance on a construction loan and triggers the advance/payment process.</param>
        /// <param name="segmentNo">(73) This field is optional. It indicates the date the advance actually occurred, as opposed to the date you enter it into the MSP system. Billing uses this field to calculate changes in the principal balance for the calculation of finance charges.</param>
        /// <param name="effectiveDate">(75-80) The date in this field must be within 240 days prior to the date in the billing date.</param>
        /// <returns>Transaction 049 Card 1</returns>
        public static string Tran049c1(string loanNumber, string hiType, string principalAdvance_Reversal,
                                       string checkNumber, string payeeDescription, string payee, string overrideCode,
                                       string paymentReserveFlag, string segmentNo, string effectiveDate)
        {
            string transaction;

            try
            {
                var transactionName = "049-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "hiType", hiType);
                CheckRequiredField(transactionName, "principalAdvance_Reversal", principalAdvance_Reversal);
                CheckRequiredField(transactionName, "checkNumber", checkNumber);
                CheckRequiredField(transactionName, "payee", payee);

                if (checkNumber.Trim() == "ODP" && !IsAvailable(payeeDescription))
                {
                    throw new Exception(string.Format(
                                            "{0}: {1}: payeeDescription is required when checkNumber is 'ODP'.",
                                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(hiType.Trim().PadRight(1)); // 15: HI TYPE
                tranBuilder.Append(FormatMoney(principalAdvance_Reversal.Trim(), true, true, 11));
                // 16-26: PRINCIPAL ADVANCE/REVERSAL
                tranBuilder.Append(checkNumber.Trim().PadRight(4)); // 27-30: CHECK NUMBER
                tranBuilder.Append(payeeDescription.Trim().PadRight(25)); // 31-55: PAYEE DESCRIPTION
                tranBuilder.Append(payee.Trim().PadRight(15)); // 56-70: PAYEE
                tranBuilder.Append(overrideCode.Trim().PadRight(1)); // 71: OVERRIDE CODE
                tranBuilder.Append(paymentReserveFlag.Trim().PadRight(1)); // 72: PAYMENT RESERVE FLAG
                tranBuilder.Append(segmentNo.Trim().PadRight(1)); // 73: SEGMENT NO
                tranBuilder.Append(' '); // 74: RESERVED
                tranBuilder.Append(FormatDate(effectiveDate.Trim())); // 75-80 EFFECTIVE DATE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}