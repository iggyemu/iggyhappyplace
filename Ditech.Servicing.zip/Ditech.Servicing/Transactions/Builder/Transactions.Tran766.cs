﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 766 - Corporate Advance Deposits (D-264)
        /// Use transactions 710 through 714 to repay various foreclosure, bankruptcy, and REO expenses and transaction 766 to repay other loan-related expenses (for example, tax penalties) that were funded from a corporate account.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="depositAmount">(14-22) This field is required. It indicates the amount of the deposit.</param>
        /// <param name="corporateAdvancePayee">(23-27) This field is required. It determines which corporate account will be refunded for funds disbursed in a prior transaction. A remittance header must be present for the payee entered.</param>
        /// <param name="recoverableFlag">(28) This field is required. It determines which balance in the master file to update: mortgagor recoverable advance balance, third-party recoverable advance balance, or non-recoverable advance balance.</param>
        /// <param name="reasonCode">(29-32) This field enables you to enter a user-defined code that is tied to a 16-character, user-defined description created in an online reason code file. This code and description further explain the reason for a deposit.</param>
        /// <param name="originalPayee">(33-42) This field is optional. It tracks the repayment of outstanding corporate advance disbursements. This payee should be the same escrow payee used for the original disbursement in order to provide an audit trail of what disbursements have been repaid and to offset the original disbursement for year-end 1099-MISC reporting. The deposit payee must be a permanent escrow payee. It cannot be temporary.</param>
        /// <param name="processor">(44-46) This is field is required. It is a user-defined, three-character field that identifies the person processing the deposit.</param>
        /// <param name="bankruptcySuspenseSwitch">(47) This field is conditional. It is used by the Bankruptcy Workstation to identify the deposit amount that comes from suspense.</param>
        /// <param name="corporateAdvanceOriginalDisbursementDate">(48-53) This field is optional. It indicates the repayment date of the outstanding corporate advance disbursements. In order to use this field, the third position of the CORPORATE ADVANCE PAYEE field must be an R or T.</param>
        /// <param name="obligor">(54-59) This field is available if you are installed on IP 2054. This field is conditional. It is required for third party recoverable deposits and optional on recoverable or non-recoverable deposits. It indicates the entity or individual, other than the mortgagor or co-mortgagor, responsible for repayment of a corporate advance.</param>
        /// <param name="overRide">(80) This field is optional. It indicates whether to override the exclamation point (!) process stop. This process stop causes the system to reject these transactions at the update level. This system-defined stop is set up on the SAF1 screen in the MSP Info Tracking Workstation.</param>
        /// <returns>Transaction 766</returns>
        public static string Tran766(string loanNumber = "", string depositAmount = "",
                                       string corporateAdvancePayee = "", string recoverableFlag = "",
                                       string reasonCode = "", string originalPayee = "", string processor = "",
                                       string bankruptcySuspenseSwitch = "",
                                       string corporateAdvanceOriginalDisbursementDate = "", string obligor = "",
                                       string overRide = "")
        {
            string transaction;

            try
            {
                var transactionName = "766";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "depositAmount", depositAmount);
                CheckRequiredField(transactionName, "corporateAdvancePayee", corporateAdvancePayee);
                CheckRequiredField(transactionName, "recoverableFlag", recoverableFlag);
                CheckRequiredField(transactionName, "processor", processor
                    );
                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(depositAmount.Trim()), 9)); // 14-22: DEPOSIT AMOUNT
                tranBuilder.Append(corporateAdvancePayee.Trim().PadRight(5)); // 23-27: CORPORATE ADVANCE PAYEE
                tranBuilder.Append(recoverableFlag.Trim().PadRight(1)); // 28: RECOVERABLE/NONRECOVERABLE
                tranBuilder.Append(reasonCode.Trim().PadRight(4)); // 29-32: REASON CODE
                tranBuilder.Append(originalPayee.Trim().PadRight(10)); // 33-42: ORIGINAL PAYEE
                tranBuilder.Append(' '); // 43: RESERVED
                tranBuilder.Append(processor.Trim().PadRight(3)); // 44-46: PROCESSOR
                tranBuilder.Append(bankruptcySuspenseSwitch.Trim().PadRight(1)); // 47: BANKRUPTCY SUSPENSE SWITCH
                tranBuilder.Append(FormatDate(corporateAdvanceOriginalDisbursementDate.Trim())); // 48-53: CORPORATE ADVANCE ORIGINAL DISBURSEMENT DATE
                tranBuilder.Append(obligor.Trim().PadRight(6)); // 54-59: OBLIGOR
                tranBuilder.Append(' ', 20); // 60-79: RESERVED
                tranBuilder.Append(overRide.Trim().PadRight(1)); // 80 OVERRIDE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
