﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 14D - Mass LetterWriter Selection Request (D-280)
        /// This transaction generates mass LetterWriter letters. It uses card 3 to produce mass letters from the selection criteria (request type S) and from individual loan selection (request type I). The transaction layout differs depending on the request type.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="letterId">(21-25) This field is required. It indicates the letter ID of the letter that you want to generate. There cannot be any user-prompt fields in the letter to be generated.</param>
        /// <param name="collections">(44) This field is optional. It indicates whether to update the Collection Workstation comments.</param>
        /// <param name="printTape">(45) This field is required. It instructs the system to produce printed letters or tape.</param>
        /// <returns>Transaction 14D r I</returns>
        public static string Tran14DrI(string loanNumber, string letterId = "", string collections = "", string printTape = "")
        {
            string transaction;

            try
            {
                var transactionName = "14D-I";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "letterId", letterId);
                CheckRequiredField(transactionName, "printTape", printTape);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("I"); // 7: REQUEST TYPE
                tranBuilder.Append("*".PadRight(7)); // 8-14: LOAN NUMBER
                tranBuilder.Append(' ', 2); // 15-16: RESERVED
                tranBuilder.Append("03"); // 17-18: CARD CODE
                tranBuilder.Append(' ', 2); // 19-20: RESERVED
                tranBuilder.Append(letterId.Trim().PadRight(5)); // 21-25: LETTER ID
                tranBuilder.Append(' ', 18); // 26-43: RESERVED
                tranBuilder.Append(collections.Trim().PadRight(1)); // 44: COLLECTIONS
                tranBuilder.Append(printTape.Trim().PadRight(1)); // 45: PRINT/TAPE
                tranBuilder.Append(' ', 35); // 46-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
