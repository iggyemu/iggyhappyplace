#region

using System;
using System.Diagnostics.Contracts;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="pos10Fld1A">(15-24) This is an optional, user-defined field.</param>
        /// <param name="pos3Fld1A">(25-27) This is an optional, user-defined field.</param>
        /// <param name="pos3Fld2A">(28-30) This is an optional, user-defined field.</param>
        /// <param name="pos5Fld1N">(31-35) This is an optional, user-defined field.</param>
        /// <param name="pos9Fld1N">(36-44) This is an optional, user-defined field.</param>
        /// <param name="pos7Fld1N">(45-51) This is an optional, user-defined field.</param>
        /// <param name="dtFld5">(52-57) This is an optional, user-defined field.</param>
        /// <param name="pos1Fld1A">(58) This is an optional, user-defined field.</param>
        /// <returns>Transaction 463 Card A</returns>
        public static string Tran463cA(string loanNumber, string pos10Fld1A, string pos3Fld1A, string pos3Fld2A,
                                       string pos5Fld1N, string pos9Fld1N, string pos7Fld1N, string dtFld5,
                                       string pos1Fld1A)
        {
            string transaction;

            try
            {
                var transactionName = "463-A";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("A"); // 14: CARD CODE
                tranBuilder.Append(pos10Fld1A.Trim().PadRight(10)); // 15-24: 10-POS-FLD-1-A
                tranBuilder.Append(pos3Fld1A.Trim().PadRight(3)); // 25-27: 3-POS-FLD-1-A
                tranBuilder.Append(pos3Fld2A.Trim().PadRight(3)); // 28-30: 3-POS-FLD-2-A
                tranBuilder.Append(FormatMoney(pos5Fld1N.Trim(), true, false, 5)); //  31-35: 5-POS-FLD-1-N
                tranBuilder.Append(FormatMoney(pos9Fld1N.Trim(), true, false, 9)); // 36-44: 9-POS-FLD-1-N
                tranBuilder.Append(FormatMoney(pos7Fld1N.Trim(), true, false, 7)); // 45-51: 7-POS-FLD-1-N
                tranBuilder.Append(FormatDate(dtFld5.Trim())); // 52-57: DT-FLD-5
                tranBuilder.Append(pos1Fld1A.Trim().PadRight(1)); // 58: 1-POS-FLD-1-A
                tranBuilder.Append(' ', 22); // 59-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="user10PositionField3A">(15-24) This is an optional, user-defined field.</param>
        /// <param name="user3PositionField5A">(25-27) This is an optional, user-defined field.</param>
        /// <param name="user3PositionField6A">(28-30) This is an optional, user-defined field.</param>
        /// <param name="user6PositionField1A">(31-36) This is an optional, user-defined field.</param>
        /// <param name="user9PositionField3N">(37-45) This is an optional, user-defined field.</param>
        /// <param name="user7PositionField3N">(46-52) This is an optional, user-defined field.</param>
        /// <param name="percentField3">(53-55) This is an optional, user-defined field.</param>
        /// <param name="user2PositionField1A">(56-57) This is an optional, user-defined field.</param>
        /// <returns>Transaction 463 Card C</returns>
        public static string Tran463cC(string loanNumber, string user10PositionField3A, string user3PositionField5A,
                                       string user3PositionField6A, string user6PositionField1A,
                                       string user9PositionField3N, string user7PositionField3N, string percentField3,
                                       string user2PositionField1A)
        {
            string transaction;

            try
            {
                var transactionName = "463-C";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("C"); // 14: CARD CODE
                tranBuilder.Append(user10PositionField3A.Trim().PadRight(10)); // 15-24: 10-POS-FLD-3-A
                tranBuilder.Append(user3PositionField5A.Trim().PadRight(3)); // 25-27: 3-POS-FLD-5-A
                tranBuilder.Append(user3PositionField6A.Trim().PadRight(3)); // 28-30: 3-POS-FLD-6-A
                tranBuilder.Append(user6PositionField1A.Trim().PadRight(6)); // 31-36: 6-POS-FLD-1-A
                tranBuilder.Append(FormatMoney(user9PositionField3N.Trim(), true, false, 9)); // 37-45: 9-POS-FLD-3-N
                tranBuilder.Append(FormatMoney(user7PositionField3N.Trim(), true, false, 7)); // 46-52: 7-POS-FLD-3-N
                tranBuilder.Append(FormatPercent(percentField3.Trim(), 3)); // 53-55: PERCENT-FLD-3
                tranBuilder.Append(user2PositionField1A.Trim().PadRight(2)); // 56-57: 2-POS-FLD-1-A
                tranBuilder.Append(' ', 23); // 58-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="user10PositionField4A">(15-24) This is an optional, user-defined field.  Type 10 alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user5PositionField1A">(25-29) This is an optional, user-defined field.  Type five alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user7PositionField1A">(30-36) This is an optional, user-defined field.  Type seven alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user6PositionField2A">(37-42) This is an optional, user-defined field.  Type six alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user9PositionField4N">(43-51) This is an optional, user-defined field.  Type nine digits in 9999999.99 format (do not type the decimal point), left zero-filled. Negative values are allowed in this field.</param>
        /// <param name="user7PositionField4N">(52-58)This is an optional, user-defined field.  Type seven digits in 99999.99 format (do not type the decimal point), left zero-filled. Negative values are allowed in this field.</param>
        /// <param name="userPercentField4">(59-61)This is an optional, user-defined field.  This is an optional, user-defined percent field.</param>
        /// <param name="user2PositionField2A">(62-63)This is an optional, user-defined field.  Type two alphanumeric characters. A space is permitted.</param>
        /// <returns>Transaction 463 Card D</returns>
        public static string Tran463cD(string loanNumber, string user10PositionField4A, string user5PositionField1A,
                                       string user7PositionField1A, string user6PositionField2A,
                                       string user9PositionField4N, string user7PositionField4N,
                                       string userPercentField4,
                                       string user2PositionField2A)
        {
            string transaction;

            try
            {
                var transactionName = "463-D";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("D"); // 14: CARD CODE
                tranBuilder.Append(user10PositionField4A.Trim().PadRight(10)); // 15-24: 10-POS-FLD-4-A
                tranBuilder.Append(user5PositionField1A.Trim().PadRight(5)); // 25-29: 5-POS-FLD-1-A
                tranBuilder.Append(user7PositionField1A.Trim().PadRight(7)); // 30-36: 7-POS-FLD-1-A
                tranBuilder.Append(user6PositionField2A.Trim().PadRight(6)); // 37-42: 6-POS-FLD-2-A
                tranBuilder.Append(FormatMoney(user9PositionField4N.Trim(), true, false, 9)); // 43-51: 9-POS-FLD-4-N
                tranBuilder.Append(FormatMoney(user7PositionField4N.Trim(), true, false, 7)); // 52-58: 7-POS-FLD-4-N
                tranBuilder.Append(FormatPercent(userPercentField4.Trim(), 3)); // 59-61: PERCENT-FLD-4
                tranBuilder.Append(user2PositionField2A.Trim().PadRight(2)); // 62-63: 2-POS-FLD-2-A
                tranBuilder.Append(' ', 17); // 64-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        /// <param name="user2PositionField5A">(15-16) This field is optional. It is a user-defined ID field. Type two alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user2PositionField6A">(17-18) This field is optional. It is a user-defined ID field. Type two alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user2PositionField7A">(19-20) This field is optional. It is a user-defined ID field. Type two alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user2PositionField8A">(21-22) This field is optional. It is a user-defined ID field. Type two alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user2PositionField9A">(23-24) This field is optional. It is a user-defined ID field. Type two alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user2PositionField1B">(25-26) This field is optional. It is a user-defined ID field. Type two alphanumeric characters. Spaces are permitted.</param>
        /// <param name="userDateField9A">(27-32) This field is optional. It is a user-defined date field.  Type the date in MMDDYY format.</param>
        /// <param name="userDateField1B">(33-38) This field is optional. It is a user-defined date field.  Type the date in MMDDYY format.</param>
        /// <param name="user5PositionField4A">(39-43) This field is optional. It is a user-defined ID field. Type five alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user5PositionField5A">(44-48) This field is optional. It is a user-defined ID field. Type five alphanumeric characters. Spaces are permitted.</param>
        /// <returns></returns>
        public static string Tran463cI(string loanNumber, string user2PositionField5A = "", string user2PositionField6A = "",
                                string user2PositionField7A = "", string user2PositionField8A = "", string user2PositionField9A = "",
            string user2PositionField1B = "", string userDateField9A = "", string userDateField1B = "", string user5PositionField4A = "",
            string user5PositionField5A = "")
        {
            string transaction;

            try
            {
                var transactionName = "463-I";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("I"); // 14: CARD CODE
                tranBuilder.Append(user2PositionField5A.Trim().PadLeft(2)); // 15-16: 2-POS-FLD-5-A
                tranBuilder.Append(user2PositionField6A.Trim().PadLeft(2)); // 17-18: 2-POS-FLD-6-A
                tranBuilder.Append(user2PositionField7A.Trim().PadLeft(2)); // 19-20: 2-POS-FLD-7-A
                tranBuilder.Append(user2PositionField8A.Trim().PadLeft(2)); // 21-22: 2-POS-FLD-8-A
                tranBuilder.Append(user2PositionField9A.Trim().PadLeft(2)); // 23-24: 2-POS-FLD-9-A
                tranBuilder.Append(user2PositionField1B.Trim().PadLeft(2)); // 25-26: 2-POS-FLD-1-B
                tranBuilder.Append(FormatDate(userDateField9A)); // 27-32: DATE-FLD-9-A
                tranBuilder.Append(FormatDate(userDateField1B)); // 33-38: DATE-FLD-1-B
                tranBuilder.Append(user5PositionField4A.Trim().PadLeft(5)); // 39-43: 2-POS-FLD-9-A
                tranBuilder.Append(user5PositionField5A.Trim().PadLeft(5)); // 44-48: 2-POS-FLD-1-B
                tranBuilder.Append(' ', 32); // 49-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="user7PositionField3A">(15-21) This is an optional, user-defined field.  Type 7 alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user7PositionField4A">(22-28) This is an optional, user-defined field.  Type 5 alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user5PositionField6A">(29-33) This is an optional, user-defined field.  Type 5 alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user1PositionField7A">(34) This is an optional, user-defined field.  Type 1 alphanumeric character. Spaces are permitted.</param>
        /// <param name="user1PositionField8A">(35) This is an optional, user-defined field.  Type 1 alphanumeric character. Spaces are permitted.</param>
        /// <param name="user1PositionField9A">(36) This is an optional, user-defined field.  Type 1 alphanumeric character. Spaces are permitted.</param>
        /// <param name="user1PositionField1B">(37) This is an optional, user-defined field.  Type 1 alphanumeric character. Spaces are permitted.</param>
        /// <param name="user3PositionField1B">(38-40) This is an optional, user-defined field.  Type 3 alphanumeric characters. Spaces are permitted.</param>
        /// <param name="user3PositionField2B">(41-43) This is an optional, user-defined field.  Type 3 alphanumeric characters. Spaces are permitted.</param>
        /// <returns>Transaction 463 Card M</returns>
        public static string Tran463cM(string loanNumber, string user7PositionField3A, string user7PositionField4A, string user5PositionField6A, string user1PositionField7A, string user1PositionField8A, string user1PositionField9A, string user1PositionField1B, string user3PositionField1B, string user3PositionField2B)
        {
            string transaction;

            try
            {
                var transactionName = "463-M";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("M"); // 14: CARD CODE
                tranBuilder.Append(user7PositionField3A.Trim().PadRight(7)); // 15-21: 7-POS-FLD-3-A
                tranBuilder.Append(user7PositionField4A.Trim().PadRight(7)); // 22-28: 7-POS-FLD-4-A
                tranBuilder.Append(user5PositionField6A.Trim().PadRight(5)); // 29-33: 5-POS-FLD-6-A
                tranBuilder.Append(user1PositionField7A.Trim().PadRight(1)); // 34: 1-POS-FLD-7-A
                tranBuilder.Append(user1PositionField8A.Trim().PadRight(1)); // 35: 1-POS-FLD-8-A
                tranBuilder.Append(user1PositionField9A.Trim().PadRight(1)); // 36: 1-POS-FLD-9-A
                tranBuilder.Append(user1PositionField1B.Trim().PadRight(1)); // 37: 1-POS-FLD-1-B
                tranBuilder.Append(user3PositionField1B.Trim().PadRight(3)); // 38-40: 3-POS-FLD-1-B
                tranBuilder.Append(user3PositionField2B.Trim().PadRight(3)); // 41-43: 3-POS-FLD-2-B
                tranBuilder.Append(' ', 37); // 44-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="user1PositionField6B">(15) This field is optional. It indicates a user-defined ID field.  Type one alphanumeric character. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user1PositionField7B">(16) This field is optional. It indicates a user-defined ID field.  Type one alphanumeric character. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user1PositionField8B">(17) This field is optional. It indicates a user-defined ID field.  Type one alphanumeric character. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user2PositionField8B">(18-19) This field is optional. It indicates a user-defined ID field.  Type two alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user2PositionField9B">(20-21) This field is optional. It indicates a user-defined ID field.  Type two alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user2PositionField1C">(22-23) This field is optional. It indicates a user-defined ID field.  Type two alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user2PositionField2C">(24-25) This field is optional. It indicates a user-defined ID field.  Type two alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user2PositionField3C">(26-27) This field is optional. It indicates a user-defined ID field.  Type two alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user3PositionField1C">(28-30) This field is optional. It indicates a user-defined ID field.  Type three alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user3PositionField2C">(31-33) This field is optional. It indicates a user-defined ID field.  Type three alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user3PositionField3C">(34-36) This field is optional. It indicates a user-defined ID field.  Type three alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user3PositionField4C">(37-39) This field is optional. It indicates a user-defined ID field.  Type three alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user3PositionField5C">(40-42) This field is optional. It indicates a user-defined ID field.  Type three alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user3PositionField6C">(43-45) This field is optional. It indicates a user-defined ID field.  Type three alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField3B">(46-49) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField4B">(50-53) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField5B">(54-57) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField6B">(58-61) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField7B">(62-65) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField8B">(66-69) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user4PositionField9B">(70-73) This field is optional. It indicates a user-defined ID field.  Type four alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <returns>Transaction 463 Card S</returns>
        public static string Tran463cS(string loanNumber, string user1PositionField6B, string user1PositionField7B, string user1PositionField8B, string user2PositionField8B, string user2PositionField9B, string user2PositionField1C, string user2PositionField2C, string user2PositionField3C, string user3PositionField1C, string user3PositionField2C, string user3PositionField3C, string user3PositionField4C, string user3PositionField5C, string user3PositionField6C, string user4PositionField3B, string user4PositionField4B, string user4PositionField5B, string user4PositionField6B, string user4PositionField7B, string user4PositionField8B, string user4PositionField9B)
        {
            string transaction;

            try
            {
                var transactionName = "463-S";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("S"); // 14: CARD CODE
                tranBuilder.Append(user1PositionField6B.Trim().PadRight(1)); // 15: 1-POS-FLD-6B
                tranBuilder.Append(user1PositionField7B.Trim().PadRight(1)); // 16: 1-POS-FLD-7B
                tranBuilder.Append(user1PositionField8B.Trim().PadRight(1)); // 17: 1-POS-FLD-8B

                tranBuilder.Append(user2PositionField8B.Trim().PadRight(2)); // 18-19: 2-POS-FLD-8B
                tranBuilder.Append(user2PositionField9B.Trim().PadRight(2)); // 20-21: 2-POS-FLD-9B
                tranBuilder.Append(user2PositionField1C.Trim().PadRight(2)); // 22-23: 2-POS-FLD-1C
                tranBuilder.Append(user2PositionField2C.Trim().PadRight(2)); // 24-25: 2-POS-FLD-2C
                tranBuilder.Append(user2PositionField3C.Trim().PadRight(2)); // 26-27: 2-POS-FLD-3C

                tranBuilder.Append(user3PositionField1C.Trim().PadRight(3)); // 28-30: 3-POS-FLD-1C
                tranBuilder.Append(user3PositionField2C.Trim().PadRight(3)); // 31-33: 3-POS-FLD-2C
                tranBuilder.Append(user3PositionField3C.Trim().PadRight(3)); // 34-36: 3-POS-FLD-3C
                tranBuilder.Append(user3PositionField4C.Trim().PadRight(3)); // 37-39: 3-POS-FLD-4C
                tranBuilder.Append(user3PositionField5C.Trim().PadRight(3)); // 40-42: 3-POS-FLD-5C
                tranBuilder.Append(user3PositionField6C.Trim().PadRight(3)); // 43-45: 3-POS-FLD-6C

                tranBuilder.Append(user4PositionField3B.Trim().PadRight(4)); // 46-49: 4-POS-FLD-3B
                tranBuilder.Append(user4PositionField4B.Trim().PadRight(4)); // 50-53: 4-POS-FLD-4B
                tranBuilder.Append(user4PositionField5B.Trim().PadRight(4)); // 54-57: 4-POS-FLD-5B
                tranBuilder.Append(user4PositionField6B.Trim().PadRight(4)); // 58-61: 4-POS-FLD-6B
                tranBuilder.Append(user4PositionField7B.Trim().PadRight(4)); // 62-65: 4-POS-FLD-7B
                tranBuilder.Append(user4PositionField8B.Trim().PadRight(4)); // 66-69: 4-POS-FLD-8B
                tranBuilder.Append(user4PositionField9B.Trim().PadRight(4)); // 70-73: 4-POS-FLD-9B
                tranBuilder.Append(' ', 7); // 74-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="user5PositionField6B">(15-19) This field is optional. It indicates a user-defined ID field.  Type five alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user5PositionField7B">(20-24) This field is optional. It indicates a user-defined ID field.  Type five alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user5PositionField8B">(25-29) This field is optional. It indicates a user-defined ID field.  Type five alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user5PositionField9B">(30-34) This field is optional. It indicates a user-defined ID field.  Type five alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user5PositionField1C">(35-39) This field is optional. It indicates a user-defined ID field.  Type five alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user5PositionField2C">(40-44) This field is optional. It indicates a user-defined ID field.  Type five alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user6PositionField7B">(45-50) This field is optional. It indicates a user-defined ID field.  Type six alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user6PositionField8B">(51-56) This field is optional. It indicates a user-defined ID field.  Type six alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user6PositionField9B">(57-62) This field is optional. It indicates a user-defined ID field.  Type six alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user6PositionField1C">(63-68) This field is optional. It indicates a user-defined ID field.  Type six alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <param name="user6PositionField2C">(69-74) This field is optional. It indicates a user-defined ID field.  Type six alphanumeric characters. Spaces are permitted. Type ampersands (&) to delete an existing value.</param>
        /// <returns>Transaction 463 Card T</returns>
        public static string Tran463cT(string loanNumber, string user5PositionField6B, string user5PositionField7B, string user5PositionField8B, string user5PositionField9B, string user5PositionField1C, string user5PositionField2C, string user6PositionField7B, string user6PositionField8B, string user6PositionField9B, string user6PositionField1C, string user6PositionField2C)
        {
            string transaction;

            try
            {
                var transactionName = "463-T";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("T"); // 14: CARD CODE

                tranBuilder.Append(user5PositionField6B.Trim().PadRight(5)); // 15-19: 5-POS-FLD-6B
                tranBuilder.Append(user5PositionField7B.Trim().PadRight(5)); // 20-24: 5-POS-FLD-7B
                tranBuilder.Append(user5PositionField8B.Trim().PadRight(5)); // 25-29: 5-POS-FLD-8B
                tranBuilder.Append(user5PositionField9B.Trim().PadRight(5)); // 30-34: 5-POS-FLD-9B
                tranBuilder.Append(user5PositionField1C.Trim().PadRight(5)); // 35-39: 5-POS-FLD-1C
                tranBuilder.Append(user5PositionField2C.Trim().PadRight(5)); // 40-44: 5-POS-FLD-2C

                tranBuilder.Append(user6PositionField7B.Trim().PadRight(6)); // 45-50: 6-POS-FLD-7B
                tranBuilder.Append(user6PositionField8B.Trim().PadRight(6)); // 51-56: 6-POS-FLD-8B
                tranBuilder.Append(user6PositionField9B.Trim().PadRight(6)); // 57-62: 6-POS-FLD-9B
                tranBuilder.Append(user6PositionField1C.Trim().PadRight(6)); // 63-68: 6-POS-FLD-1C
                tranBuilder.Append(user6PositionField2C.Trim().PadRight(6)); // 69-74: 6-POS-FLD-2C

                tranBuilder.Append(' ', 6); // 75-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="dateField6B">(15-20) This field is optional. It indicates a user-defined date field.</param>
        /// <param name="dateField7B">(21-26) This field is optional. It indicates a user-defined date field.</param>
        /// <param name="dateField8B">(27-32) This field is optional. It indicates a user-defined date field.</param>
        /// <param name="dateField9B">(33-38) This field is optional. It indicates a user-defined date field. </param>
        /// <param name="percentField5X">(39-43) This field is optional. It indicates a user-defined percentage field.</param>
        /// <param name="percentField6X">(44-48) This field is optional. It indicates a user-defined percentage field.</param>
        /// <param name="user7PositionField5N">(49-55) This field is optional. It indicates a user-defined ID field.</param>
        /// <param name="user7PositionField6N">(56-62) This field is optional. It indicates a user-defined ID field.</param>
        /// <returns>Transaction 463 Card V</returns>
        public static string Tran463cV(string loanNumber, string dateField6B, string dateField7B, string dateField8B, string dateField9B, string percentField5X, string percentField6X, string user7PositionField5N, string user7PositionField6N)
        {
            string transaction;

            try
            {
                var transactionName = "463-T";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("V"); // 14: CARD CODE

                tranBuilder.Append(FormatDate(dateField6B.Trim())); // 15-20: DATE-FLD-6B
                tranBuilder.Append(FormatDate(dateField7B.Trim())); // 21-26: DATE-FLD-7B
                tranBuilder.Append(FormatDate(dateField8B.Trim())); // 27-32: DATE-FLD-8B
                tranBuilder.Append(FormatDate(dateField9B.Trim())); // 33-38: DATE-FLD-9B
                tranBuilder.Append(FormatMoney(percentField5X.Trim(), true, false, 5)); // 39-43 PERCENT-FLD-5X
                tranBuilder.Append(FormatMoney(percentField6X.Trim(), true, false, 5)); // 44-48 PERCENT-FLD-6X
                tranBuilder.Append(user7PositionField5N.Trim().PadRight(7)); // 49-55: 7-POS-FLD-5N
                tranBuilder.Append(user7PositionField6N.Trim().PadRight(7)); // 56-62: 7-POS-FLD-6N
                tranBuilder.Append(' ', 18); // 63-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }
        /// <summary>
        /// Transaction 463 - User Fields Data - Add/Maintain (D-299).
        /// The system generates transaction 463 from the Expanded User Fields screens (USR2, USR3, or USR4) in the New Loan and Loan Maintenance workstations. You can also enter this transaction through the MSP Mortgage Online Data Entry (MODE) screen DEIA, Free Form Transaction.
        /// </summary>
        public static string Tran463cN(string loanNumber = "",string user2PositionField2B = "",string user2PositionField3B = "", string user2PositionField4B = "",
                                       string user2PositionField5B = "", string user2PositionField6B = "", string user2PositionField7B = "", string dateField2B = "",
                                       string dateField3B = "",string dateField4B = "",string dateField5B = "", string user5PositionField1B = "")
        {
            string transaction= "";

            try
            {
                var transactionName = "463";

                CheckValidLoanNumber(transactionName,loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;
                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6 CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN NUMBER
                tranBuilder.Append("N"); // 14 CARD CODE
                tranBuilder.Append(user2PositionField2B.PadRight(2)); // 15-16 USER 2 POSITION FIELD 2B
                tranBuilder.Append(user2PositionField3B.PadRight(2)); // 17-18 USER 2 POSITION FIELD 3B
                tranBuilder.Append(user2PositionField4B.PadRight(2)); // 19-20 USER 2 POSITION FIELD 4B
                tranBuilder.Append(user2PositionField5B.PadRight(2)); // 21-22 USER 2 POSITION FIELD 5B
                tranBuilder.Append(user2PositionField6B.PadRight(2)); // 23-24 USER 2 POSITION FIELD 6B
                tranBuilder.Append(user2PositionField7B.PadRight(2)); // 25-26 USER 2 POSITION FIELD 7B
                tranBuilder.Append(!dateField2B.IsNullOrEmpty(true) && !dateField2B.Contains("&")
                    ? Convert.ToDateTimeString(dateField2B, "MMddyy")
                    : dateField2B.PadRight(6)); // 27-32 DATE FIELD 2B
                tranBuilder.Append(!dateField3B.IsNullOrEmpty(true) && !dateField3B.Contains("&")
                    ? Convert.ToDateTimeString(dateField3B, "MMddyy")
                    : dateField3B.PadRight(6)); // 33-38 DATE FIELD 3B
                tranBuilder.Append(!dateField4B.IsNullOrEmpty(true) && !dateField4B.Contains("&")
                    ? Convert.ToDateTimeString(dateField4B, "MMddyy")
                    : dateField4B.PadRight(6)); // 39-44 DATE FIELD 4B
                tranBuilder.Append(!dateField5B.IsNullOrEmpty(true) && !dateField5B.Contains("&")
                    ? Convert.ToDateTimeString(dateField5B, "MMddyy")
                    : dateField5B.PadRight(6)); // 45-50 DATE FIELD 5B
                tranBuilder.Append(user5PositionField1B.PadRight(5)); // 51-55 USER 5 POSITION FIELD 1B
                tranBuilder.Append(' ', 34); // 56-89 RESERVED
                tranBuilder.Append(loanNumber.PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

                if (tranBuilder.Length != 102)
                {
                    throw new Exception("{transactionName}: Line length mismatch: {tranBuilder}");
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            
            return transaction;
        }

        public static string Tran463cO(string loanNumber = "", string user1PositionField2B = "", string user1PositionField3B = "",
            string user1PositionField4B = "", string user1PositionField5B = "",
            string user3PositionField6B = "", string user3PositionField7B = "", string user3PositionField8B = "",
            string user3PositionField9B = "",
            string user5PositionField2B = "", string user5PositionField3B = "", string user5PositionField4B = "")
        {
            string transaction = "";

            try
            {
                var transactionName = "463";
                CheckValidLoanNumber(transactionName,loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6 CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN NUMBER
                tranBuilder.Append("O"); // 14 CARD CODE
                tranBuilder.Append(user1PositionField2B.PadRight(1)); // 15 USER 1 POSITION FIELD 2B
                tranBuilder.Append(user1PositionField3B.PadRight(1)); // 16 USER 1 POSITION FIELD 3B
                tranBuilder.Append(user1PositionField4B.PadRight(1)); // 17 USER 1 POSITION FIELD 4B
                tranBuilder.Append(user1PositionField5B.PadRight(1)); // 18 USER 1 POSITION FIELD 5B
                tranBuilder.Append(user3PositionField6B.PadRight(3)); // 19-21 USER 3 POSITION FIELD 6B
                tranBuilder.Append(user3PositionField7B.PadRight(3)); // 22-24 USER 3 POSITION FIELD 7B
                tranBuilder.Append(user3PositionField8B.PadRight(3)); // 25-27 USER 3 POSITION FIELD 8B
                tranBuilder.Append(user3PositionField9B.PadRight(3)); // 28-30 USER 3 POSITION FIELD 9B
                tranBuilder.Append(user5PositionField2B.PadRight(5)); // 31-35 USER 5 POSITION FIELD 2B
                tranBuilder.Append(user5PositionField3B.PadRight(5)); // 36-40 USER 5 POSITION FIELD 3B
                tranBuilder.Append(user5PositionField4B.PadRight(5)); // 41-45 USER 5 POSITION FIELD 4B
                tranBuilder.Append(' ', 44); // 46-89 RESERVED
                tranBuilder.Append(loanNumber.PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

                if (tranBuilder.Length != 102)
                {
                    throw new Exception("{transactionName}: Line length mismatch: {tranBuilder}");
                }

                tranBuilder.AppendLine();
                transaction = tranBuilder.ToString();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            return transaction;
        }
    }
}
