#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        ///  Transaction CCN - Internet Stops and Flags (D-350)
        /// Use transaction CCN to set and update Customer CareNet stops on individual loan records to prevent borrowers from viewing or updating Customer CareNet options.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="ccnStopName">(15-29) This field is optional. It indicates the name of the stop that may be restricted on a loan.</param>
        /// <param name="ccnStopValue">(30) This field is optional. It indicates the internet stop restriction placed on a loan.</param>
        /// <param name="ccnStopExpireDate">(31-36) This field is optional. It indicates the expiration date of the corresponding internet stop.</param>
        /// <param name="ccnStopChgBy">(37-39) This field contains the user ID of the user making the change.</param>
        /// <returns>Transaction CCN Card 1</returns>
        public static string TranCCNc1(string loanNumber, string ccnStopName, string ccnStopValue,
                                       string ccnStopExpireDate, string ccnStopChgBy)
        {
            string transaction;

            try
            {
                var transactionName = "CCN-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(ccnStopName.Trim().PadRight(15)); // 15-29: CCN STOP NAME
                tranBuilder.Append(ccnStopValue.Trim().PadRight(1)); // 30: CCN STOP VALUE
                tranBuilder.Append(FormatDate(ccnStopExpireDate.Trim())); // 31-36: CCN STOP EXPIRE DATE
                tranBuilder.Append(ccnStopChgBy.Trim().PadRight(3)); // 37-39: CCN STOP CHG BY
                tranBuilder.Append(' ', 41); // 40-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }
    }
}