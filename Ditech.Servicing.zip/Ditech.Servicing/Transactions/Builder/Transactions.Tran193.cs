#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 193 - Bank Statement Balance (D-046).
        /// Use transaction 193 to perform the following: enter an account balance from a bank statement, delete all data for a given account, or to request either a trial or final reconciliation.
        /// </summary>
        /// <param name="bankStmtDate">(13-18) This field is optional. This field indicates the date of the statement that was received from the bank.</param>
        /// <param name="bankAccountPayeeCode">(19-23) This field is required. This is the payee code of the bank account to be reconciled.</param>
        /// <param name="bankStmtBalance">(24-34) This field is optional. This field indicates the balance of the account on the bank's statement.</param>
        /// <param name="cycleCode">(35) This field is optional. This field indicates the nature of the request.</param>
        /// <param name="accountNumber">(36-52) This field is required. It identifies the account number that is being reconciled.</param>
        /// <param name="bankStmtBegDate">(53-58) This field is conditional. If you enter this field, you must enter an end date. This field represents the last final date plus one.</param>
        /// <param name="bankStmtEndDate">(59-64) This field is conditional. If you enter this field, you must enter a beginning date. This field indicates the end of the accounting period.</param>
        /// <param name="oldAccountIndicator">(65) This field is conditional. It is required if you are making a 193 adjustment on an inactive account. This field identifies inactive accounts.</param>
        /// <param name="invCode">(76-78) This field is conditional. You can enter this field only if you are requesting a trial reconciliation (a value of T or space in the CYCLE CODE field [1: 35]). This field identifies the investor within the payee that is being reconciled.</param>
        /// <returns>Transaction 193</returns>
        public static string Tran193(string bankStmtDate, string bankAccountPayeeCode, string bankStmtBalance,
                                     string cycleCode, string accountNumber, string bankStmtBegDate,
                                     string bankStmtEndDate, string oldAccountIndicator, string invCode)
        {
            string transaction;

            try
            {
                var transactionName = "193";

                CheckRequiredField(transactionName, "bankAccountPayeeCode", bankAccountPayeeCode);

                if (IsAvailable(bankStmtBegDate) && !IsAvailable(bankStmtEndDate))
                {
                    throw new Exception(
                        string.Format("{0}: bankStmtEndDate must be present when bankStmtBegDate contains a value.",
                                      transactionName));
                }

                if (IsAvailable(bankStmtEndDate) && !IsAvailable(bankStmtBegDate))
                {
                    throw new Exception(
                        string.Format("{0}: bankStmtBegDate must be present when bankStmtEndDate contains a value.",
                                      transactionName));
                }

                if ((cycleCode == "T" || cycleCode == " ") && !IsAvailable(invCode))
                {
                    throw new Exception(string.Format("{0}: invCode is required when cycleCode is T or space.",
                                                      transactionName));
                }

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append(' ', 6); // 7-12: RESERVED
                tranBuilder.Append(FormatDate(bankStmtDate.Trim())); // 13-18: BANK STMT DATE
                tranBuilder.Append(bankAccountPayeeCode.Trim().PadRight(5)); // 19-23: BANK ACCOUNT PAYEE CODE
                tranBuilder.Append(Convert.ToZonedString(bankStmtBalance.Trim()).PadLeft(11, '0'));
                // 24-34: BANK STMT BALANCE
                tranBuilder.Append(cycleCode.Trim().PadRight(1)); // 35: CYCLE CODE
                tranBuilder.Append(accountNumber.Trim().PadRight(17)); // 36-52: ACCOUNT NUMBER
                tranBuilder.Append(FormatDate(bankStmtBegDate.Trim())); // 53-58: BANK STMT BEG DATE
                tranBuilder.Append(FormatDate(bankStmtEndDate.Trim())); // 59-64: BANK STMT END DATE
                tranBuilder.Append(oldAccountIndicator.Trim().PadRight(1)); // 65: OLD ACCOUNT INDICATOR
                tranBuilder.Append(' ', 10); // 66-75: RESERVED
                tranBuilder.Append(invCode.Trim().PadRight(3)); // 76-78: INV CODE
                tranBuilder.Append(' ', 2); // 79-80: RESERVED
                tranBuilder.Append(' ', 22); // 81-102: EMPTY SPACE
                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}