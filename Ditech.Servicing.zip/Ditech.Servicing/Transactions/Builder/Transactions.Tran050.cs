#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 050 - Payment Distribution - Escrow and Extras (D-021).
        /// This transaction enters the elements of the regular periodic payment, along with transaction 052. The total payment in the master record is the program-derived total of all payment elements. The system generates coupons if the COUPON CODE field is not equal to zero and the BILL MODE field equals 1.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="coupCode">(18) This field is optional. It indicates how many coupons are to be produced, if any. If you leave this field blank, or you do not submit the transaction during new loan setup, the system defaults to 1. Type 3 only if all of the following conditions are true:  You are requesting coupons during the month in which your annual coupons are prepared.  Your annual coupons have already been prepared.  The next payment for this loan is due before next month.</param>
        /// <param name="countyTax">(19-25) This field is optional. It indicates the portion of the periodic escrow deposit collected for county taxes. If the mortgage payments are monthly, this represents one-twelfth of the estimated annual tax amount. If county and city bills are consolidated, the monthly deposit is carried in this field. If present on the input, the value in this field is moved to the county tax in the master record.</param>
        /// <param name="cityTax">(26-32) This field is optional. It indicates the portion of the periodic escrow deposit collected for the city taxes. If the mortgage payments are monthly, this represents one-twelfth of the estimated annual tax amount. If present on the input, the value in this field is moved to the city tax in the master record.</param>
        /// <param name="hazardPremium">(33-39) This field is optional. It indicates the portion of the periodic escrow deposit collected for hazard insurance. If the mortgage payments are monthly, this represents one-twelfth of the annual hazard premium amount. If present on the input, the value in this field is moved to the hazard premium in the master record.</param>
        /// <param name="mip">(40-45) This field is optional. It indicates the portion of the periodic escrow deposit collected for loan guaranty insurance (MIP on FHA loans or private mortgage insurance on conventional residential loans by companies such as MGIC). If the mortgage payments are monthly, this represents one-twelfth of the annual premium. If present on the input, this field is moved to the MIP amount in the master record.</param>
        /// <param name="lien">(46-52) This field is optional. It indicates the portion of the periodic escrow deposit collected for liens and other taxes. If the mortgage payments are monthly, this represents one-twelfth of the total of all items due for one year. The term is used in updating the disbursement due date when a disbursement (transactions 310 - 329) is made for this item. The disbursement term is used also by the escrow analysis programs when calculating how much escrow should be collected with each mortgage payment.</param>
        /// <param name="bscAmt">(53-55) This field is optional. It indicates the amount collectible from the mortgagor with the monthly payment as a service charge on certain small FHA loans. The correct amount is calculated with each payment using 1/2 % of the principal balance divided by 12. The calculated amount is deposited in the borrower's service charge (BSC) account and the difference (borrower's service charge amount minus the calculated amount) is deposited in the mortgagor's escrow account. If present on the input, the value in this field is moved to the borrower's service charge amount in the master record.</param>
        /// <param name="over_shortSpread">(57-63) This field is conditional. If you enter this field, you must also enter the STOP DATE field. You can enter this field only if the acquisition code entered on transaction 020 is 2 or 3. Use this field to establish the amount collected with each monthly payment to payoff the entire escrow shortage/overage from the current due date to the over/short stop date.</param>
        /// <param name="over_shortStopDate">(64-67) Format (MMYY).  This field is conditional. If you enter this field, you must also enter the OVER/SHORT SPREAD field. You can enter this field only if the acquisition code entered on transaction 020 is 2 or 3. Use this field to establish the date of the first payment not to include the over/short spread.</param>
        /// <param name="miscAmt">(68-72) This field is optional. The miscellaneous amount is the portion of the total mortgage payment collected for miscellaneous fees which are not escrow items. A remittance of the collections is made on the basis of the miscellaneous code. If the value in this field is present on the input, it is moved to the miscellaneous amount in the master record.</param>
        /// <param name="miscCode">(73) This field is optional. The miscellaneous code designates the type of miscellaneous collection being made as part of the periodic payment. If the value in this field is present on the input, it is moved to the miscellaneous code in the master record.</param>
        /// <param name="transactionTotal">(74-80) This field is optional. This is a crossfoot field used by edit program E-004 to help prevent erroneous data from being entered into the monetary fields of this transaction.</param>
        /// <returns>Transaction 050 Record</returns>
        public static string Tran050(string loanNumber, string coupCode, string countyTax, string cityTax,
                                     string hazardPremium, string mip, string lien, string bscAmt,
                                     string over_shortSpread, string over_shortStopDate, string miscAmt, string miscCode,
                                     string transactionTotal)
        {
            string transaction;

            try
            {
                var transactionName = "050";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(' ', 4); // 14-17: RESERVED
                tranBuilder.Append(coupCode.Trim().PadRight(1)); // 18: COUP CODE
                tranBuilder.Append(FormatMoney(countyTax.Trim(), true, false, 7)); // 19-25: COUNTY TAX 
                tranBuilder.Append(FormatMoney(cityTax.Trim(), true, false, 7)); // 26-32: CITY TAX
                tranBuilder.Append(FormatMoney(hazardPremium.Trim(), true, false, 7)); // 33-39: HAZARD PREMIUM
                tranBuilder.Append(FormatMoney(mip.Trim(), true, false, 6)); // 40-45: MIP 
                tranBuilder.Append(FormatMoney(lien.Trim(), true, false, 7)); // 46-52: LIEN
                tranBuilder.Append(FormatMoney(bscAmt.Trim(), true, false, 3)); // 53-55: BSC. AMT
                tranBuilder.Append(' '); // 56: RESERVED
                tranBuilder.Append(FormatMoney(over_shortSpread.Trim(), true, false, 7));
                // 57-63: (+/-) OVER/SHORT SPREAD
                tranBuilder.Append(LeftZeroFillOptionalField(over_shortStopDate.Trim(), 4));
                // 64-67 OVER/SHORT STOP DATE
                tranBuilder.Append(FormatMoney(miscAmt.Trim(), true, false, 5)); // 68-72: MISC AMT
                tranBuilder.Append(miscCode.Trim().PadRight(1)); // 73: MISC CODE
                tranBuilder.Append(FormatMoney(transactionTotal.Trim(), true, false, 7)); // 74-80: TRANSACTION TOTAL
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}