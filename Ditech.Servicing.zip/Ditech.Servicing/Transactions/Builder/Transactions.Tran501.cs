#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 501 - Add Loan-level ARM Information (D-021).
        /// Transaction 501 (D-021) adds loan-level ARM information to the master record as part of new loan setup. You can use transaction 502 (D-254) to add or maintain the ARM information after setup.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="actionCode">(16) This field is required. It indicates the action the system should perform with the information.</param>
        /// <param name="ctlEffectiveDate">(17-22) This field is conditional. For each control or set of instructions that govern ARM activity for an established time period, this date indicates when the control becomes effective. It is the date of the earliest interest rate, P&amp;I, or convertible change that will occur as part of the control record. If you are deleting ARM control and IR/P&amp;I change information for a loan, type a date which from that point forward will delete the IR/P&amp;I or ARM control information from the change file. No entry is required when the action code equals S.</param>
        /// <param name="armPlanID">(23-26) This field is required. This field contains a code that identifies the loan as an ARM loan to the system. It also represents the ARM plan header used to copy ARM information to the loan level when adding ARM information for the first time. After the information is written from the plan to the loan level, certain fields can be changed.</param>
        /// <param name="recalculationDays">(27-28) This field is optional. If the loan fails the calculation process, then corrective action is required before the system can calculate the new interest rate, P&amp;I, or convertible information. This field indicates the number of days after the date of the failed calculation that the system should attempt the calculation again. The number entered is added to the date of the failed calculation, and the resulting date is recorded in NEXT CALC DATE. (Holidays recorded on Investor Report Request Workstation screen RW02 and weekends are considered.)</param>
        /// <param name="irProcessingLeadTimeMonths">(29-31) This field is optional. This indicates the number of months prior to an interest rate effective date that calculations are to be performed. The number entered is subtracted from the interest rate effective date to arrive at the next calculation date.</param>
        /// <param name="irProcessingLeadTimeDays">(32-34) This field is optional. This indicates the number of days prior to an interest rate effective date that calculations are to be performed. The number entered is subtracted from the interest rate effective date to arrive at the next calculation date.</param>
        /// <param name="piProcessingLeadTimeMonths">(35-37) This field is optional. This field is the number of months prior to a P&amp;I change that calculations are to be performed. The number entered is subtracted from the P&amp;I change date to arrive at the next calculation date. The lead time required is dictated by the terms of the note. The whole months are subtracted first, and the days are subtracted from that date.</param>
        /// <param name="piProcessingLeadTimeDays">(38-40) This field is optional. This field is the number of days prior to a P&amp;I change that calculations are to be performed. The number entered is subtracted from the P&amp;I change date to arrive at the next calculation date. The lead time required is dictated by the terms of the note. The whole months are subtracted first, and the days are subtracted from that date.</param>
        /// <param name="cvProcessingLeadTimeMonths">(41-43) This field is optional. For loans with scheduled conversion options, this field is the number of months before the next conversion option date that the system begins convertible calculations. The number entered is subtracted from the convertible change date to arrive at the next calculation date. The lead time required is dictated by the terms of the note. The whole months are subtracted first, and the days are subtracted from that date.</param>
        /// <param name="cvProcessingLeadTimeDays">(44-46) This field is optional. For loans with scheduled conversion options, this field is the number of days before the next conversion option date that the system begins convertible calculations. The number entered is subtracted from the convertible change date to arrive at the next calculation date. The lead time required is dictated by the terms of the note. The whole months are subtracted first, and the days are subtracted from that date.</param>
        /// <param name="pmtsBtwnIRNotcs">(47-49) This field is conditional. This field is the number of payments between interest rate change dates for which notices are generated if notices are not sent to the mortgagor for every change. This field is required if you enter the IR EFF DATE NEXT NOTICE field.</param>
        /// <param name="irEffDateNextNotice">(50-55) This field is conditional. This field is the IR effective date on which the next interest rate notice is to be sent. The date is calculated using the PMTS BTWN IR NOTICES field and is verified and updated with the calculation process. Loans with a date in this field that is earlier than the current date are reported as exceptions when calculations are run.</param>
        /// <param name="separateIrAndPiNotices">(56) This field is optional. This field is a code that indicates whether separate notices or a combined notice of interest rate and P&amp;I changes should be produced when both changes are effective with the same payment and are calculated together.</param>
        /// <param name="armStatus">(57) This field is required. This code identifies the status of the ARM loan. The system will not perform calculations for P&amp;I or interest rate changes if this field is not A. No entry is required when the ACTION CODE equals S.</param>
        /// <param name="entryUserID">(58-60) This field is required. This field is the user ID of the person entering this loan-level ARM information transaction. The ID appears in the ARM Workstation to identify the user who initially added ARM information for the loan.</param>
        /// <param name="systemID">(67-70) This field is required. This field is a code that indicates the source of this transaction.</param>
        /// <param name="armOrigLnTerm">(71-73) This field is optional. This field is the ARM term, in months, if different from the loan term.</param>
        /// <param name="recordNumber">(78-80) This field is conditional. It is required for all action codes except S. It groups multiple cards to one control effective date in card 1. A control record is the information or set of instructions that controls ARM activity for the loan for an established period of time. A control record consists of information entered in card codes 01 through 18 of this transaction, and the record number logically groups the information by the control effective date. Up to 12 record numbers (or 12 different control effective dates) are allowed per loan per day.</param>
        /// <returns>Transaction 501 Card 1</returns>
        public static string Tran501c1(string loanNumber, string actionCode, string ctlEffectiveDate, string armPlanID,
                                       string recalculationDays, string irProcessingLeadTimeMonths,
                                       string irProcessingLeadTimeDays, string piProcessingLeadTimeMonths,
                                       string piProcessingLeadTimeDays, string cvProcessingLeadTimeMonths,
                                       string cvProcessingLeadTimeDays, string pmtsBtwnIRNotcs,
                                       string irEffDateNextNotice, string separateIrAndPiNotices, string armStatus,
                                       string entryUserID, string systemID, string armOrigLnTerm, string recordNumber)
        {
            string transaction;

            try
            {
                var transactionName = "501";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "actionCode", actionCode);
                CheckRequiredField(transactionName, "armPlanID", armPlanID);
                CheckRequiredField(transactionName, "entryUserID", entryUserID);
                CheckRequiredField(transactionName, "systemID", systemID);

                if (actionCode.Trim() != "S")
                {
                    if (!IsAvailable(ctlEffectiveDate))
                    {
                        throw new Exception(
                            string.Format("{0}: {1}: ctlEffectiveDate is required if actionCode is not 'S'.",
                                          transactionName, loanNumber));
                    }

                    if (!IsAvailable(armStatus))
                    {
                        throw new Exception(string.Format("{0}: {1}: armStatus is required if actionCode is not 'S'.",
                                                          transactionName, loanNumber));
                    }
                }

                if (!IsAvailable(pmtsBtwnIRNotcs))
                {
                    if (IsAvailable(irEffDateNextNotice))
                    {
                        throw new Exception(
                            string.Format(
                                "{0}: {1}: pymtsBtwnIRNotics is required if a value is entered for irEffDateNextNotice.",
                                transactionName, loanNumber));
                    }
                    //else
                    //{
                    //    throw new Exception(string.Format("{0}: {1}: irEffDateNextNotice cannot be blank if pmtsBtwnIRNotcs is blank.", transactionName, loanNumber));
                    //}
                }

                var tranClient = "501" + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("01"); // 14-15: CARD CODE
                tranBuilder.Append(actionCode.Trim().PadRight(1)); // 16: ACTION CODE
                tranBuilder.Append(FormatDate(ctlEffectiveDate.Trim())); // 17-22: CTL EFFECTIVE DATE
                tranBuilder.Append(armPlanID.Trim().PadRight(4)); // 23-26 ARM PLAN ID
                tranBuilder.Append(LeftZeroFillOptionalField(recalculationDays.Trim(), 2)); // 27-28: RECALCULATION DAYS
                tranBuilder.Append(LeftZeroFillOptionalField(irProcessingLeadTimeMonths.Trim(), 3));
                // 29-31: IR PROCESSING LEAD TIME MONTHS
                tranBuilder.Append(LeftZeroFillOptionalField(irProcessingLeadTimeDays.Trim(), 3));
                // 32-34: IR PROCESSING LEAD TIME DAYS
                tranBuilder.Append(LeftZeroFillOptionalField(piProcessingLeadTimeMonths.Trim(), 3));
                // 35-37: PI PROCESSING LEAD TIME MONTHS
                tranBuilder.Append(LeftZeroFillOptionalField(piProcessingLeadTimeDays.Trim(), 3));
                // 38-40: PI PROCESSING LEAD TIME DAYS
                tranBuilder.Append(LeftZeroFillOptionalField(cvProcessingLeadTimeMonths.Trim(), 3));
                // 41-43: CV PROCESSING LEAD TIME MONTHS
                tranBuilder.Append(LeftZeroFillOptionalField(cvProcessingLeadTimeDays.Trim(), 3));
                // 44-46: CV PROCESSING LEAD TIME DAYS
                tranBuilder.Append(LeftZeroFillOptionalField(pmtsBtwnIRNotcs.Trim(), 3)); // 47-49: PMTS BTWN IR NOTICES
                tranBuilder.Append(FormatDate(irEffDateNextNotice.Trim())); // 50-55 IR EFF DATE NEXT NOTICE
                tranBuilder.Append(separateIrAndPiNotices.Trim().PadRight(1)); // 56: SEPARATE IR AND PI NOTICES 
                tranBuilder.Append(armStatus.Trim().PadRight(1)); // 57: ARM STATUS
                tranBuilder.Append(entryUserID.Trim().PadRight(3)); // 58-60: ENTRY USER ID
                tranBuilder.Append(' ', 6); // 61-66: RESERVED
                tranBuilder.Append(systemID.Trim().PadRight(4)); // 67-70: SYSTEM ID
                tranBuilder.Append(LeftZeroFillOptionalField(armOrigLnTerm.Trim(), 3)); // 71-73: ARM ORIG LN TERM
                tranBuilder.Append(' ', 4); // 74-77: RESERVED
                tranBuilder.Append(LeftZeroFillOptionalField(recordNumber.Trim(), 3)); // 78-80: RECORD NUMBER
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}