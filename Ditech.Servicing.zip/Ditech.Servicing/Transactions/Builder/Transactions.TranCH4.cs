﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction CH4 - Escrow Header Data - Request (D-015)
        /// There are two distinct CH4 transactions, both of which request report S-224. You enter one of the CH4 transactions to request regular escrow header information, and the other to request optional insurance escrow header information.
        /// </summary>
        /// <param name="escrowType">(70-71) This field is optional. It identifies the escrow type you want included on the output.</param>
        /// <param name="sortOption">(76) This field is required. It indicates the order in which you want the system to sort the headers.</param>
        /// <returns>Transaction CH4 Card 1</returns>
        public static string TranCH4c1(string escrowType, string sortOption)
        {
            string transaction;

            try
            {
                var transactionName = "CH4-1";

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                CheckRequiredField(transactionName, "sortOption", sortOption);

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append(' ' , 10); // 7-16
                tranBuilder.Append("1"); // 17: CARD CODE
                tranBuilder.Append(' ', 52); // 18-69: RESERVED
                tranBuilder.Append(escrowType.Trim().PadRight(2)); // 70-71: ESCROW TYPE
                tranBuilder.Append(' ', 4); // 72-75: RESERVED
                tranBuilder.Append(sortOption.Trim().PadRight(1)); // 76: SORT OPTION
                tranBuilder.Append(' ', 4); // 77-80: RESERVED
                transaction = tranBuilder.ToString();

                if (transaction.Length != 80)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "********** " + ex.Message;
            }

            return transaction;
        }
    }
}