﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Ditech.Servicing.Transactions.Models;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions : TransactionModels
    {
        /// <summary>
        ///     Transaction 03R - Stops and Flags Reason Codes (D-423)
        ///     Use transaction 03R to set stops and flags and their corresponding reason codes on the loan record. Use this
        ///     transaction in place of or in addition to transaction 031 when you want to provide reason codes with the stops and
        ///     flags.
        /// </summary>
        /// <param name="loanNumber">Required.  The number assigned to the loan.</param>
        /// <param name="changedBy">Optional.  The user who submitted the transaction.</param>
        /// <param name="stopExpirationDate">
        ///     Conditional.  It indicates the date that the values for certain fields are
        ///     automatically selected by the system for removal in the following MSP cycle.
        /// </param>
        /// <param name="processStop">
        ///     Optional.  Indicates whether the loan has a process stop, which prevents the system from
        ///     applying monetary transactions.
        /// </param>
        /// <param name="processStopReasonCode">Optional.  The reason code for the process stop change.</param>
        /// <param name="badCheckStop">
        ///     Optional.  Indicates whether the loan has a bad check stop and how to process payments.  If
        ///     a bad check stop is present, the system rejects the loan from automatic drafting.
        /// </param>
        /// <param name="badCheckStopReasonCode">Optional.  The reason code for the bad check stop change.</param>
        /// <param name="paidInFullStop">
        ///     Optional.  Indicates whether the loan has a paid-in-full stop and identifies why the
        ///     system prevents payment application.
        /// </param>
        /// <param name="paidInFullStopReasonCode">Optional.  The reason code for the paid in full stop change.</param>
        /// <param name="foreclosureStop">
        ///     Optional.  Indicates the action the system takes on payments and/or disbursements for
        ///     loans in foreclosure.
        /// </param>
        /// <param name="foreclosureStopReasonCode">Optional.  The reason code for the foreclosure stop change.</param>
        /// <param name="noNoticeCode">
        ///     Optional.  Determines whether notices are sent to the mortgagor on accounts for which you
        ///     would otherwise send delinquent notices.
        /// </param>
        /// <param name="noNoticeStopReasonCode">Optional.  The reason code for the no notice stop change.</param>
        /// <param name="noAnalysisStop">Optional.  Indicates whether to prevent an escrow analysis from occurring on the loan.</param>
        /// <param name="noAnalysisStopReasonCode">Optional.  The reason code for the no analysis stop change.</param>
        /// <param name="aAndHFlag">
        ///     Optional.  Indicates whether the system permits solicitation for accident and health insurance
        ///     for the loan.
        /// </param>
        /// <param name="aAndHFlagReasonCode">Optional.  The reason code for the A&H flag change.</param>
        /// <param name="lifeFlag">Optional.  Indicates whether the system permits solicitation for life insurance for the loan.</param>
        /// <param name="lifeFlagReasonCode">Optional.  The reason code for the life flag change.</param>
        /// <param name="disbursementStop">
        ///     Optional.  Indicates whether the loan has an escrow disbursement stop, which prevents
        ///     the system from applying escrow disbursements except for mortgage insurance premiums.
        /// </param>
        /// <param name="disbursementStopReasonCode">Optional.  The reason code for the disbursement stop change.</param>
        /// <param name="lateChargeAssessmentStop">
        ///     Optional.  Indicates whether late charges are assessed, regardless of the loan's
        ///     due date.
        /// </param>
        /// <param name="lateChargeStopReasonCode">Optional.  The reason code for the late charge assessment stop change.</param>
        /// <param name="payoffPendingDisbursementStop">
        ///     Optional.  A code that indicatess whether the escrow balance was deducted
        ///     from the payoff quote. It determines whether the system processes hazard insurance and tax disbursements if the
        ///     disbursement amount is greater than the escrow balance.
        /// </param>
        /// <param name="payoffPendingDisbursementStopReasonCode">
        ///     Optional.  The reason code for the payoff pending disbursement
        ///     stop change.
        /// </param>
        /// <param name="armUpdateStop">
        ///     Conditional.  Prevents updates to the loan when automatic ARM calculations occur and
        ///     prevents ARM notices from being generated.
        /// </param>
        /// <param name="armUpdateStopReasonCode">Optional.  The reason code for the ARM update stop change.</param>
        /// <param name="armNoticeStop">
        ///     Conditional.  Indicates whether to suppress printing of ARM notices, but does not stop the
        ///     interest rate and P&I from being updated.
        /// </param>
        /// <param name="armNoticeStopReasonCode">Optional.  The reason code change for the ARM notice stop change.</param>
        /// <param name="elocAdvanceStop">
        ///     A code that indicates whether the system stops transaction 049 from processing in
        ///     advance.
        /// </param>
        /// <param name="elocAdvanceStopReasonCode">Optional.  The reason code for the ELOC advance stop change.</param>
        /// <param name="elocDisputedFlag">Indicates if the borrower is disputing an ELOC bill statement.</param>
        /// <param name="elocDisputedFlagReasonCode">Optional.  The reason code for the ELOC disputed flag change.</param>
        /// <param name="optOutStop">Optional.  A code that prevents solicitation for all third-party products.</param>
        /// <param name="optOutStopReasonCode">Optional.  The reason code for the opt out stop change.</param>
        /// <returns></returns>
        public static string Tran03R(string loanNumber, string changedBy = "", string stopExpirationDate = "",
            string processStop = "", string processStopReasonCode = "", string badCheckStop = "",
            string badCheckStopReasonCode = "",
            string paidInFullStop = "", string paidInFullStopReasonCode = "", string foreclosureStop = "",
            string foreclosureStopReasonCode = "",
            string noNoticeCode = "", string noNoticeStopReasonCode = "", string noAnalysisStop = "",
            string noAnalysisStopReasonCode = "",
            string aAndHFlag = "", string aAndHFlagReasonCode = "", string lifeFlag = "", string lifeFlagReasonCode = "",
            string disbursementStop = "",
            string disbursementStopReasonCode = "", string lateChargeAssessmentStop = "",
            string lateChargeStopReasonCode = "", string payoffPendingDisbursementStop = "",
            string payoffPendingDisbursementStopReasonCode = "", string armUpdateStop = "",
            string armUpdateStopReasonCode = "", string armNoticeStop = "",
            string armNoticeStopReasonCode = "", string elocAdvanceStop = "", string elocAdvanceStopReasonCode = "",
            string elocDisputedFlag = "", string elocDisputedFlagReasonCode = "",
            string optOutStop = "", string optOutStopReasonCode = "")
        {
            string transaction;

            const string transactionName = "03R";

            CheckValidLoanNumber(transactionName, loanNumber);

            var allStops =
                string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}", armNoticeStop.Trim(), armUpdateStop.Trim(),
                    badCheckStop.Trim(), disbursementStop.Trim(),
                    lateChargeAssessmentStop.Trim(), noAnalysisStop.Trim(), noNoticeCode.Trim(),
                    payoffPendingDisbursementStop.Trim(), processStop.Trim());

            if (allStops.Length > 1 && IsAvailable(stopExpirationDate))
            {
                throw new Exception(
                    string.Format(
                        "{0}: {1}: Only one stop can be set per transaction if an expiration date is present.",
                        transactionName, loanNumber));
            }

            const string tranClient = transactionName + CLIENT_NUMBER;

            var tranBuilder = new StringBuilder();

            tranBuilder.Append(tranClient); // 1-6 CLIENT NUMBER
            tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN NUMBER
            tranBuilder.Append("1"); // 14 CARD CODE
            tranBuilder.Append(TrimAndPad(changedBy,3)); // 15-17 CHANGED BY
            tranBuilder.Append(FormatDate(TrimAndPad(stopExpirationDate,6))); // 18-23 STOP EXPIRATION DATE
            tranBuilder.Append(TrimAndPad(processStop,1)); // 24 PROCESS STOP
            tranBuilder.Append(TrimAndPad(processStopReasonCode,2)); // 25-26 PROCESS STOP REASON CODE
            tranBuilder.Append(TrimAndPad(badCheckStop,1)); // 27 BAD CHECK STOP
            tranBuilder.Append(TrimAndPad(badCheckStopReasonCode,2)); // 28-29 BAD CHECK STOP REASON CODE
            tranBuilder.Append(TrimAndPad(paidInFullStop,1)); // 30 PAID IN FULL STOP
            tranBuilder.Append(TrimAndPad(paidInFullStopReasonCode,2)); // 31-32 PAID IN FULL STOP REASON CODE
            tranBuilder.Append(TrimAndPad(foreclosureStop,1)); // 33 FORECLOSURE STOP
            tranBuilder.Append(TrimAndPad(foreclosureStopReasonCode,2)); // 34-35 FORECLOSURE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(noNoticeCode,1)); // 36 NO NOTICE CODE
            tranBuilder.Append(TrimAndPad(noNoticeStopReasonCode,2)); // 37-38 NO NOTICE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(noAnalysisStop,1)); // 39 NO ANALYSIS STOP
            tranBuilder.Append(TrimAndPad(noNoticeStopReasonCode,2)); // 40-41 NO ANALYSIS STOP REASON CODE
            tranBuilder.Append(TrimAndPad(aAndHFlag,1)); // 42 A&H FLAG 
            tranBuilder.Append(TrimAndPad(aAndHFlagReasonCode,2)); // 43-44 A&H FLAG REASON CODE
            tranBuilder.Append(TrimAndPad(lifeFlag,1)); // 45 LIFE FLAG
            tranBuilder.Append(TrimAndPad(lifeFlagReasonCode,2)); //46-47 LIFE FLAG REASON CODE
            tranBuilder.Append(TrimAndPad(disbursementStop,1)); // 48 DISBURSEMENT STOP
            tranBuilder.Append(TrimAndPad(disbursementStopReasonCode,2)); // 49-50 DISBURSEMENT STOP REASON CODE
            tranBuilder.Append(TrimAndPad(lateChargeAssessmentStop,1)); // 51 LATE CHARGE ASSESSMENT STOP
            tranBuilder.Append(TrimAndPad(lateChargeStopReasonCode,2)); // 52-53 LATE CHARGE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(payoffPendingDisbursementStop,1)); // 54 PAYOFF PENDING DISBURSEMENT STOP
            tranBuilder.Append(TrimAndPad(payoffPendingDisbursementStopReasonCode,2));
                // 55-56 PAYOFF PENDING DISBURSEMENT STOP REASON CODE
            tranBuilder.Append(TrimAndPad(armUpdateStop,1)); // 57 ARM UPDATE STOP
            tranBuilder.Append(TrimAndPad(armUpdateStopReasonCode,2)); // 58-59 ARM UPDATE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(armNoticeStop,1)); // 60 ARM NOTICE STOP
            tranBuilder.Append(TrimAndPad(armUpdateStopReasonCode,2)); // 61-62 ARM NOTICE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(elocAdvanceStop,1)); // 63 ELOC ADVANCE STOP
            tranBuilder.Append(TrimAndPad(elocAdvanceStopReasonCode,2)); // 64-65 ELOC ADVANCE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(elocDisputedFlag,1)); // 66 ELOC DISPUTED FLAG
            tranBuilder.Append(TrimAndPad(elocDisputedFlagReasonCode,2)); // 67-68 ELOC DISPUTED FLAG REASON CODE
            tranBuilder.Append(TrimAndPad(optOutStop,1)); // 69 OPT OUT STOP
            tranBuilder.Append(TrimAndPad(optOutStopReasonCode,2)); // 70-71 OPT OUT STOP REASON CODE
            tranBuilder.Append(' ', 9); // 72-80 RESERVED
            tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
            tranBuilder.Append(loanNumber.Trim().PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

            if (tranBuilder.Length != 102)
            {
                throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
            }

            tranBuilder.AppendLine();
            transaction = tranBuilder.ToString();


            return transaction;
        }
        /// <summary>
        /// Transaction 03R - Stops and Flags Reason Codes (D-423)
        ///     Use transaction 03R to set stops and flags and their corresponding reason codes on the loan record. Use this
        ///     transaction in place of or in addition to transaction 031 when you want to provide reason codes with the stops and
        ///     flags.
        /// </summary>
        /// <param name="tran03rModel"></param>
        /// <returns></returns>
        public static string Tran03R(Tran03RModel tran03rModel)
        {
            string transaction;

            const string transactionName = "03R";

            CheckValidLoanNumber(transactionName,tran03rModel.LoanNumber);

            var stopLimitations = new string[]
            {
                "ArmNoticeStop",
                "ArmUpdateStop",
                "BadCheckStop",
                "DisbursementStop",
                "LateChargeAssessmentStop",
                "NoAnalysisStop",
                "NoNoticeCode",
                "PayoffPendingDisbursementStop",
                "ProcessStop"
            };

            
            var stopsWithData = 0;
            foreach (var stop in stopLimitations)
            {
                var value = (string) tran03rModel.GetType().GetProperty(stop).GetValue(tran03rModel);

                if (!string.IsNullOrEmpty(value)) stopsWithData++;
            }

            if(stopsWithData  > 1 && IsAvailable(tran03rModel.StopExpirationDate))
            {
                throw new Exception(
                    string.Format(
                        "{0}: {1}: Only one stop can be set per transaction if an expiration date is present.",
                        transactionName,tran03rModel.LoanNumber));
            }

            const string tranClient = transactionName + CLIENT_NUMBER;

            var tranBuilder = new StringBuilder();

            tranBuilder.Append(tranClient); // 1-6 CLIENT NUMBER
            tranBuilder.Append("*".PadRight(7)); // 7-13 LOAN NUMBER
            tranBuilder.Append("1"); // 14 CARD CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.ChangedBy, 3)); // 15-17 CHANGED BY
            tranBuilder.Append(FormatDate(TrimAndPad(tran03rModel.StopExpirationDate, 6))); // 18-23 STOP EXPIRATION DATE
            tranBuilder.Append(TrimAndPad(tran03rModel.ProcessStop, 1)); // 24 PROCESS STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.ProcessStopReasonCode, 2)); // 25-26 PROCESS STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.BadCheckStop, 1)); // 27 BAD CHECK STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.BadCheckStopReasonCode, 2)); // 28-29 BAD CHECK STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.PaidInFullStop, 1)); // 30 PAID IN FULL STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.PaidInFullStopReasonCode, 2)); // 31-32 PAID IN FULL STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.ForeclosureStop, 1)); // 33 FORECLOSURE STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.ForeclosureStopReasonCode, 2)); // 34-35 FORECLOSURE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.NoNoticeCode, 1)); // 36 NO NOTICE CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.NoNoticeStopReasonCode, 2)); // 37-38 NO NOTICE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.NoAnalysisStop, 1)); // 39 NO ANALYSIS STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.NoNoticeStopReasonCode, 2)); // 40-41 NO ANALYSIS STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.AAndHFlag, 1)); // 42 A&H FLAG 
            tranBuilder.Append(TrimAndPad(tran03rModel.AAndHFlagReasonCode, 2)); // 43-44 A&H FLAG REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.LifeFlag, 1)); // 45 LIFE FLAG
            tranBuilder.Append(TrimAndPad(tran03rModel.LifeFlagReasonCode, 2)); //46-47 LIFE FLAG REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.DisbursementStop, 1)); // 48 DISBURSEMENT STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.DisbursementStopReasonCode, 2)); // 49-50 DISBURSEMENT STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.LateChargeAssessmentStop, 1)); // 51 LATE CHARGE ASSESSMENT STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.LateChargeStopReasonCode, 2)); // 52-53 LATE CHARGE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.PayoffPendingDisbursementStop, 1)); // 54 PAYOFF PENDING DISBURSEMENT STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.PayoffPendingDisbursementStopReasonCode, 2));
            // 55-56 PAYOFF PENDING DISBURSEMENT STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.ArmUpdateStop, 1)); // 57 ARM UPDATE STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.ArmUpdateStopReasonCode, 2)); // 58-59 ARM UPDATE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.ArmNoticeStop, 1)); // 60 ARM NOTICE STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.ArmUpdateStopReasonCode, 2)); // 61-62 ARM NOTICE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.ElocAdvanceStop, 1)); // 63 ELOC ADVANCE STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.ElocAdvanceStopReasonCode, 2)); // 64-65 ELOC ADVANCE STOP REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.ElocDisputedFlag, 1)); // 66 ELOC DISPUTED FLAG
            tranBuilder.Append(TrimAndPad(tran03rModel.ElocDisputedFlagReasonCode, 2)); // 67-68 ELOC DISPUTED FLAG REASON CODE
            tranBuilder.Append(TrimAndPad(tran03rModel.OptOutStop, 1)); // 69 OPT OUT STOP
            tranBuilder.Append(TrimAndPad(tran03rModel.OptOutStopReasonCode, 2)); // 70-71 OPT OUT STOP REASON CODE
            tranBuilder.Append(' ', 9); // 72-80 RESERVED
            tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
            tranBuilder.Append(tran03rModel.LoanNumber.Trim().PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

            if (tranBuilder.Length != 102)
            {
                throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
            }

            tranBuilder.AppendLine();
            transaction = tranBuilder.ToString();


            return transaction;
        }
    }

    
}