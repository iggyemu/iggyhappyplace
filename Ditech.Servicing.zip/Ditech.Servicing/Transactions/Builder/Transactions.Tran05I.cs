#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 05I - Prepayment Penalty Indicators - Add, Change, and Delete (D-260).
        /// Use transaction 05I to add, change, or delete prepayment penalty indicators and descriptions. You generate this transaction from the Prepayment Penalty screen (PAYP) in the New Loan, Loan Maintenance, or Payoff Workstation.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="hitype">(14) This field is required. It indicates whether the loan is for a first, second, or piggyback mortgage.</param>
        /// <param name="cardCode">(15) This field is required. It indicates the card you are entering.</param>
        /// <param name="act">(16) This field is required. It indicates the action the system should perform.</param>
        /// <param name="prepaymentPenaltyIndicator">(17) This field is conditional. It is required if you are adding or deleting the prepayment penalty indicator. It indicates whether a prepayment penalty exists for the loan. This field updates the PREPAY-PEN-INDIC field in the master file.</param>
        /// <param name="prepaymentPenaltyDescription">(18-80) This field is required. It indicates a description of the prepayment penalty.</param>
        /// <returns>Transaction 05I</returns>
        public static string Tran05I(string loanNumber, string hitype, string cardCode, string act,
                                     string prepaymentPenaltyIndicator, string prepaymentPenaltyDescription)
        {
            string transaction;

            try
            {
                var transactionName = "05I";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "hitype", hitype);
                CheckRequiredField(transactionName, "cardCode", cardCode);
                CheckRequiredField(transactionName, "act", act);

                // Cannot check prepayment penalty description because blank lines can be used in the description (card codes 1-9 = lines 1-9)

                //CheckRequiredField(transactionName, "prepaymentPenaltyDescription", prepaymentPenaltyDescription);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(hitype.Trim().PadRight(1)); // 14: HI-TYPE
                tranBuilder.Append(cardCode.Trim().PadRight(1)); // 15: CARD CODE
                tranBuilder.Append(act.Trim().PadRight(1)); // 16: ACT
                tranBuilder.Append(prepaymentPenaltyIndicator.Trim().PadRight(1)); // 17: PREPAYMENT PENALTY INDICATOR
                tranBuilder.Append(prepaymentPenaltyDescription.Trim().PadRight(63));
                // 18-80: PREPAYMENT PENALTY DESCRIPTION 
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}