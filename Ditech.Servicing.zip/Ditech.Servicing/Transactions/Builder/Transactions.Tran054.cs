#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 054 - Mortgage Data - New Loans (D-021).
        /// Transaction 054 (D-021) This transaction is required to add a loan to the master file.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="bank">(18-20) This required field contains a code to designate the investor or mortgagee bank number and is left zero-filled.</param>
        /// <param name="category">(21-23) This required field contains the category code for this loan. Use category codes to segregate groups of loans within an investor in conformity with reporting requirements for remittance and principal reconciliations or for other control purposes.</param>
        /// <param name="investorLoanNumber">(24-33) This optional field contains the serial number by which an investor identifies a loan.</param>
        /// <param name="annualServiceFee">(34-41) This field is optional. A nonzero value in this field directs the system to compute the service fee paid by the investor. The service fee paid is included in the interest paid. It is calculated upon receipt of each mortgage payment. The service fee rate is divided by the annual interest rate, and the result is multiplied by the interest paid, giving the service fee paid. If the service fee is a level amount, use the LEVEL SERVICE FEE field instead.</param>
        /// <param name="levelServiceFee">(42-46) This field is optional. A nonzero value in this field indicates to the system that the service fee paid by the investor is a level amount. This is the dollars and cents amount to be taken from interest on each payment on this loan to pay the service fee. If the service fee is not a level amount, but a percentage of the interest paid, use the ANNUAL SERVICE FEE field instead.</param>
        /// <param name="masterServicerFeeAmount">(48-52) The following information applies only if you are installed on the Master Servicing System optional enhancement (IP 1303).  This required field indicates the dollar amount (flat fee) charged by the master servicer.</param>
        /// <param name="masterServicerFeePercentage">(53-57) The following information applies only if you are installed on the Master Servicing System optional enhancement (IP 1303).  This required field indicates the percentage fee charged by the master servicer.</param>
        /// <param name="agentCategory">(58-60) The following information applies only if you are installed on the Master Servicing System optional enhancement (IP 1303).  This required field indicates the category of the agent whose loan you are servicing.</param>
        /// <param name="sslInterestChangeDate">(61-64) This field is conditional. It is required for subserviced loans with SSL ARM/GPM INDICATOR equal to D. It indicates the payment due date on which the next interest rate change is to occur for the loan. The subserviced loan system expects a change for the payment with this due date.</param>
        /// <param name="sslInterestPeriod">(65-67) This is a conditional field. It is required only for subserviced loans with SSL ARM/GPM INDICATOR equal to D. It indicates the number of months between interest rate changes. When the payment with the due date equal to the SSL interest change date is applied, the system automatically advances the SSL interest change date by the number of months indicated by SSL interest period.</param>
        /// <param name="sslPIChangeDate">(68-71) This is a conditional field. It is required only for subserviced loans with SSL ARM/GPM INDICATOR equal to D or E. It indicates the payment due date on which the next P&amp;I change is to occur for the loan. The subserviced loan system expects a change for the payment with this due date.</param>
        /// <param name="sslPIPeriod">(72-74) This is a conditional field. It is required only for subserviced loans with SSL ARM/GPM INDICATOR equal to D or E. It indicates the number of months between P&amp;I changes. When the payment with the due date equal to the SSL P&amp;I change date is applied, the system automatically advances the SSL P&amp;I change date by the number of months indicated by SSL P&amp;I period.</param>
        /// <param name="agentNumber">(75-79) This field is optional. AGENT NUMBER is broken into two parts. The first part is composed of positions 1 through 3 of the agent number and is used to uniquely identify the agent servicing the loans and to refer to the corresponding agent header. The second part is composed of positions 4 through 5 and is used to subcategorize the loans that are being serviced by the agent.</param>
        /// <param name="sslArm_GpmIndicator">(80) Use this optional field to indicate to the subserviced loan subsystem whether changes in interest rate and/or P&amp;I are to be expected and, if so, whether the subserviced loan subsystem is to monitor and report the changes.</param>
        /// <returns>Transaction 054 Card 1</returns>
        public static string Tran054c1(string loanNumber, string bank, string category, string investorLoanNumber,
                                       string annualServiceFee, string levelServiceFee, string masterServicerFeeAmount,
                                       string masterServicerFeePercentage, string agentCategory,
                                       string sslInterestChangeDate, string sslInterestPeriod, string sslPIChangeDate,
                                       string sslPIPeriod, string agentNumber, string sslArm_GpmIndicator)
        {
            string transaction;

            try
            {
                var transactionName = "054";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "bank", bank);
                CheckRequiredField(transactionName, "category", category);

                // When indicator is set to D, other fields must be populated
                if (sslArm_GpmIndicator.Trim() == "D")
                {
                    if (!IsAvailable(sslInterestChangeDate))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when SSL ARM/GPM Indicator is set to D.",
                                          transactionName, loanNumber, "sslInterestChangeDate"));

                    if (!IsAvailable(sslInterestPeriod))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when SSL ARM/GPM Indicator is set to D.",
                                          transactionName, loanNumber, "sslInterestPeriod"));

                    if (!IsAvailable(sslPIChangeDate))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when SSL ARM/GPM Indicator is set to D.",
                                          transactionName, loanNumber, "sslPIChangeDate"));

                    if (!IsAvailable(sslPIPeriod))
                        throw new Exception(
                            string.Format("{0}: {1}: {2} is required when SSL ARM/GPM Indicator is set to D.",
                                          transactionName, loanNumber, "sslPIPeriod"));
                }


                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(' ', 3); // 15-17: RESERVED
                tranBuilder.Append(bank.Trim().PadLeft(3, '0')); // 18-20: BANK
                tranBuilder.Append(category.Trim().PadLeft(3, '0')); // 21-23: CATEGORY
                tranBuilder.Append(investorLoanNumber.Trim().PadRight(10)); // 24-33: INVESTOR LOAN NUMBER
                tranBuilder.Append(FormatPercent(annualServiceFee.Trim(), 8)); // 34-41: ANNUAL SERVICE FEE
                tranBuilder.Append(FormatMoney(levelServiceFee.Trim(), true, false, 5)); // 42-46: LEVEL SERVICE FEE
                tranBuilder.Append(' ', 1); // 47: RESERVED
                tranBuilder.Append(FormatMoney(masterServicerFeeAmount.Trim(), false, false, 5));
                // 48-52: MASTER SERVICER FEE AMOUNT
                tranBuilder.Append(LeftZeroFillOptionalField(masterServicerFeePercentage.Trim(), 5));
                // 53-57: MASTER SERVICER FEE PERCENTAGE
                tranBuilder.Append(LeftZeroFillOptionalField(agentCategory.Trim(), 3)); // 58-60: AGENT CATEGORY
                tranBuilder.Append(sslInterestChangeDate.Trim().PadLeft(4)); // 61-64: SSL INTEREST CHANGE DATE
                tranBuilder.Append(LeftZeroFillOptionalField(sslInterestPeriod.Trim(), 3));
                // 65-67: SSL INTEREST PERIOD
                tranBuilder.Append(sslPIChangeDate.Trim().PadLeft(4)); // 68-71: SSL P&I CHANGE DATE
                tranBuilder.Append(LeftZeroFillOptionalField(sslPIPeriod.Trim(), 3)); // 72-74: SSL P&I PERIOD
                tranBuilder.Append(LeftZeroFillOptionalField(agentNumber.Trim(), 5)); // 75-79: AGENT NUMBER
                tranBuilder.Append(sslArm_GpmIndicator.Trim().PadRight(1)); // 80: SSL ARM/GPM INDICATOR
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}