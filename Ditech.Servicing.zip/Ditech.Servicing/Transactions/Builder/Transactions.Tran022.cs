﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 022 - Loan Guaranty Information - Add (D-021)
        /// Use this transaction to enter loan guaranty data on FHA insured, VA guaranteed, or private mortgage insurance company insured loans.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="fhaSection">(14-16) This field is optional. This field is used to record the National Housing Act section code used by FHA for an FHA-insured loan.</param>
        /// <param name="fhaNumber">(17-26) This field is optional. This field is used to record the serial number assigned to the loan by FHA. Two primary sources of FHA numbers are the FHA commitment which may be used in setting up a new loan, and the FHA's MIP bills. Two other ways these may be obtained are through purchases of portfolio or transfers of servicing.</param>
        /// <param name="fhaCheckDigit">(27) This field is optional. This field is used to enter the FHA check digit, if assigned by FHA.</param>
        /// <param name="guarantyInsCo_VaOfficeCode">(28-30) This field is optional. This field indicates the servicer-assigned code for the PMI company for conventional loans covered by private mortgage insurance.</param>
        /// <param name="guarantyNo">(31-40) This field is optional. This field displays the policy or certificate number assigned to the loan by the guaranty insurance company.</param>
        /// <param name="vaNumber">(41-50) This field is optional. This field displays the VA number assigned to the loan by the Veterans Administration.</param>
        /// <param name="propertyValue">(51-59) This field is optional. This field is used for loans covered by private mortgage insurance (PMI) to determine when the principal balance falls below 75% of the property value. When this occurs, PMI may be discontinued on some loans.</param>
        /// <param name="pmi_MipRate">(60-64) This field is optional. The private mortgage insurance rate is used to record the percentage rate for the private mortgage insurance premium. Normally the principal balance is multiplied by this rate to compute the PMI premium.</param>
        /// <param name="purchasePrice">(66-76) This field is optional. This field displays the purchase price in dollars. This field is used for MIDANET I and FHLBB reporting.</param>
        /// <param name="vaOfficeCodeIndicator">(77) This field is conditional. This field is required when field 6 is used to enter a VA office code.</param>
        /// <param name="percentOfPrimaryPmiCoverage">(78-80) This field is optional. The percent of primary PMI coverage is used to record the percent of the loan amount that is covered by the primary PMI company. This is not intended to track the percentage of pool PMI coverage.</param>
        /// <returns>Transaction 022 Card 1</returns>
        public static string Tran022c1(string loanNumber, string fhaSection, string fhaNumber, string fhaCheckDigit,
                                       string guarantyInsCo_VaOfficeCode, string guarantyNo, string vaNumber,
                                       string propertyValue, string pmi_MipRate, string purchasePrice,
                                       string vaOfficeCodeIndicator, string percentOfPrimaryPmiCoverage)
        {
            string transaction;

            try
            {
                var transactionName = "022-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(LeftZeroFillOptionalField(fhaSection.Trim(), 3)); // 14-16: FHA SECTION
                tranBuilder.Append(LeftZeroFillOptionalField(fhaNumber.Trim(), 10)); // 17-26: FHA NUMBER
                tranBuilder.Append(fhaCheckDigit.Trim().PadRight(1)); // 27 FHA: CHECK DIGIT
                tranBuilder.Append(LeftZeroFillOptionalField(guarantyInsCo_VaOfficeCode.Trim(), 3));
                // 28-30: GUARANTY INS CO / VA OFFICE CODE
                tranBuilder.Append(guarantyNo.Trim().PadRight(10)); // 31-40: GUARANTY NO.
                tranBuilder.Append(vaNumber.Trim().PadRight(10)); // 41-50: VA NUMBER
                tranBuilder.Append(FormatMoney(propertyValue.Trim(), false, false, 9)); // 51-59: PROPERTY VALUE
                tranBuilder.Append(FormatPercent(pmi_MipRate.Trim(), 5)); // 60-64: PMI/MIP RATE
                tranBuilder.Append(' '); // 65: RESERVED
                tranBuilder.Append(FormatMoney(purchasePrice.Trim(), false, false, 11)); // 66-76: PURCHASE PRICE
                tranBuilder.Append(vaOfficeCodeIndicator.Trim().PadRight(1)); // 77: VA OFFICE CODE INDICATOR
                tranBuilder.Append(FormatPercent(percentOfPrimaryPmiCoverage.Trim(), 3));
                // 78-80 PERCENT OF PRIMARY PMI COVERAGE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}