#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 010 - Card 1 - New Loan Data - Name and Address (D-021).
        /// This transaction is required to enter the billing name and address fields at loan setup. It is also used to set up other master file data, such as abbreviated names, social security numbers, second telephone number, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="billingName">(15-37) This field is required. It indicates the full name of the mortgagor for billing purposes.</param>
        /// <param name="billingName2">(38-60) This field is optional. It indicates the full name of a second individual for billing purposes.</param>
        /// <param name="assumptionDate">(61-66) This field is optional. It indicates the date a loan assumption was effective.</param>
        /// <param name="locationCode">(67) This field is optional. It indicates the location (business, relative, etc.) of the second telephone number.</param>
        /// <param name="secondTelephoneNumber">(68-77) This field is optional. It indicates a second telephone number for the mortgagor or co-mortgagor. Include area code, no dashes or blanks.</param>
        /// <param name="assumptionCode">(79) This field is optional. It indicates whether the loan is assumable. If it is not assumable, the system rejects an assumption transaction (011) entered for the loan.</param>
        /// <returns>Transaction 010 Card 1</returns>
        public static string Tran010c1(string loanNumber, string billingName, string billingName2, string assumptionDate,
                                       string locationCode, string secondTelephoneNumber, string assumptionCode)
        {
            string transaction;

            try
            {
                var transactionName = "010-1";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Billing Name (15-37)", billingName);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(billingName.Trim().PadRight(23)); // 15-37: BILLING NAME
                tranBuilder.Append(billingName2.Trim().PadRight(23)); // 38-60: BILLING NAME 2
                tranBuilder.Append(FormatDate(assumptionDate.Trim())); // 61-66: ASSUMPTION DATE
                tranBuilder.Append(locationCode.Trim().PadRight(1)); // 67: LOCATION CODE
                tranBuilder.Append(secondTelephoneNumber.Trim().PadRight(10)); // 68-77: SECOND TELEPHONE NUMBER
                tranBuilder.Append(' '); // 78: RESERVED
                tranBuilder.Append(assumptionCode.Trim().PadRight(1)); // 79: ASSUMPTION CODE
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 010 - Card 2 - New Loan Data - Name and Address (D-021).
        /// This transaction is required to enter the billing name and address fields at loan setup. It is also used to set up other master file data, such as abbreviated names, social security numbers, second telephone number, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="addressLine1">(15-37) This field is required. It indicates the primary postal delivery address, such as street address, post office box, or rural route.</param>
        /// <param name="billingCity">(38-57) This field is required. It indicates the name of the city for postal delivery purposes.</param>
        /// <param name="foreignAddressIndicator">(58) This field is conditional. It is required if the city is in a foreign country. It indicates whether the address is in a foreign country and is to be reported to the IRS as a foreign address. The system does not validate the STATE field for a foreign address.</param>
        /// <param name="billingState">(59-60) This field is conditional. It is required if you leave the FOREIGN ADDRESS INDICATOR field (2: 58) blank. It indicates the U.S. Postal Service abbreviation for the postal delivery state or U.S. possession. If you type 1 in the FOREIGN ADDRESS INDICATOR field, the system does not validate this field.</param>
        /// <param name="zipCode">(61-65) This field is optional. It indicates the postal delivery zip code.</param>
        /// <param name="mortgagorInitials">(66-67) This field is optional. It indicates the mortgagor's first and middle initials. Use this field for reporting when the space available cannot accommodate the billing name.</param>
        /// <param name="mortgagorShortName">(68-75) This field is required. It indicates the mortgagor's abbreviated name. Use this field for reporting when the space available cannot accommodate the billing name.</param>
        /// <param name="ahCode">(76) This field is optional. It indicates whether the mortgagor can be solicited for accident and health (A&amp;H) insurance coverage.</param>
        /// <param name="lifeCode">(77) This field is optional. It indicates whether the mortgagor can be solicited for life insurance coverage.</param>
        /// <param name="billMode">(78) This field is optional. It indicates the method used to bill the mortgagor for payments.</param>
        /// <param name="employeeCode">(79) This field is optional. It indicates whether the mortgagor is employed by the servicer.</param>
        /// <param name="floodEarthquakeInsuranceCode">(80) This field is optional. It indicates whether flood and/or earthquake insurance is required for the loan.</param>
        /// <returns>Transaction 010 Card 2</returns>
        public static string Tran010c2(string loanNumber, string addressLine1, string billingCity,
                                       string foreignAddressIndicator, string billingState, string zipCode,
                                       string mortgagorInitials, string mortgagorShortName, string ahCode,
                                       string lifeCode, string billMode, string employeeCode,
                                       string floodEarthquakeInsuranceCode)
        {
            string transaction;

            try
            {
                var transactionName = "010-2";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Address Line 1 (15-37)", addressLine1);
                CheckRequiredField(transactionName, "Billing City (38-57)", billingCity);
                CheckRequiredField(transactionName, "Mortgagor Short Name (68-75)",
                                   mortgagorShortName);

                CheckForeignAddressIndicatorAndState(transactionName, loanNumber, foreignAddressIndicator, billingState);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("2"); // 14: CARD CODE
                tranBuilder.Append(addressLine1.Trim().PadRight(23)); // 15-37: ADDRESS LINE 1
                tranBuilder.Append(billingCity.Trim().PadRight(20)); // 38-57: BILLING CITY
                tranBuilder.Append(foreignAddressIndicator.Trim().PadRight(1)); // 58: FOREIGN ADDRESS INDICATOR
                tranBuilder.Append(billingState.Trim().PadRight(2)); // 59-60: BILLING STATE
                tranBuilder.Append(FormatZipCode(zipCode.Trim())); // 61-65: ZIP CODE
                tranBuilder.Append(mortgagorInitials.Trim().PadRight(2));
                // 66-67: MORTGAGOR ABBREVIATED NAME (INITIALS)
                tranBuilder.Append(mortgagorShortName.Trim().PadRight(8));
                // 68-75: MORTGAGOR ABBREVIATED NAME (SHORT NAME)
                tranBuilder.Append(ahCode.Trim().PadRight(1)); // 76: A&H CODE
                tranBuilder.Append(lifeCode.Trim().PadRight(1)); // 77: LIFE CODE
                tranBuilder.Append(billMode.Trim().PadRight(1)); // 78: BILL MODE
                tranBuilder.Append(employeeCode.Trim().PadRight(1)); //79: BILL MODE
                tranBuilder.Append(floodEarthquakeInsuranceCode.Trim().PadRight(1));
                // 80: FLOOD/EARTHQUAKE INSURANCE CODE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 010 - Card 3 - New Loan Data - Name and Address (D-021).
        /// This transaction is required to enter the billing name and address fields at loan setup. It is also used to set up other master file data, such as abbreviated names, social security numbers, second telephone number, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="coMortgagorName">(15-37) This field is optional. It indicates the full name of the co-mortgagor.</param>
        /// <param name="mortgagorSsn">(38-47) This field is conditional. It is required if you enter the IOE INDICATOR field on transactions EW1, Interest on Escrow - Add (D-021), or EW1, Interest on Escrow - Maintain (D-231), or the INTEREST ON ESCROW INDICATOR field on transaction 510, Expanded Name and Address (D-021). It indicates the mortgagor's social security number (SSN) or federal tax ID number (TIN) assigned by the IRS.</param>
        /// <param name="mortgagorCodeIsSsnOrTin">(48) This field is conditional. This field is required if you enter the MORTGAGOR SSN OR TAX ID field (3: 38-47). This field indicates whether the number typed in the MORTGAGOR SSN OR TAX ID field is an SSN or TIN.</param>
        /// <param name="coMortgagorSsn">(49-58) This field is optional. It indicates the co-mortgagor's social security number (SSN) or federal tax ID number (TIN) assigned by the IRS.</param>
        /// <param name="coMortgagorCodeIsSsnOrTin">(59) This field is conditional. This field is required if you enter the CO-MORTGAGOR SSN OR TAX ID field (3: 49-58). It indicates whether the number typed in the CO-MORTGAGOR SSN OR TAX ID is an SSN or TIN.</param>
        /// <param name="coMortgagorInitials">(66-67) This field is optional. It indicates the co-mortgagor's first and middle initials. Use this field for reporting when the space available cannot accommodate the billing name.</param>
        /// <param name="coMortgagorShortName">(68-75) This field is optional. It indicates the co-mortgagor's abbreviated name. Use this field for reporting when the space available cannot accommodate the billing name.</param>
        /// <returns>Transaction 010 Card 3</returns>
        public static string Tran010c3(string loanNumber, string coMortgagorName, string mortgagorSsn,
                                       string mortgagorCodeIsSsnOrTin, string coMortgagorSsn,
                                       string coMortgagorCodeIsSsnOrTin, string coMortgagorInitials,
                                       string coMortgagorShortName)
        {
            string transaction;

            try
            {
                var transactionName = "010-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(mortgagorSsn) && !IsAvailable(mortgagorCodeIsSsnOrTin))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Mortgagor SSN/TIN indicator (48) cannot be empty if mortgagor SSN/TIN (38-47) is populated.",
                            transactionName, loanNumber));
                }

                if (IsAvailable(coMortgagorSsn) && !IsAvailable(coMortgagorCodeIsSsnOrTin))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Co-mortgagor SSN/TIN indicator (59) cannot be empty if co-mortgagor SSN/TIN (49-58) is populated.",
                            transactionName, loanNumber));
                }
                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;
                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("3"); // 14: CARD CODE
                tranBuilder.Append(coMortgagorName.Trim().PadRight(23)); // 15-37: COMORTGAGOR NAME
                tranBuilder.Append(FormatSsnTin(mortgagorSsn.Trim(), mortgagorCodeIsSsnOrTin.Trim()));
                // 38-47: MORTGAGOR SSN OR TAX ID
                tranBuilder.Append(mortgagorCodeIsSsnOrTin.Trim().PadRight(1)); // 48: MORTGAGOR SSN/TIN CODE
                tranBuilder.Append(FormatSsnTin(coMortgagorSsn.Trim(), coMortgagorCodeIsSsnOrTin.Trim()));
                // 49-58: COMORTGAGOR SSN OR TAX ID
                tranBuilder.Append(coMortgagorCodeIsSsnOrTin.Trim().PadRight(1)); // 59: COMORTGAGOR SSN/TIN CODE
                tranBuilder.Append(' ', 6); // 60-65: RESERVED
                tranBuilder.Append(coMortgagorInitials.Trim().PadRight(2));
                // 66-67: COMORTGAGOR ABBREVIATED NAME (INITIALS)
                tranBuilder.Append(coMortgagorShortName.Trim().PadRight(8));
                // 68-75: COMORTGAGOR ABBREVIATED NAME (SHORT NAME)
                tranBuilder.Append(' ', 5); // 76-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 010 - Card 6 - New Loan Data - Name and Address (D-021).
        /// This transaction is required to enter the billing name and address fields at loan setup. It is also used to set up other master file data, such as abbreviated names, social security numbers, second telephone number, and various codes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan.</param>
        /// <param name="mortgagorFormattedName">(15-44) This field is required. It is the full name of the mortgagor in last, first, middle name format.</param>
        /// <param name="coMortgagorFormattedName">(45-74) This field is optional. It is the full name of the co-mortgagor in last, first, middle name format.</param>
        /// <param name="transferDeedDate">(75-80) This field is optional. It indicates the date of the deed that transferred ownership of the property from a previous assumption.</param>
        /// <returns>Transaction 010 Card 6</returns>
        public static string Tran010c6(string loanNumber, string mortgagorFormattedName, string coMortgagorFormattedName,
                                       string transferDeedDate)
        {
            string transaction;

            try
            {
                var transactionName = "010-6";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "Mortgagor Formatted Name (15-44)",
                                   mortgagorFormattedName);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("6"); // 14: CARD CODE
                tranBuilder.Append(mortgagorFormattedName.Trim().PadRight(30)); // 15-44: MORTGAGOR FORMATTED NAME
                tranBuilder.Append(coMortgagorFormattedName.Trim().PadRight(30)); // 45-74: COMORTGAGOR FORMATTED NAME
                tranBuilder.Append(FormatDate(transferDeedDate.Trim())); // 75-80: TRANSFER DEED DATE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}