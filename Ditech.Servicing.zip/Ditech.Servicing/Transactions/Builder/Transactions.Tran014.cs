#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="primeRateCode">(15-16) This field is optional. It identifies the loan as a prime rate loan. Use it when setting up a prime rate loan. It is only valid for clients using the Prime Rate Loan enhancement.</param>
        /// <param name="billingDays">(17-18) This field is optional. It determines the number of days prior to the due date that a payment is produced. If the bill mode equals 5, this field determines the number of days prior to the due date that the bill is produced.</param>
        /// <param name="propertyType">(19-21) This field is optional. It indicates the type of property securing the loan.</param>
        /// <param name="firstPaymentDueDate">(22-27) This field is optional. It records the due date of the first payment for a loan.</param>
        /// <param name="acquisitionDate">(28-33) This field is optional. It indicates the date of loan acquisition. The year-end subsystem and T-37C use it to exclude the payment activity processed prior to the acquisition reporting. If you enter this field, you must enter an acquisition reporting flag also. Refer to the YEAR-END ACQUISITION REPORTING field.</param>
        /// <param name="exempt1098">(34) This field is optional. It provides flexibility reporting of mortgage interest to mortgagors by annual statements and to the IRS by the IRS 1098 tape.</param>
        /// <param name="fhlbbPropertyType">(35) This field is optional. It indicates the type of property being mortgaged and is used for FHLBB and Freddie Mac MIDANET I reporting.</param>
        /// <param name="loanPurpose">(36) This field is optional. It establishes loan purpose for Fannie Mae, Freddie Mac, and HMDA reporting.</param>
        /// <param name="ownershipType">(37) This field is optional. It establishes the type of ownership for MIDANET I reporting.</param>
        /// <param name="developmentType">(38) This field is optional. It establishes the type of housing development for MIDANET I reporting.</param>
        /// <param name="nonconformingLoanFlag">(39) This field is optional. It indicates whether a loan is a nonconforming loan.</param>
        /// <param name="subsidiaryCode">(40) This field is optional. It indicates whether this loan has been made to a related corporate entity.</param>
        /// <param name="acquisitionPrincipalBalance">(41-51) This field is optional. It indicates the loan principal balance at the time the loan is acquired by the client.</param>
        /// <param name="ssnVerifyCode">(52) This field is optional. It records the number of P-40M reports produced for this loan. This field automatically updates by one each time a request is produced, but you may also manually update it.</param>
        /// <param name="reminderNoticeDays">(53-54) This field is optional. It indicates whether a 10-day delinquency notice (P-197) should be automatically sent to the mortgagor or whether it should be blocked.</param>
        /// <param name="finalNoticeDays">(55-56) This field is optional. It indicates whether a 30-day delinquency notice (P-199) should be automatically sent to the mortgagor or whether it should be blocked.</param>
        /// <param name="ssnVerifyDate">(57-62) This field is optional. It records the date of the latest entry in the SSN verify code. It is automatically updated each time a P-40M request is produced, but you may manually update it.</param>
        /// <param name="ssnCertifyCode">(63) This field is optional. It represents the last response to the verification of the social security or tax ID number (P-40M requests), and you must update it manually. A blank in this field indicates that no response has been recorded.</param>
        /// <param name="ssnCertifyDate">(64-69) This field is optional. It records the date of the latest entry in the SSN certify code. It automatically updates each time the SSN CERTIFY CODE field (1:63) is updated, but you may also update it manually.</param>
        /// <param name="fnmaProjectType">(70) This field is optional. It indicates the Fannie Mae project approval type for condominiums or co-ops and reports on Fannie Mae 2005 submission form (T-67Q) and magnetic tape.</param>
        /// <param name="irsPurposeCode">(71) This field is optional. It is a user-defined code that identifies mortgages incurred after 1987 for a purpose other than the purchase of a personal residence.</param>
        /// <param name="escrowDueFromClosing">(72-79) This field is optional. It records the initial escrow deposit amount collected at closing.</param>
        /// <param name="constructionLoanType">(80) See IP 0845 in the Additional Enhancement Information topic.</param>
        /// <returns>Transaction 014 Card 1</returns>
        public static string Tran014c1(string loanNumber, string primeRateCode = "", string billingDays = "", string propertyType = "",
                                       string firstPaymentDueDate = "", string acquisitionDate = "", string exempt1098 = "",
                                       string fhlbbPropertyType = "", string loanPurpose = "", string ownershipType = "",
                                       string developmentType = "", string nonconformingLoanFlag = "", string subsidiaryCode = "",
                                       string acquisitionPrincipalBalance = "", string ssnVerifyCode = "",
                                       string reminderNoticeDays = "", string finalNoticeDays = "", string ssnVerifyDate = "",
                                       string ssnCertifyCode = "", string ssnCertifyDate = "", string fnmaProjectType = "",
                                       string irsPurposeCode = "", string escrowDueFromClosing = "", string constructionLoanType = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(primeRateCode.Trim().PadRight(2)); // 15-16: PRIME RATE CODE
                tranBuilder.Append(billingDays.Trim().PadRight(2)); // 17-18: BILLING DAYS
                tranBuilder.Append(propertyType.Trim().PadRight(3)); // 19-21: PROPERTY TYPE
                tranBuilder.Append(FormatDate(firstPaymentDueDate.Trim())); // 22-27: FIRST PAYMENT DUE DATE
                tranBuilder.Append(FormatDate(acquisitionDate.Trim())); // 28-33: AQUISITION DATE
                tranBuilder.Append(exempt1098.Trim().PadRight(1)); // 34: 1098 EXEMPT
                tranBuilder.Append(fhlbbPropertyType.Trim().PadRight(1)); // 35: PROPERTY TYPE
                tranBuilder.Append(loanPurpose.Trim().PadRight(1)); // 36: LOAN PURPOSE
                tranBuilder.Append(ownershipType.Trim().PadRight(1)); // 37: OWNERSHIP TYPE
                tranBuilder.Append(developmentType.Trim().PadRight(1)); // 38: DEVELOPMENT TYPE
                tranBuilder.Append(nonconformingLoanFlag.Trim().PadRight(1)); // 39: NONCONFORMING LOAN FLAG
                tranBuilder.Append(subsidiaryCode.Trim().PadRight(1)); // 40: SUBSIDIARY CODE
                tranBuilder.Append(FormatMoney(acquisitionPrincipalBalance.Trim(), true, false, 11));
                // 41-51: ACQUISITION PRINCIPAL BALANCE
                tranBuilder.Append(ssnVerifyCode.Trim().PadRight(1)); // 52: SSN VERIFY CODE
                tranBuilder.Append(reminderNoticeDays.Trim().PadLeft(2)); // 53-54: REMINDER NOTICE DAYS
                tranBuilder.Append(finalNoticeDays.Trim().PadLeft(2)); // 55-56: FINAL NOTICE DAYS
                tranBuilder.Append(FormatDate(ssnVerifyDate.Trim())); // 57-62: SSN VERIFY DATE
                tranBuilder.Append(ssnCertifyCode.Trim().PadRight(1)); // 63: SSN CERTIFY CODE
                tranBuilder.Append(FormatDate(ssnCertifyDate.Trim())); // 64-69: SSN CERTIFY DATE
                tranBuilder.Append(fnmaProjectType.Trim().PadRight(1)); // 70: FNMA PROJECT TYPE
                tranBuilder.Append(irsPurposeCode.Trim().PadRight(1)); // 71: IRS PURPOSE CODE
                tranBuilder.Append(FormatMoney(escrowDueFromClosing.Trim(), false, false, 8));
                // 72-79: ESCROW DUE FROM CLOSING
                tranBuilder.Append(constructionLoanType.Trim().PadRight(1)); // 80: CONSTRUCTION LOAN TYPE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="oldLoanNumber">(15-29) This field is optional. It retains the loan number used by the previous servicer for loans purchased through acquisition. This allows indexing by the old loan number in CICS for two years from the acquisition date. You must enter the acquisition date to add this field to the CICS old loan number index file. This field cannot contain the literal CPI if an OLD SERVICER NUMBER is present on the account.</param>
        /// <param name="acquisitionID">(30-39) This field is optional. It retains an identifier of the acquisition or loan sale through which the loan was purchased.</param>
        /// <param name="yearEndAcquisitionReporting">(40) This field is optional. Use this field in reporting 1098 interest to the IRS. It indicates if the year-to-date totals reflect the entire year's payment history or just the history since the acquisition date. This field must contain a value if the ACQUISITION DATE field (1:28-33) contains a value.</param>
        /// <param name="fnmaSpecialFeature1">(46-48) This field is optional. Special feature codes are assigned to specific loans or commitments by Fannie Mae. A common loan special feature is 34, which should be entered if a loan was originated under Fannie Mae's TimeSaver Plus documentation program. (See Fannie Mae announcement 88-15.) </param>
        /// <param name="fnmaSpecialFeature2">(49-51) This field is optional. Special feature codes are assigned to specific loans or commitments by Fannie Mae. A common loan special feature is 34, which should be entered if a loan was originated under Fannie Mae's TimeSaver Plus documentation program. (See Fannie Mae announcement 88-15.) </param>
        /// <param name="fnmaSpecialFeature3">(52-54) This field is optional. Special feature codes are assigned to specific loans or commitments by Fannie Mae. A common loan special feature is 34, which should be entered if a loan was originated under Fannie Mae's TimeSaver Plus documentation program. (See Fannie Mae announcement 88-15.) </param>
        /// <param name="fnmaSpecialFeature4">(55-57) This field is optional. Special feature codes are assigned to specific loans or commitments by Fannie Mae. A common loan special feature is 34, which should be entered if a loan was originated under Fannie Mae's TimeSaver Plus documentation program. (See Fannie Mae announcement 88-15.) </param>
        /// <param name="fnmaLtvQualifier">(58) This field is optional. It identifies special loan characteristics for delivery to Fannie Mae. The code on the loan is used to determine the maximum LTV established by Fannie Mae. The value is user-defined, but it must correspond to the Fannie Mae LTV qualifier header (transaction 02V [D-225]). For example, Fannie Mae has established a maximum LTV ratio for a loan made to a non-permanent resident alien. By creating a header and entering the corresponding qualifier on the loan master, you can perform LTV validation for virtually any special LTV restriction during delivery to Fannie Mae by 1068/1069, 2005, or 2025 schedules.</param>
        /// <param name="armPlanCode">(59-61) This field is optional. This user-defined field identifies the investor's ARM program under which the loan was originated.</param>
        /// <param name="overrideControlHeader">(62-73) This field is optional. It directs the escrow analysis to a special control header when overage, shortage, or cushion calculations for this loan are different from other loans having the same lo-type, state, county, and city combination.</param>
        /// <param name="controlHeaderExpiresDate">(74-79) This field is optional. It limits the use of the override control header. After this date, the location header determines which control header is used.</param>
        /// <returns>Transaction 014 Card 2</returns>
        public static string Tran014c2(string loanNumber, string oldLoanNumber = "", string acquisitionID = "",
                                       string yearEndAcquisitionReporting = "", string fnmaSpecialFeature1 = "",
                                       string fnmaSpecialFeature2 = "", string fnmaSpecialFeature3 = "",
                                       string fnmaSpecialFeature4 = "", string fnmaLtvQualifier = "", string armPlanCode = "",
                                       string overrideControlHeader = "", string controlHeaderExpiresDate = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-2";

                CheckValidLoanNumber(transactionName, loanNumber);

                // Cannot enter FNMA Special Feature unless previous feature is filled.
                if ((!IsAvailable(fnmaSpecialFeature1.Trim()) &&
                     (IsAvailable(fnmaSpecialFeature2.Trim()) ||
                      IsAvailable(fnmaSpecialFeature3.Trim()) ||
                      IsAvailable(fnmaSpecialFeature4.Trim())))
                    ||
                    (!IsAvailable(fnmaSpecialFeature2.Trim()) &&
                     (IsAvailable(fnmaSpecialFeature3.Trim()) ||
                      IsAvailable(fnmaSpecialFeature4.Trim())))
                    ||
                    (!IsAvailable(fnmaSpecialFeature3.Trim()) &&
                     IsAvailable(fnmaSpecialFeature4.Trim())))
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Cannot enter FNMA Special Feature unless previous feature is filled.",
                                      transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("2"); // 14: CARD CODE
                tranBuilder.Append(oldLoanNumber.Trim().PadRight(15)); // 15-29: OLD LOAN NUMBER
                tranBuilder.Append(acquisitionID.Trim().PadRight(10)); // 30-39: ACQUISITION / SALE ID
                tranBuilder.Append(yearEndAcquisitionReporting.Trim().PadRight(1));
                // 40: YEAR-END ACQUISITION REPORTING
                tranBuilder.Append(' ', 5); // 41-45: RESERVED
                tranBuilder.Append(LeftZeroFillOptionalField(fnmaSpecialFeature1.Trim(), 3));
                // 46-48: FNMA SPECIAL FEATURES 1
                tranBuilder.Append(LeftZeroFillOptionalField(fnmaSpecialFeature2.Trim(), 3));
                // 49-51: FNMA SPECIAL FEATURES 2
                tranBuilder.Append(LeftZeroFillOptionalField(fnmaSpecialFeature3.Trim(), 3));
                // 52-54: FNMA SPECIAL FEATURES 3
                tranBuilder.Append(LeftZeroFillOptionalField(fnmaSpecialFeature4.Trim(), 3));
                // 55-57: FNMA SPECIAL FEATURES 4
                tranBuilder.Append(fnmaLtvQualifier.Trim().PadRight(1)); // 58: FNMA LTV QUALIFIER
                tranBuilder.Append(armPlanCode.Trim().PadRight(3)); // 59-61: ARM PLAN CODE
                tranBuilder.Append(overrideControlHeader.Trim().PadRight(12)); // 62-73: OVERRIDE CONTROL HEADER
                tranBuilder.Append(FormatDate(controlHeaderExpiresDate.Trim())); // 74-79: CONTROL HEADER EXPIRES DATE
                tranBuilder.Append(' ', 1); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="userBillingTable">(15-34) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic..</param>
        /// <param name="stopBillingFlag">(35) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic.</param>
        /// <param name="billingCycle">(36-38) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic.</param>
        /// <param name="fnmaPlanNumber">(39-43) This field is optional. It identifies the number Fannie Mae has assigned to the program plan under which the loan was originated.</param>
        /// <param name="fhlmcReducedDocumentCode">(44) This field is optional. It enables lenders to track those loans originated under a Freddie Mac reduced document loan program.</param>
        /// <param name="recourseFlag">(45) This field is optional. It identifies loans sold or purchased with recourse.</param>
        /// <param name="recourseDate">(46-49) This field is optional. It contains the date at which the recourse provision expires.</param>
        /// <param name="adpCode">(57-59) This field is optional. The information entered in this field is reported on HUD 92068-A SFDMS reports in the ADP code field. If ADP is not present on the master file, the FHA section number prints. HUD SFDMS reports are the only HUD reports that use this field. Other HUD reports use the section number. Refer to the most recent HUD-428 publication for a complete list of ADP code assignments.</param>
        /// <param name="payoffEffectiveDate">(60-65) This field is optional. It indicates the date through which the system calculates the payoff interest for a loan.</param>
        /// <param name="oldLoanNumberStopDate">(66-71) This field is optional. It indicates the date when the old loan number will no longer exist in the old loan number index.</param>
        /// <param name="classCode">(72-73) This field is optional. Use this field to classify loans for delinquency processing.</param>
        /// <param name="collectorDays">(74-76) This field is optional. It indicates how many days past the due date before the system selects the loan for delinquency processing.</param>
        /// <param name="reasonableCauseCode">(78) This field is optional. It is a user-defined code that indicates your company's response to the IRS B notice received on this loan. Define the codes on the RCH1 screen in the Info Tracking Workstation.</param>
        /// <param name="suppressPrintYearEndStatement">(79) This field is optional. It indicates whether I-723 prints the statement generated in year-end. If this field is set to a user-defined value, I-723 does not print the statement and does not send the statement record to the MICR data tape (vendor tape). All other processing of the statement records occurs normally. Define the codes entered in this field on the SPIR screen in the MSP Info Tracking Workstation.</param>
        /// <param name="produceDetailHistory">(80) This field is optional. It is a code that indicates whether a detail history is desired for a given loan out of year-end processing.</param>
        /// <returns>Transaction 014 Card 3</returns>
        public static string Tran014c3(string loanNumber, string userBillingTable = "", string stopBillingFlag = "",
                                       string billingCycle = "", string fnmaPlanNumber = "", string fhlmcReducedDocumentCode = "",
                                       string recourseFlag = "", string recourseDate = "", string adpCode = "",
                                       string payoffEffectiveDate = "", string oldLoanNumberStopDate = "", string classCode = "",
                                       string collectorDays = "", string reasonableCauseCode = "",
                                       string suppressPrintYearEndStatement = "", string produceDetailHistory = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("3"); // 14: CARD CODE
                tranBuilder.Append(userBillingTable.Trim().PadRight(20)); // 15-34: USER BILLING TABLE
                tranBuilder.Append(stopBillingFlag.Trim().PadRight(1)); // 35: STOP BILLING FLAG
                tranBuilder.Append(LeftZeroFillOptionalField(billingCycle.Trim(), 3)); // 36-38: BILLING CYCLE
                tranBuilder.Append(LeftZeroFillOptionalField(fnmaPlanNumber.Trim(), 5));
                // 39-43: FNMA PLAN NUMBER
                tranBuilder.Append(fhlmcReducedDocumentCode.Trim().PadRight(1)); // 44: FHLMC REDUCED DOCUMENT CODE
                tranBuilder.Append(recourseFlag.Trim().PadRight(1)); // 45: RECOURSE FLAG
                //tranBuilder.Append(FormatDate(recourseDate, "MMYY")); // 46-49: RECOURSE DATE
                tranBuilder.Append(
                    string.Format("{0}{1}", FormatDate(recourseDate.Trim()).Substring(0, 2),
                                  FormatDate(recourseDate.Trim()).Substring(4))); // 46-49: RECOURSE DATE
                tranBuilder.Append(' ', 7); // 50-56: RESERVED
                tranBuilder.Append(adpCode.Trim().PadRight(3)); // 57-59: ADP CODE
                tranBuilder.Append(FormatDate(payoffEffectiveDate.Trim())); // 60-65: PAYOFF EFFECTIVE DATE
                tranBuilder.Append(FormatDate(oldLoanNumberStopDate.Trim())); // 66-71: OLD LOAN NUMBER STOP DATE
                tranBuilder.Append(classCode.Trim().PadRight(2)); // 72-73: CLASS CODE
                tranBuilder.Append(LeftZeroFillOptionalField(collectorDays.Trim(), 3)); // 74-76: COLLECTOR DAYS
                tranBuilder.Append(' ', 1); // 77: RESERVED
                tranBuilder.Append(reasonableCauseCode.Trim().PadRight(1)); // 78: REASONABLE CAUSE CODE
                tranBuilder.Append(suppressPrintYearEndStatement.Trim().PadRight(1));
                // 79: SUPPRESS PRINT/MICR YE STMT INDICATOR
                tranBuilder.Append(produceDetailHistory.Trim().PadRight(1)); // 80: 1098 DETAIL HISTORY TAPE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="escrowActivityStatementDate">(15-21) This field is optional. It indicates the last time the activity statement was produced (MSP input only).  Entry: Type the date in YYDDMM format in positions 15-20; this is the reverse of the other date formats. Type the MSP-assigned password in position 21, left zero-filled.</param>
        /// <param name="couponTapeDate">(22-27) See IP 0778/0947/1395/1639 in the Additional Enhancement Information topic.</param>
        /// <param name="autoNewOrderProcessingCode">(28-30) This field is used for audit purposes only. See the NORM CODE field on transactions 119 (D-021) and 119 (D-218).</param>
        /// <param name="interestOnlyEndDate">(31-36) This field is optional.  It indicates the date on which the payment of interest-only ends so that the mortgage begins to amortize with the first payment due after this date.</param>
        /// <param name="mortgageInsuranceAdjustorFlag">(37) This field is optional. It indicates that additional protection under the mortgage insurance coverage is required due to negative amortization.</param>
        /// <param name="freddieMacLoanLevelSelectionFlag">(38) This field is optional. It indicates the loan-level flag that allows the selection of individual loans for reporting on the Servicing Transfer Report Form 981A.</param>
        /// <param name="additionalTaxParcelsFlag">(39) This field is optional. It updates the loan-level flag that indicates whether additional tax parcels are present.</param>
        /// <param name="vaLoanIdentificationNumber">(40-52) This field is optional. It includes a 12-digit, standardized number used for loan-level reporting to the Veteran's Administration.</param>
        /// <param name="escrowDocumentType">(56-57) This field is optional. It defines the document type used for escrow analysis calculations.</param>
        /// <param name="initialStatementCode">(58) This field is conditional. It identifies loans requiring an initial escrow statement or escrow history or projection.  If you enter a value in the INITIAL ESCROW STATEMENT DATE field, you must also enter this field.</param>
        /// <param name="initialEscrowStatementDate">(59-64) This field is conditional. It identifies when the initial statement is scheduled to be produced for a loan. If the INITIAL STATEMENT CODE is 9, this date indicates the date the statement was created. If you enter a value in the INITIAL STATEMENT CODE, you must also enter this field.</param>
        /// <param name="documentMinimumBal">(65-69) This field is optional. This field represents the number of escrow payments to be held in the account for a loan to reach its low point.</param>
        /// <param name="escrowComputationDate">(70-73) This field is optional. It indicates the month and year in which the next escrow computation year is scheduled to begin.</param>
        /// <param name="password">(74) This optional field is MSP-assigned.</param>
        /// <param name="sellId">(75) See IP 1432 in the Additional Enhancement Information topic.</param>
        /// <param name="quarterlyBilling">(76) See IP 1428 in the Additional Enhancement Information topic.</param>
        /// <returns>Transaction 014 Card 5</returns>
        public static string Tran014c5(string loanNumber, string escrowActivityStatementDate = "", string couponTapeDate = "",
                                       string autoNewOrderProcessingCode = "", string interestOnlyEndDate = "",
                                       string mortgageInsuranceAdjustorFlag = "", string freddieMacLoanLevelSelectionFlag = "",
                                       string additionalTaxParcelsFlag = "", string vaLoanIdentificationNumber = "",
                                       string escrowDocumentType = "", string initialStatementCode = "",
                                       string initialEscrowStatementDate = "", string documentMinimumBal = "",
                                       string escrowComputationDate = "", string password = "", string sellId = "",
                                       string quarterlyBilling = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-5";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(escrowActivityStatementDate))
                {
                    escrowActivityStatementDate =
                        DateTime.Parse(escrowActivityStatementDate.Substring(0, 6)).ToString("YYDDMM") +
                        escrowActivityStatementDate.Substring(6, 1);
                }

                // Check conditional statements
                if (!IsAvailable(initialStatementCode) &&
                    IsAvailable(initialEscrowStatementDate))
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Initial Statement Code is required when using Initial Escrow Statement Date",
                            transactionName, loanNumber));

                if (IsAvailable(initialStatementCode) &&
                    !IsAvailable(initialEscrowStatementDate))
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Initial Escrow Statement Date is required when using Initial Statement Code",
                            transactionName, loanNumber));

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("5"); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(escrowActivityStatementDate.Trim(), 7));
                // 15-21: ESCROW ACTIVITY STATEMENT DATE
                tranBuilder.Append(FormatDate(couponTapeDate.Trim())); // 22-27: COUPON TAPE DATE
                tranBuilder.Append(autoNewOrderProcessingCode.Trim().PadRight(3));
                // 28-30: AUTO-NEW-ORDER-PROCESSING-CODE
                tranBuilder.Append(FormatDate(interestOnlyEndDate.Trim())); // 31-36: INTEREST ONLY END DATE
                tranBuilder.Append(mortgageInsuranceAdjustorFlag.Trim().PadRight(1));
                // 37: MORTGAGE INSURANCE ADJUSTOR FLAG
                tranBuilder.Append(freddieMacLoanLevelSelectionFlag.Trim().PadRight(1));
                // 38: FREDDIE MAC LOAN LEVEL SELECTION FLAG
                tranBuilder.Append(additionalTaxParcelsFlag.Trim().PadRight(1)); // 39: ADDITIONAL TAX PARCELS FLAG
                tranBuilder.Append(LeftZeroFillOptionalField(vaLoanIdentificationNumber.Trim(), 13));
                // 40-52: VA LOAN IDENTIFICATION NUMBER
                tranBuilder.Append(' ', 3); // 53-55: RESERVED
                tranBuilder.Append(escrowDocumentType.Trim().PadRight(2)); // 56-57: ESCROW DOCUMENT TYPE
                tranBuilder.Append(initialStatementCode.Trim().PadRight(1)); // 58: INITIAL STATEMENT CODE
                tranBuilder.Append(FormatDate(initialEscrowStatementDate.Trim()));
                // 59-64 INITIAL ESCROW STATEMENT DATE
                tranBuilder.Append(LeftZeroFillOptionalField(documentMinimumBal.Trim(), 5));
                // 65-69: DOCUMENT MINIMUM BAL
                tranBuilder.Append(LeftZeroFillOptionalField(escrowComputationDate.Trim(), 4));
                // 70-73: ESCROW COMPUTATION DATE
                tranBuilder.Append(password.Trim().PadRight(1)); // 74: PASSWORD
                tranBuilder.Append(sellId.Trim().PadRight(1)); // 75: SELL ID
                tranBuilder.Append(quarterlyBilling.Trim().PadRight(1)); // 76: QUARTERLY BILLING
                tranBuilder.Append(' ', 4); // 77-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="currentAppraisalDate">(19-24) This field is optional. It indicates the date that the property for this loan was appraised.</param>
        /// <param name="currentLandAppraisal">(36-46) This field is optional. It indicates the current appraisal value of the land.</param>
        /// <param name="originalLandOnlyAppraisal">(47-57) This field is optional. It indicates the original appraisal value of the land.</param>
        /// <returns>Transaction 014 Card 6</returns>
        public static string Tran014c6(string loanNumber, string currentAppraisalDate = "", string currentLandAppraisal = "",
                                       string originalLandOnlyAppraisal = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-6";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("6"); // 14: CARD CODE
                tranBuilder.Append(' ', 4); // 15-18: RESERVED
                tranBuilder.Append(FormatDate(currentAppraisalDate.Trim()));
                // 19-24: CURRENT APPRAISAL DATE
                tranBuilder.Append(' ', 1); // 25: RESERVED
                tranBuilder.Append(' ', 9); // 26-34: CURRENT PROPERTY VALUE (NO LONGER USED)
                tranBuilder.Append(' ', 1); // 35: RESERVED
                tranBuilder.Append(FormatMoney(currentLandAppraisal.Trim(), false, false, 11));
                // 36-46: CURRENT LAND APPRAISAL
                tranBuilder.Append(FormatMoney(originalLandOnlyAppraisal.Trim(), false, false, 11));
                // 47-57: ORIGINAL LAND ONLY APPRAISAL
                tranBuilder.Append(' ', 23); // 58-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="originalHouseholdExpense">(36-42) This field is optional. It indicates the amount of household expenses used in the approval of the loan application.</param>
        /// <param name="originalOccupancyStatus">(43) This field is optional. It indicates the intended use of the property at the time the loan was originated.</param>
        /// <param name="curtailmentInterestFlag">(45) See IP 1332 in the Additional Enhancement Information topic.</param>
        /// <param name="balance">(46-56) See IP 1332 in the Additional Enhancement Information topic.</param>
        /// <param name="custodianCode">(57) This field is conditional. It aids clients in identifying the physical location of a loan package or documents.  If you report to the Federal Home Loan Banks in New York and Chicago, you are required to use this field.</param>
        /// <param name="creditDecisionByLender">(58) This field is optional. It indicates whether or not the credit decision on the loan was made by the lender when a loan was acquired by a third party. The HMDA subsystem uses it to determine HMDA Action Taken type for wholesale loans.</param>
        /// <param name="originalPropertyValue">(70-78) This field is optional. It indicates the appraised dollar value of the property when the loan was originated.</param>
        /// <param name="originalSelfEmployed">(79) This field is optional. It indicates whether the borrower was self-employed when the loan was originated.</param>
        /// <returns>Transaction 014 Card 7</returns>
        public static string Tran014c7(string loanNumber, string originalHouseholdExpense = "",
                                       string originalOccupancyStatus = "", string curtailmentInterestFlag = "", string balance = "",
                                       string custodianCode = "", string creditDecisionByLender = "", string originalPropertyValue = "",
                                       string originalSelfEmployed = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-7";

                CheckValidLoanNumber(transactionName, loanNumber);
                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("7"); // 14: CARD CODE
                tranBuilder.Append(' ', 8); // 15-22: RESERVED
                tranBuilder.Append(' ', 1); // 23: LOSS MITIGATION INDICATOR (not entered on Tran014)
                tranBuilder.Append(' ', 2); // 24-25: INVESTOR DELINQUENCY STATUS (not entered on Tran014)
                tranBuilder.Append(' ', 3); // 26-28: INVESTOR DELINQUENCY REASON (not entered on Tran014)
                tranBuilder.Append(' ', 1); // 29: RESERVED
                tranBuilder.Append(' ', 6); // 30-35: INVESTOR DELINQUENCY REPORT DATE (system-generated)
                tranBuilder.Append(FormatMoney(originalHouseholdExpense.Trim(), false, false, 7));
                // 36-42: ORIGINAL HOUSEHOLD EXPENSE
                tranBuilder.Append(originalOccupancyStatus.Trim().PadRight(1)); // 43: ORIGINAL OCCUPANCY STATUS
                tranBuilder.Append(' ', 1); // 44: RESERVED
                tranBuilder.Append(curtailmentInterestFlag.Trim().PadRight(1)); // 45: CURTAILMENT INTEREST FLAG
                tranBuilder.Append(FormatMoney(balance.Trim(), true, false, 11)); // 46-56: BALANCE
                tranBuilder.Append(custodianCode.Trim().PadRight(1)); // 57: CUSTODIAN CODE
                tranBuilder.Append(creditDecisionByLender.Trim().PadRight(1)); // 58: CREDIT DECISION BY LENDER
                tranBuilder.Append(' ', 11); // 59-69: RESERVED
                tranBuilder.Append(FormatMoney(originalPropertyValue.Trim(), false, false, 9));
                // 70-78: ORIGINAL PROPERTY VALUE
                tranBuilder.Append(originalSelfEmployed.Trim().PadRight(1)); // 79: ORIGINAL SELF-EMPLOYED
                tranBuilder.Append(' ', 1); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="interestOnlyFlag">(61) This field is optional. It indicates whether the loan is an interest-only ARM loan.</param>
        /// <param name="expire">(62-67) This field is optional. It indicates the payment date that the loan will have a fully amortized PI due and will no longer be an interest-only payment.</param>
        /// <param name="rhsLoanNumber">(68-69) This field indicates the loan number used to identify RHS loans (formerly known as Farmers Home loans).</param>
        /// <param name="pmtOptionInd">(80) This field is optional. It indicates the loan has optional payment amounts calculated for billing.</param>
        /// <returns>Transaction 014 Card 8</returns>
        public static string Tran014c8(string loanNumber, string interestOnlyFlag = "", string expire = "", string rhsLoanNumber = "",
                                       string pmtOptionInd = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-8";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("8"); // 14: CARD CODE
                tranBuilder.Append(' ', 46); // 15-60: RESERVED
                tranBuilder.Append(interestOnlyFlag.Trim().PadRight(1)); // 61: INTEREST ONLY FLAG
                tranBuilder.Append(FormatDate(expire.Trim())); // 62-67: EXPIRE
                tranBuilder.Append(LeftZeroFillOptionalField(rhsLoanNumber.Trim(), 2)); // 68-69: RHS LOAN NUMBER
                tranBuilder.Append(' ', 10); // 70-79: RESERVED
                tranBuilder.Append(pmtOptionInd.Trim().PadRight(1)); // 80: PMT OPTION IND
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="creditQualityOriginal">(15-19) This field is optional. It indicates the mortgagor's credit quality, score, or rating at the time of origination.</param>
        /// <param name="creditQualityEntryDate">(25-30) This field is optional. It indicates the date on which the current credit quality, score, or rating determination was made.</param>
        /// <param name="creditQualityAgent">(31-34) This field is optional. It indicates the name of the credit agency or credit bureau that provided the credit quality, score, or rating.</param>
        /// <param name="creditQualityReasonCode">(35-36) This field is optional. It indicates the reason for the credit quality, score, or rating.</param>
        /// <param name="ausSystem">(37-38) This field is conditional. It is required if you enter a value in the AUS IDENTIFICATION KEY field. This field is a user-defined code that identifies which automated underwriting system was used to deliver the loans to underwriting.</param>
        /// <param name="ausIdentificationKey">(39-53) This field is optional. This user-defined code identifies loans submitted through an automated underwriting system for approval.</param>
        /// <param name="subprimeFlag">(73) This field is optional. It indicates whether the loan was considered a subprime loan at the time of origination.</param>
        /// <param name="riskGradeCurrent">(74) This field is optional. It indicates the current score assigned to the loan based upon the credit score and scoring model used.</param>
        /// <param name="vaLoanGuarantyPercent">(75-80) This field is optional. It indicates the percentage of the loan amount that the VA will reimburse the lender if the loan is a VA no-bid.</param>
        /// <returns>Transaction 014, Card A</returns>
        public static string Tran014cA(string loanNumber, string creditQualityOriginal = "", string creditQualityEntryDate = "",
                                       string creditQualityAgent = "", string creditQualityReasonCode = "", string ausSystem = "",
                                       string ausIdentificationKey = "", string subprimeFlag = "", string riskGradeCurrent = "",
                                       string vaLoanGuarantyPercent = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-A";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("A"); // 14: CARD CODE
                tranBuilder.Append(creditQualityOriginal.Trim().PadRight(5)); // 15-19: CREDIT QUALITY: ORIGINAL
                tranBuilder.Append(' ', 5); // 20-24: RESERVED
                tranBuilder.Append(FormatDate(creditQualityEntryDate.Trim())); // 25-30: CREDIT QUALITY: ENTRY DATE
                tranBuilder.Append(creditQualityAgent.Trim().PadRight(4)); // 31-34: CREDIT QUALITY: AGENT
                tranBuilder.Append(creditQualityReasonCode.Trim().PadRight(2)); // 35-36: CREDIT QUALITY: REASON CODE
                tranBuilder.Append(ausSystem.Trim().PadRight(2)); // 37-38: AUS SYSTEM
                tranBuilder.Append(ausIdentificationKey.Trim().PadRight(15)); // 39-53: AUS IDENTIFICATION KEY
                tranBuilder.Append(' ', 19); // 54-72: RESERVED
                tranBuilder.Append(subprimeFlag.Trim().PadRight(1)); // 73: SUBPRIME FLAG
                tranBuilder.Append(riskGradeCurrent.Trim().PadRight(1)); // 74: RISK GRADE CURRENT
                tranBuilder.Append(FormatPercent(vaLoanGuarantyPercent.Trim(), 6)); // 75-80: VA LOAN GUARANTY PERCENT
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }


        /// <summary>
        /// Creates Transaction 014 - Miscellaneous Master Data - Add (D-021).
        /// Use transaction 014 to enter various master file fields and other loan-level fields linked to the loan master. Make corrections to this data using transaction 084 (D-148).
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="mersMortgageIdentificationNumber">(15-32) This field is conditional. It depends on the value in the MERS MORTGAGE IDENTIFICATION NUMBER REGISTRATION FLAG field in the 014 transaction and on the AUTO GENERATE MORTGAGE IDENTIFICATION NUMBER field in the client header. This field indicates the mortgage identification number assigned to a loan which distinguishes it to the Mortgage Electronic Registration System (MERS).</param>
        /// <param name="mersMortgageIdNumberRegistrationDate">(33-38) This field is conditional. It is required if the MERS MORTGAGE IDENTIFICATION NUMBER REGISTRATION FLAG (B: 39) is D, U, or Y. This field indicates either the date of the MSP transaction that generated the EDI X12 transaction transmitted to the Mortgage Electronic Registration System (MERS) to register the loan or the user-entered date the loan was registered with MERS. Do not enter this field if the MERS MORTGAGE ID NUMBER REGISTRATION FLAG is R.</param>
        /// <param name="mersMortgageIdNumberRegistrationFlag">(39) This field is optional. It indicates the MERS registration status of the loan.</param>
        /// <param name="mersForeclosureStatus">(40-41) This field is optional. It indicates the foreclosure status of the loan as it relates to MERS.</param>
        /// <param name="contractLoanServicingSoldDate">(42-47) This field is optional. It indicates the date the loan servicing rights were sold, as opposed to the date the loan was service released, and it is used in conjunction with the LOAN SERVICING SOLD DATE field in the master.</param>
        /// <param name="mersOriginalMortgageeIndicator">(48) This field is optional. It indicates whether MERS is the original mortgagee of the loan.</param>
        /// <param name="documentCustodian">(49-58) This field is optional. It indicates the document custodian's payee number.</param>
        /// <returns>Transaction 014 Card B</returns>
        public static string Tran014cB(string loanNumber, string mersMortgageIdentificationNumber = "",
                                       string mersMortgageIdNumberRegistrationDate = "",
                                       string mersMortgageIdNumberRegistrationFlag = "", string mersForeclosureStatus = "",
                                       string contractLoanServicingSoldDate = "", string mersOriginalMortgageeIndicator = "",
                                       string documentCustodian = "")
        {
            string transaction;

            try
            {
                var transactionName = "014-B";

                CheckValidLoanNumber(transactionName, loanNumber);

                if ((mersMortgageIdNumberRegistrationFlag == "D" || mersMortgageIdNumberRegistrationFlag == "U" ||
                     mersMortgageIdNumberRegistrationFlag == "Y") &&
                    !IsAvailable(mersMortgageIdNumberRegistrationDate))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: MERS registration date cannot be blank if registration flag is D, U, or Y.",
                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("B"); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(mersMortgageIdentificationNumber.Trim(), 18));
                // 15-32: MERS MORTGAGE IDENTIFICATION NUMBER
                tranBuilder.Append(FormatDate(mersMortgageIdNumberRegistrationDate.Trim()));
                // 33-38: MERS MORTGAGE ID NUMBER REGISTRATION DATE
                tranBuilder.Append(mersMortgageIdNumberRegistrationFlag.Trim().PadRight(1));
                // 39: MERS MORTGAGE ID NUMBER REGISTRATION FLAG
                tranBuilder.Append(mersForeclosureStatus.Trim().PadRight(2)); // 40-41: MERS FORECLOSURE STATUS
                tranBuilder.Append(FormatDate(contractLoanServicingSoldDate.Trim()));
                // 42-47: CONTRACT LOAN SERVICING SOLD DATE
                tranBuilder.Append(mersOriginalMortgageeIndicator.Trim().PadRight(1));
                // 48: MERS ORIGINAL MORTGAGEEE INDICATOR
                tranBuilder.Append(LeftZeroFillOptionalField(documentCustodian.Trim(), 10));
                // 49-58: DOCUMENT CUSTODIAN
                tranBuilder.Append(' ', 22); // 59-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}