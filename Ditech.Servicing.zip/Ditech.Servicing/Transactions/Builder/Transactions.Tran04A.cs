#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 04A - Points Paid by Borrower (D-021)
        /// Use transaction 04A to enter the points paid by the borrower at loan closing.
        /// </summary>
        /// <param name="loanNumber">This field is required. It identifies the loan number.</param>
        /// <param name="pointsPaidByBorrower">(15-25) This field is optional. It records the dollar amount of points paid by the borrower at the time of loan closing.</param>
        /// <param name="reportedYear">(26-27) This field is optional. If the RPTD YR in the loan master equals spaces and POINTS PAID BY BORROWER is greater than zero, reports T-37C and I-723 report points on the annual statements they produce. I-7RS (at year end) then sets the RPTD YR field in the loan master to the current tax year if points are reported. This prevents either T-37C or I-723 from reporting points in subsequent tax years.</param>
        /// <param name="AdjustmentIndicator1098">(28) This field is conditional. It indicates whether the system automatically creates an adjustment to your 1098 form, or creates an "updated only" adjustment. If you select to only update an adjustment, the system overrides the automatic 1098 update option set on the YEH3 header screen in the Year-end Workstation. This allows you to perform maintenance on a loan for more than one day and send the 1098 statement to a print spool or data tape when you complete all maintenance for a loan number.</param>
        /// <param name="discPtsFlag">(29) This field is conditional. It indicates whether any discount points paid by the borrower were paid or financed.</param>
        /// <param name="ppbbFlg">(30) This field is required if an amount appears in the POINTS PD BY BORROWER field. It indicates whether any points paid by the borrower were paid or financed.</param>
        /// <returns>Transaction 04A Card 1</returns>
        public static string Tran04Ac1(string loanNumber, string pointsPaidByBorrower, string reportedYear,
                                       string AdjustmentIndicator1098, string discPtsFlag, string ppbbFlg)
        {
            string transaction;

            try
            {
                var transactionName = "04A-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranBuilder = new StringBuilder();

                decimal pointsPaid = 0;

                // Get the points paid by borrower in decimal format to check for zero or blank
                decimal.TryParse(pointsPaidByBorrower, out pointsPaid);

                if (pointsPaid > 0 && !IsAvailable(ppbbFlg))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: PPBB FLG is required when points paid by borrower is not blank or zero",
                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                tranBuilder.Append(tranClient); // 1-6
                tranBuilder.Append("*".PadRight(7)); // 7-13
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(FormatMoney(pointsPaidByBorrower.Trim(), true, false, 11));
                // 15-25: POINTS PAID BY BORROWER
                tranBuilder.Append(LeftZeroFillOptionalField(reportedYear.Trim(), 2)); // 26-27: REPORTED YEAR
                tranBuilder.Append(AdjustmentIndicator1098.Trim().PadRight(1)); // 28: 1098 ADJUSTMENT INDICATOR
                tranBuilder.Append(discPtsFlag.Trim().PadRight(1)); // 29: DISC PTS FLAG
                tranBuilder.Append(ppbbFlg.Trim().PadRight(1)); // 30: PPBB FLG
                tranBuilder.Append(' ', 50); // 31-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}