﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates 032 - Late Charge Adjustments/Payment History Record Table Adjustment (D-026)
        /// Use transaction 032 to adjust the delinquent table in the master file, the late charge count, and the fee balances. You can also use this transaction to change the payment history record table.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="lateChargeCount">(25) This field is optional. It sets the entire delinquent table, including the LAST-LATE-DATE master file field (MFF #1170), to zero.</param>
        /// <param name="lateChargeCountAdjustment">(36-37) This field is optional. It adjusts the late charge count and the delinquent table in the master file. If the adjustment causes the late charge count to be greater than 12 or less than 0, the transaction does not apply. It displays on report P-151 with error code 1005.</param>
        /// <param name="sourceIndicator">(38) This field is available if you are installed on IP 2168. This field is system generated and should not be entered by the user. It indicates the source of the fee assessment for late charge or $ fees that are auto-assessed or manually assessed (using an online screen) on consumer loans.</param>
        /// <param name="paymentRecordTable">(39-50) This field is optional. It indicates the table displaying when a payment was actually paid. This system automatically updates this field as payments are received. You may change this field manually with this transaction. The table is broken down by month according to the following field positions:</param>
        /// <param name="reasonForLateChargeAdjustment">(52) This field is optional. It indicates the reason an adjustment was made to late charge due.</param>
        /// <param name="referenceDate">(53-58) This field is optional. It indicates the date a fee was assessed or waived.</param>
        /// <param name="feeCode">(59) This field is conditional. It is required if you enter an amount in the FEE AMOUNT field (1: 60-66). It indicates the adjusted fee code. The fee codes are maintained on the Miscellaneous Payment Description Headers screen (PL24) in Online LetterWriter. This field updates the fee header.</param>
        /// <param name="feeAmount">(60-66) This field is conditional. It is required if you enter a value in the FEE CODE field (1: 59). It indicates the amount of adjustment. This field is moved to the fee header.</param>
        /// <param name="elocFeeSubcode">(75) This field is available if you are installed on IP 1423. This field is conditional. It is required for ELOC loans. It indicates the adjusted fee. It is the second part of a two-part code including the FEE CODE. All ELOC descriptions are maintained on the PL24 screen in Online LetterWriter.</param>
        /// <returns>Transaction 032</returns>
        public static string Tran032(string loanNumber = "", string lateChargeCount = "", string lateChargeCountAdjustment = "", string sourceIndicator = "", string paymentRecordTable = "", string reasonForLateChargeAdjustment = "", string referenceDate = "", string feeCode ="", string feeAmount ="", string elocFeeSubcode = "")
        {
            string transaction;

            try
            {
                var transactionName = "032";

                CheckValidLoanNumber(transactionName, loanNumber);

                if (IsAvailable(feeCode) && !IsAvailable(feeAmount))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Fee Amount cannot be empty if Fee Code is populated.",
                            transactionName, loanNumber));
                }

                if (!IsAvailable(feeCode) && IsAvailable(feeAmount))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Fee Code cannot be empty if Fee Amount is populated.",
                            transactionName, loanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(' ', 11); // 14-24: RESERVED
                tranBuilder.Append(lateChargeCount.Trim().PadRight(1)); // 25: LATE CHARGE COUNT
                tranBuilder.Append(' ', 10); //  26-35: RESERVED
                tranBuilder.Append(LeftZeroFillOptionalField(lateChargeCountAdjustment, 2)); //  36-37: LATE CHARGE COUNT ADJUSTMENT
                tranBuilder.Append(sourceIndicator.Trim().PadRight(1)); // 38: SOURCE INDICATOR
                tranBuilder.Append(paymentRecordTable.Trim().PadRight(12)); // 39-50: PAYMENT RECORD TABLE
                tranBuilder.Append(' '); //  51: RESERVED
                tranBuilder.Append(reasonForLateChargeAdjustment.Trim().PadRight(1)); // 52: REASON FOR LATE CHARGE ADJUSTMENT
                tranBuilder.Append(FormatDate(referenceDate.Trim())); // 53-58: REFERENCE DATE
                tranBuilder.Append(feeCode.Trim().PadRight(1)); // 59: FEE CODE
                tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(feeAmount.Trim()), 7)); // 60-66: FEE AMOUNT
                tranBuilder.Append(' ', 8); //  67-74: RESERVED
                tranBuilder.Append(elocFeeSubcode.Trim().PadRight(1)); // 75: ELOC FEE SUBCODE
                tranBuilder.Append(' ', 5); //  76-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        public static string Tran032(Tran032Model model)
        {
            string transaction;

            
            
                var transactionName = "032";

                CheckValidLoanNumber(transactionName,model.LoanNumber);

                if (IsAvailable(model.FeeCode) && !IsAvailable(model.FeeAmount))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Fee Amount cannot be empty if Fee Code is populated.",
                            transactionName, model.LoanNumber));
                }

                if (!IsAvailable(model.FeeCode) && IsAvailable(model.FeeAmount))
                {
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Fee Code cannot be empty if Fee Amount is populated.",
                            transactionName, model.LoanNumber));
                }

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

            var tranBuilder = new StringBuilder();
            tranBuilder.Append(tranClient); // 1-6: CLIENT
            tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
            tranBuilder.Append(' ', 11); // 14-24: RESERVED
            tranBuilder.Append(TrimAndPad(model.LateChargeCount, 1)); // 25 LATE CHARGE COUNT
            tranBuilder.Append(' ', 10); // 26-35 RESERVED
            tranBuilder.Append(TrimAndPad(model.LateChargeCountAdjustment, 2)); // 36-37 LATE CHARGE COUNT ADJUSTMENT
            tranBuilder.Append(' ', 1); // 38 SOURCE INDICATOR
            tranBuilder.Append(TrimAndPad(model.PaymentRecordTable, 12)); // 39-50 PAYMENT RECORD TABLE
            tranBuilder.Append(' ', 1); // 51 RESERVED
            tranBuilder.Append(TrimAndPad(model.ReasonForLateChargeAdjustment, 1)); //   52 REASON FOR LATE CHARGE ADJUSTMENT
            tranBuilder.Append(TrimAndPad(model.ReferenceDate, 6)); // 53-58 REFERENCE DATE
            tranBuilder.Append(TrimAndPad(model.FeeCode, 1)); // 59 FEE CODE
            tranBuilder.Append(LeftZeroFillOptionalField(Convert.ToZonedString(model.FeeAmount),7)); // 60-66 FEE AMOUNT
            tranBuilder.Append(' ', 8); // 67-74 RESERVED
            tranBuilder.Append(TrimAndPad(model.ElocFeeSubcode, 1)); // 75 ELOC FEE SUBCODE
            tranBuilder.Append(' ', 14);// 76-89 RESERVED
            tranBuilder.Append(model.LoanNumber.PadLeft(13, '0')); // 90-102 EXPANDED LOAN NUMBER

            if (tranBuilder.Length != 102)
            {
                throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, tranBuilder));
            }

            tranBuilder.AppendLine();

            transaction = tranBuilder.ToString();

            return transaction;
        }
    }
}
