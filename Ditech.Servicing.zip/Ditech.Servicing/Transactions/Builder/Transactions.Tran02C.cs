#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 02C - Other Loans to Mortgagor (D-276)
        /// Use transaction 02C to enter up to 10 loan numbers of other loans that the mortgagor has.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="cardCode">The card code.</param>
        /// <param name="otherLoan1">(15-27) These fields are optional. They identify the five other loans of the mortgagor. </param>
        /// <param name="otherLoan2">(28-40) These fields are optional. They identify the five other loans of the mortgagor. </param>
        /// <param name="otherLoan3">(41-53) These fields are optional. They identify the five other loans of the mortgagor. </param>
        /// <param name="otherLoan4">(54-66) These fields are optional. They identify the five other loans of the mortgagor. </param>
        /// <param name="otherLoan5">(67-79) These fields are optional. They identify the five other loans of the mortgagor. </param>
        /// <returns>Transaction 02C</returns>
        public static string Tran02C(string loanNumber, string cardCode, string otherLoan1, string otherLoan2,
                                     string otherLoan3, string otherLoan4, string otherLoan5)
        {
            string transaction;

            try
            {
                var transactionName = "02C";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                if (cardCode != "1" && cardCode != "2")
                {
                    throw new Exception(
                        string.Format("{0}: {1}: Invalid card code: \"{2}\"",
                                      transactionName, loanNumber, cardCode));
                }

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(cardCode.Trim().PadRight(1)); // 14: CARD CODE
                tranBuilder.Append(LeftZeroFillOptionalField(otherLoan1.Trim(), 13)); // 15-27: OTHER LOAN 1
                tranBuilder.Append(LeftZeroFillOptionalField(otherLoan2.Trim(), 13)); // 28-40: OTHER LOAN 1
                tranBuilder.Append(LeftZeroFillOptionalField(otherLoan3.Trim(), 13)); // 41-53: OTHER LOAN 1
                tranBuilder.Append(LeftZeroFillOptionalField(otherLoan4.Trim(), 13)); // 54-66: OTHER LOAN 1
                tranBuilder.Append(LeftZeroFillOptionalField(otherLoan5.Trim(), 13)); // 67-79: OTHER LOAN 1
                tranBuilder.Append(' '); // 80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}