#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 021 - Loan Dates and Origination Data - Maintenance (D-019).
        /// Use transaction 021 to correct data previously entered on transaction 020 (D-021). For clients installed on the RLIC/MSP combined system and Buy Price Workstation, when loan term, type loan, or product line code is changed with a transaction 021, a change to the buy price history file is generated only if the loan is not sold..
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="loanClosingDate">(14-19) This field is optional. It indicates the date that the loan was closed. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="paymentDueDate">(20-25) This field is optional. It indicates the date on which the next mortgage payment is due. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="loanMaturityDate">(26-31) This field is optional. It indicates the date that the final payment is due on the loan. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="loanTerm">(32-34) This field is optional. It indicates the number of months in the full term of the loan. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="nextPaymentNumber">(35-37) This field is optional. It indicates the next scheduled principal payment of the loan. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="originalMortgageAmount">(38-46) This field is optional. It indicates the dollar amount of the note. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="office">(47-48) This field is optional. It designates the originating office or service branch. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="typeOfAcquisition">(49) This field is optional. It contains the code for the manner in which the loan was added to the portfolio. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="typeOfLoan">(50-51) This field is optional. It indicates the type of mortgage and loan. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="telephoneNumber">(52-61) This field is optional. It indicates the mortgagor's telephone number. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="man">(62) This field is optional. It indicates the man code. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="numberOfUnits">(63) This field is optional. It indicates the number of units for Fannie Mae reporting. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="fnmaStatusCode">(73) This field is optional. It indicates the code for AES reporting to Fannie Mae. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="couponMonth">(74-75) This field is optional. It is used in the calculation of the number of coupons to be produced.</param>
        /// <param name="capitalizedLoanFlag">(76) This field is optional. It indicates whether the loan is a capitalized loan.</param>
        /// <param name="interestIndicator">(77) This field is optional. It indicates how interest is earned. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <param name="productLineCode">(78-80) This is an optional user-defined code. Use this field to group loans by any criterion that you require. The system replaces the value in the corresponding master file field with the value you enter in this field.</param>
        /// <returns>Transaction 021</returns>
        public static string Tran021(string loanNumber, string loanClosingDate, string paymentDueDate,
                                     string loanMaturityDate, string loanTerm, string nextPaymentNumber,
                                     string originalMortgageAmount, string office, string typeOfAcquisition,
                                     string typeOfLoan, string telephoneNumber, string man, string numberOfUnits,
                                     string fnmaStatusCode, string couponMonth, string capitalizedLoanFlag,
                                     string interestIndicator, string productLineCode)
        {
            string transaction;

            try
            {
                var transactionName = "021";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(FormatDate(loanClosingDate.Trim())); // 14-19: LOAN CLOSING DATE
                tranBuilder.Append(FormatDate(paymentDueDate.Trim())); // 20-25: PAYMENT DUE DATE
                tranBuilder.Append(FormatDate(loanMaturityDate.Trim())); // 26-31: LOAN MATURITY DATE
                tranBuilder.Append(LeftZeroFillOptionalField(loanTerm.Trim(), 3)); // 32-34: LOAN TERM
                tranBuilder.Append(LeftZeroFillOptionalField(nextPaymentNumber.Trim(), 3)); // 35-37 NEXT PAYMENT NUMBER
                tranBuilder.Append(FormatMoney(originalMortgageAmount.Trim(), false, false, 9));
                // 38-46: ORIGINAL MORTGAGE AMOUNT                 
                tranBuilder.Append(office.Trim().PadRight(2)); //  47-48: OFFICE
                tranBuilder.Append(typeOfAcquisition.Trim().PadRight(1)); // 49: TYPE OF ACQUISITION
                tranBuilder.Append(typeOfLoan.Trim().PadRight(2)); // 50-51: TYPE OF LOAN
                tranBuilder.Append(telephoneNumber.Trim().PadRight(10)); // 52-61 TELEPHONE NUMBER
                tranBuilder.Append(man.Trim().PadRight(1)); // 62: MAN
                tranBuilder.Append(numberOfUnits.Trim().PadRight(1)); // 63: NUMBER OF UNITS
                tranBuilder.Append(' ', 9); // 64-72: NET PAYMENT
                tranBuilder.Append(fnmaStatusCode.Trim().PadRight(1)); // 73: FNMA STATUS CODE
                tranBuilder.Append(LeftZeroFillOptionalField(couponMonth.Trim(), 2)); // 74-75: COUPON MONTH
                tranBuilder.Append(capitalizedLoanFlag.Trim().PadRight(1)); // 76: CAPITALIZED LOAN FLAG
                tranBuilder.Append(interestIndicator.Trim().PadRight(1)); // 77: INTEREST INDICATOR
                tranBuilder.Append(productLineCode.Trim().PadRight(3)); // 78-80: PRODUCT LINE CODE
                tranBuilder.Append(' ', 9); // 81-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102 EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}