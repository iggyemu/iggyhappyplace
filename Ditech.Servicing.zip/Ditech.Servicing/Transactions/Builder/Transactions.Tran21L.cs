#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 21L - Second Lienholder Name/Address (D-246)
        /// Use transaction 21L to add, change, delete, or list an item in the lienholder name/address file. The system uses this information to create a batch LetterWriter letter each time a P-198 delinquent notice is produced.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="action">(15) This field is required. It indicates the type of processing for this transaction.</param>
        /// <param name="lienholderNumber">(16-17) This field is required. It indicates which of the five lienholder records per loan is to be added, changed, deleted, or listed.</param>
        /// <param name="lienholderName">(18-40) This field is conditional. It is required on an add transaction, optional on a change transaction, and not used for a delete or list transaction. It contains the lienholder name.</param>
        /// <param name="lienHolderAddress1">(41-63) This field is conditional. It is required on an add transaction, optional on a change transaction, and not used for a delete or list transaction. It contains the lienholder mailing address.</param>
        /// <param name="lienHolderLoanNumber">(64-78) This field is conditional. It is optional on an add or change transaction and not used for a delete or list transaction. It contains the lienholder loan number.</param>
        /// <returns>Transaction 21L Card 1</returns>
        public static string Tran21Lc1(string loanNumber, string action, string lienholderNumber, string lienholderName,
                                       string lienHolderAddress1, string lienHolderLoanNumber)
        {
            string transaction;

            try
            {
                var transactionName = "21L-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "action", action);
                CheckRequiredField(transactionName, "lienholderNumber", lienholderNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(action.PadRight(1)); // 15: ACTION
                tranBuilder.Append(lienholderNumber.PadLeft(2, '0')); // 16-17: LIENHOLDER NUMBER
                tranBuilder.Append(lienholderName.PadRight(23)); // 18-40: LIENHOLDER NAME
                tranBuilder.Append(lienHolderAddress1.PadRight(23)); // 41-63: LIENHOLDER ADDRESS 1
                tranBuilder.Append(LeftZeroFillOptionalField(lienHolderLoanNumber, 15));
                // 64-78: LIENHOLDER LOAN NUMBER
                tranBuilder.Append(' ', 2); // 79-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }

        /// <summary>
        /// Transaction 21L - Second Lienholder Name/Address (D-246)
        /// Use transaction 21L to add, change, delete, or list an item in the lienholder name/address file. The system uses this information to create a batch LetterWriter letter each time a P-198 delinquent notice is produced.        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="action">(15) This field is required. It indicates the type of processing for this transaction.</param>
        /// <param name="lienholderNumber">(16-17) This field is required. It indicates which of the five lienholder records per loan is to be added, changed, deleted, or listed.</param>
        /// <param name="lienDate">(18-23) This field is optional. It indicates the date the lien was placed on the property.</param>
        /// <param name="typeOfLien">(24-26) This field is optional. It indicates the type of lien that was placed on the property.</param>
        /// <param name="originalAmount">(27-33) This field is optional. It indicates the amount of the original lien for this lienholder.</param>
        /// <param name="currentAmount">(34-40) This field is optional. It indicates the amount owed to the lienholder at the present time.</param>
        /// <param name="negotiableAmountRemaining">(41-47) This field is optional. It indicates the amount of the lien that remains after the loss mitigation negotiations.</param>
        /// <param name="contactName">(48-70) This field is optional. It indicates the lienholder's name.</param>
        /// <param name="contactPhone">(71-80) This field is optional. It indicates the lienholder's phone number.</param>
        /// <returns>Transaction 21L Card 3</returns>
        public static string Tran21Lc3(string loanNumber, string action, string lienholderNumber, string lienDate,
                                       string typeOfLien, string originalAmount, string currentAmount,
                                       string negotiableAmountRemaining, string contactName, string contactPhone)
        {
            string transaction;

            try
            {
                var transactionName = "21L-3";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "action", action);
                CheckRequiredField(transactionName, "lienholderNumber", lienholderNumber);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("3"); // 14: CARD CODE
                tranBuilder.Append(action.Trim().PadRight(1)); // 15: ACTION
                tranBuilder.Append(lienholderNumber.Trim().PadLeft(2, '0')); // 16-17: LIENHOLDER NUMBER
                tranBuilder.Append(FormatDate(lienDate.Trim())); // 18-23: LIEN DATE
                tranBuilder.Append(typeOfLien.Trim().PadRight(3)); // 24-26: TYPE OF LIEN
                tranBuilder.Append(FormatMoney(originalAmount.Trim(), false, false, 7)); // 27-33: ORIGINAL AMOUNT
                tranBuilder.Append(FormatMoney(currentAmount.Trim(), false, false, 7)); // 34-40: CURRENT AMOUNT
                tranBuilder.Append(FormatMoney(negotiableAmountRemaining.Trim(), false, false, 7));
                // 41-47: NEGOTIABLE AMOUNT REMAINING
                tranBuilder.Append(contactName.Trim().PadRight(23)); // 48-70: CONTACT NAME
                tranBuilder.Append(contactPhone.Trim().PadRight(10)); // 71-80: CONTACT PHONE
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.Trim().PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}