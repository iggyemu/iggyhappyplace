﻿using System;
using System.Text;

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Transaction 248 - Customer Account Activity Statement Request (D-007)
        /// Use transaction 248 to request a customer account activity statement for a loan.
        /// </summary>
        /// <param name="loanNumber">This field is required. This field identifies the loan number.</param>
        /// <param name="requestedBy">(15-17) This field is optional. It indicates the requester's initials. The value entered is moved from input on schedule and used to sort requests by requester.</param>
        /// <param name="messageCode">(19-20) This field is optional. It indicates the standard message code.</param>
        /// <param name="dateRange">(21-32) This field is required. It indicates the valid dates of the history to be displayed.</param>
        /// <param name="reportSelect">(33) This field is optional. It indicates which report you want the system to produce.</param>
        /// <param name="stmtTapeBoth">(34) This field is required only when the REPORT SELECT field is equal to Q. Otherwise, the system rejects the transaction.</param>
        /// <param name="summaryDetail">(35) This field is required when the REPORT SELECT field is equal to Q.</param>
        /// <returns>Transaction 248 Card 1</returns>
        public static string Tran248(string loanNumber, string requestedBy, string messageCode, string dateRange,
                                     string reportSelect, string stmtTapeBoth, string summaryDetail)
        {
            string transaction;

            try
            {
                var transactionName = "248-1";

                CheckValidLoanNumber(transactionName, loanNumber);

                CheckRequiredField(transactionName, "Date Range (21-32)", dateRange);

                if (reportSelect == "Q" && !IsAvailable(summaryDetail))
                    throw new Exception(
                        string.Format(
                            "{0}: {1}: Summary Detail is required when Report Select field is equal to Q.",
                            transactionName, loanNumber));

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append("1"); // 14: CARD CODE
                tranBuilder.Append(requestedBy.Trim().PadLeft(3)); // 15-17: REQUESTED BY
                tranBuilder.Append(' '); // 18: RESERVED
                tranBuilder.Append(messageCode.Trim().PadLeft(2)); // 19-20: MESSAGE CODE
                tranBuilder.Append(dateRange.Trim().PadLeft(12)); // 21-32: DATE RANGE
                tranBuilder.Append(reportSelect.Trim().PadLeft(1)); // 33: REPORT SELECT
                tranBuilder.Append(stmtTapeBoth.Trim().PadLeft(1)); // 34: STMT/TAPE/BOTH
                tranBuilder.Append(summaryDetail.Trim().PadLeft(1)); // 35: SUMMARY/DETAIL
                tranBuilder.Append(' ', 45); // 36-80: RESERVED
                tranBuilder.Append(' ', 9); // 81-89: EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}