﻿#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        ///<summary>
        /// Transaction GH3 - Payoff Tracking Header Change (D-165) This transaction is used to modify scheduled and actual tracking dates for loans on the Payoff Tracking Subsystem. It is also used to move a loan from one employee to another.
        ///</summary>
        ///<param name="loanNumber">This field is required. It indicates the loan number.</param>
        ///<param name="cardCode">(14) Required, Enter the appropriate card code.</param>
        ///<param name="employeeId">(15-17) Enter the employee ID responsible for tracking this loan.</param>
        ///<param name="requestDocuments">(21-26) Enter the scheduled date for requesting documents from the trustee.</param>
        ///<param name="refundEscrow">(27-32) Enter the scheduled date for refunding the mortgagor's escrow balance.</param>
        ///<param name="userDate1">(33-38) Enter the scheduled date for the user date 1 activity.</param>
        ///<param name="userDate2">(39-44) Enter the scheduled date for the user date 2 activity.</param>
        ///<param name="userDate3">(45-50) Enter the scheduled date for the user date 3 activity.</param>
        ///<param name="userDate4">(51-56) Enter the scheduled date for the user date 4 activity.</param>
        ///<param name="userDate5">(57-62) Enter the scheduled date for the user date 5 activity.</param>
        ///<param name="userDate6">(63-68) Enter the scheduled date for the user date 6 activity.</param>
        ///<param name="userDate7">(69-74) Enter the scheduled date for the user date 7 activity.</param>
        ///<param name="userDate8">(75-80) Enter the scheduled date for the user date 8 activity.</param>
        ///<returns></returns>
        public static string TranGH3(string loanNumber, string cardCode, string employeeId, string requestDocuments, string refundEscrow, string userDate1, string userDate2, string userDate3, string userDate4, string userDate5, string userDate6, string userDate7, string userDate8)
        {
            string transaction;

            try
            {
                var transactionName = "GH3";

                CheckValidLoanNumber(transactionName, loanNumber);
                CheckRequiredField(transactionName, "cardCode", cardCode);

                var tranClient = transactionName.Substring(0, 3) + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(cardCode); // 14: CARD CODE
                tranBuilder.Append(employeeId.Trim().PadRight(3)); // 15-17: EMPLOYEE ID
                tranBuilder.Append(' ', 3); // 18-20: NOT USED
                tranBuilder.Append(FormatDate(requestDocuments.Trim())); // 21-26: REQUEST DOCUMENTS
                tranBuilder.Append(FormatDate(refundEscrow.Trim())); // 27-32: REFUND ESCROW
                tranBuilder.Append(FormatDate(userDate1.Trim())); // 33-38: USER DATE 1
                tranBuilder.Append(FormatDate(userDate2.Trim())); // 39-44: USER DATE 2
                tranBuilder.Append(FormatDate(userDate3.Trim())); // 45-50: USER DATE 3
                tranBuilder.Append(FormatDate(userDate4.Trim())); // 51-56: USER DATE 4
                tranBuilder.Append(FormatDate(userDate5.Trim())); // 57-62: USER DATE 5
                tranBuilder.Append(FormatDate(userDate6.Trim())); // 63-68: USER DATE 6
                tranBuilder.Append(FormatDate(userDate7.Trim())); // 69-74: USER DATE 7
                tranBuilder.Append(FormatDate(userDate8.Trim())); // 75-80: USER DATE 8
                tranBuilder.Append(' ', 9); // 81-89: NOT USED
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102: EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}
