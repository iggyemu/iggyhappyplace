#region

using System;
using System.Text;

#endregion

namespace Ditech.Servicing.Transactions
{
    public partial class Transactions
    {
        /// <summary>
        /// Creates Transaction 017 - Tax and Location Data - New Loans (D-021).  
        /// This transaction is used to enter the property location data for taxes.
        /// </summary>
        /// <param name="loanNumber">This field is required. It indicates the loan number.</param>
        /// <param name="state"> (14-15) This field is optional. It indicates the code that identifies the state where the property is located. Entering this field will update the STATE field in the master file. If this field is blank, the master file field will be zero (00). </param>
        /// <param name="county">(16-18) This field is optional. It indicates the code that identifies the county where the property is located. Entering this field will update the COUNTY field in the master file. If this field is blank, the master file field will be zero (000). </param>
        /// <param name="city"> (19-22) This field is optional. It indicates the code that identifies the city where the property is located. Entering this field will update the CITY field in the master file. If this field is blank, the master file field will be zero (0000). </param>
        /// <param name="subdivision"> (23-52) This field is optional. It indicates the name of the subdivision where the property is located. This field is also used to record the class of subdivision for Freddie Mac. Entering this field will update the SUB-DIVISION field in the master file. </param>
        /// <param name="section"> (53-64) This field is optional. It indicates the section number of the property as defined in the deed. Entering this field will update the SECTION field in the master file. </param>
        /// <param name="block">(65-70) This field is optional. It indicates the block number on which the property is located. Entering this field will update the BLOCK field in the master file. </param>
        /// <param name="lot">(71-76) This field is optional. It indicates the lot number on which the property is located. Entering this field will update the LOT field in the master file.</param>
        /// <returns>Transaction 017</returns>
        public static string Tran017(string loanNumber, string state, string county, string city, string subdivision,
                                     string section, string block, string lot)
        {
            string transaction;

            try
            {
                var transactionName = "017";

                CheckValidLoanNumber(transactionName, loanNumber);

                var tranClient = transactionName + CLIENT_NUMBER;

                var tranBuilder = new StringBuilder();

                tranBuilder.Append(tranClient); // 1-6: CLIENT
                tranBuilder.Append("*".PadRight(7)); // 7-13: LOAN
                tranBuilder.Append(LeftZeroFillOptionalField(state.Trim(), 2)); // 14-15: STATE
                tranBuilder.Append(LeftZeroFillOptionalField(county.Trim(), 3)); // 16-18: COUNTY
                tranBuilder.Append(LeftZeroFillOptionalField(city.Trim(), 4)); // 19-22: CITY
                tranBuilder.Append(subdivision.Trim().PadRight(30)); // 23-52: SUBDIVISION
                tranBuilder.Append(section.Trim().PadRight(12)); // 53-64: SECTION 
                tranBuilder.Append(block.Trim().PadRight(6)); // 65-70: BLOCK                      
                tranBuilder.Append(lot.Trim().PadRight(6)); //  71-76: LOT
                tranBuilder.Append(' ', 1); // 77: EXTENDED LEGAL CODE (system filled)
                tranBuilder.Append(' ', 12); // 78-89 EMPTY SPACE
                tranBuilder.Append(loanNumber.PadLeft(13)); // 90-102 EXPANDED LOAN NUMBER

                transaction = tranBuilder.ToString();

                if (transaction.Length != 102)
                    throw new Exception(string.Format("{0}: Line length mismatch: {1}", transactionName, transaction));
            }
            catch (Exception ex)
            {
                transaction = "***** TRAN ERROR: " + ex.Message;
            }

            return transaction;
        }
    }
}