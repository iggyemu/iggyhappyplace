#region

using System;
using System.Text;
using Ditech;
#endregion

namespace Ditech.Servicing.Transactions
{
    public  partial class Transactions
    {
        private const string CLIENT_NUMBER = "511";

        /// <summary>
        /// Formats the zip code.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        private static string FormatZipCode(string value)
        {
            value = value.Trim();
            return IsAvailable(value) && !value.Equals("&") ? value.PadLeft(5, '0') : value.PadRight(5);
           
        }

        /// <summary>
        /// Used to submit the proper number of ampersands to clear a field.  
        /// Some fields only require one while others require the number of ambersands equal to the length of the field
        /// </summary>
        /// <param name="value">The value</param>
        /// <param name="length">The length</param>
        /// <returns></returns>
        private static string FormatFieldValueRemoval(string value,int length)
        {
             value = value.Trim();
             return IsAvailable(value) && value.Contains("&") ? value.PadRight(length, '&') : value.PadRight(length,' ');
        }

        /// <summary>
        /// Checks the state of the foreign address indicator and.
        /// </summary>
        /// <param name="transactionName">Name of the transaction.</param>
        /// <param name="loanNumber">The loan number.</param>
        /// <param name="foreignAddressIndicator">The foreign address indicator.</param>
        /// <param name="state">The state.</param>
        private static void CheckForeignAddressIndicatorAndState(string transactionName, string loanNumber,
                                                                 string foreignAddressIndicator, string state)
        {
            if ((IsAvailable(foreignAddressIndicator) && IsAvailable(state)))
            {
                throw new Exception(
                    string.Format("{0}: {1}: State field cannot have a value when foreign address indicator is set.",
                                  transactionName, loanNumber));
            }

            if (!IsAvailable(foreignAddressIndicator) && !IsAvailable(state))
            {
                throw new Exception(
                    string.Format("{0}: {1}: State field must have a value when foreign address indicator is not set.",
                                  transactionName, loanNumber));
            }
        }

        /// <summary>
        /// Formats an SSN or TIN for a transaction when there is no SSN/TIN indicator present.
        /// </summary>
        /// <param name="value">The value to format.</param>
        /// <returns>Formatted SSN/TIN</returns>
        private static string FormatSsnTin(string value)
        {
            return value.Contains("-") ? FormatSsnTin(value, "2") : FormatSsnTin(value, "1");
        }

        /// <summary>
        /// Formats an SSN or TIN for a transaction.
        /// </summary>
        /// <param name="value">The value to format.</param>
        /// <param name="ssnOrTin">A value of 1 indicates SSN.  A value of 2 indicates a TIN.</param>
        /// <returns>Formatted SSN/TIN</returns>
        private static string FormatSsnTin(string value, string ssnOrTin)
        {
            var result = value.Remove('-').PadRight(10);

            if (ssnOrTin == "2")
            {
                result = string.Format("{0}-{1}", result.Substring(0, 2), result.Substring(2));
            }

            return result;
        }

        /// <summary>
        /// Formats a date to MMDDYY format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>A formatted date.</returns>
        private static string FormatDate(string value)
        {
            return FormatDate(value, "MMddyy");
         
        }

        /// <summary>
        /// Formats a date to YYMMDD format.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="format">The format</param>
        /// <returns>A formatted date.</returns>
        private static string FormatDate(string value, string format)
        {
            DateTime dt;
            var result = value.PadLeft(format.Length, ' ');

            if (DateTime.TryParse(value, out dt))
            {
                result = dt.ToString(format);
            }

            return result;
        }

        public static string FormatMoney(string value, bool includeCents, int length)
        {
            return FormatMoney(value, includeCents).PadLeft(length, '0');
        }

        public static string FormatMoney(string value, bool includeCents, bool isRequired, int length)
        {
            return FormatMoney(value, includeCents, isRequired, length, false);
        }

        public static string FormatMoney(string value, bool includeCents, bool isRequired, int length, bool blankIfPastLength)
        {
            string result;

            if (isRequired)
            {
                result = FormatMoney(value, includeCents, length);
            }
            else
            {
                result = LeftZeroFillOptionalField(FormatMoney(value, includeCents), length);
            }

            if (result.Length > length)
            {
                result = blankIfPastLength ? new string(' ', length) : result.Left(length);
            }

            return result;
        }

        /// <summary>
        /// Formats a number to a money value for a transaction.  If including cents, make sure that the value is not already in the Fidelity format
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="includeCents">If true, include the whole money amount.  If false, round to the nearest dollar.</param>
        /// <returns>A money value.</returns>
        public static string FormatMoney(string value, bool includeCents)
        {
            var result = string.Empty;

            decimal number;

            if (decimal.TryParse(value, out number))
            {
                result = includeCents ? number.ToString("0.00") : number.ToString("0");
            }

            // If the value was blank, a blank value will be returned
            return result.Remove(".");
        }

        /// <summary>
        /// Formats a number to a percent value for a transaction.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="decimalPlaces">The decimal places.</param>
        /// <returns>A percent value.</returns>
        private static string FormatPercent(string value, int decimalPlaces)
        {
            var result = new string(' ', decimalPlaces);

            decimal tempNumber;

            if (!string.IsNullOrEmpty(value) && decimal.TryParse(value, out tempNumber))
            {
                if (tempNumber > 1)
                {
                    tempNumber = tempNumber/100;
                }

                result = tempNumber.ToString("N" + decimalPlaces).Substring(2);
            }

            return result;
        }

        /// <summary>
        /// Checks to make sure a loan number is valid.
        /// </summary>
        /// <param name="transaction">The transaction.</param>
        /// <param name="value">The value.</param>
        private static void CheckValidLoanNumber(string transaction, string value)
        {
            if (!value.IsLoanNumber())
            {
                throw new Exception(string.Format("{0}: {1}: Invalid loan number.", transaction, value));
            }
        }

        /// <summary>
        /// Checks to make sure that a required field is present.
        /// </summary>
        /// <param name="transaction">The transaction.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="value">The value.</param>
        private static void CheckRequiredField(string transaction, string fieldName, string value)
        {
            if (value.IsNullOrEmpty(true))
            {
                throw new Exception(string.Format("{0}: {1} is required.", transaction, fieldName));
            }
        }


        /// <summary>
        /// Left zero fills an optional field.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="length">The length.</param>
        /// <returns></returns>
        public static string LeftZeroFillOptionalField(string value, int length)
        {
            return value.IsNullOrEmpty(true) ? new string(' ', length) : value.PadLeft(length, '0');
        }

        /// <summary>
        /// Determines whether the specified value is available.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is available; otherwise, <c>false</c>.
        /// </returns>
        private static bool IsAvailable(string value)
        {
            return !value.IsNullOrEmpty(true);
        }

        /// <summary>
        /// Creates the batch card.
        /// </summary>
        /// <param name="batchID">The batch ID.</param>
        /// <param name="transactionNumber">The transaction number.</param>
        /// <param name="transactionCount">The transaction count.</param>
        /// <returns></returns>
        public static string CreateBatchCard(string batchID, string transactionNumber, int transactionCount)
        {
            var batchCard = new StringBuilder();

            if (batchID.Length != 3)
            {
                throw new Exception(string.Format("Invalid batch ID length: {0}", batchID));
            }

            if (transactionNumber.Length != 3)
            {
                throw new Exception(string.Format("Invalid transaction number length: {0}", transactionNumber));
            }

            if (CLIENT_NUMBER.Length != 3)
            {
                throw new Exception(string.Format("Invalid client number length: {0}", CLIENT_NUMBER));
            }

            if (transactionCount > 99999)
            {
                transactionCount = 99999;
            }

            batchCard.Append(transactionNumber); // 1-3: TRANSACTION
            batchCard.Append(CLIENT_NUMBER); // 4-6: USER ID
            batchCard.Append("##"); // 7-8: BATCH CODE
            batchCard.Append(batchID); // 9-11: BATCH NUMBER
            batchCard.Append(transactionCount.ToString().PadLeft(5, '0')); // 12-16: ITEM COUNT
            batchCard.Append(' ', 64); // 17-80: EMPTY SPACE

            return batchCard.ToString();
        }
        /// <summary>
        /// Creates the batch card for cash transactions
        /// </summary>
        /// <param name="batchId">The batch id</param>
        /// <param name="transactionNumber">The transaction number</param>
        /// <param name="transactionCount">The transaction count</param>
        /// <param name="amountReceived">The total amount received for this transaction</param>
        /// <param name="suspense">The total suspense for this transaction</param>
        /// <returns></returns>
        public static string CreateBatchCard(string batchId,string transactionNumber,int transactionCount,string amountReceived,string suspense)
        {
            var batchCard = new StringBuilder();

            if (batchId.Length != 3)
            {
                throw new Exception(string.Format("Invalid batch ID length: {0}", batchId));
            }

            if (transactionNumber.Length != 3)
            {
                throw new Exception(string.Format("Invalid transaction number length: {0}", transactionNumber));
            }

            if (CLIENT_NUMBER.Length != 3)
            {
                throw new Exception(string.Format("Invalid client number length: {0}", CLIENT_NUMBER));
            }

            if (transactionCount > 99999)
            {
                transactionCount = 99999;
            }

            batchCard.Append(transactionNumber); // 1-3: TRANSACTION
            batchCard.Append(CLIENT_NUMBER); // 4-6: USER ID
            batchCard.Append("##"); // 7-8: BATCH CODE
            batchCard.Append(batchId); // 9-11: BATCH NUMBER
            batchCard.Append(transactionCount.ToString().PadLeft(5, '0')); // 12-16: ITEM COUNT
            batchCard.Append(transactionNumber == "081" ? Convert.ToZonedString(amountReceived).PadLeft(15,'0') : Convert.ToZonedString(amountReceived).PadLeft(9,'0')); // 17-31: AMOUNT RECEIVED
            batchCard.Append(Convert.ToZonedString(suspense).PadLeft(9, '0')); // 32-40 SUSPENSE

            return batchCard.ToString();
        }

        public static string TrimAndPad(string instance, int length,PadDirection padDirection = PadDirection.Left )
        {
            if (instance == null) return string.Empty.PadLeft(length);

            switch (padDirection)
            {
                    case PadDirection.Right:
                        return instance.Trim().PadRight(length);

                    default:
                        return instance.Trim().PadLeft(length);

            }
        }

        public enum PadDirection
        {
            Left,
            Right
        }

    }
        }
    

