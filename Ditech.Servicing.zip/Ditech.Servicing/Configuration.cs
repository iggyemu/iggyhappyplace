﻿using System.Collections.Specialized;
using System.Configuration;

namespace Ditech.Servicing
{
    public static class Configuration
    {
        //private static System.Configuration.Configuration _configuration =
        //     ConfigurationManager.OpenExeConfiguration("Ditech.Servicing.dll");

        //private static AppSettingsSection _appSettings = (AppSettingsSection) _configuration.GetSection("appSettings");
        private static NameValueCollection _appSettings = ConfigurationManager.AppSettings;

        public static string MSPReportsConnectionString
        {
            get { return _appSettings["MSPReportsConnectionString"]; }
        }

        public static string BulkInsertBasePath
        {
            get { return _appSettings["BulkInsertBasePath"]; }
        }

        public static string LoggingDatabaseName
        {
            get { return _appSettings["LoggingDatabaseName"]; }
        }

        public static string GetConfigValue(string key)
        {
            return _appSettings[key];
        }

        public static string DatabaseServer
        {
            get { return _appSettings["DatabaseServer"].Coalesce(_appSettings["DevelopmentServer"]); }
        }

        public static string DatabaseLogin
        {
            get { return _appSettings["DatabaseLogin"].Coalesce(_appSettings["DevelopmentLogin"]); }
        }

        public static string DatabasePassword
        {
            get { return _appSettings["DatabasePassword"].Coalesce(_appSettings["DevelopmentPassword"]); }
        }

        public static string LogEmailRecipient
        { get { return _appSettings["LogEmailRecipient"]; } }
}
}
