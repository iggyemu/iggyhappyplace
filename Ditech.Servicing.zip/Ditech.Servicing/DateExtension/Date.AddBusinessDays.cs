﻿using System;

namespace Ditech.Servicing.DateExtension
{
    public static class DateTimeExtensions
    {
        public static DateTime AddBusinessDays(this DateTime originalDate, int workDays)
        {
            int direction = workDays < 0 ? -1 : 1;
            DateTime tmpDate = originalDate;
            while (workDays != 0)
            {
                tmpDate = tmpDate.AddDays(direction);
                if (tmpDate.DayOfWeek != DayOfWeek.Saturday &&
                    tmpDate.DayOfWeek != DayOfWeek.Sunday &&
                    !Validation.IsHoliday(tmpDate))
                {
                    workDays -= direction;
                }
            }
            return tmpDate;
        }
    }
}
