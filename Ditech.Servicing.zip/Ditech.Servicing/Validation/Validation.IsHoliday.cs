﻿using System;
using System.Data;
using System.Data.SqlClient;
using Ditech.Servicing.Data.Common;
using DbCommand = Ditech.Data.Common.DbCommand;

namespace Ditech.Servicing
{
    public static partial class Validation
    {
        /// <summary>
        /// Determines if date passed is a holiday
        /// </summary>
        /// <returns>True if date passed is in holiday table.</returns>
        public static bool IsHoliday(DateTime date)
        {
            bool holiday;

            using (var dbConnection = Connection.Create(SqlDbName.MSP_APPLICATIONS))
            {
                holiday = IsHoliday(date, dbConnection);
            }

            return holiday;
        }

        /// <summary>
        /// Determines if date passed is a holiday
        /// </summary>
        /// <returns>True if date passed is in holiday table.</returns>
        public static bool IsHoliday(DateTime date, SqlConnection connection)
        {
            var holiday = false;

            using (
                var dbCommand = new DbCommand("MSP_APPLICATIONS.SHARED.Holiday_Check", connection, "@DATE",
                                              date.ToShortDateString()))
            {
                using (var dbDataReader = dbCommand.ExecuteReader())
                {
                    if (dbDataReader.HasRows)
                    {
                        holiday = true;
                    }
                }
            }

            return holiday;
        }
    }
}
