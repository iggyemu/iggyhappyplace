namespace Ditech.Servicing
{
    /// <summary>
    /// This static class provides re-usable validation methods.
    /// </summary>
    public static partial class Validation
    {
        /// <summary>
        /// Determines whether the specified value is valid loan number.
        /// </summary>
        /// <param name="value">The value to check.</param>
        /// <returns>
        /// 	<c>true</c> if the specified value is loan; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsLoanNumber(this string value)
        {
            var allZeroesPattern = @"^0{7,13}$";
            var regExPattern = @"^\d{7,13}$";
            return
                !Ditech.Validation.MatchString(value, allZeroesPattern) &&
                Ditech.Validation.MatchString(value, regExPattern);
        }
    }
}