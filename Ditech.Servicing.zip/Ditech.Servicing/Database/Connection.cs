

using System;
using System.Data.Common;
using System.Data.SqlClient;

namespace EverBank.Servicing.Database
{
    /// <summary>
    /// Class for creating database connections.
    /// </summary>
    public class Connection : EverBank.Database.Connection
    {
        /// <summary>
        /// Gets the DB connection.
        /// </summary>
        /// <param name="environment">The environment.</param>
        /// <param name="database">The database.</param>
        /// <returns>
        /// A SqlConnection based on the environment requested.
        /// </returns>
        public static DbConnection GetConnection(ConnectionType environment, SqlDbName database)
        {
            string serverName = DatabaseResource.ResourceManager.GetString(environment.ToString("G") + "Server");

            string databaseName = database.ToString("G");
            string connectionType = environment.ToString("G");
            string login = DatabaseResource.ResourceManager.GetString(databaseName + connectionType + "Login");
            string password = DatabaseResource.ResourceManager.GetString(databaseName + connectionType + "Password");

            return GetConnection(serverName, databaseName, login, password);
        }
    }
}