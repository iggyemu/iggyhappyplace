﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EverBank.Servicing.Database
{
    #region SqlDbName enum

    /// <summary>
    /// List of available databases.
    /// </summary>
    public enum SqlDbName
    {
        /// <summary>
        /// Database for script logging and miscellaneous related information
        /// </summary>
        director,
        /// <summary>
        /// Database to hold extracted master file data (Rey's Process)
        /// </summary>
        findm,
        /// <summary>
        /// Logging database
        /// </summary>
        logging,
        /// <summary>
        /// Primary MSP Database
        /// </summary>
        msp,
        /// <summary>
        /// Database for MSP Report data
        /// </summary>
        mspReports,
        /// <summary>
        /// Database for Query Results data
        /// </summary>
        queryResults,
        /// <summary>
        /// Database for Servicing Data from the Master File
        /// </summary>
        masData,
    }

    #endregion
}
