﻿namespace EverBank.Servicing.Database
{
    #region ConnectionType enum

    /// <summary>
    /// Enum to define the connection types available.
    /// </summary>
    public enum ConnectionType
    {
        /// <summary>
        /// Development database server
        /// </summary>
        Development,
        /// <summary>
        /// Staging database server (currently unavailable)
        /// </summary>
        Staging,
        /// <summary>
        /// Production database server
        /// </summary>
        Production,
        /// <summary>
        /// Process logging database server (currently JVFSQL2KDEV)
        /// </summary>
        Logging
    }

    #endregion
}
