﻿    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Reflection;

namespace Ditech.Servicing.Data.Common
{
    public class BulkInsert : Ditech.Data.Common.BulkInsert
    {
        //static SqlConnectionStringBuilder sqlConnectionStringBuilder = new SqlConnectionStringBuilder() { DataSource = "JX112784", InitialCatalog = "MSPreports", IntegratedSecurity = true };

        public BulkInsert(string table)
              : this(table, Connection.Create(SqlDbName.MspReports))
        {

        }

        public BulkInsert(string table, SqlConnection dbConnection) : base(table, dbConnection)
        {
            var tries = 5;

            while (tries > 0)
            {
                SetFileName(table);

                try
                {
                    using (var output = new StreamWriter(TemporaryLocalFilePath))
                    {
                    }

                    break;
                }
                catch (Exception ex)
                {
                    if (!ex.Message.Contains("cannot access the file"))
                    {
                        throw;
                    }
                }

                tries--;
            }

            //TemporaryBulkInsertPath = Path.Combine(Connection.BulkInsertPath, Path.GetFileName(TemporaryLocalFilePath));
            TemporaryBulkInsertPath = Path.Combine(Configuration.BulkInsertBasePath, Path.GetFileName(TemporaryLocalFilePath));
        }

        private void SetFileName(string table)
        {
            var random = new Random();
            var randomNumber = random.Next(0, 100000);

            TemporaryLocalFilePath = Path.Combine(@"C:\temp", string.Format("{0}.{1}.{2}.txt", table, DateTime.Now.Ticks, randomNumber));
        }
    }
}
