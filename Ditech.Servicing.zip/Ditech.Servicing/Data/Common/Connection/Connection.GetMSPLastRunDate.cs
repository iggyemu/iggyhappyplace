﻿using System;
using System.Data.SqlClient;

namespace Ditech.Servicing.Data.Common
{
    public static partial class Connection
    {
        /// <summary>
        /// Pulls the last MSP run date from MASDATA_CURRENT
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <returns></returns>
        public static DateTime? GetMSPLastRunDate(SqlConnection dbConnection = null)
        {
            SetMspDates(dbConnection);

            return Convert.ToNullableDateTime(_mspDates.Rows[0]["MSP_LAST_RUN_DATE"]);
        }
    }
}
