﻿using System.Data;
using System.Data.SqlClient;
using System.IO;
using Ditech.Data.Common;

namespace Ditech.Servicing.Data.Common
{
    /// <summary>
    /// Class for creating database connections.
    /// </summary>
    public static partial class Connection
    {
        /// <summary>
        /// Inserts the name of the file into ReportParsedFiles in the MspReports database.
        /// </summary>
        /// <param name="file">The file.</param>
        /// <param name="reportsFileName">Name of the reports file.</param>
        /// <param name="connection">The connection.</param>
        public static void InsertFileName(FileInfo file, string reportsFileName, SqlConnection connection)
        {
            // After processing insert to parsed records
            using (
                var command =
                    new DbCommand("MSPReports.dbo.sp_ReportParser_InsertParsedFileName", connection))
            {
                command.AddWithValue("@FILENAME", reportsFileName);
                command.AddWithValue("@FILELENGTH", file.Length);

                command.ExecuteNonQuery();
            }
        }
    }
}
