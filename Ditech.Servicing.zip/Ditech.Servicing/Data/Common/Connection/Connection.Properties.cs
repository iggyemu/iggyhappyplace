﻿#region



#endregion

using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;

namespace Ditech.Servicing.Data.Common
{
    /// <summary>
    /// Class for creating database connections.
    /// </summary>
    public static partial class Connection
    {
        private static bool _isInitialized;
        private static string _bulkInsertBasePath;

        /// <summary>

        /// <summary>
        /// Gets the bulk insert path.
        /// </summary>
        /// <value>The bulk insert path.</value>
        public static string BulkInsertBasePath
        {
            get
            {
                if (!_isInitialized)
                {
                    InitializeVariables();
                }

                return _bulkInsertBasePath;
            }
        }

        /// <summary>
        /// Gets the bulk insert path (temp path).
        /// </summary>
        /// <value>The bulk insert path.</value>
        public static string BulkInsertPath
        {
            get { return Path.Combine(BulkInsertBasePath, "temp"); }
        }

        /// <summary>
        /// Initialize environment variables for Connection class explicitly with existing SQL connection
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="forceInitialization"></param>
        public static void InitializeVariables(SqlConnection connection = null, bool forceInitialization = false)
        {
            if (!_isInitialized || forceInitialization)
            {
                var connectionCreated = false;

                if (connection == null)
                {
                    //connection = Create(CurrentConnectionType, integratedAuthentication: false);
                    connectionCreated = true;
                }

                _bulkInsertBasePath = Variable.Select("FrameworkConnectionClass", "BulkInsertBasePath", connection);

                if (connectionCreated)
                {
                    connection.Dispose();
                }

                _isInitialized = true;
            }
        }
    }
}