﻿#region

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using Ditech.Data;


#endregion

namespace Ditech.Servicing.Data.Common
{
	/// <summary>
	/// Class for creating database connections.
	/// </summary>
	public static partial class Connection
	{
	    private static string _defaultDatabase = "MASDATA_CURRENT";

		#region Methods (11) 

		// Public Methods (11) 


	    /// <summary>
	    /// Gets the DB connection.
	    /// </summary>
	    /// <param name="database">The database.</param>
        /// <param name="integratedAuthentication">if set to <c>true</c> [integrated authentication].</param>
	    /// <returns>
	    /// A SqlConnection based on the environment requested.
	    /// </returns>
	    public static SqlConnection Create(SqlDbName database, bool integratedAuthentication = true)
	   {
           return Create(databaseName: database.ToString("G"), integratedAuthentication: integratedAuthentication);
	   }

	   /// <summary>
	   /// Gets the DB connection.
	   /// </summary>
       /// <param name="serverName">The SQL Server Instance Name.</param>
	   /// <param name="dataType">Type of the data.</param>
	   /// <param name="databaseName">Name of the database.</param>
	   /// <param name="integratedAuthentication">if set to <c>true</c> [integrated authentication].</param>
	   /// <returns>
	   /// A SqlConnection based on the environment requested.
	   /// </returns>
	   public static SqlConnection Create(string serverName = "", string databaseName = "", bool integratedAuthentication = true)
	   {
	       if (string.IsNullOrEmpty(databaseName))
	       {
	           databaseName = _defaultDatabase;
	       }

           if (string.IsNullOrEmpty(serverName))
           {
               serverName = Configuration.DatabaseServer;
           }

		  SqlConnection connection;

		  if (integratedAuthentication)
		  {
			 connection = new SqlConnection(ConnectionString.SqlServer(serverName, databaseName));
		  }
		  else
		  {
             var userName = Configuration.DatabaseLogin;
			 var password = Configuration.DatabasePassword;

			 connection =
				new SqlConnection(ConnectionString.SqlServer(serverName, databaseName, userName,
													password));
		  }

		  return connection;
	   }

	   #endregion Methods 
	}
}