﻿using System;
using System.Data;
using System.Data.SqlClient;
using Ditech.Data.Common;

namespace Ditech.Servicing.Data.Common
{
    public static partial class Connection
    {
        /// <summary>
        /// Pulls the last MSP month end date from MASDATA_CURRENT
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <returns></returns>
        public static DateTime? GetMSPLastMonthEndDate(SqlConnection dbConnection = null)
        {
            SetMspDates(dbConnection);

            return Convert.ToNullableDateTime(_mspDates.Rows[0]["PREVIOUS_MONTH_END"]);
        }

        private static DataTable _mspDates;

        private static void SetMspDates(SqlConnection dbConnection = null)
        {
            if (_mspDates != null)
            {
                return;
            }

            var createNewConnection = (dbConnection == null);

            if (createNewConnection)
            {
                dbConnection = Create();
            }

            using (var command = new DbCommand("MASDATA_CURRENT.dbo.Get_DataEffectiveDates", dbConnection))
            {
                _mspDates = command.ExecuteDataTable();
            }

            if (createNewConnection)
            {
                dbConnection.Dispose();
            }
        }
    }


}
