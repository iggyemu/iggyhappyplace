﻿using System;
using System.Data.SqlClient;

namespace Ditech.Servicing.Data.Common
{
    public static partial class Connection
    {
        /// <summary>
        /// Checks if there is currently month end data in MASDATA_CURRENT
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <returns></returns>
        public static bool IsMonthEnd(SqlConnection dbConnection = null)
        {
            var lastRunDate = GetMSPLastRunDate(dbConnection);
            var lastMonthEnd = GetMSPLastMonthEndDate(dbConnection);

            if (!lastRunDate.HasValue || !lastMonthEnd.HasValue)
            {
                return false;
            }

            return lastRunDate.Value.Date == lastMonthEnd.Value.Date;
        }
    }
}
