﻿using System.Data;
using System.Data.SqlClient;
using Ditech.Data.Common;

namespace Ditech.Servicing.Data.Common
{
    /// <summary>
    /// Class for creating database connections.
    /// </summary>
    public static partial class Connection
    {
        /// <summary>
        /// Determines whether the file entry exists in ReportParsedFiles in the MspReports database.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="connection">The connection.</param>
        /// <returns>
        /// 	<c>true</c> if [is file parsed] [the specified file]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsFileParsed(string fileName, SqlConnection connection)
        {
            bool result;

            // Check if the file has been parsed before
            using (var command = new DbCommand("MSPReports.dbo.sp_ReportParser_IsFileParsed", connection))
            {
                command.AddWithValue("@FILENAME", fileName);

                var reportCount = int.Parse(command.ExecuteScalar().ToString());

                result = reportCount > 0;
            }

            return result;
        }
    }
}
