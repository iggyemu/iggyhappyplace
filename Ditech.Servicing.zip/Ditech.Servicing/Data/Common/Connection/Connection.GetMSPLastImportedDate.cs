﻿using System;
using System.Data.SqlClient;

namespace Ditech.Servicing.Data.Common
{
    public static partial class Connection
    {
        /// <summary>
        /// Pulls the last last import end date from MASDATA_CURRENT
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <returns></returns>
        public static DateTime? GetMSPLastImportedDate(SqlConnection dbConnection = null)
        {
            SetMspDates(dbConnection);

            return Convert.ToNullableDateTime(_mspDates.Rows[0]["LAST_IMPORT_END_DATE"]);
        }
    }
}
