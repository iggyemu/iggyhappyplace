﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Ditech.Data.Common;

namespace Ditech.Servicing.Data.Common
{
    public static class Database
    {
        /// <summary>
        /// Executes the stored procedure on the Msp database.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public static DataTable ExecuteStoredProcedure(string storedProcedureName, string[,] parameters)
        {
            return ExecuteStoredProcedure(storedProcedureName, parameters, SqlDbName.MSP_APPLICATIONS);
        }

        /// <summary>
        /// Executes the stored procedure.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public static DataTable ExecuteStoredProcedure(string storedProcedureName, string[,] parameters, SqlDbName databaseName)
        {
            return ExecuteStoredProcedure(storedProcedureName, false, parameters, true, databaseName);
        }

        /// <summary>
        /// Executes the stored procedure.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="databaseName">The development database.</param>
        /// <returns></returns>
        public static DataTable ExecuteStoredProcedure(string storedProcedureName, SqlDbName databaseName)
        {
            return ExecuteStoredProcedure(storedProcedureName, false, null, true, databaseName);
        }


        /// <summary>
        /// Executes the stored procedure.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="isExecuteNonQuery">if set to <c>true</c> (default false) [is execute non query].</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public static DataTable ExecuteStoredProcedure(string storedProcedureName, bool isExecuteNonQuery, string[,] parameters)
        {
            return ExecuteStoredProcedure(storedProcedureName, isExecuteNonQuery, parameters, true, SqlDbName.MSP_APPLICATIONS);
        }

        /// <summary>
        /// Executes the stored procedure.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="isExecuteNonQuery">if set to <c>true</c> (default false) [is execute non query].</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="isIntegratedAuthentication">if set to <c>true</c> (default true) [is integrated authentication].</param>
        /// <param name="databaseName">Name of the database.</param>
        /// <returns></returns>
        public static DataTable ExecuteStoredProcedure(string storedProcedureName, bool isExecuteNonQuery, string[,] parameters,
                                                bool isIntegratedAuthentication, SqlDbName databaseName)
        {
            DataTable result = null;
            try
            {
                using (var connection = Connection.Create(databaseName: databaseName.ToString()))
                {
                    using (var dbCommand = new DbCommand(storedProcedureName, connection))
                    {
                        if (parameters != null)
                        {
                            for (int i = 0; i <= parameters.GetUpperBound(0); i++)
                            {
                                dbCommand.AddWithValue(parameters[i, 0], parameters[i, 1]);
                            }
                        }

                        if (isExecuteNonQuery)
                        {
                            dbCommand.ExecuteNonQuery();
                        }
                        else
                        {
                            result = dbCommand.ExecuteDataTable();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            return result;
        }
    }
}
