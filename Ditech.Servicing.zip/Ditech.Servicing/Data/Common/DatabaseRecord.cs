﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;

namespace Ditech.Servicing.Data.Common
{
    public class DatabaseRecord
    {
        private static IPropertywiseInstantiatorCache propertywiseInstantiatorCache;

        static DatabaseRecord()
        {
            propertywiseInstantiatorCache = new PropertywiseInstantiatorCacheUnlimitedDictionary();
            propertywiseInstantiatorCache.Initialize(string.Empty);
        }

        public static List<T> GetListFromDatabase<T>(CommandType cmdType, string databaseName, string nameOrSql, Dictionary<string, object> parameters = null, SqlTransaction transaction = null)
        {
            List<T> result = new List<T>();
            using (var connection = Connection.Create(null, databaseName))
            {
                using (var command = new SqlCommand(nameOrSql, connection, transaction))
                {
                    command.CommandType = cmdType;
                    if (parameters != null)
                        foreach (KeyValuePair<string, object> kvp in parameters)
                            command.Parameters.AddWithValue(kvp.Key, kvp.Value);
                    connection.Open();
                    using (SqlDataReader rdr = command.ExecuteReader())
                    {
                        if (rdr.HasRows)
                        {
                            Func<IDataReader, T> instantiator
                                = propertywiseInstantiatorCache.GetOrCreatePropertywiseInstantiator<IDataReader, T>("*", () => PropertywiseInstantiator.ConstructPropertywiseInstantiatorFromDataReader<T>(rdr));
                            while (rdr.Read())
                            {
                                result.Add(instantiator(rdr));
                            }
                        }
                    }
                    connection.Close();
                }
            }
            return result;
        }

        public static T GetOneFromDatabase<T>(CommandType cmdType,
            string databaseName, string nameOrSql, Dictionary<string, object> parameters = null,
            SqlTransaction transaction = null)
        {
            List<T> result = GetListFromDatabase<T>(cmdType, databaseName, nameOrSql, parameters,
                transaction);
            if (result == null || result.Count < 1)
                return default(T);
            return result[0];
        }

        public static List<T> GetListFromStoredProcedure<T>(string databaseName, string storedProcName, Dictionary<string, object> parameters = null, SqlTransaction transaction = null)
        {
            return GetListFromDatabase<T>(CommandType.StoredProcedure, databaseName, storedProcName, parameters, transaction);
        }
        public static List<T> GetListFromSqlText<T>(string databaseName, string sqlText, Dictionary<string, object> parameters = null, SqlTransaction transaction = null)
        {
            return GetListFromDatabase<T>(CommandType.Text, databaseName, sqlText, parameters, transaction);
        }

        public static DataSet GetDataSetFromDatabase(CommandType cmdType, string databaseName, string nameOrSql, Dictionary<string, object> parameters = null, SqlTransaction transaction = null)
        {
            DataSet result = new DataSet();
            using (var connection = Connection.Create(null, databaseName))
            {
                using (var command = new SqlCommand(nameOrSql, connection, transaction))
                {
                    command.CommandType = cmdType;
                    if (parameters != null)
                        foreach (KeyValuePair<string, object> kvp in parameters)
                            command.Parameters.AddWithValue(kvp.Key, kvp.Value);
                    connection.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(command))
                        da.Fill(result);
                    connection.Close();
                }
            }
            return result;
        }

        public static DataSet GetDataSetFromStoredProcedure(string databaseName, string storedProcName, Dictionary<string, object> parameters = null, SqlTransaction transaction = null)
        {
            return GetDataSetFromDatabase(CommandType.StoredProcedure, databaseName, storedProcName, parameters, transaction);
        }

        public static DataSet GetDataSetFromSqlText(string databaseName, string sqlText, Dictionary<string, object> parameters = null, SqlTransaction transaction = null)
        {
            return GetDataSetFromDatabase(CommandType.Text, databaseName, sqlText, parameters, transaction);
        }
    }
}
