namespace Ditech.Servicing.Data.Common
{

    #region SqlDbName enum

    /// <summary>
    /// List of available databases.
    /// </summary>
    public enum SqlDbName
    {
        Logging,
        MASDATA_CURRENT,
        MSP_APPLICATIONS,
        MspReports,
        MSP_TRANSACTIONS
    }

    #endregion
}