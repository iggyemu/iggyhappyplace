﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using Ditech.Data.Common;
using Ditech.Servicing.Data.Common;
using DbCommand = Ditech.Data.Common.DbCommand;

namespace Ditech.Servicing.Data
{
    public static class Variable
    {
        /// Note: Ditech.Servicing.ServicingLogConfiguratorAttribute uses this class to read its configuration.
        /// This creates a scenario where the Log object below will be null which is why it is checked with each use.
        public static string Select(string appName, string variableName, SqlConnection connection = null)
        {
            bool connectionSet;

            connection = SetConnection(connection, out connectionSet);

            var result = string.Empty;

            using (var command = new DbCommand("MSP_APPLICATIONS.STORAGE.Select_Variable", connection, new[] { "@APP_NAME", "@VARIABLE_NAME" }, new[] { appName, variableName }))
            {
                result = command.ExecuteScalar().ToString();
            }

            DisposeConnection(connection, connectionSet);

            return result;
        }

        public static List<string> SelectList(string appName, string variableName, SqlConnection connection = null)
        {
            bool connectionSet;

            connection = SetConnection(connection, out connectionSet);

            var result = new List<string>();

            using (var command = new DbCommand("MSP_APPLICATIONS.STORAGE.Select_Variable", connection, new[] { "@APP_NAME", "@VARIABLE_NAME" }, new[] { appName, variableName }))
            {
                
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(Convert.ToString(reader["VALUE"]));
                    }
                }
            }

            DisposeConnection(connection, connectionSet);

            return result;
        }

        public static void Insert(string appName, string variableName, string value, SqlConnection connection = null)
        {
            bool connectionSet;

            connection = SetConnection(connection, out connectionSet);

            using (var command = new DbCommand("MSP_APPLICATIONS.STORAGE.Insert_Variable", connection))
            {
                command.AddWithValue("@APP_NAME", appName);
                command.AddWithValue("@VARIABLE_NAME", variableName);
                command.AddWithValue("@VALUE", value);

                command.ExecuteNonQuery();
            }

            DisposeConnection(connection, connectionSet);
        }

        public static void InsertList(string appName, string variableName, List<string> value, SqlConnection connection = null)
        {
            bool connectionSet;

            connection = SetConnection(connection, out connectionSet);

            using (var command = new DbCommand("MSP_APPLICATIONS.STORAGE.Insert_Variable", connection))
            {
                for (var i = 0; i < value.Count; i++)
                {
                    command.AddWithValue("@APP_NAME", appName);
                    command.AddWithValue("@VARIABLE_NAME", variableName);
                    command.AddWithValue("@SEQUENCE", (i + 1));
                    command.AddWithValue("@VALUE", value[i]);
                    command.ExecuteNonQuery();

                    command.Parameters.Clear();
                }
            }

            DisposeConnection(connection, connectionSet);
        }

        private static SqlConnection SetConnection(SqlConnection connection, out bool connectionSet)
        {
            connectionSet = false;

            if (connection == null)
            {
                connection = Connection.Create(SqlDbName.MSP_APPLICATIONS);
                connectionSet = true;
            }

            return connection;
        }

        private static void DisposeConnection(SqlConnection connection, bool connectionSet)
        {
            if (connectionSet)
            {
                connection.Dispose();
            }
        }

    }
}
