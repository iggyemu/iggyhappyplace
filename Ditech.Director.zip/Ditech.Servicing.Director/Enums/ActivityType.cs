﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ditech.Servicing.Director.Enums
{
    public enum ActivityType
    {
        AllActivity = 0,
        AllNotes = 1,
        AnalysisNotes = 2,
        ARMNotes = 3,
        BalloonNotes = 4,
        BankruptcyActivity = 5,
        BankruptcyNotes = 6,
        BillingActivity = 7,
        CollectionContacts = 8,
        CorporateAdvanceActivity = 9,
        CustomerServiceContacts = 10,
        EquityLineofCreditActivity = 11,
        EquityLineofCreditNotes = 12,
        EscrowActivity = 13,
        FeeActivity = 14,
        ForeclosureHistory = 15,
        ForeclosureNotes = 16,
        FutureActivity = 17,
        HazardActivity = 18,
        HazardNotes = 19,
        History = 20,
        LateChargeActivity = 21,
        LetterLog = 22,
        LienActivity = 23,
        LossMitigationHistory = 24,
        LossMitigationNotes = 25,
        Memos = 26,
        MiscellaneousActivity = 27,
        MiscellaneousDisbursements = 28,
        MortgageInsuranceActivity = 29,
        MortgageInsuranceNotes = 30,
        OptionalInsuranceActivity = 31,
        PAndIPlusInterestRateChanges = 32,
        PaymentAndReversal = 33,
        REOHistory = 34,
        REONotes = 35,
        SuspenseActivity = 36,
        TaskHistoryAndNotes = 37,
        TaxActivity = 38,
        TaxNotes = 39
    }
}
