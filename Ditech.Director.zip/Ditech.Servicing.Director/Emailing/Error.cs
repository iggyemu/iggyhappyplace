using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;
//using Ditech.CoreServices.Network;

namespace Ditech.Servicing.Director.Emailing
{
    /// <summary>
    /// This class is used for logging the success and failure of scheduled jobs.
    /// </summary>
    public class Error
    {
        ///// <summary>
        ///// Logs process failures
        ///// </summary>
        ///// <param name="ex">The exception.</param>
        ///// <param name="emailAddresses">The email addresses.</param>
        ///// <param name="additionalErrorInfo">The additional error information.</param>
        ///// <param name="notifyOperations">if set to <c>true</c> [notify operations].</param>
        //public void LogProcessFailure(Exception ex, string[] emailAddresses, string additionalErrorInfo,
        //                              bool notifyOperations)
        //{
        //    SendFailureEmail("Howard.Greisman@Ditech.com", additionalErrorInfo, emailAddresses, notifyOperations);
        //}

        ///// <summary>
        ///// Logs the process failure.
        ///// </summary>
        ///// <param name="ex">The exception.</param>
        ///// <param name="sendNotice">if set to <c>true</c> [send email].</param>
        //public void LogProcessFailure(Exception ex, bool sendNotice)
        //{
        //    if (sendNotice)
        //    {
        //        // Send an e-mail to alert the the process failed
        //        string[] emailRecipients = {
        //                                       "Howard.Greisman@Ditech.com", "Howard.Greisman@Ditech.com"
        //                                   };


        //        SendFailureEmail("Howard.Greisman@Ditech.com", string.Empty, emailRecipients, true);
        //    }
        //}
        ///// <summary>
        ///// Sends the failure email.
        ///// </summary>
        ///// <param name="senderAddress">The sender address.</param>
        ///// <param name="additionalText">The additional text.</param>
        ///// <param name="emailRecipients">The email recipients.</param>
        ///// <param name="notifyOperations">if set to <c>true</c> [notify operations].</param>
        //private void SendFailureEmail(string senderAddress, string additionalText, string[] emailRecipients,
        //                              bool notifyOperations)
        //{
        //    try
        //    {
        //        string emailBody = string.Format(
        //            "Full details available at: http://z-amc2157/Operations/ProcessLogProd.asp?ID={0}\r\n\r\n",
        //            eventID);
        //        emailBody += string.Format("Process ID: {0}\r\n", eventID);
        //        emailBody += string.Format("Operator Name: {0}\r\n", processUser);
        //        emailBody += string.Format("Machine Name: {0}\r\n", processMachine);
        //        emailBody += string.Format("Start Class: {0}\r\n", processClass);
        //        emailBody += string.Format("Error Method: {0}\r\n", baseMethod);
        //        emailBody += string.Format("Error Message: {0}\r\n", failureException.Message);
        //        emailBody += string.Format("\r\n{0}\r\n\r\n", failureException.StackTrace);
        //        emailBody += additionalText;

        //        Email.SendEmail(senderAddress, emailRecipients,
        //                        processName + " (" + baseClass + ") Failed!", emailBody, notifyOperations);
        //    }
        //    catch (Exception ex)
        //    {
        //        LogProcessFailure(ex);
        //    }
        //}

    }
}