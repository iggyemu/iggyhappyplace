﻿namespace Ditech.Servicing.Director
{
    /// <summary>
    /// Simple interface to help abstract the most common functionality for the Msp3270 class.
    /// </summary>
    public interface IMsp3270
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <param name="screenName"></param>
        /// <param name="subScreen"></param>
        void GoToScreen(string loanNumber, string screenName, string subScreen);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="row"></param>
        /// <param name="column"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        string ReadData(int row, int column, int length);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="keyType"></param>
        /// <param name="row"></param>
        /// <param name="column"></param>
        void SendKey(string keyType, int row, int column);

        /// <summary>
        /// 
        /// </summary>
        void CommitChanges();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="row"></param>
        /// <param name="column"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        bool IsFieldProtected(int row, int column, int length);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="row"></param>
        /// <param name="column"></param>
        /// <param name="value"></param>
        void WriteData(int row, int column, string value);
    }
}