

using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Ditech.Servicing.Director.Forms
{
    /// <summary>
    /// Prompts the user for a loan number.
    /// </summary>
    public partial class GetLoanNumber : Form
    {
		#region�Constructors�(1)�

        /// <summary>
        /// Initializes a new instance of the <see cref="GetLoanNumber"/> class.
        /// </summary>
        public GetLoanNumber(string[] message)
        {
            InitializeComponent();

            if (message != null)
            {
                lblMessage.Text = message[0];
            }

            Loan.PreviousLoanNumber = Msp3270.LoanNumber;
            txtLoanNumber.Text = Msp3270.LoanNumber;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetLoanNumber"/> class.
        /// </summary>
        public GetLoanNumber()
            : this(null)
        {
        }

		#endregion�Constructors�

		#region�Methods�(3)�

		//�Private�Methods�(3)�

        /// <summary>
        /// When user clicks cancel or the 'X' button, throw an exception to trigger the MessageBox from the global exception handler.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
            Environment.Exit(-1);
        }

        /// <summary>
        /// When user clicks submit, set the 3270 loan number to the entered value.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (errorProvider.GetError(txtLoanNumber).Equals(string.Empty))
            {
                Msp3270.LoanNumber = txtLoanNumber.Text;
                Close();
            }
        }

        /// <summary>
        /// Check to make sure the loan number is valid.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.CancelEventArgs"/> instance containing the event data.</param>
        private void txtLoanNumber_Validating(object sender, CancelEventArgs e)
        {
            txtLoanNumber.Text = txtLoanNumber.Text.PadLeft(10, '0');

            if (!txtLoanNumber.Text.IsLoanNumber())
            {
                errorProvider.SetError(txtLoanNumber, "Please enter a valid loan number.");
            }
            else
            {
                errorProvider.SetError(txtLoanNumber, string.Empty);
            }
        }

		#endregion�Methods�
    }
}