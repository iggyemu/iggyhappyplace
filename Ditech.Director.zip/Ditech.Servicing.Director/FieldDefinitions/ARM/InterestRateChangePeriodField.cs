

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class InterestRateChangePeriodField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InterestRateChangePeriodField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public InterestRateChangePeriodField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "ARMU";
            ReadWindowName = "DATE";
            ReadRow = 12;
            ReadColumn = 13;
            ReadLength = 3;

            WriteScreenName = "ARMU";
            WriteWindowName = "DATE";
            WriteRow = 12;
            WriteColumn = 13;

        }
    }
}