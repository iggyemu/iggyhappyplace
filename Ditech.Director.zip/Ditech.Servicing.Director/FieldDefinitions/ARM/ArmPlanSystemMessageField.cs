namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ArmPlanSystemMessageField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ArmPlanSystemMessageField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ArmPlanSystemMessageField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "ARMU";
            ReadWindowName = "DATE";
            ReadRow = 22;
            ReadColumn = 2;
            ReadLength = 49;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}