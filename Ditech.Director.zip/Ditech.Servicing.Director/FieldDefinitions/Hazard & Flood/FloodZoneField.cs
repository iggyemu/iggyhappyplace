

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Flood Zone
    /// </summary>
    public class FloodZoneField : MspField
    {
        #region�Constructors�(1)�

        /// <summary>
        /// Initializes a new instance of the <see cref="FloodZoneField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public FloodZoneField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "HAZ1";
            ReadWindowName = "FLOD";
            ReadRow = 7;
            ReadColumn = 19;
            ReadLength = 3;

            WriteScreenName = "HAZ1";
            WriteWindowName = "FLOD";
            WriteRow = 7;
            WriteColumn = 19;
        }

        #endregion�Constructors�
    }
}