namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Flood Zone
    /// </summary>
    public class HazardExpiresDateField : MspField
    {
        #region�Constructors�(1)�

        /// <summary>
        /// Initializes a new instance of the <see cref="HazardExpiresDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public HazardExpiresDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "HAZ1";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 24;
            ReadLength = 8;

            WriteScreenName = "HAZ1";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 24;

            DatePattern = "MM/dd/yy";
        }

        #endregion�Constructors�
    }
}