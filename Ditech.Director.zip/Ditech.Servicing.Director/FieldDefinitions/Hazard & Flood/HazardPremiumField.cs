namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Flood Zone
    /// </summary>
    public class HazardPremiumField : MspField
    {
        #region�Constructors�(1)�

        /// <summary>
        /// Initializes a new instance of the <see cref="HazardPremiumField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public HazardPremiumField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "HAZ1";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 33;
            ReadLength = 9;

            WriteScreenName = "HAZ1";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 33;
        }

        #endregion�Constructors�
    }
}