namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class ForeclosureAttorneyField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ForeclosureAttorneyField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ForeclosureAttorneyField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "FOR1";
            ReadWindowName = "STAT";
            ReadRow = 21;
            ReadColumn = 16;
            ReadLength = 24;

            WriteScreenName = "FOR1";
            WriteWindowName = "STAT";
            WriteRow = 21;
            WriteColumn = 16;
        }
    }
}