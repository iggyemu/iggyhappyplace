namespace Ditech.Servicing.Director.MspFields
{

    public class ForeclosureAttorneyPhoneNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ForeclosureAttorneyPhoneNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ForeclosureAttorneyPhoneNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "FOR1";
            ReadWindowName = "STAT";
            ReadRow = 22;
            ReadColumn = 16;
            ReadLength = 14;

            WriteScreenName = "FOR1";
            WriteWindowName = "STAT";
            WriteRow = 22;
            WriteColumn = 16;
        }
    }
}