namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class ForeclosureStatusField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ForeclosureStatusField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ForeclosureStatusField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "FOR1";
            ReadWindowName = "STAT";
            ReadRow = 6;
            ReadColumn = 4;
            ReadLength = 1;

            WriteScreenName = "FOR1";
            WriteWindowName = "STAT";
            WriteRow = 6;
            WriteColumn = 4;

            ValidData = new[] {"A","C","D"};

        }
    }
}