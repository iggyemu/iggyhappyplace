﻿namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Gets the foreclosure stop value
    /// </summary>
    public class ForeclosureStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ForeclosureStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ForeclosureStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 14;
            ReadColumn = 53;
            ReadLength = 1;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}