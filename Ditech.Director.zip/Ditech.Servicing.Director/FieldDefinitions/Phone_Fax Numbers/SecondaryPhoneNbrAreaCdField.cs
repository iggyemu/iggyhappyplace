

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class SecondaryPhoneNbrAreaCdField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SecondaryPhoneNbrAreaCdField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public SecondaryPhoneNbrAreaCdField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 17;
            ReadColumn = 19;
            ReadLength = 3;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 17;
            WriteColumn = 19;

        }
    }
}