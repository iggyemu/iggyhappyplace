

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PrimaryPhoneNumberLocal3Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrimaryPhoneNumberLocal3Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PrimaryPhoneNumberLocal3Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 17;
            ReadColumn = 7;
            ReadLength = 3;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 17;
            WriteColumn = 7;

        }
    }
}