

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PrimaryPhoneNumberLocal4Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrimaryPhoneNumberLocal4Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PrimaryPhoneNumberLocal4Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 17;
            ReadColumn = 11;
            ReadLength = 4;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 17;
            WriteColumn = 11;

        }
    }
}