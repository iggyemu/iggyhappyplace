namespace Ditech.Servicing.Director.MspFields
{

    public class DelinquencyRepaymentPlanDueDateLine2Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyRepaymentPlanDueDateLine2Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyRepaymentPlanDueDateLine2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ2";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 8;
            ReadLength = 6;

            WriteScreenName = "DLQ2";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 8;

            DatePattern = "MMddyy";
        }
    }
}