namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyRepaymentPlanActionNumberField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyRepaymentPlanActionNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyRepaymentPlanActionNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 5;
            ReadLength = 2;

            WriteScreenName = "DLQ2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 5;
        }
    }
}