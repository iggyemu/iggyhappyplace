namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyLoanMaintenanceLateChargeReasonField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyLoanMaintenanceLateChargeReasonField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyLoanMaintenanceLateChargeReasonField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DLQ4";
            WriteWindowName = "MAIN";
            WriteRow = 10;
            WriteColumn = 4;
        }
    }
}