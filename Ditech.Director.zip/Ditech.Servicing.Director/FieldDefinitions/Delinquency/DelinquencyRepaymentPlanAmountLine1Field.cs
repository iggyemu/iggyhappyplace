namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyRepaymentPlanAmountLine1Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyRepaymentPlanAmountLine1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyRepaymentPlanAmountLine1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 15;
            ReadLength = 10;

            WriteScreenName = "DLQ2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 15;
        }
    }
}