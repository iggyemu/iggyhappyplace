﻿namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Number of times the loan has been delinquent in the last 12 months.
    /// </summary>
    public class TimesDelinquentField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TimesDelinquentField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TimesDelinquentField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 20;
            ReadColumn = 73;
            ReadLength = 2;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}