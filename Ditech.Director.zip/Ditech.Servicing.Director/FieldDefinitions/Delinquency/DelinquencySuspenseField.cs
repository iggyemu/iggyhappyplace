namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencySuspenseField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencySuspenseField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencySuspenseField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ1";
            ReadWindowName = "COM2";
            ReadRow = 8;
            ReadColumn = 10;
            ReadLength = 13;

            WriteScreenName = "DLQ1";
            WriteWindowName = "COM2";
            WriteRow = 8;
            WriteColumn = 10;
        }
    }
}