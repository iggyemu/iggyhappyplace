namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyRepaymentPlanActionField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyRepaymentPlanActionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyRepaymentPlanActionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ2";
            ReadWindowName = "PLAN";
            ReadRow = 7;
            ReadColumn = 2;
            ReadLength = 1;

            WriteScreenName = "DLQ2";
            WriteWindowName = "PLAN";
            WriteRow = 7;
            WriteColumn = 2;

            ValidData = new [] {"A", "C", "D"};
        }
    }
}