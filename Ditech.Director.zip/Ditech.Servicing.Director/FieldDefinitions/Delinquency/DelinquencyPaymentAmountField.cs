namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyPaymentAmountField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyPaymentAmountField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyPaymentAmountField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ1";
            ReadWindowName = "COM2";
            ReadRow = 4;
            ReadColumn = 31;
            ReadLength = 16;

            WriteScreenName = "DLQ1";
            WriteWindowName = "COM2";
            WriteRow = 4;
            WriteColumn = 31;
        }
    }
}