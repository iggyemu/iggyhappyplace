namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyRepaymentPlanDueDateLine1Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyRepaymentPlanDueDateLine1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyRepaymentPlanDueDateLine1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 8;
            ReadLength = 6;

            WriteScreenName = "DLQ2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 8;

            DatePattern = "MMddyy";
        }
    }
}