namespace Ditech.Servicing.Director.MspFields
{

    public class DelinquencyRepaymentPlanAmountLine2Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyRepaymentPlanAmountLine2Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyRepaymentPlanAmountLine2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ2";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 15;
            ReadLength = 10;

            WriteScreenName = "DLQ2";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 15;
        }
    }
}