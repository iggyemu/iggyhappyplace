namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKN Log Code Field
    /// </summary>
    public class TaskActionField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="TaskActionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaskActionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "TSK1";
            ReadWindowName = "TASK";
            ReadRow = 6;
            ReadColumn = 6;
            ReadLength = 1;

            WriteScreenName = "TSK1";
            WriteWindowName = "TASK";
            WriteRow = 6;
            WriteColumn = 6;
            ValidData = new[] {"C", "D", "R", "U"};
        }
    }
}