
namespace Ditech.Servicing.Director.MspFields
{


    public class MemoPadLifeOfLoanField : MspField
    {


        public MemoPadLifeOfLoanField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 17;
            ReadLength = 60;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 5;
            WriteColumn = 17;
        }
    }
}