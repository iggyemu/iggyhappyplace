namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyCommentLine1Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyCommentLine1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyCommentLine1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DLQ1";
            WriteWindowName = "COM2";
            WriteRow = 19;
            WriteColumn = 20;

            WriteAdditionalKeys = new[] { DirectorKeys.PF3 };

            AdditionalKeysWriteVerification.Screen = "DLQ1";
            AdditionalKeysWriteVerification.SubScreen = "COM3";
            AdditionalKeysWriteVerification.Row = 16;
            AdditionalKeysWriteVerification.Column = 3;
            AdditionalKeysWriteVerification.SearchValue = "COM3";
        }
    }
}