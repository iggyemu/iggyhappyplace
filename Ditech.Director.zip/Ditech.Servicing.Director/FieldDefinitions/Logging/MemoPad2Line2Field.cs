
namespace Ditech.Servicing.Director.MspFields
{


    public class MemoPad2Line2Field : MspField
    {


        public MemoPad2Line2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 18;
            WriteColumn = 17;
        }
    }
}