
namespace Ditech.Servicing.Director.MspFields
{


    public class MemoPad1Line1Field : MspField
    {


        public MemoPad1Line1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 9;
            WriteColumn = 17;
        }
    }
}