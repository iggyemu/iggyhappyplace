namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKN Log Code Field
    /// </summary>
    public class LossMitigationNoteLine7Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationNoteLine7Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationNoteLine7Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "LMTN";
            WriteWindowName = string.Empty;
            WriteRow = 17;
            WriteColumn = 24;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "LMTN";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 10;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "LOG CODE";
        }
    }
}