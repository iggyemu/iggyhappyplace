namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKM NoteLine 2 Field
    /// </summary>
    public class MassTaskNoteLine2Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="MassTaskNoteLine2Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MassTaskNoteLine2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "TSKM";
            WriteWindowName = string.Empty;
            WriteRow = 9;
            WriteColumn = 15;
        }
    }
}