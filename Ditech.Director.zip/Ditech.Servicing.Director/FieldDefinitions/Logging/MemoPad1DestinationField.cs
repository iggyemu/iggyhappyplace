
namespace Ditech.Servicing.Director.MspFields
{

    public class MemoPad1DestinationField : MspField
    {

        public MemoPad1DestinationField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 13;
            ReadLength = 3;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 13;

        }
    }
}