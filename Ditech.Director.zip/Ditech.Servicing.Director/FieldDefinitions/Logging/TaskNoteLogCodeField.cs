namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKN Log Code Field
    /// </summary>
    public class TaskNoteLogCodeField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="TaskNoteLogCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaskNoteLogCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "TSK1";
            WriteWindowName = "TASK";
            WriteRow = 11;
            WriteColumn = 3;

            WriteAdditionalKeys = new[] { DirectorKeys.PF10, DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "TSKN";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 10;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "LOG CODE";
        }
    }
}