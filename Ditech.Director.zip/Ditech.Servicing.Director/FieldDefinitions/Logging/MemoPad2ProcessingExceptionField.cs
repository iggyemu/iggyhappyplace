
namespace Ditech.Servicing.Director.MspFields
{

    public class MemoPad2ProcessingExceptionField : MspField
    {

        public MemoPad2ProcessingExceptionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 41;
            ReadLength = 1;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 41;

            ValidData = new [] {"Y","N"};
        }
    }
}