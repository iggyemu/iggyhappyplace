namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKM NoteLine 3 Field
    /// </summary>
    public class MassTaskNoteLine3Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="MassTaskNoteLine3Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MassTaskNoteLine3Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "TSKM";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 15;
        }
    }
}