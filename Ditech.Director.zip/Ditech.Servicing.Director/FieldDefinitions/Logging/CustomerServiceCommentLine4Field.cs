namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// SER1 NoteLine 4 Field
    /// </summary>
    public class CustomerServiceCommentLine4Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerServiceCommentLine4Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CustomerServiceCommentLine4Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "SER1";
            WriteWindowName = "LOAN";
            WriteRow = 14;
            WriteColumn = 13;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "SER1";
            AdditionalKeysWriteVerification.SubScreen = "COMM";
            AdditionalKeysWriteVerification.Row = 10;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "LOG CODE";
        }
    }
}