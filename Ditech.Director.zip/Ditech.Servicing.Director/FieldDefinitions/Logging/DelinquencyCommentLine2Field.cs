namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyCommentLine2Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyCommentLine2Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyCommentLine2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DLQ1";
            WriteWindowName = "COM3";
            WriteRow = 20;
            WriteColumn = 20;
        }
    }
}