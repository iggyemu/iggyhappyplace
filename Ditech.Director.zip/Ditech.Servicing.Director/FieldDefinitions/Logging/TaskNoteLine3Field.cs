namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKN NoteLine 3 Field
    /// </summary>
    public class TaskNoteLine3Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="TaskNoteLine3Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaskNoteLine3Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "TSK1";
            WriteWindowName = "TASK";
            WriteRow = 13;
            WriteColumn = 13;

            WriteAdditionalKeys = new[] { DirectorKeys.PF10, DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "TSK1";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 10;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "LOG CODE";
        }
    }
}