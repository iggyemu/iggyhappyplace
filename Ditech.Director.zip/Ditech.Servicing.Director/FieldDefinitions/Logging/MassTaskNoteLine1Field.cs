namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKM NoteLine 1 Field
    /// </summary>
    public class MassTaskNoteLine1Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="MassTaskNoteLine1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MassTaskNoteLine1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "TSKM";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 15;
        }
    }
}