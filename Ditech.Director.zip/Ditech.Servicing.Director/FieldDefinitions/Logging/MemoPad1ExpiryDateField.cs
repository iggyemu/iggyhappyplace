
namespace Ditech.Servicing.Director.MspFields
{


    public class MemoPad1ExpiryDateField : MspField
    {


        public MemoPad1ExpiryDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 23;
            ReadLength = 8;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 23;

            DatePattern = "MM/dd/yy";
        }
    }
}