namespace Ditech.Servicing.Director.MspFields
{

    public class HazardNoteLine5Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="HazardNoteLine5Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public HazardNoteLine5Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "HAZN";
            WriteWindowName = string.Empty;
            WriteRow = 15;
            WriteColumn = 24;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "HAZN";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 10;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "LOG CODE";
        }
    }
}