namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKN Log Code Field
    /// </summary>
    public class TaskResponsibleNameField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="TaskResponsibleNameField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaskResponsibleNameField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "TSK1";
            WriteWindowName = "TASK";
            WriteRow = 9;
            WriteColumn = 51;
        }
    }
}