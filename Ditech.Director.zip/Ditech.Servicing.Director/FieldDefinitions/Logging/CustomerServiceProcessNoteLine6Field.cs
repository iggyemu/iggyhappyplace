

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class CustomerServiceProcessNoteLine6Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerServiceProcessNoteLine6Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CustomerServiceProcessNoteLine6Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "SER2";
            WriteWindowName = "NOTE";
            WriteRow = 10;
            WriteColumn = 20;

        }
    }
}