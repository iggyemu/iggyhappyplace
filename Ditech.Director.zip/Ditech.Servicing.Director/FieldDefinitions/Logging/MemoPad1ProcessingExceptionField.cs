namespace Ditech.Servicing.Director.MspFields
{

    public class MemoPad1ProcessingExceptionField : MspField
    {

        public MemoPad1ProcessingExceptionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 41;
            ReadLength = 1;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 41;

            ValidData = new [] {"Y","N"};
        }
    }
}