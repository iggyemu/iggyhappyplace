
namespace Ditech.Servicing.Director.MspFields
{

    public class MemoPad1DeleteField : MspField
    {

        public MemoPad1DeleteField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 54;
            ReadLength = 1;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 54;

            ValidData = new [] {"Y","N"};
        }
    }
}