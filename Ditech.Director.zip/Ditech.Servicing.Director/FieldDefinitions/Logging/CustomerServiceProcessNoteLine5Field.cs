

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class CustomerServiceProcessNoteLine5Field : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerServiceProcessNoteLine5Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CustomerServiceProcessNoteLine5Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "SER2";
            WriteWindowName = "NOTE";
            WriteRow = 9;
            WriteColumn = 20;

        }
    }
}