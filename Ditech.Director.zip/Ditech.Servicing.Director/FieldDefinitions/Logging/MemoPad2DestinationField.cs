
namespace Ditech.Servicing.Director.MspFields
{

    public class MemoPad2DestinationField : MspField
    {

        public MemoPad2DestinationField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 13;
            ReadLength = 3;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 13;

        }
    }
}