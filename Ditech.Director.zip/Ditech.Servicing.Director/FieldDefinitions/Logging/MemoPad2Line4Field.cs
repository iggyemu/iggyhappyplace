
namespace Ditech.Servicing.Director.MspFields
{


    public class MemoPad2Line4Field : MspField
    {


        public MemoPad2Line4Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 20;
            WriteColumn = 17;
        }
    }
}