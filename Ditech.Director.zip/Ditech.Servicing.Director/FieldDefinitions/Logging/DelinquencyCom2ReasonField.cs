

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Response Field on DLQ1 Screen 1
    /// </summary>
    public class DelinquencyCom2ReasonField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="DelinquencyCom2ReasonField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DelinquencyCom2ReasonField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DLQ1";
            WriteWindowName = "COM2";
            WriteRow = 18;
            WriteColumn = 52;
        }
    }
}