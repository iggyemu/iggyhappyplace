
namespace Ditech.Servicing.Director.MspFields
{

    public class MemoPad2DeleteField : MspField
    {

        public MemoPad2DeleteField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MEM1";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 54;
            ReadLength = 1;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 54;

            ValidData = new [] {"Y","N"};
        }
    }
}