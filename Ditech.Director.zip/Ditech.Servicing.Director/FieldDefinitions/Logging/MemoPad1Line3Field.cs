
namespace Ditech.Servicing.Director.MspFields
{


    public class MemoPad1Line3Field : MspField
    {


        public MemoPad1Line3Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MEM1";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 17;
        }
    }
}