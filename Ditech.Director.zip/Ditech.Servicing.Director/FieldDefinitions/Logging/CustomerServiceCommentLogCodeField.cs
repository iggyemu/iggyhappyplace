namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// SER1 Log Code Field
    /// </summary>
    public class CustomerServiceCommentLogCodeField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerServiceCommentLogCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CustomerServiceCommentLogCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "SER1";
            WriteWindowName = "LOAN";
            WriteRow = 11;
            WriteColumn = 3;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "SER1";
            AdditionalKeysWriteVerification.SubScreen = "COMM";
            AdditionalKeysWriteVerification.Row = 10;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "LOG CODE";
        }
    }
}