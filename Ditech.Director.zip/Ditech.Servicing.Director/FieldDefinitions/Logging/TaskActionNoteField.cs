namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// TSKN Log Code Field
    /// </summary>
    public class TaskActionNoteField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="TaskActionNoteField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaskActionNoteField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "TSK1";
            ReadWindowName = "TASK";
            ReadRow = 6;
            ReadColumn = 10;
            ReadLength = 60;

            WriteScreenName = "TSK1";
            WriteWindowName = "TASK";
            WriteRow = 6;
            WriteColumn = 10;
        }
    }
}