namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class SecondaryLienHolderCurrentAmountField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SecondaryLienHolderCurrentAmountField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public SecondaryLienHolderCurrentAmountField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "SLH1";
            ReadRow = 12;
            ReadColumn = 42;
            ReadLength = 8;

            WriteScreenName = "MAS1";
            WriteWindowName = "SLH1";
            WriteRow = 12;
            WriteColumn = 42;
        }
    }
}