

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class CreditIndicatorSwitchExpiryDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditIndicatorSwitchExpiryDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CreditIndicatorSwitchExpiryDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "CBR1";
            ReadRow = 5;
            ReadColumn = 23;
            ReadLength = 6;

            WriteScreenName = "MAS1";
            WriteWindowName = "CBR1";
            WriteRow = 5;
            WriteColumn = 23;

            DatePattern = "MMddyy";

        }
    }
}