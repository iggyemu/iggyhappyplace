

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class CreditQualityPreviousDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditQualityPreviousDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CreditQualityPreviousDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "CBR1";
            ReadRow = 5;
            ReadColumn = 23;
            ReadLength = 6;

            WriteScreenName = "MAS1";
            WriteWindowName = "CBR1";
            WriteRow = 5;
            WriteColumn = 23;
        }
    }
}