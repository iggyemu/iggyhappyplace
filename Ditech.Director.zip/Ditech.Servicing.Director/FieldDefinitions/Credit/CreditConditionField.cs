

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    public class CreditConditionField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditConditionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CreditConditionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MAS1";
            WriteWindowName = "CBR1";
            WriteRow = 8;
            WriteColumn = 9;

        }
    }
}