

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class CreditIndicatorSwitchField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditIndicatorSwitchField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CreditIndicatorSwitchField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "CBR1";
            ReadRow = 5;
            ReadColumn = 9;
            ReadLength = 1;

            WriteScreenName = "MAS1";
            WriteWindowName = "CBR1";
            WriteRow = 5;
            WriteColumn = 9;
        }
    }
}