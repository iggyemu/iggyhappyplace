

namespace Ditech.Servicing.Director.MspFields
{
    public class FeeCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeeCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public FeeCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PMTA";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 11;
            ReadLength = 1;

            WriteScreenName = "PMTA";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 11;
        }
    }
}