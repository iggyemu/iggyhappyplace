

namespace Ditech.Servicing.Director.MspFields
{
    public class FeeAmountField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeeAmountField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public FeeAmountField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DLQ4";
            WriteWindowName = "MAIN";
            WriteRow = 10;
            WriteColumn = 28;
        }
    }
}