

namespace Ditech.Servicing.Director.MspFields
{
    public class ReasonCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReasonCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReasonCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DLQ4";
            WriteWindowName = "MAIN";
            WriteRow = 10;
            WriteColumn = 4;
        }
    }
}