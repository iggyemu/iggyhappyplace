namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// 
    /// </summary>
    public class MplIdField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MplIdField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MplIdField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "PYT1";
            ReadRow = 20;
            ReadColumn = 9;
            ReadLength = 4;

            WriteScreenName = "MAS1";
            WriteWindowName = "PYT1";
            WriteRow = 20;
            WriteColumn = 9;
        }
    }
}