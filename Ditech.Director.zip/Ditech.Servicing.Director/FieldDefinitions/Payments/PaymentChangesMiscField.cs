namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesMiscField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesMiscField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesMiscField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH2";
            ReadWindowName = "ESCR";
            ReadRow = 18;
            ReadColumn = 23;
            ReadLength = 6;

            WriteScreenName = "PCH2";
            WriteWindowName = "ESCR";
            WriteRow = 18;
            WriteColumn = 23;

        }
    }
}