

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesCurrentCountyField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesCurrentCountyField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesCurrentCountyField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 22;
            ReadLength = 11;

            WriteScreenName = "PCH1";
            WriteWindowName = string.Empty;
            WriteRow = 5;
            WriteColumn = 22;

        }
    }
}