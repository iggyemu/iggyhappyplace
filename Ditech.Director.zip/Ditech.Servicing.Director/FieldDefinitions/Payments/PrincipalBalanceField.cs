namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PrincipalBalanceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrincipalBalanceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PrincipalBalanceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 3;
            ReadColumn = 45;
            ReadLength = 12;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}