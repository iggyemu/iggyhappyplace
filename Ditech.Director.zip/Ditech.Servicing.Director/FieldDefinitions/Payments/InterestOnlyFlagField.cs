

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class InterestOnlyFlagField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InterestOnlyFlagField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public InterestOnlyFlagField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "PYT1";
            ReadRow = 18;
            ReadColumn = 65;
            ReadLength = 1;

            WriteScreenName = "MAS1";
            WriteWindowName = "PYT1";
            WriteRow = 18;
            WriteColumn = 65;

            ValidData = new [] {"Y","N"};
        }
    }
}