namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ClassCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClassCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ClassCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "COL1";
            ReadRow = 7;
            ReadColumn = 22;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "COL1";
            WriteRow = 7;
            WriteColumn = 22;

        }
    }
}