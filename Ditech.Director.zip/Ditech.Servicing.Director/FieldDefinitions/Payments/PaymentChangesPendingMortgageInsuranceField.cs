

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesPendingMortgageInsuranceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesPendingMortgageInsuranceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesPendingMortgageInsuranceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 41;
            ReadLength = 11;

            WriteScreenName = "PCH2";
            WriteWindowName = "ESCR";
            WriteRow = 12;
            WriteColumn = 20;

        }
    }
}