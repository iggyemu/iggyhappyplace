namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentAsOfDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentAsOfDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentAsOfDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY2";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 2;
            ReadLength = 8;

            WriteScreenName = "PAY2";
            WriteWindowName = string.Empty;
            WriteRow = 5;
            WriteColumn = 2;

            DatePattern = "MM/dd/yy";
        }
    }
}