namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentRefinanceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentRefinanceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentRefinanceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY2";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 24;
            ReadLength = 1;

            WriteScreenName = "PAY2";
            WriteWindowName = string.Empty;
            WriteRow = 5;
            WriteColumn = 24;

            ValidData = new [] {"Y", "N"};
        }
    }
}