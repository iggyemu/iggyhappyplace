

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class OfficeCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OfficeCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public OfficeCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "COL1";
            ReadRow = 7;
            ReadColumn = 5;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "COL1";
            WriteRow = 7;
            WriteColumn = 5;

        }
    }
}