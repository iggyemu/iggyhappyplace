

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesEffectiveDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesEffectiveDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesEffectiveDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 57;
            ReadLength = 5;

            WriteScreenName = "PCH2";
            WriteWindowName = "ESCR";
            WriteRow = 1;
            WriteColumn = 26;

            DatePattern = "MM/dd/yy";
        }
    }
}