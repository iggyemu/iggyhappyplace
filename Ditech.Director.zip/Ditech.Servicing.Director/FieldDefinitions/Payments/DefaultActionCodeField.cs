

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class DefaultActionCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultActionCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DefaultActionCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "DFT1";
            ReadRow = 6;
            ReadColumn = 11;
            ReadLength = 1;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 6;
            WriteColumn = 11;

            ValidData = new [] {"A","D"};
        }
    }
}