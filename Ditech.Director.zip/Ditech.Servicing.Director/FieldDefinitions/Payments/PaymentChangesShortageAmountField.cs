namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesShortageAmountField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesShortageAmountField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesShortageAmountField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 22;
            ReadLength = 10;

            WriteScreenName = "PCH2";
            WriteWindowName = "ESCR";
            WriteRow = 16;
            WriteColumn = 20;

        }
    }
}