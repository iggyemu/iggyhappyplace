namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentPrincipalBalanceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentPrincipalBalanceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentPrincipalBalanceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY4";
            ReadWindowName = string.Empty;
            ReadRow = 4;
            ReadColumn = 23;
            ReadLength = 15;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}