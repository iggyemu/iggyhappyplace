

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesCouponField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesCouponField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesCouponField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 69;
            ReadLength = 1;

            WriteScreenName = "PCH1";
            WriteWindowName = string.Empty;
            WriteRow = 5;
            WriteColumn = 69;

        }
    }
}