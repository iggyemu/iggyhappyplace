namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentWhichMortgageField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentWhichMortgageField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentWhichMortgageField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "PAY2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 65;
        }
    }
}