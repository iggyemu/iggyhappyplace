namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentRevisionField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentRevisionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentRevisionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY2";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 19;
            ReadLength = 1;

            WriteScreenName = "PAY2";
            WriteWindowName = string.Empty;
            WriteRow = 5;
            WriteColumn = 19;

            ValidData = new [] {"Y", "N"};
        }
    }
}