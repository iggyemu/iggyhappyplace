

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentModeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentModeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentModeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "PYT1";
            ReadRow = 5;
            ReadColumn = 26;
            ReadLength = 1;

            WriteScreenName = "MAS1";
            WriteWindowName = "PYT1";
            WriteRow = 5;
            WriteColumn = 26;

            ValidData = new [] {"0","1","4","5","6","7","8","9"};
        }
    }
}