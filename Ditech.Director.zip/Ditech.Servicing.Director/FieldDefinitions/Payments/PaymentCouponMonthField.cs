namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentCouponMonthField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentCouponMonthField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentCouponMonthField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "PYT1";
            ReadRow = 5;
            ReadColumn = 50;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "PYT1";
            WriteRow = 5;
            WriteColumn = 50;

            ValidData = new [] {"01","02","03","04","05","06","07","08","09","10","11","12"};
        }
    }
}