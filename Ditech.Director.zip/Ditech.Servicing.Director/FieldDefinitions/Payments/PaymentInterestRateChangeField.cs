namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentInterestRateChangeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentInterestRateChangeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentInterestRateChangeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY4";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 55;
            ReadLength = 11;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}