namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentCalculationInterestField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentCalculationInterestField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentCalculationInterestField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY2";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 43;
            ReadLength = 1;

            WriteScreenName = "PAY2";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 43;

            ValidData = new [] {"1", "2"};
        }
    }
}