namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentCalculationMethodField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentRevisionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentCalculationMethodField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 13;
            ReadLength = 1;

            WriteScreenName = "PAY2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 13;

            ValidData = new [] {"A", "B", "C", "F", "G"};
        }
    }
}