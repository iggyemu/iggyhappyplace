namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentInterestField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentInterestField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentInterestField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PAY4";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 23;
            ReadLength = 15;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}