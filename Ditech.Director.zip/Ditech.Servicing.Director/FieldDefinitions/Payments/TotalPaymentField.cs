﻿namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// The total monthly payment
    /// </summary>
    public class TotalPaymentField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TotalPaymentField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TotalPaymentField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 19;
            ReadColumn = 31;
            ReadLength = 10;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}