

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesCurrentCityField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesCurrentCityField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesCurrentCityField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 22;
            ReadLength = 11;

            WriteScreenName = "PCH1";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 22;

        }
    }
}