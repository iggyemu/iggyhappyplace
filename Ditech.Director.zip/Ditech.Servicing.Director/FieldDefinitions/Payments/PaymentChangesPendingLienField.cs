

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesPendingLienField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesPendingLienField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesPendingLienField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 9;
            ReadColumn = 41;
            ReadLength = 11;

            WriteScreenName = "PCH2";
            WriteWindowName = "ESCR";
            WriteRow = 14;
            WriteColumn = 20;

        }
    }
}