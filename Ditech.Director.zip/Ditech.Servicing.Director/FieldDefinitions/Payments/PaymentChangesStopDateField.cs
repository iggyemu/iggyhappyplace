

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PaymentChangesStopDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentChangesStopDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentChangesStopDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "PCH1";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 57;
            ReadLength = 5;

            WriteScreenName = "PCH1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 57;

            DatePattern = "MM/yy";
        }
    }
}