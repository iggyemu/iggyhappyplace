namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class TitleDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TitleDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TitleDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "HUDA";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 21;
            ReadLength = 8;

            WriteScreenName = "HUDA";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 21;

            DatePattern = "MM/dd/yy";

        }
    }
}