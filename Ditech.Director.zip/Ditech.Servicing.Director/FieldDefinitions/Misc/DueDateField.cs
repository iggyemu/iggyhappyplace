namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class DueDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DueDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DueDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SER1";
            ReadWindowName = "LOAN";
            ReadRow = 7;
            ReadColumn = 7;
            ReadLength = 9;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

            DatePattern = "MM/dd/yy";

        }
    }
}