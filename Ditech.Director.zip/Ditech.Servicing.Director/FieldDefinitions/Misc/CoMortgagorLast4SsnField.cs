﻿namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Comortgagor Last 4 SSN Field
    /// </summary>
    public class CoMortgagorLast4SsnField : MspField
    {
        /// <summary>
        /// Mortgagors the last4 SSN field.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CoMortgagorLast4SsnField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SER1";
            ReadWindowName = "LOAN";
            ReadRow = 3;
            ReadColumn = 37;
            ReadLength = 4;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}