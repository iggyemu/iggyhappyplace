namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LoTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 2;
            ReadColumn = 64;
            ReadLength = 1;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

            ValidData = new[] {"1","2","3","4","5","6","7","8","9"};

        }
    }
}