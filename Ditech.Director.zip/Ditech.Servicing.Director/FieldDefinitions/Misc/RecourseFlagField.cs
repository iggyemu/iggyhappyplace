﻿namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class RecourseFlagField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RecourseFlagField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public RecourseFlagField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "NOT1";
            ReadRow = 17;
            ReadColumn = 59;
            ReadLength = 1;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}