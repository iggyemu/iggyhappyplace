namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class MaturityDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MaturityDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MaturityDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "NOT1";
            ReadRow = 12;
            ReadColumn = 31;
            ReadLength = 4;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

            //DatePattern = "MMyy";

        }
    }
}