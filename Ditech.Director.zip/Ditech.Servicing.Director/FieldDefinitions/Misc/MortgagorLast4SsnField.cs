﻿namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Mortgagor Last 4 SSN Field
    /// </summary>
    public class MortgagorLast4SsnField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MortgagorLast4SsnField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MortgagorLast4SsnField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SER1";
            ReadWindowName = "LOAN";
            ReadRow = 2;
            ReadColumn = 37;
            ReadLength = 4;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}