﻿namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class LoanDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoanDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 15;
            ReadColumn = 67;
            ReadLength = 8;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

            DatePattern = "MM-dd-yy";
        }
    }
}