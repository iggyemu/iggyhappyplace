

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class LateChargeGraceDaysField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LateChargeGraceDaysField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LateChargeGraceDaysField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "LTE1";
            ReadRow = 20;
            ReadColumn = 4;
            ReadLength = 3;

            WriteScreenName = "MAS1";
            WriteWindowName = "LTE1";
            WriteRow = 20;
            WriteColumn = 4;

        }
    }
}