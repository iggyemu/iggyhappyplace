

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class FirstLegalActionDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FirstLegalActionDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public FirstLegalActionDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DLQ1";
            ReadWindowName = "FLED";
            ReadRow = 19;
            ReadColumn = 2;
            ReadLength = 6;

            WriteScreenName = "DLQ1";
            WriteWindowName = "FLED";
            WriteRow = 19;
            WriteColumn = 2;

            DatePattern = "MMddyy";

        }
    }
}