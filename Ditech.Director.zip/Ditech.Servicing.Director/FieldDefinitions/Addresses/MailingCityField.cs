

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class MailingCityField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailingCityField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MailingCityField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 10;
            ReadColumn = 11;
            ReadLength = 21;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 10;
            WriteColumn = 11;

        }
    }
}