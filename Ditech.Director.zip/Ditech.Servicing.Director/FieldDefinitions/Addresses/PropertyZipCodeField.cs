namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PropertyZipCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyZipCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PropertyZipCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 11;
            ReadColumn = 30;
            ReadLength = 5;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 11;
            WriteColumn = 30;

        }
    }
}