namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PropertyStreetNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyStreetNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PropertyStreetNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 9;
            ReadColumn = 30;
            ReadLength = 6;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 9;
            WriteColumn = 30;

        }
    }
}