namespace Ditech.Servicing.Director.MspFields
{
    public class EmailMortgagorField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EmailMortgagorField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EmailMortgagorField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 6;
            ReadColumn = 2;
            ReadLength = 66;

            ReadAdditionalKeys = new[] { DirectorKeys.PF15 };

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 6;
            WriteColumn = 2;

            WriteAdditionalKeys = new[] { DirectorKeys.PF15 };

            AdditionalKeysWriteVerification.Screen = "MAS1";
            AdditionalKeysWriteVerification.SubScreen = "ADD1";
            AdditionalKeysWriteVerification.Row = 5;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "MORTGAGOR E-MAIL";
        }
    }
}