

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class MailingZipCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailingZipCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MailingZipCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 11;
            ReadColumn = 11;
            ReadLength = 5;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 11;
            WriteColumn = 11;

        }
    }
}