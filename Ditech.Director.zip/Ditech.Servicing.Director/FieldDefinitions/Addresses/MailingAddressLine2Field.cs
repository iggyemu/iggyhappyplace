

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class MailingAddressLine2Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailingAddressLine2Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MailingAddressLine2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 8;
            ReadColumn = 11;
            ReadLength = 30;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 8;
            WriteColumn = 11;

        }
    }
}