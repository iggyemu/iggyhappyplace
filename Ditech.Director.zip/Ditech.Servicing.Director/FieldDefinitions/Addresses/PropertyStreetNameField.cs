namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PropertyStreetNameField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyStreetNameField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PropertyStreetNameField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 9;
            ReadColumn = 40;
            ReadLength = 20;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 9;
            WriteColumn = 40;

        }
    }
}