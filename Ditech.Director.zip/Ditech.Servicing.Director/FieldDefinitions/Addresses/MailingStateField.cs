

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class MailingStateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailingStateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MailingStateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 10;
            ReadColumn = 33;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 10;
            WriteColumn = 33;

        }
    }
}