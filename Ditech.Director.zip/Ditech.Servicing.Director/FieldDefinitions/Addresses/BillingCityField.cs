namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Billing Street (also called BILL-LINE-3)
    /// </summary>
    public class BillingCityField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingCityField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BillingCityField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 10;
            ReadColumn = 44;
            ReadLength = 20;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 10;
            WriteColumn = 44;
        }
    }
}