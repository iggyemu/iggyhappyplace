namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Billing Street (also called BILL-LINE-3)
    /// </summary>
    public class BillingStateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingStateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BillingStateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 10;
            ReadColumn = 65;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 10;
            WriteColumn = 65;
        }
    }
}