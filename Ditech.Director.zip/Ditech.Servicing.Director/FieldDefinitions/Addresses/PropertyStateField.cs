

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class PropertyStateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyStateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PropertyStateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 10;
            ReadColumn = 52;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 10;
            WriteColumn = 52;

        }
    }
}