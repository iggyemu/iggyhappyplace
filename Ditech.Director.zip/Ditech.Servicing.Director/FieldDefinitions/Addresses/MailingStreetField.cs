

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class MailingStreetField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailingStreetField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MailingStreetField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 9;
            ReadColumn = 11;
            ReadLength = 30;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 9;
            WriteColumn = 11;

        }
    }
}