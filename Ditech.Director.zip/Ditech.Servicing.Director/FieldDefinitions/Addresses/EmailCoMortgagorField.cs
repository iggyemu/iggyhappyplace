namespace Ditech.Servicing.Director.MspFields
{
    public class EmailCoMortgagorField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EmailCoMortgagorField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EmailCoMortgagorField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD1";
            ReadRow = 8;
            ReadColumn = 2;
            ReadLength = 66;

            ReadAdditionalKeys = new[] { DirectorKeys.PF15 };

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD1";
            WriteRow = 8;
            WriteColumn = 2;

            WriteAdditionalKeys = new[] { DirectorKeys.PF15 };

            AdditionalKeysWriteVerification.Screen = "MAS1";
            AdditionalKeysWriteVerification.SubScreen = "ADD1";
            AdditionalKeysWriteVerification.Row = 7;
            AdditionalKeysWriteVerification.Column = 2;
            AdditionalKeysWriteVerification.SearchValue = "CO-MORTGAGOR E-MAIL";
        }
    }
}