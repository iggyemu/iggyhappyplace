

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class MailingAddressLine1Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MailingAddressLine1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MailingAddressLine1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 7;
            ReadColumn = 11;
            ReadLength = 30;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 7;
            WriteColumn = 11;

        }
    }
}