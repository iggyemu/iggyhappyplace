

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Billing Zip Code
    /// </summary>
    public class BillingZipCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingZipCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BillingZipCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "ADD2";
            ReadRow = 11;
            ReadColumn = 44;
            ReadLength = 5;

            WriteScreenName = "MAS1";
            WriteWindowName = "ADD2";
            WriteRow = 11;
            WriteColumn = 44;
        }
    }
}