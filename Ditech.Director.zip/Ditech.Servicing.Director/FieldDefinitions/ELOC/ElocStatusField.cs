

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ElocStatusField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ElocStatusField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ElocStatusField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "ELC3";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 31;
            ReadLength = 1;

            WriteScreenName = "ELCU";
            WriteWindowName = "ORIG";
            WriteRow = 8;
            WriteColumn = 10;

            ValidData = new[] {"A"};

        }
    }
}