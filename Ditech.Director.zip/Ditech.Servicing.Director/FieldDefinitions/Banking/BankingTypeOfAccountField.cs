namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankingTypeOfAccountField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankingTypeOfAccountField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankingTypeOfAccountField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 61;
            ReadLength = 1;

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 61;

            ValidData = new [] {"C", "S"};

        }
    }
}