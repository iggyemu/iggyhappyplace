namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankingRoutingNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankingRoutingNumberField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankingRoutingNumberField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 8;
            ReadLength = 9;

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 8;

        }
    }
}