namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankingBankNameField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankingBankNameField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankingBankNameField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "AEG2";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 12;
            ReadLength = 23;

            WriteScreenName = "AEG2";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 12;

        }
    }
}