namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankingAccountNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankingAccountNumberField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankingAccountNumberField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 20;
            ReadLength = 17;

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 20;

        }
    }
}