namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class CustomerServiceRequestCoupon1Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerServiceRequestCoupon1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public CustomerServiceRequestCoupon1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "SER4";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 18;
        }
    }
}