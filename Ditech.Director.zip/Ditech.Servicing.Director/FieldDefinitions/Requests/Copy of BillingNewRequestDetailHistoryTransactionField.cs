namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class BillingNewRequestOptionsResetAlphaUserTableField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingNewRequestOptionsResetAlphaUserTableField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BillingNewRequestOptionsResetAlphaUserTableField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "BIL1";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 29;

            ValidData = new [] {"Y", "N"};
        }
    }
}