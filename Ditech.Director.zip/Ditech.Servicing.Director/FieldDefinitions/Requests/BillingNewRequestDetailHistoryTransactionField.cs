namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class BillingNewRequestDetailHistoryTransactionField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingNewRequestDetailHistoryTransactionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BillingNewRequestDetailHistoryTransactionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "BIL1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 48;

            ValidData = new [] {"Y", "N"};
        }
    }
}