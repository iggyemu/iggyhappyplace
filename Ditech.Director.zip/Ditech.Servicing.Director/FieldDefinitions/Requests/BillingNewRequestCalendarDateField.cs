namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class BillingNewRequestCalendarDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BillingNewRequestCalendarDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BillingNewRequestCalendarDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "BILR";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 40;
        }
    }
}