

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Late Charge Expire Date Field
    /// </summary>
    public class NoNoticeStopExpiryDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NoNoticeStopExpiryDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public NoNoticeStopExpiryDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 13;
            ReadColumn = 58;
            ReadLength = 8;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 13;
            WriteColumn = 58;

            DatePattern = "MM/dd/yy";
        }
    }
}