

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Stop
    /// </summary>
    public class LateChargeStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LateChargeStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LateChargeStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 12;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 12;
            WriteColumn = 27;
        }
    }
}