

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class BadCheckStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BadCheckStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BadCheckStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 12;
            ReadColumn = 53;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 9;
            WriteColumn = 27;
        }
    }
}