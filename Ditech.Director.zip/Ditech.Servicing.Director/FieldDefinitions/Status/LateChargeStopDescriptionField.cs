

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class LateChargeStopDescriptionField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LateChargeStopDescriptionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LateChargeStopDescriptionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 12;
            ReadColumn = 32;
            ReadLength = 25;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}