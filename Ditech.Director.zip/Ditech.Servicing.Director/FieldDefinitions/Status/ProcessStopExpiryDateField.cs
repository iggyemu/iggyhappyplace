namespace Ditech.Servicing.Director.MspFields
{

    public class ProcessStopExpiryDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessStopExpiryDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ProcessStopExpiryDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 58;
            ReadLength = 8;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 58;

            DatePattern = "MM/dd/yy";
        }
    }
}