namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Stop
    /// </summary>
    public class LifeSolicitationField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LifeSolicitationField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LifeSolicitationField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 18;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 18;
            WriteColumn = 27;
        }
    }
}