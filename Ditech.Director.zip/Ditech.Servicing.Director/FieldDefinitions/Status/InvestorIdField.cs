

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class InvestorIdField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvestorIdField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public InvestorIdField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SER1";
            ReadWindowName = "LOAN";
            ReadRow = 1;
            ReadColumn = 54;
            ReadLength = 3;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}