namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class OptOutStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptOutStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public OptOutStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 27;
            ReadLength = 1;

            ReadAdditionalKeys = new[] { DirectorKeys.PF8 };

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 27;

            WriteAdditionalKeys = new [] {DirectorKeys.PF8};

            AdditionalKeysWriteVerification.Screen = "SAF1";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 8;
            AdditionalKeysWriteVerification.Column = 12;
            AdditionalKeysWriteVerification.SearchValue = "OPT OUT";

        }
    }
}