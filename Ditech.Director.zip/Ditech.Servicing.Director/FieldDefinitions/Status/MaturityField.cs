namespace Ditech.Servicing.Director.MspFields
{

    public class MaturityField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MaturityField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MaturityField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 5;
            ReadColumn = 73;
            ReadLength = 5;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

            DatePattern = "MM/01/20yy";
        }
    }
}