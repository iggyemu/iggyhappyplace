

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Man Code (also called PERSON-CODE)
    /// </summary>
    public class ManCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ManCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ManCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 3;
            ReadColumn = 11;
            ReadLength = 1;

            WriteScreenName = "MAS1";
            WriteWindowName = "COL1";
            WriteRow = 7;
            WriteColumn = 13;
        }
    }
}