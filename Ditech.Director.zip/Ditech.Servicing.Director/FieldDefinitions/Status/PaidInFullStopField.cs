namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class PaidInFullStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaidInFullStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaidInFullStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 27;

            ValidData = new [] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
        }
    }
}