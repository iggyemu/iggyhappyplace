namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Stop
    /// </summary>
    public class AAndHSolicitationField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AAndHSolicitationField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public AAndHSolicitationField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 17;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 17;
            WriteColumn = 27;
        }
    }
}