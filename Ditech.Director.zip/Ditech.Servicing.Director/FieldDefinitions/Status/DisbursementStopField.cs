namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Stop
    /// </summary>
    public class DisbursementStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DisbursementStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DisbursementStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 27;
        }
    }
}