

namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class OrganizationIdField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OrganizationIdField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public OrganizationIdField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P197";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 64;
            ReadLength = 4;

            WriteScreenName = "P197";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 64;
        }
    }
}