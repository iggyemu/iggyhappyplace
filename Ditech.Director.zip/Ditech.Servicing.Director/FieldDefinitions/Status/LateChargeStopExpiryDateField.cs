

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Late Charge Expire Date Field
    /// </summary>
    public class LateChargeStopExpiryDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LateChargeStopExpiryDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LateChargeStopExpiryDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 12;
            ReadColumn = 58;
            ReadLength = 8;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 12;
            WriteColumn = 58;

            DatePattern = "MM/dd/yy";
        }
    }
}