

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class NoNoticeStopField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NoNoticeStopField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public NoNoticeStopField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "SAF1";
            ReadWindowName = string.Empty;
            ReadRow = 13;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "SAF1";
            WriteWindowName = string.Empty;
            WriteRow = 13;
            WriteColumn = 27;
        }
    }
}