﻿namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class InvestorNameField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvestorNameField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public InvestorNameField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "INV1";
            ReadRow = 7;
            ReadColumn = 6;
            ReadLength = 25;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}