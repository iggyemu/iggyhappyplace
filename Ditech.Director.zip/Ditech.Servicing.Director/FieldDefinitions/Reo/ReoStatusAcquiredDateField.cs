namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusAcquiredDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusAcquiredDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusAcquiredDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 11;
            ReadColumn = 54;
            ReadLength = 6;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 11;
            WriteColumn = 54;

            DatePattern = "MMddyy";
        }
    }
}