namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusExpectedSaleTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusExpectedSaleTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusExpectedSaleTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 73;
            ReadLength = 1;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 73;
        }
    }
}