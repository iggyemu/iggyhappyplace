namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusStageField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusStageField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusStageField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 28;
            ReadLength = 3;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 28;
        }
    }
}