namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusForeclosureSaleDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusForeclosureSaleDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusForeclosureSaleDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 11;
            ReadColumn = 64;
            ReadLength = 6;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 11;
            WriteColumn = 64;

            DatePattern = "MMddyy";
        }
    }
}