namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusSetupDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusSetupDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusSetupDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 11;
            ReadColumn = 21;
            ReadLength = 6;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 11;
            WriteColumn = 21;

            DatePattern = "MMddyy";
        }
    }
}