namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusTemplateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusTemplateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusTemplateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 11;
            ReadLength = 7;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 11;
        }
    }
}