namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 11;
            ReadColumn = 49;
            ReadLength = 1;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 11;
            WriteColumn = 49;
        }
    }
}