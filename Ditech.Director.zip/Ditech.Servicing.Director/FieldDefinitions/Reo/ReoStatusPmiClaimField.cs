namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusPmiClaimField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusPmiClaimField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusPmiClaimField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 11;
            ReadColumn = 6;
            ReadLength = 1;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 11;
            WriteColumn = 6;
        }
    }
}