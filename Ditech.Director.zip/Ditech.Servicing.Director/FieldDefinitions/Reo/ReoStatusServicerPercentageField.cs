namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusServicerPercentageField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusServicerPercentageField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusServicerPercentageField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 48;
            ReadLength = 6;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 48;
        }
    }
}