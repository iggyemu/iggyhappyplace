namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusFileLocationField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusFileLocationField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusFileLocationField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 34;
            ReadLength = 3;

            WriteScreenName = "REO1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 34;
        }
    }
}