namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class AmortizationLoanNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AmortizationLoanNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public AmortizationLoanNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "P198";
            WriteWindowName = string.Empty;
            WriteRow = 23;
            WriteColumn = 35;

        }
    }
}