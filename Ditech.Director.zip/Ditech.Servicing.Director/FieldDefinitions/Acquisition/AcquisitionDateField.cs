namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class AcquisitionDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AcquisitionDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public AcquisitionDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "AQN1";
            ReadRow = 6;
            ReadColumn = 3;
            ReadLength = 6;

            WriteScreenName = "MAS1";
            WriteWindowName = "AQN1";
            WriteRow = 6;
            WriteColumn = 3;

            DatePattern = "MMddyy";
        }
    }
}