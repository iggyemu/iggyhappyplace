namespace Ditech.Servicing.Director.MspFields
{

    public class MortgageInsuranceTermination78DateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MortgageInsuranceTermination78DateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MortgageInsuranceTermination78DateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MIP1";
            ReadWindowName = "MAIN";
            ReadRow = 6;
            ReadColumn = 23;
            ReadLength = 8;
            ReadAdditionalKeys = new[] { DirectorKeys.PF16 };

            WriteScreenName = "MIP1";
            WriteWindowName = "MAIN";
            WriteRow = 6;
            WriteColumn = 23;
            WriteAdditionalKeys = new [] {DirectorKeys.PF16};

            DatePattern = "MM-dd-yy";

            AdditionalKeysWriteVerification.Screen = "MIP1";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 31;
            AdditionalKeysWriteVerification.SearchValue = "* PMI CANC/TERM INFO *";
        }
    }
}