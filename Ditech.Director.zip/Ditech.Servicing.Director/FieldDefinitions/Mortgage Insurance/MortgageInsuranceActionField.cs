namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class MortgageInsuranceActionField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MortgageInsuranceActionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MortgageInsuranceActionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MIP1";
            ReadWindowName = "MAIN";
            ReadRow = 6;
            ReadColumn = 3;
            ReadLength = 1;

            WriteScreenName = "MIP1";
            WriteWindowName = "MAIN";
            WriteRow = 6;
            WriteColumn = 3;

            ValidData = new [] {"A", "C", "D", "P", "X"};
        }
    }
}