namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class MortgageInsuranceCancellation80PercentDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MortgageInsuranceCancellation80PercentDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MortgageInsuranceCancellation80PercentDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MIP1";
            ReadWindowName = "MAIN";
            ReadRow = 6;
            ReadColumn = 4;
            ReadLength = 8;
            ReadAdditionalKeys = new[] { DirectorKeys.PF16 };

            WriteScreenName = "MIP1";
            WriteWindowName = "MAIN";
            WriteRow = 6;
            WriteColumn = 4;
            WriteAdditionalKeys = new [] {DirectorKeys.PF16};

            DatePattern = "MM-dd-yy";

            AdditionalKeysWriteVerification.Screen = "MIP1";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 31;
            AdditionalKeysWriteVerification.SearchValue = "* PMI CANC/TERM INFO *";
        }
    }
}