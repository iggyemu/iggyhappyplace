namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class MortgageInsuranceDueDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MortgageInsuranceDueDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public MortgageInsuranceDueDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MIP1";
            ReadWindowName = "MAIN";
            ReadRow = 6;
            ReadColumn = 27;
            ReadLength = 5;

            WriteScreenName = "MIP1";
            WriteWindowName = "MAIN";
            WriteRow = 6;
            WriteColumn = 27;

            DatePattern = "MM-yy";
        }
    }
}