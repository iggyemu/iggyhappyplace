﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowDisbursementConfirmPayeeField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowDisbursementConfirmPayeeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowDisbursementConfirmPayeeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DEQE";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 59;
            ReadLength = 1;

            WriteScreenName = "DEQE";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 59;

            ValidData = new [] {"Y", "N"};
        }

        #endregion Constructors
    }
}