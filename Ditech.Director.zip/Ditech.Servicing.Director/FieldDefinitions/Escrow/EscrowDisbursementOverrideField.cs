﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowDisbursementOverrideField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowDisbursementOverrideField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowDisbursementOverrideField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DEQE";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 67;
            ReadLength = 1;

            WriteScreenName = "DEQE";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 67;
        }

        #endregion Constructors
    }
}