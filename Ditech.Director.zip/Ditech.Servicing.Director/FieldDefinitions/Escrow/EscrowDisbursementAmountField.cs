﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowDisbursementAmountField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowDisbursementAmountFieldclass.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowDisbursementAmountField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DEQE";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 13;
            ReadLength = 10;

            WriteScreenName = "DEQE";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 13;
        }

        #endregion Constructors
    }
}