﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowPaymentField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowPaymentFieldclass.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowPaymentField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P190";
            ReadWindowName = string.Empty;
            ReadRow = 13;
            ReadColumn = 31;
            ReadLength = 10;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }

        #endregion Constructors
    }
}