﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowDisbursementTypeField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowDisbursementTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowDisbursementTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DEQE";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 27;
            ReadLength = 1;

            WriteScreenName = "DEQE";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 27;
        }

        #endregion Constructors
    }
}