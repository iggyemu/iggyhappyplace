﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowDisbursementTranCodeField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowDisbursementTranCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowDisbursementTranCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DEQE";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 5;
            ReadLength = 3;

            WriteScreenName = "DEQE";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 5;
        }

        #endregion Constructors
    }
}