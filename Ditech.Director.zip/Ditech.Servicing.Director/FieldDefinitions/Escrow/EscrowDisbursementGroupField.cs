﻿namespace Ditech.Servicing.Director.MspFields
{
    public class EscrowDisbursementGroupField : MspField
    {
        #region Constructors (1)

        /// <summary>
        /// Initializes a new instance of the <see cref="EscrowDisbursementGroupField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public EscrowDisbursementGroupField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DEQE";
            WriteWindowName = string.Empty;
            WriteRow = 1;
            WriteColumn = 18;
        }

        #endregion Constructors
    }
}