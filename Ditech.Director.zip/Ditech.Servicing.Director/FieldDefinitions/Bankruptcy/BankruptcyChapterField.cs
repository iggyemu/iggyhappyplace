namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyChapterField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyChapterField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyChapterField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNK1";
            ReadWindowName = "STAT";
            ReadRow = 18;
            ReadColumn = 16;
            ReadLength = 8;

            WriteScreenName = "BNK1";
            WriteWindowName = "STAT";
            WriteRow = 18;
            WriteColumn = 16;

        }
    }
}