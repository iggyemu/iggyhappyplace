namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyFilingDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyFilingDateField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyFilingDateField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNK1";
            ReadWindowName = "STAT";
            ReadRow = 22;
            ReadColumn = 54;
            ReadLength = 8;

            WriteScreenName = "BNK1";
            WriteWindowName = "STAT";
            WriteRow = 22;
            WriteColumn = 54;

            DatePattern = "MM-dd-yy";

        }
    }
}