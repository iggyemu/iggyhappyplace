namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyPostPetitionDueDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyPostPetitionDueDateField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyPostPetitionDueDateField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNKA";
            ReadWindowName = "DEBT";
            ReadRow = 18;
            ReadColumn = 52;
            ReadLength = 8;

            WriteScreenName = "BNKA";
            WriteWindowName = "DEBT";
            WriteRow = 18;
            WriteColumn = 52;

            DatePattern = "MM-dd-yy";

        }
    }
}