namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyMortgagorCoAttorneyField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyMortgagorCoAttorneyField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyMortgagorCoAttorneyField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNK1";
            ReadWindowName = "STAT";
            ReadRow = 21;
            ReadColumn = 16;
            ReadLength = 24;

            WriteScreenName = "BNK1";
            WriteWindowName = "STAT";
            WriteRow = 21;
            WriteColumn = 16;

        }
    }
}