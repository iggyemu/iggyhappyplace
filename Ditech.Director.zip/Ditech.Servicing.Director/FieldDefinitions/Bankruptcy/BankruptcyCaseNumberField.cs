namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyCaseNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyCaseNumberField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyCaseNumberField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNK1";
            ReadWindowName = "STAT";
            ReadRow = 6;
            ReadColumn = 35;
            ReadLength = 20;

            WriteScreenName = "BNK1";
            WriteWindowName = "STAT";
            WriteRow = 6;
            WriteColumn = 35;

        }
    }
}