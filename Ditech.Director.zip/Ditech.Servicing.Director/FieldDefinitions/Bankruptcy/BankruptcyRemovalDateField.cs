namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyRemovalDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyRemovalDateField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyRemovalDateField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNK1";
            ReadWindowName = "STAT";
            ReadRow = 18;
            ReadColumn = 54;
            ReadLength = 8;

            WriteScreenName = "BNK1";
            WriteWindowName = "STAT";
            WriteRow = 18;
            WriteColumn = 54;

            DatePattern = "MM-dd-yy";

        }
    }
}