namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyPostPetitionPaymentField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyPostPetitionPaymentField"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public BankruptcyPostPetitionPaymentField(string loanNumber)
            : base(loanNumber)
        {
            ReadScreenName = "BNKA";
            ReadWindowName = "DEBT";
            ReadRow = 18;
            ReadColumn = 61;
            ReadLength = 8;

            WriteScreenName = "BNKA";
            WriteWindowName = "DEBT";
            WriteRow = 18;
            WriteColumn = 61;

        }
    }
}