

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class BankruptcyStatusField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankruptcyStatusField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public BankruptcyStatusField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "BNK1";
            ReadWindowName = "STAT";
            ReadRow = 6;
            ReadColumn = 4;
            ReadLength = 1;

            WriteScreenName = "BNK1";
            WriteWindowName = "STAT";
            WriteRow = 6;
            WriteColumn = 4;

            ValidData = new[] {"A","C","D"};

        }
    }
}