namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class TaxesAndLiensTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TaxesAndLiensTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaxesAndLiensTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "TAX2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 13;
            ReadLength = 3;

            WriteScreenName = "TAX2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 13;
        }
    }
}