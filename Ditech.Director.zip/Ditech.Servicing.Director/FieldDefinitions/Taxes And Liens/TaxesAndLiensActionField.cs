namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class TaxesAndLiensActionField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TaxesAndLiensActionField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaxesAndLiensActionField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "TAX2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 9;
            ReadLength = 1;

            WriteScreenName = "TAX2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 9;
        }
    }
}