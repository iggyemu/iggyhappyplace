namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class TaxesAndLiensSequenceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TaxesAndLiensSequenceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaxesAndLiensSequenceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "TAX2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 17;
            ReadLength = 2;

            WriteScreenName = "TAX2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 17;
        }
    }
}