namespace Ditech.Servicing.Director.MspFields
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class TaxesAndLiensBillField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TaxesAndLiensBillField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TaxesAndLiensBillField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "TAX2";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 59;
            ReadLength = 1;

            WriteScreenName = "TAX2";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 59;
        }
    }
}