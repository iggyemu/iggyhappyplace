namespace Ditech.Servicing.Director.MspFields
{

    public class TransferOfServiceLoanServiceSoldIdField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferOfServiceLoanServiceSoldIdField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferOfServiceLoanServiceSoldIdField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "XFR1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 10;

        }
    }
}