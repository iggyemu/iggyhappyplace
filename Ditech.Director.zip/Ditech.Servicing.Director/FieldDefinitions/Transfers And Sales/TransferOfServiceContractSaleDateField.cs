
namespace Ditech.Servicing.Director.MspFields
{

    public class TransferOfServiceContractSaleDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferOfServiceContractSaleDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferOfServiceContractSaleDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "XFR1";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 46;
            ReadLength = 6;

            WriteScreenName = "XFR1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 46;
            WriteColumn = 46;

            DatePattern = "MMddyyyy";
        }
    }
}