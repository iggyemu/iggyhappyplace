
namespace Ditech.Servicing.Director.MspFields
{

    public class TransferOfServiceEffectiveDueDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferOfServiceEffectiveDueDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferOfServiceEffectiveDueDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "XFR1";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 37;
            ReadLength = 6;

            WriteScreenName = "XFR1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 37;

            DatePattern = "MMddyyyy";
        }
    }
}