namespace Ditech.Servicing.Director.MspFields
{

    public class TransferHistoryTransactionDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferHistoryTransactionDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferHistoryTransactionDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "LNTH";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 2;
            ReadLength = 8;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

            DatePattern = "MM/dd/yyyy";
        }
    }
}