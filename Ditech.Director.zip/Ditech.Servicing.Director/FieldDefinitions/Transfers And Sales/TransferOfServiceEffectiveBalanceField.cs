namespace Ditech.Servicing.Director.MspFields
{

    public class TransferOfServiceEffectiveBalanceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferOfServiceEffectiveBalanceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferOfServiceEffectiveBalanceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "XFR1";
            ReadWindowName = string.Empty;
            ReadRow = 10;
            ReadColumn = 21;
            ReadLength = 13;

            WriteScreenName = "XFR1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 21;
        }
    }
}