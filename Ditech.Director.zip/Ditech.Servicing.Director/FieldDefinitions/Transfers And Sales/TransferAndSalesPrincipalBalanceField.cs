namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesPrincipalBalanceField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesPrincipalBalanceField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesPrincipalBalanceField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 53;
            ReadLength = 11;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 53;
        }
    }
}