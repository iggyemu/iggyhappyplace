namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesEffectiveDueDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesEffectiveDueDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesEffectiveDueDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 35;
            ReadLength = 4;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 35;

            //DatePattern = "MMyy";
        }
    }
}