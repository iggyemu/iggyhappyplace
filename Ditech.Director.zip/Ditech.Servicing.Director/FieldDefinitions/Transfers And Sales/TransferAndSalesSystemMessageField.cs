namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesSystemMessageField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesSystemMessageField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesSystemMessageField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 24;
            ReadColumn = 2;
            ReadLength = 79;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;
        }
    }
}