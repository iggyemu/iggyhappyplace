namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesNewInvestorField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesNewInvestorField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesNewInvestorField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 21;
            ReadLength = 3;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 21;
        }
    }
}