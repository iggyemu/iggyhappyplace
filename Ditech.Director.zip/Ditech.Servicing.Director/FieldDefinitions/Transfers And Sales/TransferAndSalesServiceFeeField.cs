namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesServiceFeeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesServiceFeeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesServiceFeeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 5;
            ReadLength = 10;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 5;
        }
    }
}