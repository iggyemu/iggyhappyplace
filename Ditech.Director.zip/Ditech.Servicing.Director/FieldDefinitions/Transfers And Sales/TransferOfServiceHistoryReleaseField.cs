namespace Ditech.Servicing.Director.MspFields
{

    public class TransferOfServiceHistoryReleaseField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferOfServiceHistoryReleaseField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferOfServiceHistoryReleaseField(string LoanNumber): base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "XFR1";
            WriteWindowName = string.Empty;
            WriteRow = 10;
            WriteColumn = 3;

            ValidData = new [] {"Y", "N"};
        }
    }
}