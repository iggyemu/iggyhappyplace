namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesDatePaidField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesDatePaidField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesDatePaidField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 31;
            ReadLength = 6;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 31;

            DatePattern = "MMddyy";
        }
    }
}