namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesNotifyMersField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesNotifyMersField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesNotifyMersField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 16;
            ReadColumn = 45;
            ReadLength = 1;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 16;
            WriteColumn = 45;

            ValidData = new [] {"Y", "N"};
        }
    }
}