namespace Ditech.Servicing.Director.MspFields
{

    public class TransferAndSalesFlagField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransferAndSalesFlagField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public TransferAndSalesFlagField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DELP";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 5;
            ReadLength = 1;

            WriteScreenName = "DELP";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 5;

            ValidData = new [] {"S", "R", "M"};
        }
    }
}