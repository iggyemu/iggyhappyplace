namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingOneTimeCodeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingOneTimeCodeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingOneTimeCodeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 8;
            ReadColumn = 33;
            ReadLength = 2;

            ReadAdditionalKeys = new[] { DirectorKeys.PF5 };

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 33;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "DFT4";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 34;
            AdditionalKeysWriteVerification.SearchValue = "PAYMENT INFO";
        }
    }
}