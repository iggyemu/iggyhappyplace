namespace Ditech.Servicing.Director.MspFields
{

    public class DraftingOneTimeTotalDraftFeesField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingOneTimeTotalDraftFeesField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingOneTimeTotalDraftFeesField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 11;
            ReadColumn = 28;
            ReadLength = 16;

            ReadAdditionalKeys = new[] { DirectorKeys.PF5 };

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 28;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "DFT4";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 32;
            AdditionalKeysWriteVerification.SearchValue = "PAYMENT INFO";
        }
    }
}