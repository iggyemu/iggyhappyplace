namespace Ditech.Servicing.Director.MspFields
{
    public class DraftingEffectiveDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingEffectiveDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingEffectiveDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "DFT1";
            ReadRow = 14;
            ReadColumn = 4;
            ReadLength = 6;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 14;
            WriteColumn = 4;

            DatePattern = "MMddyy";
        }
    }
}