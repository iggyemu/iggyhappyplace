

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingTransitNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingTransitNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingTransitNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 6;
            WriteColumn = 23;

        }
    }
}