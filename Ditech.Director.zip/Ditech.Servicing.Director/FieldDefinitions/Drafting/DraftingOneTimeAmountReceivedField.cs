namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingOneTimeAmountReceivedField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingOneTimeAmountReceivedField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingOneTimeAmountReceivedField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 16;
            ReadLength = 11;

            ReadAdditionalKeys = new[] { DirectorKeys.PF5 };

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 16;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "DFT4";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 34;
            AdditionalKeysWriteVerification.SearchValue = "PAYMENT INFO";
        }
    }
}