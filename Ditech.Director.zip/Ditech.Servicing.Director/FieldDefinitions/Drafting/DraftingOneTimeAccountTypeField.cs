namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingOneTimeAccountTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingOneTimeAccountTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingOneTimeAccountTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 61;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "DFT4";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 32;
            AdditionalKeysWriteVerification.SearchValue = "DRAFT ACCOUNT INFO";
        }
    }
}