namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingOneTimePaymentAmountField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingOneTimePaymentAmountField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingOneTimePaymentAmountField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "DFT4";
            ReadWindowName = string.Empty;
            ReadRow = 6;
            ReadColumn = 38;
            ReadLength =10;

            ReadAdditionalKeys = new[] { DirectorKeys.PF5 };

            WriteScreenName = "DFT4";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 38;

            WriteAdditionalKeys = new[] { DirectorKeys.PF5 };

            AdditionalKeysWriteVerification.Screen = "DFT4";
            AdditionalKeysWriteVerification.SubScreen = "********";
            AdditionalKeysWriteVerification.Row = 4;
            AdditionalKeysWriteVerification.Column = 34;
            AdditionalKeysWriteVerification.SearchValue = "PAYMENT INFO";
        }
    }
}