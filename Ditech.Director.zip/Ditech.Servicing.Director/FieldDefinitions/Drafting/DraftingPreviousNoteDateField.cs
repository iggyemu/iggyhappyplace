

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingPreviousNoteDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingPreviousNoteDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingPreviousNoteDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 14;
            WriteColumn = 15;

            DatePattern = "MMddyy";
        }
    }
}