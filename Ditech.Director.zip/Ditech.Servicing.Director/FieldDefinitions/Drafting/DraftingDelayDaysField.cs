

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingDelayDaysField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingDelayDaysField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingDelayDaysField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "DFT1";
            ReadRow = 14;
            ReadColumn = 40;
            ReadLength = 2;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 14;
            WriteColumn = 40;

        }
    }
}