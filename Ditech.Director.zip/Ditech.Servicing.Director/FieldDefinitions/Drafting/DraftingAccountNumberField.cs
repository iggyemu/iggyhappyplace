

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingAccountNumberField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingAccountNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingAccountNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MAS1";
            ReadWindowName = "DFT1";
            ReadRow = 6;
            ReadColumn = 36;
            ReadLength = 17;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 6;
            WriteColumn = 36;

        }
    }
}