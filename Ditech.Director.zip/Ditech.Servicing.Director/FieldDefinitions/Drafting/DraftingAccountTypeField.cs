

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// No Notice Stop Field
    /// </summary>
    public class DraftingAccountTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DraftingAccountTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public DraftingAccountTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MAS1";
            WriteWindowName = "DFT1";
            WriteRow = 9;
            WriteColumn = 39;

            ValidData = new[] { "C", "S" };
            

        }
    }
}