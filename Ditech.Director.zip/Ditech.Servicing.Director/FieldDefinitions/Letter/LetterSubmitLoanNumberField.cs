namespace Ditech.Servicing.Director.MspFields
{

    public class LetterSubmitLoanNumberField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="LetterSubmitLoanNumberField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LetterSubmitLoanNumberField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "PL03";
            WriteWindowName = string.Empty;
            WriteRow = 8;
            WriteColumn = 42;
        }
    }
}