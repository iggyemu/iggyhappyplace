namespace Ditech.Servicing.Director.MspFields
{

    public class LetterSubmitLetterOrLetterSetField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="LetterSubmitLetterOrLetterSetField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LetterSubmitLetterOrLetterSetField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "PL03";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 42;
        }
    }
}