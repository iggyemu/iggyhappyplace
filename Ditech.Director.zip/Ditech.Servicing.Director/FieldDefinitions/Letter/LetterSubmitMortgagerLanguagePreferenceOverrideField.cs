namespace Ditech.Servicing.Director.MspFields
{

    public class LetterSubmitMortgagerLanguagePreferenceOverrideField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="LetterSubmitMortgagerLanguagePreferenceOverrideField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LetterSubmitMortgagerLanguagePreferenceOverrideField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "PL03";
            WriteWindowName = string.Empty;
            WriteRow = 11;
            WriteColumn = 42;

            ValidData = new [] {"Y", "N"};
        }
    }
}