namespace Ditech.Servicing.Director.MspFields
{

    public class LetterSubmitPrinterDestinationField : MspField
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="LetterSubmitPrinterDestinationField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LetterSubmitPrinterDestinationField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty; 
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "PL03";
            WriteWindowName = string.Empty;
            WriteRow = 12;
            WriteColumn = 42;
        }
    }
}