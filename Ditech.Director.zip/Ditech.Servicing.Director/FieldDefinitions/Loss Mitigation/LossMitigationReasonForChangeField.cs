

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    public class LossMitigationReasonForChangeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationReasonForChangeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationReasonForChangeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "LMT3";
            WriteWindowName = string.Empty;
            WriteRow = 6;
            WriteColumn = 10;

        }
    }
}