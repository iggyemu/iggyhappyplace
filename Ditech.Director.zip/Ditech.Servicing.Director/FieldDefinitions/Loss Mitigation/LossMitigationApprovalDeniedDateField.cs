

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LossMitigationApprovalDeniedDateField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationApprovalDeniedDateField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationApprovalDeniedDateField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "LMT1";
            ReadWindowName = "STAT";
            ReadRow = 11;
            ReadColumn = 29;
            ReadLength = 6;

            WriteScreenName = "LMT1";
            WriteWindowName = "STAT";
            WriteRow = 11;
            WriteColumn = 29;

            DatePattern = "MMddyy";

        }
    }
}