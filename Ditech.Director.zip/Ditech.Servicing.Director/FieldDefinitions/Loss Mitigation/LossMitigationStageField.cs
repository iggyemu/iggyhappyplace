

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LossMitigationStageField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationStageField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationStageField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "LMT1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 34;
            ReadLength = 3;

            WriteScreenName = "LMT1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 34;

        }
    }
}