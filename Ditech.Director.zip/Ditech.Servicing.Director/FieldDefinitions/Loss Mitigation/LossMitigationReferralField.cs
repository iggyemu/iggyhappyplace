

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LossMitigationReferralField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationReferralField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationReferralField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "LMT1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 49;
            ReadLength = 5;

            WriteScreenName = "LMT1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 49;


        }
    }
}