

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LossMitigationProcField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationProcField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationProcField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "LMT1";
            ReadWindowName = "STAT";
            ReadRow = 7;
            ReadColumn = 20;
            ReadLength = 3;

            WriteScreenName = "LMT1";
            WriteWindowName = "STAT";
            WriteRow = 7;
            WriteColumn = 20;


        }
    }
}