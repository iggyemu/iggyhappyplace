namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LossMitigationAttorneyField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationAttorneyField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationAttorneyField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "LMT1";
            ReadWindowName = "STAT";
            ReadRow = 21;
            ReadColumn = 16;
            ReadLength = 24;

            WriteScreenName = "LMT1";
            WriteWindowName = "STAT";
            WriteRow = 21;
            WriteColumn = 16;
        }
    }
}