

using System;
using System.Globalization;

namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LossMitigationIndicatorField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LossMitigationIndicatorField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LossMitigationIndicatorField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "MAS1";
            WriteWindowName = "COL2";
            WriteRow = 7;
            WriteColumn = 16;


        }
    }
}