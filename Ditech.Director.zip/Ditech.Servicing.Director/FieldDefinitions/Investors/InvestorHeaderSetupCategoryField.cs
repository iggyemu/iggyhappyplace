namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class InvestorHeaderSetupCategoryField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvestorHeaderSetupCategoryField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public InvestorHeaderSetupCategoryField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = string.Empty;
            ReadWindowName = string.Empty;
            ReadRow = 0;
            ReadColumn = 0;
            ReadLength = 0;

            WriteScreenName = "IN01";
            WriteWindowName = string.Empty;
            WriteRow = 3;
            WriteColumn = 15;

        }
    }
}