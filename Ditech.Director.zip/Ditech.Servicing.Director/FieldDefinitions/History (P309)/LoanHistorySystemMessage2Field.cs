namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LoanHistorySystemMessage2Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanHistorySystemMessage2Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoanHistorySystemMessage2Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P309";
            ReadWindowName = string.Empty;
            ReadRow = 1;
            ReadColumn = 21;
            ReadLength = 35;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}