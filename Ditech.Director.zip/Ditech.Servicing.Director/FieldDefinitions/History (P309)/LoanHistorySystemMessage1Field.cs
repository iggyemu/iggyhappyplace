namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LoanHistorySystemMessage1Field : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanHistorySystemMessage1Field"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoanHistorySystemMessage1Field(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P309";
            ReadWindowName = string.Empty;
            ReadRow = 4;
            ReadColumn = 24;
            ReadLength = 24;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}