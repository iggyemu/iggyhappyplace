namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LoanHistoryInvestorIdField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanHistoryInvestorIdField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoanHistoryInvestorIdField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P309";
            ReadWindowName = string.Empty;
            ReadRow = 2;
            ReadColumn = 37;
            ReadLength = 3;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}