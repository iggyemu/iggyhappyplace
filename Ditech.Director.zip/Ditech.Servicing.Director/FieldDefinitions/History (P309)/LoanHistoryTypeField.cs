namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LoanHistoryTypeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanHistoryTypeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoanHistoryTypeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P309";
            ReadWindowName = string.Empty;
            ReadRow = 2;
            ReadColumn = 74;
            ReadLength = 6;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}