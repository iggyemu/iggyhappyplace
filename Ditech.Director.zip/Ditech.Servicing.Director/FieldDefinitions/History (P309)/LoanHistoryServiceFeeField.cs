namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class LoanHistoryServiceFeeField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanHistoryServiceFeeField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public LoanHistoryServiceFeeField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "P309";
            ReadWindowName = string.Empty;
            ReadRow = 4;
            ReadColumn = 33;
            ReadLength = 10;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}