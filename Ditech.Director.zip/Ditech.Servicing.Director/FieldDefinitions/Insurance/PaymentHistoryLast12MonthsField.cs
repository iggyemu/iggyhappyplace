namespace Ditech.Servicing.Director.MspFields
{

    /// <summary>
    /// Credit Quality Previous Date Field
    /// </summary>
    public class PaymentHistoryLast12MonthsField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentHistoryLast12MonthsField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public PaymentHistoryLast12MonthsField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "MIPC";
            ReadWindowName = string.Empty;
            ReadRow = 12;
            ReadColumn = 52;
            ReadLength = 12;

            WriteScreenName = string.Empty;
            WriteWindowName = string.Empty;
            WriteRow = 0;
            WriteColumn = 0;

        }
    }
}