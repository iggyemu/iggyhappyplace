using Ditech.Servicing.Director.MspFields;

namespace Ditech.Servicing.CoreServices.Director.FieldDefinitions.Reo
{
    /// <summary>
    /// Late Charge Description
    /// </summary>
    public class ReoStatusStatusField : MspField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReoStatusStatusField"/> class.
        /// </summary>
        /// <param name="LoanNumber">The loan number.</param>
        public ReoStatusStatusField(string LoanNumber)
            : base(LoanNumber)
        {
            ReadScreenName = "REO1";
            ReadWindowName = string.Empty;
            ReadRow = 7;
            ReadColumn = 6;
            ReadLength = 1;

            WriteScreenName = "REO1";
            WriteWindowName = string.Empty;
            WriteRow = 7;
            WriteColumn = 6;

        }
    }
}