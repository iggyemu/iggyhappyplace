#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BadCheckStopField badCheckStop;

        /// <summary>
        /// Gets or sets the bad check stop.
        /// </summary>
        /// <value>The bad check stop.</value>
        public BadCheckStopField BadCheckStop
        {
            get
            {
                badCheckStop = badCheckStop ?? new BadCheckStopField(LoanNumber);
                UpdateOtherFields(badCheckStop, true);
                return badCheckStop;
            }
            set
            {
                badCheckStop = badCheckStop ?? new BadCheckStopField(LoanNumber);
                UpdateOtherFields(badCheckStop, false);
                badCheckStop = value;
            }
        }
    }
}