﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardDueDateField hazardDueDate;

        /// <summary>
        /// Gets or sets the hazard due date.
        /// </summary>
        /// <value>The hazard due date.</value>
        public HazardDueDateField HazardDueDate
        {
            get
            {
                hazardDueDate = hazardDueDate ?? new HazardDueDateField(LoanNumber);
                UpdateOtherFields(hazardDueDate, true);
                return hazardDueDate;
            }
            set
            {
                hazardDueDate = hazardDueDate ?? new HazardDueDateField(LoanNumber);
                UpdateOtherFields(hazardDueDate, false);
                hazardDueDate = value;
            }
        }
    }
}