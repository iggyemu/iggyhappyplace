#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingPreviousNoteDateField draftingPreviousNoteDate;

        /// <summary>
        /// Gets or sets the drafting previous note date.
        /// </summary>
        /// <value>The drafting previous note date.</value>
        public DraftingPreviousNoteDateField DraftingPreviousNoteDate
        {
            get
            {
                draftingPreviousNoteDate = draftingPreviousNoteDate ?? new DraftingPreviousNoteDateField(LoanNumber);
                UpdateOtherFields(draftingPreviousNoteDate, true);
                return draftingPreviousNoteDate;
            }
            set
            {
                draftingPreviousNoteDate = draftingPreviousNoteDate ?? new DraftingPreviousNoteDateField(LoanNumber);
                UpdateOtherFields(draftingPreviousNoteDate, false);
                draftingPreviousNoteDate = value;
            }
        }
    }
}