﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine1Field hazardNoteLine1;

        /// <summary>
        /// Gets or sets the hazard note line1.
        /// </summary>
        /// <value>The hazard note line1.</value>
        public HazardNoteLine1Field HazardNoteLine1
        {
            get
            {
                hazardNoteLine1 = hazardNoteLine1 ?? new HazardNoteLine1Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine1, true);
                return hazardNoteLine1;
            }
            set
            {
                hazardNoteLine1 = hazardNoteLine1 ?? new HazardNoteLine1Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine1, false);
                hazardNoteLine1 = value;
            }
        }
    }
}