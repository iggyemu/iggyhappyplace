#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine7Field customerServiceCommentLine7;


        /// <summary>
        /// Gets or sets the SER1 Note Line 7.
        /// </summary>
        /// <value>The SER1 Note Line 7.</value>
        public CustomerServiceCommentLine7Field CustomerServiceCommentLine7
        {
            get
            {
                customerServiceCommentLine7 = customerServiceCommentLine7 ?? new CustomerServiceCommentLine7Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine7, true);
                return customerServiceCommentLine7;
            }
            set
            {
                customerServiceCommentLine7 = customerServiceCommentLine7 ?? new CustomerServiceCommentLine7Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine7, false);
                customerServiceCommentLine7 = value;
            }
        }
    }
}