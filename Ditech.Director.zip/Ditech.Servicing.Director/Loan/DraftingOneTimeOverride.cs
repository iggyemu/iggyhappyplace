﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeOverrideField draftingOneTimeOverride;

        /// <summary>
        /// Gets or sets the drafting one time override.
        /// </summary>
        /// <value>The drafting one time override.</value>
        public DraftingOneTimeOverrideField DraftingOneTimeOverride
        {
            get
            {
                draftingOneTimeOverride = draftingOneTimeOverride ?? new DraftingOneTimeOverrideField(LoanNumber);
                UpdateOtherFields(draftingOneTimeOverride, true);
                return draftingOneTimeOverride;
            }
            set
            {
                draftingOneTimeOverride = draftingOneTimeOverride ?? new DraftingOneTimeOverrideField(LoanNumber);
                UpdateOtherFields(draftingOneTimeOverride, false);
                draftingOneTimeOverride = value;
            }
        }
    }
}