﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyPaymentAmountField delinquencyPaymentAmount;

        /// <summary>
        /// Gets or sets the delinquency payment amount.
        /// </summary>
        /// <value>The delinquency payment amount.</value>
        public DelinquencyPaymentAmountField DelinquencyPaymentAmount
        {
            get
            {
                delinquencyPaymentAmount = delinquencyPaymentAmount ?? new DelinquencyPaymentAmountField(LoanNumber);
                UpdateOtherFields(delinquencyPaymentAmount, true);
                return delinquencyPaymentAmount;
            }
            set
            {
                delinquencyPaymentAmount = delinquencyPaymentAmount ?? new DelinquencyPaymentAmountField(LoanNumber);
                UpdateOtherFields(delinquencyPaymentAmount, false);
                delinquencyPaymentAmount = value;
            }
        }
    }
}