﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine4Field hazardNoteLine4;

        /// <summary>
        /// Gets or sets the hazard note line4.
        /// </summary>
        /// <value>The hazard note line4.</value>
        public HazardNoteLine4Field HazardNoteLine4
        {
            get
            {
                hazardNoteLine4 = hazardNoteLine4 ?? new HazardNoteLine4Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine4, true);
                return hazardNoteLine4;
            }
            set
            {
                hazardNoteLine4 = hazardNoteLine4 ?? new HazardNoteLine4Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine4, false);
                hazardNoteLine4 = value;
            }
        }
    }
}