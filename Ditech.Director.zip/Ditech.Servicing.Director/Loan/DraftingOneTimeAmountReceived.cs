﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAmountReceivedField draftingOneTimeTotalAmountReceived;

        /// <summary>
        /// Gets or sets the drafting one time amount received.
        /// </summary>
        /// <value>The drafting one time amount received.</value>
        public DraftingOneTimeAmountReceivedField DraftingOneTimeAmountReceived
        {
            get
            {
                draftingOneTimeTotalAmountReceived = draftingOneTimeTotalAmountReceived ?? new DraftingOneTimeAmountReceivedField(LoanNumber);
                UpdateOtherFields(draftingOneTimeTotalAmountReceived, true);
                return draftingOneTimeTotalAmountReceived;
            }
            set
            {
                draftingOneTimeTotalAmountReceived = draftingOneTimeTotalAmountReceived ?? new DraftingOneTimeAmountReceivedField(LoanNumber);
                UpdateOtherFields(draftingOneTimeTotalAmountReceived, false);
                draftingOneTimeTotalAmountReceived = value;
            }
        }
    }
}