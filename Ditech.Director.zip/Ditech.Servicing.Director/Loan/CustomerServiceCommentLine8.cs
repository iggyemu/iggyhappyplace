#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine8Field customerServiceCommentLine8;


        /// <summary>
        /// Gets or sets the SER1 Note Line 8.
        /// </summary>
        /// <value>The SER1 Note Line 8.</value>
        public CustomerServiceCommentLine8Field CustomerServiceCommentLine8
        {
            get
            {
                customerServiceCommentLine8 = customerServiceCommentLine8 ?? new CustomerServiceCommentLine8Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine8, true);
                return customerServiceCommentLine8;
            }
            set
            {
                customerServiceCommentLine8 = customerServiceCommentLine8 ?? new CustomerServiceCommentLine8Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine8, false);
                customerServiceCommentLine8 = value;
            }
        }
    }
}