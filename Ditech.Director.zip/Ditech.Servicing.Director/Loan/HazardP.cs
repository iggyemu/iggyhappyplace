﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardPField hazardP;

        /// <summary>
        /// Gets or sets the hazard P.
        /// </summary>
        /// <value>The hazard P.</value>
        public HazardPField HazardP
        {
            get
            {
                hazardP = hazardP ?? new HazardPField(LoanNumber);
                UpdateOtherFields(hazardP, true);
                return hazardP;
            }
            set
            {
                hazardP = hazardP ?? new HazardPField(LoanNumber);
                UpdateOtherFields(hazardP, false);
                hazardP = value;
            }
        }
    }
}