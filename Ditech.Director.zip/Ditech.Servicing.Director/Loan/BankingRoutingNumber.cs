﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankingRoutingNumberField bankingRoutingNumber;

        /// <summary>
        /// Gets or sets the banking routing number.
        /// </summary>
        /// <value>The banking routing number.</value>
        public BankingRoutingNumberField BankingRoutingNumber
        {
            get
            {
                bankingRoutingNumber = bankingRoutingNumber ?? new BankingRoutingNumberField(LoanNumber);
                UpdateOtherFields(bankingRoutingNumber, true);
                return bankingRoutingNumber;
            }
            set
            {
                bankingRoutingNumber = bankingRoutingNumber ?? new BankingRoutingNumberField(LoanNumber);
                UpdateOtherFields(bankingRoutingNumber, false);
                bankingRoutingNumber = value;
            }
        }
    }
}