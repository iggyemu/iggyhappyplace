﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine9Field hazardNoteLine9;

        /// <summary>
        /// Gets or sets the hazard note line9.
        /// </summary>
        /// <value>The hazard note line9.</value>
        public HazardNoteLine9Field HazardNoteLine9
        {
            get
            {
                hazardNoteLine9 = hazardNoteLine9 ?? new HazardNoteLine9Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine9, true);
                return hazardNoteLine9;
            }
            set
            {
                hazardNoteLine9 = hazardNoteLine9 ?? new HazardNoteLine9Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine9, false);
                hazardNoteLine9 = value;
            }
        }
    }
}