#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine6Field customerServiceProcessNoteLine6;


        /// <summary>
        /// Gets or sets the SER2 Note Line 6.
        /// </summary>
        /// <value>The SER2 Note Line 6.</value>
        public CustomerServiceProcessNoteLine6Field CustomerServiceProcessNoteLine6
        {
            get
            {
                customerServiceProcessNoteLine6 = customerServiceProcessNoteLine6 ?? new CustomerServiceProcessNoteLine6Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine6, true);
                return customerServiceProcessNoteLine6;
            }
            set
            {
                customerServiceProcessNoteLine6 = customerServiceProcessNoteLine6 ?? new CustomerServiceProcessNoteLine6Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine6, false);
                customerServiceProcessNoteLine6 = value;
            }
        }
    }
}