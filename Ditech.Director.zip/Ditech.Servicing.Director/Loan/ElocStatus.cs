#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ElocStatusField elocStatus;

        /// <summary>
        /// Gets or sets the eloc status.
        /// </summary>
        /// <value>The eloc status.</value>
        public ElocStatusField ElocStatus
        {
            get
            {
                elocStatus = elocStatus ?? new ElocStatusField(LoanNumber);
                UpdateOtherFields(elocStatus, true);
                return elocStatus;
            }
            set
            {
                elocStatus = elocStatus ?? new ElocStatusField(LoanNumber);
                UpdateOtherFields(elocStatus, false);
                elocStatus = value;
            }
        }
    }
}