﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeNumberOfPaymentsField draftingOneTimeNumberOfPayments;

        /// <summary>
        /// Gets or sets the drafting one time number of payments.
        /// </summary>
        /// <value>The drafting one time number of payments.</value>
        public DraftingOneTimeNumberOfPaymentsField DraftingOneTimeNumberOfPayments
        {
            get
            {
                draftingOneTimeNumberOfPayments = draftingOneTimeNumberOfPayments ?? new DraftingOneTimeNumberOfPaymentsField(LoanNumber);
                UpdateOtherFields(draftingOneTimeNumberOfPayments, true);
                return draftingOneTimeNumberOfPayments;
            }
            set
            {
                draftingOneTimeNumberOfPayments = draftingOneTimeNumberOfPayments ?? new DraftingOneTimeNumberOfPaymentsField(LoanNumber);
                UpdateOtherFields(draftingOneTimeNumberOfPayments, false);
                draftingOneTimeNumberOfPayments = value;
            }
        }
    }
}