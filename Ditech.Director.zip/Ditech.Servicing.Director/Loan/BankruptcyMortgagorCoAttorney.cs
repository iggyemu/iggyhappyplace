﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyMortgagorCoAttorneyField bankruptcyMortgagorCoAttorney;

        /// <summary>
        /// Gets or sets the bankruptcy mortgagor co attorney.
        /// </summary>
        /// <value>The bankruptcy mortgagor co attorney.</value>
        public BankruptcyMortgagorCoAttorneyField BankruptcyMortgagorCoAttorney
        {
            get
            {
                bankruptcyMortgagorCoAttorney = bankruptcyMortgagorCoAttorney ?? new BankruptcyMortgagorCoAttorneyField(LoanNumber);
                UpdateOtherFields(bankruptcyMortgagorCoAttorney, true);
                return bankruptcyMortgagorCoAttorney;
            }
            set
            {
                bankruptcyMortgagorCoAttorney = bankruptcyMortgagorCoAttorney ?? new BankruptcyMortgagorCoAttorneyField(LoanNumber);
                UpdateOtherFields(bankruptcyMortgagorCoAttorney, false);
                bankruptcyMortgagorCoAttorney = value;
            }
        }
    }
}