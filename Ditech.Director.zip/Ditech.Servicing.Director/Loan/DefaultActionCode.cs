#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DefaultActionCodeField defaultActionCode;

        /// <summary>
        /// Gets or sets the default action code.
        /// </summary>
        /// <value>The default action code.</value>
        public DefaultActionCodeField DefaultActionCode
        {
            get
            {
                defaultActionCode = defaultActionCode ?? new DefaultActionCodeField(LoanNumber);
                UpdateOtherFields(defaultActionCode, true);
                return defaultActionCode;
            }
            set
            {
                defaultActionCode = defaultActionCode ?? new DefaultActionCodeField(LoanNumber);
                UpdateOtherFields(defaultActionCode, false);
                defaultActionCode = value;
            }
        }
    }
}