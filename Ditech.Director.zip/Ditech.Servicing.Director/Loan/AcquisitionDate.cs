#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private AcquisitionDateField acquisitionDate;

        /// <summary>
        /// Gets or sets the acquisition date.
        /// </summary>
        /// <value>The acquisition date.</value>
        public AcquisitionDateField AcquisitionDate
        {
            get
            {
                acquisitionDate = acquisitionDate ?? new AcquisitionDateField(LoanNumber);
                UpdateOtherFields(acquisitionDate, true);
                return acquisitionDate;
            }
            set
            {
                acquisitionDate = acquisitionDate ?? new AcquisitionDateField(LoanNumber);
                UpdateOtherFields(acquisitionDate, false);
                acquisitionDate = value;
            }
        }
    }
}