﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ArmPlanSystemMessageField armPlanSystemMessage;

        /// <summary>
        /// Gets or sets the arm plan system message.
        /// </summary>
        /// <value>The arm plan system message.</value>
        public ArmPlanSystemMessageField ArmPlanSystemMessage
        {
            get
            {
                armPlanSystemMessage = armPlanSystemMessage ?? new ArmPlanSystemMessageField(LoanNumber);
                UpdateOtherFields(armPlanSystemMessage, true);
                return armPlanSystemMessage;
            }
            set
            {
                armPlanSystemMessage = armPlanSystemMessage ?? new ArmPlanSystemMessageField(LoanNumber);
                UpdateOtherFields(armPlanSystemMessage, false);
                armPlanSystemMessage = value;
            }
        }
    }
}