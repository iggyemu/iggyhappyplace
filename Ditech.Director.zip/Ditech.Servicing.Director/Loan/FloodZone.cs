#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FloodZoneField floodZone;

        /// <summary>
        /// Gets or sets the flood zone.
        /// </summary>
        /// <value>The flood zone.</value>
        public FloodZoneField FloodZone
        {
            get
            {
                floodZone = floodZone ?? new FloodZoneField(LoanNumber);
                UpdateOtherFields(floodZone, true);
                return floodZone;
            }
            set
            {
                floodZone = floodZone ?? new FloodZoneField(LoanNumber);
                UpdateOtherFields(floodZone, false);
                floodZone = value;
            }
        }
    }
}