﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimePhoneNumberField draftingOneTimePhoneNumber;

        /// <summary>
        /// Gets or sets the drafting one time phone number.
        /// </summary>
        /// <value>The drafting one time phone number.</value>
        public DraftingOneTimePhoneNumberField DraftingOneTimePhoneNumber
        {
            get
            {
                draftingOneTimePhoneNumber = draftingOneTimePhoneNumber ?? new DraftingOneTimePhoneNumberField(LoanNumber);
                UpdateOtherFields(draftingOneTimePhoneNumber, true);
                return draftingOneTimePhoneNumber;
            }
            set
            {
                draftingOneTimePhoneNumber = draftingOneTimePhoneNumber ?? new DraftingOneTimePhoneNumberField(LoanNumber);
                UpdateOtherFields(draftingOneTimePhoneNumber, false);
                draftingOneTimePhoneNumber = value;
            }
        }
    }
}