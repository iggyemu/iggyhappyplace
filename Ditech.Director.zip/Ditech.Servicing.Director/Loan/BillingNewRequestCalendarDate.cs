﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
		#region Fields (1) 

        private BillingNewRequestCalendarDateField billingNewRequestCalendarDate;

		#endregion Fields 

		#region Properties (1) 

        /// <summary>
        /// Gets or sets the billing new request calendar date.
        /// </summary>
        /// <value>The billing new request calendar date.</value>
        public BillingNewRequestCalendarDateField BillingNewRequestCalendarDate
        {
            get
            {
                billingNewRequestCalendarDate = billingNewRequestCalendarDate ?? new BillingNewRequestCalendarDateField(LoanNumber);
                UpdateOtherFields(billingNewRequestCalendarDate, true);
                return billingNewRequestCalendarDate;
            }
            set
            {
                billingNewRequestCalendarDate = billingNewRequestCalendarDate ?? new BillingNewRequestCalendarDateField(LoanNumber);
                UpdateOtherFields(billingNewRequestCalendarDate, false);
                billingNewRequestCalendarDate = value;
            }
        }

		#endregion Properties 
    }
}