﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BillingCityField billingCity;

        /// <summary>
        /// Gets or sets the billing city.
        /// </summary>
        /// <value>The billing city.</value>
        public BillingCityField BillingCity
        {
            get
            {
                billingCity = billingCity ?? new BillingCityField(LoanNumber);
                UpdateOtherFields(billingCity, true);
                return billingCity;
            }
            set
            {
                billingCity = billingCity ?? new BillingCityField(LoanNumber);
                UpdateOtherFields(billingCity, false);
                billingCity = value;
            }
        }
    }
}