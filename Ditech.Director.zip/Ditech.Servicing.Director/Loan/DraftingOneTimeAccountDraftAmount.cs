﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAccountDraftAmountField draftingOneTimeAccountDraftAmount;

        /// <summary>
        /// Gets or sets the drafting one time account draft amount.
        /// </summary>
        /// <value>The drafting one time account draft amount.</value>
        public DraftingOneTimeAccountDraftAmountField DraftingOneTimeAccountDraftAmount
        {
            get
            {
                draftingOneTimeAccountDraftAmount = draftingOneTimeAccountDraftAmount ?? new DraftingOneTimeAccountDraftAmountField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountDraftAmount, true);
                return draftingOneTimeAccountDraftAmount;
            }
            set
            {
                draftingOneTimeAccountDraftAmount = draftingOneTimeAccountDraftAmount ?? new DraftingOneTimeAccountDraftAmountField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountDraftAmount, false);
                draftingOneTimeAccountDraftAmount = value;
            }
        }
    }
}