#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BillingStreetField billingStreet;

        /// <summary>
        /// Gets or sets the billing street.
        /// </summary>
        /// <value>The billing street.</value>
        public BillingStreetField BillingStreet
        {
            get
            {
                billingStreet = billingStreet ?? new BillingStreetField(LoanNumber);
                UpdateOtherFields(billingStreet, true);
                return billingStreet;
            }
            set
            {
                billingStreet = billingStreet ?? new BillingStreetField(LoanNumber);
                UpdateOtherFields(billingStreet, false);
                billingStreet = value;
            }
        }
    }
}