#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceRequestLoanNumber1Field customerServiceRequestLoanNumber1;

        /// <summary>
        /// Gets or sets the customer service request loan number1.
        /// </summary>
        /// <value>The customer service request loan number1.</value>
        public CustomerServiceRequestLoanNumber1Field CustomerServiceRequestLoanNumber1
        {
            get
            {
                customerServiceRequestLoanNumber1 = customerServiceRequestLoanNumber1 ?? new CustomerServiceRequestLoanNumber1Field(LoanNumber);
                UpdateOtherFields(customerServiceRequestLoanNumber1, true);
                return customerServiceRequestLoanNumber1;
            }
            set
            {
                customerServiceRequestLoanNumber1 = customerServiceRequestLoanNumber1 ?? new CustomerServiceRequestLoanNumber1Field(LoanNumber);
                UpdateOtherFields(customerServiceRequestLoanNumber1, false);
                customerServiceRequestLoanNumber1 = value;
            }
        }
    }
}