﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementTypeField escrowDisbursementType;

        /// <summary>
        /// Gets or sets the type of the escrow disbursement.
        /// </summary>
        /// <value>The type of the escrow disbursement.</value>
        public EscrowDisbursementTypeField EscrowDisbursementType
        {
            get
            {
                escrowDisbursementType = escrowDisbursementType ?? new EscrowDisbursementTypeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementType, true);
                return escrowDisbursementType;
            }
            set
            {
                escrowDisbursementType = escrowDisbursementType ?? new EscrowDisbursementTypeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementType, false);
                escrowDisbursementType = value;
            }
        }
    }
}