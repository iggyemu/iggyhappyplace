﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyRepaymentPlanAmountLine1Field delinquencyRepaymentPlanAmountLine1;

        /// <summary>
        /// Gets or sets the delinquency repayment plan amount line1.
        /// </summary>
        /// <value>The delinquency repayment plan amount line1.</value>
        public DelinquencyRepaymentPlanAmountLine1Field DelinquencyRepaymentPlanAmountLine1
        {
            get
            {
                delinquencyRepaymentPlanAmountLine1 = delinquencyRepaymentPlanAmountLine1 ?? new DelinquencyRepaymentPlanAmountLine1Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanAmountLine1, true);
                return delinquencyRepaymentPlanAmountLine1;
            }
            set
            {
                delinquencyRepaymentPlanAmountLine1 = delinquencyRepaymentPlanAmountLine1 ?? new DelinquencyRepaymentPlanAmountLine1Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanAmountLine1, false);
                delinquencyRepaymentPlanAmountLine1 = value;
            }
        }
    }
}