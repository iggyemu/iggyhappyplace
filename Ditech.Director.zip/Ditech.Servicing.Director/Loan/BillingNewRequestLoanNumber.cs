﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        #region Fields (1)

        private BillingNewRequestLoanNumberField billingNewRequestLoanNumber;

        #endregion Fields

        #region Properties (1)

        /// <summary>
        /// Gets or sets the billing new request loan number.
        /// </summary>
        /// <value>The billing new request loan number.</value>
        public BillingNewRequestLoanNumberField BillingNewRequestLoanNumber
        {
            get
            {
                billingNewRequestLoanNumber = billingNewRequestLoanNumber ?? new BillingNewRequestLoanNumberField(LoanNumber);
                UpdateOtherFields(billingNewRequestLoanNumber, true);
                return billingNewRequestLoanNumber;
            }
            set
            {
                billingNewRequestLoanNumber = billingNewRequestLoanNumber ?? new BillingNewRequestLoanNumberField(LoanNumber);
                UpdateOtherFields(billingNewRequestLoanNumber, false);
                billingNewRequestLoanNumber = value;
            }
        }

        #endregion Properties
    }
}