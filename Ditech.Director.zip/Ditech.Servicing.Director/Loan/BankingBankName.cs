﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankingBankNameField bankingBankName;

        /// <summary>
        /// Gets or sets the name of the banking bank.
        /// </summary>
        /// <value>The name of the banking bank.</value>
        public BankingBankNameField BankingBankName
        {
            get
            {
                bankingBankName = bankingBankName ?? new BankingBankNameField(LoanNumber);
                UpdateOtherFields(bankingBankName, true);
                return bankingBankName;
            }
            set
            {
                bankingBankName = bankingBankName ?? new BankingBankNameField(LoanNumber);
                UpdateOtherFields(bankingBankName, false);
                bankingBankName = value;
            }
        }
    }
}