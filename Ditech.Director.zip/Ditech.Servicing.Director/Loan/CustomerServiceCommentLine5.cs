#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine5Field customerServiceCommentLine5;


        /// <summary>
        /// Gets or sets the SER1 Note Line 5.
        /// </summary>
        /// <value>The SER1 Note Line 5.</value>
        public CustomerServiceCommentLine5Field CustomerServiceCommentLine5
        {
            get
            {
                customerServiceCommentLine5 = customerServiceCommentLine5 ?? new CustomerServiceCommentLine5Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine5, true);
                return customerServiceCommentLine5;
            }
            set
            {
                customerServiceCommentLine5 = customerServiceCommentLine5 ?? new CustomerServiceCommentLine5Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine5, false);
                customerServiceCommentLine5 = value;
            }
        }
    }
}