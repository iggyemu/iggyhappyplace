#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FirstLegalActionDateField firstLegalActionDate;

        /// <summary>
        /// Gets or sets the first legal action date.
        /// </summary>
        /// <value>The first legal action date.</value>
        public FirstLegalActionDateField FirstLegalActionDate
        {
            get
            {
                firstLegalActionDate = firstLegalActionDate ?? new FirstLegalActionDateField(LoanNumber);
                UpdateOtherFields(firstLegalActionDate, true);
                return firstLegalActionDate;
            }
            set
            {
                firstLegalActionDate = firstLegalActionDate ?? new FirstLegalActionDateField(LoanNumber);
                UpdateOtherFields(firstLegalActionDate, false);
                firstLegalActionDate = value;
            }
        }
    }
}