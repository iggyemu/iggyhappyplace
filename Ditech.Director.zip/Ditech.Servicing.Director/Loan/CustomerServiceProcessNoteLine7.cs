#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine7Field customerServiceProcessNoteLine7;


        /// <summary>
        /// Gets or sets the SER2 Note Line 7.
        /// </summary>
        /// <value>The SER2 Note Line 7.</value>
        public CustomerServiceProcessNoteLine7Field CustomerServiceProcessNoteLine7
        {
            get
            {
                customerServiceProcessNoteLine7 = customerServiceProcessNoteLine7 ?? new CustomerServiceProcessNoteLine7Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine7, true);
                return customerServiceProcessNoteLine7;
            }
            set
            {
                customerServiceProcessNoteLine7 = customerServiceProcessNoteLine7 ?? new CustomerServiceProcessNoteLine7Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine7, false);
                customerServiceProcessNoteLine7 = value;
            }
        }
    }
}