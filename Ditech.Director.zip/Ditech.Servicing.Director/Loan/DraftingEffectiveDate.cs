﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingEffectiveDateField draftingEffectiveDate;

        /// <summary>
        /// Gets or sets the drafting effective date.
        /// </summary>
        /// <value>The drafting effective date.</value>
        public DraftingEffectiveDateField DraftingEffectiveDate
        {
            get
            {
                draftingEffectiveDate = draftingEffectiveDate ?? new DraftingEffectiveDateField(LoanNumber);
                UpdateOtherFields(draftingEffectiveDate, true);
                return draftingEffectiveDate;
            }
            set
            {
                draftingEffectiveDate = draftingEffectiveDate ?? new DraftingEffectiveDateField(LoanNumber);
                UpdateOtherFields(draftingEffectiveDate, false);
                draftingEffectiveDate = value;
            }
        }
    }
}