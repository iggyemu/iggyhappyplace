#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingAccountNameField draftingAccountName;

        /// <summary>
        /// Gets or sets the name of the drafting account.
        /// </summary>
        /// <value>The name of the drafting account.</value>
        public DraftingAccountNameField DraftingAccountName
        {
            get
            {
                draftingAccountName = draftingAccountName ?? new DraftingAccountNameField(LoanNumber);
                UpdateOtherFields(draftingAccountName, true);
                return draftingAccountName;
            }
            set
            {
                draftingAccountName = draftingAccountName ?? new DraftingAccountNameField(LoanNumber);
                UpdateOtherFields(draftingAccountName, false);
                draftingAccountName = value;
            }
        }
    }
}