﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementOverrideField escrowDisbursementOverride;

        /// <summary>
        /// Gets or sets the escrow disbursement override.
        /// </summary>
        /// <value>The escrow disbursement override.</value>
        public EscrowDisbursementOverrideField EscrowDisbursementOverride
        {
            get
            {
                escrowDisbursementOverride = escrowDisbursementOverride ?? new EscrowDisbursementOverrideField(LoanNumber);
                UpdateOtherFields(escrowDisbursementOverride, true);
                return escrowDisbursementOverride;
            }
            set
            {
                escrowDisbursementOverride = escrowDisbursementOverride ?? new EscrowDisbursementOverrideField(LoanNumber);
                UpdateOtherFields(escrowDisbursementOverride, false);
                escrowDisbursementOverride = value;
            }
        }
    }
}