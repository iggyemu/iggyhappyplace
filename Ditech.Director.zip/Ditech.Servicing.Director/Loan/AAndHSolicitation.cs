﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private AAndHSolicitationField aAndHSolicitation;

        /// <summary>
        /// Gets or sets the life solicitation.
        /// </summary>
        /// <value>The life solicitation.</value>
        public AAndHSolicitationField AAndHSolicitation
        {
            get
            {
                aAndHSolicitation = aAndHSolicitation ?? new AAndHSolicitationField(LoanNumber);
                UpdateOtherFields(aAndHSolicitation, true);
                return aAndHSolicitation;
            }
            set
            {
                aAndHSolicitation = aAndHSolicitation ?? new AAndHSolicitationField(LoanNumber);
                UpdateOtherFields(aAndHSolicitation, false);
                aAndHSolicitation = value;
            }
        }
    }
}