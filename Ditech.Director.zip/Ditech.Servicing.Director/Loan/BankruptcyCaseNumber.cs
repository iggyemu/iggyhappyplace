﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyCaseNumberField bankruptcyCaseNumber;

        /// <summary>
        /// Gets or sets the bankruptcy case number.
        /// </summary>
        /// <value>The bankruptcy case number.</value>
        public BankruptcyCaseNumberField BankruptcyCaseNumber
        {
            get
            {
                bankruptcyCaseNumber = bankruptcyCaseNumber ?? new BankruptcyCaseNumberField(LoanNumber);
                UpdateOtherFields(bankruptcyCaseNumber, true);
                return bankruptcyCaseNumber;
            }
            set
            {
                bankruptcyCaseNumber = bankruptcyCaseNumber ?? new BankruptcyCaseNumberField(LoanNumber);
                UpdateOtherFields(bankruptcyCaseNumber, false);
                bankruptcyCaseNumber = value;
            }
        }
    }
}