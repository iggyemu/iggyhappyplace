#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DueDateNextPaymentField dueDateNextPayment;

        /// <summary>
        /// Gets or sets the due date next payment.
        /// </summary>
        /// <value>The due date next payment.</value>
        public DueDateNextPaymentField DueDateNextPayment
        {
            get
            {
                dueDateNextPayment = dueDateNextPayment ?? new DueDateNextPaymentField(LoanNumber);
                UpdateOtherFields(dueDateNextPayment, true);
                return dueDateNextPayment;
            }
            set
            {
                dueDateNextPayment = dueDateNextPayment ?? new DueDateNextPaymentField(LoanNumber);
                UpdateOtherFields(dueDateNextPayment, false);
                dueDateNextPayment = value;
            }
        }
    }
}