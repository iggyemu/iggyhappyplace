﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAccountNumberField draftingOneTimeAccountNumber;

        /// <summary>
        /// Gets or sets the drafting one time account number.
        /// </summary>
        /// <value>The drafting one time account number.</value>
        public DraftingOneTimeAccountNumberField DraftingOneTimeAccountNumber
        {
            get
            {
                draftingOneTimeAccountNumber = draftingOneTimeAccountNumber ?? new DraftingOneTimeAccountNumberField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountNumber, true);
                return draftingOneTimeAccountNumber;
            }
            set
            {
                draftingOneTimeAccountNumber = draftingOneTimeAccountNumber ?? new DraftingOneTimeAccountNumberField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountNumber, false);
                draftingOneTimeAccountNumber = value;
            }
        }
    }
}