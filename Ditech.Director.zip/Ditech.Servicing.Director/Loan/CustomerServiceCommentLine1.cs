#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine1Field customerServiceCommentLine1;


        /// <summary>
        /// Gets or sets the SER1 Note Line 1.
        /// </summary>
        /// <value>The SER1 Note Line 1.</value>
        public CustomerServiceCommentLine1Field CustomerServiceCommentLine1
        {
            get
            {
                customerServiceCommentLine1 = customerServiceCommentLine1 ?? new CustomerServiceCommentLine1Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine1, true);
                return customerServiceCommentLine1;
            }
            set
            {
                customerServiceCommentLine1 = customerServiceCommentLine1 ?? new CustomerServiceCommentLine1Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine1, false);
                customerServiceCommentLine1 = value;
            }
        }
    }
}