#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FeeAmountField feeAmount;

        /// <summary>
        /// Gets or sets the fee amount.
        /// </summary>
        /// <value>The fee amount.</value>
        public FeeAmountField FeeAmount
        {
            get
            {
                feeAmount = feeAmount ?? new FeeAmountField(LoanNumber);
                UpdateOtherFields(feeAmount, true);
                return feeAmount;
            }
            set
            {
                feeAmount = feeAmount ?? new FeeAmountField(LoanNumber);
                UpdateOtherFields(feeAmount, false);
                feeAmount = value;
            }
        }
    }
}