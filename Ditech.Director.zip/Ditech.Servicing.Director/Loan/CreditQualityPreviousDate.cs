#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CreditQualityPreviousDateField creditQualityPreviousDate;

        /// <summary>
        /// Gets or sets the credit quality previous date.
        /// </summary>
        /// <value>The credit quality previous date.</value>
        public CreditQualityPreviousDateField CreditQualityPreviousDate
        {
            get
            {
                creditQualityPreviousDate = creditQualityPreviousDate ?? new CreditQualityPreviousDateField(LoanNumber);
                UpdateOtherFields(creditQualityPreviousDate, true);
                return creditQualityPreviousDate;
            }
            set
            {
                creditQualityPreviousDate = creditQualityPreviousDate ?? new CreditQualityPreviousDateField(LoanNumber);
                UpdateOtherFields(creditQualityPreviousDate, false);
                creditQualityPreviousDate = value;
            }
        }
    }
}