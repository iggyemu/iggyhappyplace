﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAccountNameField draftingOneTimeAccountName;

        /// <summary>
        /// Gets or sets the name of the drafting one time account.
        /// </summary>
        /// <value>The name of the drafting one time account.</value>
        public DraftingOneTimeAccountNameField DraftingOneTimeAccountName
        {
            get
            {
                draftingOneTimeAccountName = draftingOneTimeAccountName ?? new DraftingOneTimeAccountNameField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountName, true);
                return draftingOneTimeAccountName;
            }
            set
            {
                draftingOneTimeAccountName = draftingOneTimeAccountName ?? new DraftingOneTimeAccountNameField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountName, false);
                draftingOneTimeAccountName = value;
            }
        }
    }
}