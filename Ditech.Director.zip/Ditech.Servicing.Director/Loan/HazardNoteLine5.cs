﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine5Field hazardNoteLine5;

        /// <summary>
        /// Gets or sets the hazard note line5.
        /// </summary>
        /// <value>The hazard note line5.</value>
        public HazardNoteLine5Field HazardNoteLine5
        {
            get
            {
                hazardNoteLine5 = hazardNoteLine5 ?? new HazardNoteLine5Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine5, true);
                return hazardNoteLine5;
            }
            set
            {
                hazardNoteLine5 = hazardNoteLine5 ?? new HazardNoteLine5Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine5, false);
                hazardNoteLine5 = value;
            }
        }
    }
}