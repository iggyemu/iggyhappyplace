#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine5Field customerServiceProcessNoteLine5;


        /// <summary>
        /// Gets or sets the SER2 Note Line 5.
        /// </summary>
        /// <value>The SER2 Note Line 5.</value>
        public CustomerServiceProcessNoteLine5Field CustomerServiceProcessNoteLine5
        {
            get
            {
                customerServiceProcessNoteLine5 = customerServiceProcessNoteLine5 ?? new CustomerServiceProcessNoteLine5Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine5, true);
                return customerServiceProcessNoteLine5;
            }
            set
            {
                customerServiceProcessNoteLine5 = customerServiceProcessNoteLine5 ?? new CustomerServiceProcessNoteLine5Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine5, false);
                customerServiceProcessNoteLine5 = value;
            }
        }
    }
}