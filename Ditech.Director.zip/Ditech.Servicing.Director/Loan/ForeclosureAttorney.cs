﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ForeclosureAttorneyField foreclosureAttorney;

        /// <summary>
        /// Gets or sets the foreclosure attorney.
        /// </summary>
        /// <value>The foreclosure attorney.</value>
        public ForeclosureAttorneyField ForeclosureAttorney
        {
            get
            {
                foreclosureAttorney = foreclosureAttorney ?? new ForeclosureAttorneyField(LoanNumber);
                UpdateOtherFields(foreclosureAttorney, true);
                return foreclosureAttorney;
            }
            set
            {
                foreclosureAttorney = foreclosureAttorney ?? new ForeclosureAttorneyField(LoanNumber);
                UpdateOtherFields(foreclosureAttorney, false);
                foreclosureAttorney = value;
            }
        }
    }
}