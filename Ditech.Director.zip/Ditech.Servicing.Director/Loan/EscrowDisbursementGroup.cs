﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementGroupField escrowDisbursementGroup;

        /// <summary>
        /// Gets or sets the escrow disbursement group.
        /// </summary>
        /// <value>The escrow disbursement group.</value>
        public EscrowDisbursementGroupField EscrowDisbursementGroup
        {
            get
            {
                escrowDisbursementGroup = escrowDisbursementGroup ?? new EscrowDisbursementGroupField(LoanNumber);
                UpdateOtherFields(escrowDisbursementGroup, true);
                return escrowDisbursementGroup;
            }
            set
            {
                escrowDisbursementGroup = escrowDisbursementGroup ?? new EscrowDisbursementGroupField(LoanNumber);
                UpdateOtherFields(escrowDisbursementGroup, false);
                escrowDisbursementGroup = value;
            }
        }
    }
}