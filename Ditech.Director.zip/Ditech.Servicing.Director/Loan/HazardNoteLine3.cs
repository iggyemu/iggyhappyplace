﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine3Field hazardNoteLine3;

        /// <summary>
        /// Gets or sets the hazard note line3.
        /// </summary>
        /// <value>The hazard note line3.</value>
        public HazardNoteLine3Field HazardNoteLine3
        {
            get
            {
                hazardNoteLine3 = hazardNoteLine3 ?? new HazardNoteLine3Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine3, true);
                return hazardNoteLine3;
            }
            set
            {
                hazardNoteLine3 = hazardNoteLine3 ?? new HazardNoteLine3Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine3, false);
                hazardNoteLine3 = value;
            }
        }
    }
}