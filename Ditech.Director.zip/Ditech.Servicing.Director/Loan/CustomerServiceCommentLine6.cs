#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine6Field customerServiceCommentLine6;


        /// <summary>
        /// Gets or sets the SER1 Note Line 6.
        /// </summary>
        /// <value>The SER1 Note Line 6.</value>
        public CustomerServiceCommentLine6Field CustomerServiceCommentLine6
        {
            get
            {
                customerServiceCommentLine6 = customerServiceCommentLine6 ?? new CustomerServiceCommentLine6Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine6, true);
                return customerServiceCommentLine6;
            }
            set
            {
                customerServiceCommentLine6 = customerServiceCommentLine6 ?? new CustomerServiceCommentLine6Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine6, false);
                customerServiceCommentLine6 = value;
            }
        }
    }
}