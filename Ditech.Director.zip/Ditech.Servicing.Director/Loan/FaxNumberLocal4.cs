#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FaxNumberLocal4Field faxNumberLocal4;

        /// <summary>
        /// Gets or sets the fax number local4.
        /// </summary>
        /// <value>The fax number local4.</value>
        public FaxNumberLocal4Field FaxNumberLocal4
        {
            get
            {
                faxNumberLocal4 = faxNumberLocal4 ?? new FaxNumberLocal4Field(LoanNumber);
                UpdateOtherFields(faxNumberLocal4, true);
                return faxNumberLocal4;
            }
            set
            {
                faxNumberLocal4 = faxNumberLocal4 ?? new FaxNumberLocal4Field(LoanNumber);
                UpdateOtherFields(faxNumberLocal4, false);
                faxNumberLocal4 = value;
            }
        }
    }
}