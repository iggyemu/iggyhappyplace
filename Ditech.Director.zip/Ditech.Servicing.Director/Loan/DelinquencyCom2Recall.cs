#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCom2RecallField delinquencyCom2Recall;


        /// <summary>
        /// Gets or sets the delinquency com2 recall.
        /// </summary>
        /// <value>The delinquency com2 recall.</value>
        public DelinquencyCom2RecallField DelinquencyCom2Recall
        {
            get
            {
                delinquencyCom2Recall = delinquencyCom2Recall ?? new DelinquencyCom2RecallField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Recall, true);
                return delinquencyCom2Recall;
            }
            set
            {
                delinquencyCom2Recall = delinquencyCom2Recall ?? new DelinquencyCom2RecallField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Recall, false);
                delinquencyCom2Recall = value;
            }
        }
    }
}