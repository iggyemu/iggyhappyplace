﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankingAccountNumberField bankingAccountNumber;

        /// <summary>
        /// Gets or sets the banking account number.
        /// </summary>
        /// <value>The banking account number.</value>
        public BankingAccountNumberField BankingAccountNumber
        {
            get
            {
                bankingAccountNumber = bankingAccountNumber ?? new BankingAccountNumberField(LoanNumber);
                UpdateOtherFields(bankingAccountNumber, true);
                return bankingAccountNumber;
            }
            set
            {
                bankingAccountNumber = bankingAccountNumber ?? new BankingAccountNumberField(LoanNumber);
                UpdateOtherFields(bankingAccountNumber, false);
                bankingAccountNumber = value;
            }
        }
    }
}