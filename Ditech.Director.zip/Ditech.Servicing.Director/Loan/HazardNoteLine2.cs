﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine2Field hazardNoteLine2;

        /// <summary>
        /// Gets or sets the hazard note line2.
        /// </summary>
        /// <value>The hazard note line2.</value>
        public HazardNoteLine2Field HazardNoteLine2
        {
            get
            {
                hazardNoteLine2 = hazardNoteLine2 ?? new HazardNoteLine2Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine2, true);
                return hazardNoteLine2;
            }
            set
            {
                hazardNoteLine2 = hazardNoteLine2 ?? new HazardNoteLine2Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine2, false);
                hazardNoteLine2 = value;
            }
        }
    }
}