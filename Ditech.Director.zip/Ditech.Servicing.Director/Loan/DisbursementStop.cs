﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DisbursementStopField disbursementStop;

        /// <summary>
        /// Gets or sets the disbursement stop.
        /// </summary>
        /// <value>The disbursement stop.</value>
        public DisbursementStopField DisbursementStop
        {
            get
            {
                disbursementStop = disbursementStop ?? new DisbursementStopField(LoanNumber);
                UpdateOtherFields(disbursementStop, true);
                return disbursementStop;
            }
            set
            {
                disbursementStop = disbursementStop ?? new DisbursementStopField(LoanNumber);
                UpdateOtherFields(disbursementStop, false);
                disbursementStop = value;
            }
        }
    }
}