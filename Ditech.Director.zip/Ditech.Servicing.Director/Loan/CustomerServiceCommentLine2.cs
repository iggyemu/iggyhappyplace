#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine2Field customerServiceCommentLine2;


        /// <summary>
        /// Gets or sets the SER1NoteLine2.
        /// </summary>
        /// <value>The SER1NoteLine 2.</value>
        public CustomerServiceCommentLine2Field CustomerServiceCommentLine2
        {
            get
            {
                customerServiceCommentLine2 = customerServiceCommentLine2 ?? new CustomerServiceCommentLine2Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine2, true);
                return customerServiceCommentLine2;
            }
            set
            {
                customerServiceCommentLine2 = customerServiceCommentLine2 ?? new CustomerServiceCommentLine2Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine2, false);
                customerServiceCommentLine2 = value;
            }
        }
    }
}