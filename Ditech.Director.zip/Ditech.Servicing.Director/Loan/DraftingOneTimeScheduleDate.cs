﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeScheduleDateField draftingOneTimeScheduleDate;

        /// <summary>
        /// Gets or sets the drafting one time schedule date.
        /// </summary>
        /// <value>The drafting one time schedule date.</value>
        public DraftingOneTimeScheduleDateField DraftingOneTimeScheduleDate
        {
            get
            {
                draftingOneTimeScheduleDate = draftingOneTimeScheduleDate ?? new DraftingOneTimeScheduleDateField(LoanNumber);
                UpdateOtherFields(draftingOneTimeScheduleDate, true);
                return draftingOneTimeScheduleDate;
            }
            set
            {
                draftingOneTimeScheduleDate = draftingOneTimeScheduleDate ?? new DraftingOneTimeScheduleDateField(LoanNumber);
                UpdateOtherFields(draftingOneTimeScheduleDate, false);
                draftingOneTimeScheduleDate = value;
            }
        }
    }
}