#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine3Field customerServiceProcessNoteLine3;


        /// <summary>
        /// Gets or sets the SER2 Note Line 3.
        /// </summary>
        /// <value>The SER2 Note Line 3.</value>
        public CustomerServiceProcessNoteLine3Field CustomerServiceProcessNoteLine3
        {
            get
            {
                customerServiceProcessNoteLine3 = customerServiceProcessNoteLine3 ?? new CustomerServiceProcessNoteLine3Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine3, true);
                return customerServiceProcessNoteLine3;
            }
            set
            {
                customerServiceProcessNoteLine3 = customerServiceProcessNoteLine3 ?? new CustomerServiceProcessNoteLine3Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine3, false);
                customerServiceProcessNoteLine3 = value;
            }
        }
    }
}