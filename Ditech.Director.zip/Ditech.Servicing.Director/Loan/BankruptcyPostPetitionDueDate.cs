﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyPostPetitionDueDateField bankruptcyPostPetitionDueDate;

        /// <summary>
        /// Gets or sets the bankruptcy post petition due date.
        /// </summary>
        /// <value>The bankruptcy post petition due date.</value>
        public BankruptcyPostPetitionDueDateField BankruptcyPostPetitionDueDate
        {
            get
            {
                bankruptcyPostPetitionDueDate = bankruptcyPostPetitionDueDate ?? new BankruptcyPostPetitionDueDateField(LoanNumber);
                UpdateOtherFields(bankruptcyPostPetitionDueDate, true);
                return bankruptcyPostPetitionDueDate;
            }
            set
            {
                bankruptcyPostPetitionDueDate = bankruptcyPostPetitionDueDate ?? new BankruptcyPostPetitionDueDateField(LoanNumber);
                UpdateOtherFields(bankruptcyPostPetitionDueDate, false);
                bankruptcyPostPetitionDueDate = value;
            }
        }
    }
}