﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyFilingDateField bankruptcyFilingDate;

        /// <summary>
        /// Gets or sets the bankruptcy filing date.
        /// </summary>
        /// <value>The bankruptcy filing date.</value>
        public BankruptcyFilingDateField BankruptcyFilingDate
        {
            get
            {
                bankruptcyFilingDate = bankruptcyFilingDate ?? new BankruptcyFilingDateField(LoanNumber);
                UpdateOtherFields(bankruptcyFilingDate, true);
                return bankruptcyFilingDate;
            }
            set
            {
                bankruptcyFilingDate = bankruptcyFilingDate ?? new BankruptcyFilingDateField(LoanNumber);
                UpdateOtherFields(bankruptcyFilingDate, false);
                bankruptcyFilingDate = value;
            }
        }
    }
}