#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingDelayDaysField draftingDelayDays;

        /// <summary>
        /// Gets or sets the drafting delay days.
        /// </summary>
        /// <value>The drafting delay days.</value>
        public DraftingDelayDaysField DraftingDelayDays
        {
            get
            {
                draftingDelayDays = draftingDelayDays ?? new DraftingDelayDaysField(LoanNumber);
                UpdateOtherFields(draftingDelayDays, true);
                return draftingDelayDays;
            }
            set
            {
                draftingDelayDays = draftingDelayDays ?? new DraftingDelayDaysField(LoanNumber);
                UpdateOtherFields(draftingDelayDays, false);
                draftingDelayDays = value;
            }
        }
    }
}