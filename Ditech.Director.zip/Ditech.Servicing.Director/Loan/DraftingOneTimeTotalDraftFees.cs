﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeTotalDraftFeesField draftingOneTimeTotalDraftFees;

        /// <summary>
        /// Gets or sets the drafting one time total draft fees.
        /// </summary>
        /// <value>The drafting one time total draft fees.</value>
        public DraftingOneTimeTotalDraftFeesField DraftingOneTimeTotalDraftFees
        {
            get
            {
                draftingOneTimeTotalDraftFees = draftingOneTimeTotalDraftFees ?? new DraftingOneTimeTotalDraftFeesField(LoanNumber);
                UpdateOtherFields(draftingOneTimeTotalDraftFees, true);
                return draftingOneTimeTotalDraftFees;
            }
            set
            {
                draftingOneTimeTotalDraftFees = draftingOneTimeTotalDraftFees ?? new DraftingOneTimeTotalDraftFeesField(LoanNumber);
                UpdateOtherFields(draftingOneTimeTotalDraftFees, false);
                draftingOneTimeTotalDraftFees = value;
            }
        }
    }
}