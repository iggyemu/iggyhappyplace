﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        #region Fields (1)

        private BillingNewRequestDetailHistoryTransactionField billingNewRequestDetailHistoryTransaction;

        #endregion Fields

        #region Properties (1)

        /// <summary>
        /// Gets or sets the billing new request detail history transaction.
        /// </summary>
        /// <value>The billing new request detail history transaction.</value>
        public BillingNewRequestDetailHistoryTransactionField BillingNewRequestDetailHistoryTransaction
        {
            get
            {
                billingNewRequestDetailHistoryTransaction = billingNewRequestDetailHistoryTransaction ?? new BillingNewRequestDetailHistoryTransactionField(LoanNumber);
                UpdateOtherFields(billingNewRequestDetailHistoryTransaction, true);
                return billingNewRequestDetailHistoryTransaction;
            }
            set
            {
                billingNewRequestDetailHistoryTransaction = billingNewRequestDetailHistoryTransaction ?? new BillingNewRequestDetailHistoryTransactionField(LoanNumber);
                UpdateOtherFields(billingNewRequestDetailHistoryTransaction, false);
                billingNewRequestDetailHistoryTransaction = value;
            }
        }

        #endregion Properties
    }
}
