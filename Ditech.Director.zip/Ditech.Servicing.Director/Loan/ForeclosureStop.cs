﻿using Ditech.Servicing.Director.MspFields;

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ForeclosureStopField foreclosureStop;

        /// <summary>
        /// Gets or sets the foreclosure Stop .
        /// </summary>
        /// <value>The foreclosure Stop .</value>
        public ForeclosureStopField ForeclosureStop
        {
            get
            {
                foreclosureStop = foreclosureStop ?? new ForeclosureStopField(LoanNumber);
                UpdateOtherFields(foreclosureStop, true);
                return foreclosureStop;
            }
            set
            {
                foreclosureStop = foreclosureStop ?? new ForeclosureStopField(LoanNumber);
                UpdateOtherFields(foreclosureStop, false);
                foreclosureStop = value;
            }
        }
    }
}