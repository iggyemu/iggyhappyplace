﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencySuspenseField delinquencySuspense;

        /// <summary>
        /// Gets or sets the delinquency suspense.
        /// </summary>
        /// <value>The delinquency suspense.</value>
        public DelinquencySuspenseField DelinquencySuspense
        {
            get
            {
                delinquencySuspense = delinquencySuspense ?? new DelinquencySuspenseField(LoanNumber);
                UpdateOtherFields(delinquencySuspense, true);
                return delinquencySuspense;
            }
            set
            {
                delinquencySuspense = delinquencySuspense ?? new DelinquencySuspenseField(LoanNumber);
                UpdateOtherFields(delinquencySuspense, false);
                delinquencySuspense = value;
            }
        }
    }
}