#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine2Field customerServiceProcessNoteLine2;


        /// <summary>
        /// Gets or sets the SER2 Note Line 2.
        /// </summary>
        /// <value>The SER2 Note Line 2.</value>
        public CustomerServiceProcessNoteLine2Field CustomerServiceProcessNoteLine2
        {
            get
            {
                customerServiceProcessNoteLine2 = customerServiceProcessNoteLine2 ?? new CustomerServiceProcessNoteLine2Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine2, true);
                return customerServiceProcessNoteLine2;
            }
            set
            {
                customerServiceProcessNoteLine2 = customerServiceProcessNoteLine2 ?? new CustomerServiceProcessNoteLine2Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine2, false);
                customerServiceProcessNoteLine2 = value;
            }
        }
    }
}