#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CouponFlagField couponFlag;

        /// <summary>
        /// Gets or sets the coupon flag.
        /// </summary>
        /// <value>The coupon flag.</value>
        public CouponFlagField CouponFlag
        {
            get
            {
                couponFlag = couponFlag ?? new CouponFlagField(LoanNumber);
                UpdateOtherFields(couponFlag, true);
                return couponFlag;
            }
            set
            {
                couponFlag = couponFlag ?? new CouponFlagField(LoanNumber);
                UpdateOtherFields(couponFlag, false);
                couponFlag = value;
            }
        }
    }
}