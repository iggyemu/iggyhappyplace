using Ditech.Servicing.Director.MspFields;

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLogCodeField customerServiceCommentLogCode;


        /// <summary>
        /// Gets or sets the SER2 log code.
        /// </summary>
        /// <value>The SER2 log code.</value>
        public CustomerServiceCommentLogCodeField CustomerServiceCommentLogCode
        {
            get
            {
                customerServiceCommentLogCode = customerServiceCommentLogCode ?? new CustomerServiceCommentLogCodeField(LoanNumber);
                UpdateOtherFields(customerServiceCommentLogCode, true);
                return customerServiceCommentLogCode;
            }
            set
            {
                customerServiceCommentLogCode = customerServiceCommentLogCode ?? new CustomerServiceCommentLogCodeField(LoanNumber);
                UpdateOtherFields(customerServiceCommentLogCode, false);
                customerServiceCommentLogCode = value;
            }
        }
    }
}