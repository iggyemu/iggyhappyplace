#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FeeCodeField feeCode;

        /// <summary>
        /// Gets or sets the fee code.
        /// </summary>
        /// <value>The fee code.</value>
        public FeeCodeField FeeCode
        {
            get
            {
                feeCode = feeCode ?? new FeeCodeField(LoanNumber);
                UpdateOtherFields(feeCode, true);
                return feeCode;
            }
            set
            {
                feeCode = feeCode ?? new FeeCodeField(LoanNumber);
                UpdateOtherFields(feeCode, false);
                feeCode = value;
            }
        }
    }
}