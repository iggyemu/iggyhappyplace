#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EmailMortgagorField emailMortgagor;

        /// <summary>
        /// Gets or sets the email mortgagor.
        /// </summary>
        /// <value>The email mortgagor.</value>
        public EmailMortgagorField EmailMortgagor
        {
            get
            {
                emailMortgagor = emailMortgagor ?? new EmailMortgagorField(LoanNumber);
                UpdateOtherFields(emailMortgagor, true);
                return emailMortgagor;
            }
            set
            {
                emailMortgagor = emailMortgagor ?? new EmailMortgagorField(LoanNumber);
                UpdateOtherFields(emailMortgagor, false);
                emailMortgagor = value;
            }
        }
    }
}