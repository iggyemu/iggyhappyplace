﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine10Field hazardNoteLine10;

        /// <summary>
        /// Gets or sets the hazard note line10.
        /// </summary>
        /// <value>The hazard note line10.</value>
        public HazardNoteLine10Field HazardNoteLine10
        {
            get
            {
                hazardNoteLine10 = hazardNoteLine10 ?? new HazardNoteLine10Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine10, true);
                return hazardNoteLine10;
            }
            set
            {
                hazardNoteLine10 = hazardNoteLine10 ?? new HazardNoteLine10Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine10, false);
                hazardNoteLine10 = value;
            }
        }
    }
}