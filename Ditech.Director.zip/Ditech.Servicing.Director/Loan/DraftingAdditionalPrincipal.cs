#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingAdditionalPrincipalField draftingAdditionalPrincipal;

        /// <summary>
        /// Gets or sets the drafting additional principal.
        /// </summary>
        /// <value>The drafting additional principal.</value>
        public DraftingAdditionalPrincipalField DraftingAdditionalPrincipal
        {
            get
            {
                draftingAdditionalPrincipal = draftingAdditionalPrincipal ??
                                              new DraftingAdditionalPrincipalField(LoanNumber);
                UpdateOtherFields(draftingAdditionalPrincipal, true);
                return draftingAdditionalPrincipal;
            }
            set
            {
                draftingAdditionalPrincipal = draftingAdditionalPrincipal ??
                                              new DraftingAdditionalPrincipalField(LoanNumber);
                UpdateOtherFields(draftingAdditionalPrincipal, false);
                draftingAdditionalPrincipal = value;
            }
        }
    }
}