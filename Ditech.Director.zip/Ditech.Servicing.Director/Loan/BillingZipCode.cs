#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BillingZipCodeField billingZipCode;

        /// <summary>
        /// Gets or sets the billing zip code.
        /// </summary>
        /// <value>The billing zip code.</value>
        public BillingZipCodeField BillingZipCode
        {
            get
            {
                billingZipCode = billingZipCode ?? new BillingZipCodeField(LoanNumber);
                UpdateOtherFields(billingZipCode, true);
                return billingZipCode;
            }
            set
            {
                billingZipCode = billingZipCode ?? new BillingZipCodeField(LoanNumber);
                UpdateOtherFields(billingZipCode, false);
                billingZipCode = value;
            }
        }
    }
}