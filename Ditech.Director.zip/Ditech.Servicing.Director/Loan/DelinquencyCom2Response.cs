#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCom2ResponseField delinquencyCom2Response;

        /// <summary>
        /// Gets or sets the delinquency com2 response.
        /// </summary>
        /// <value>The delinquency com2 response.</value>
        public DelinquencyCom2ResponseField DelinquencyCom2Response
        {
            get
            {
                delinquencyCom2Response = delinquencyCom2Response ?? new DelinquencyCom2ResponseField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Response, true);
                return delinquencyCom2Response;
            }
            set
            {
                delinquencyCom2Response = delinquencyCom2Response ?? new DelinquencyCom2ResponseField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Response, false);
                delinquencyCom2Response = value;
            }
        }
    }
}