#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCom2ContactField delinquencyCom2Contact;

        /// <summary>
        /// Gets or sets the delinquency com2 contact.
        /// </summary>
        /// <value>The delinquency com2 contact.</value>
        public DelinquencyCom2ContactField DelinquencyCom2Contact
        {
            get
            {
                delinquencyCom2Contact = delinquencyCom2Contact ?? new DelinquencyCom2ContactField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Contact, true);
                return delinquencyCom2Contact;
            }
            set
            {
                delinquencyCom2Contact = delinquencyCom2Contact ?? new DelinquencyCom2ContactField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Contact, false);
                delinquencyCom2Contact = value;
            }
        }
    }
}