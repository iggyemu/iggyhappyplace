﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCommentLine1Field delinquencyCommentLine1;

        /// <summary>
        /// Gets or sets the delinquency comment line1.
        /// </summary>
        /// <value>The delinquency comment line1.</value>
        public DelinquencyCommentLine1Field DelinquencyCommentLine1
        {
            get
            {
                delinquencyCommentLine1 = delinquencyCommentLine1 ?? new DelinquencyCommentLine1Field(LoanNumber);
                UpdateOtherFields(delinquencyCommentLine1, true);
                return delinquencyCommentLine1;
            }
            set
            {
                delinquencyCommentLine1 = delinquencyCommentLine1 ?? new DelinquencyCommentLine1Field(LoanNumber);
                UpdateOtherFields(delinquencyCommentLine1, false);
                delinquencyCommentLine1 = value;
            }
        }
    }
}
