﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeSuspenseAmountField draftingOneTimeSuspenseAmount;

        /// <summary>
        /// Gets or sets the drafting one time suspense amount.
        /// </summary>
        /// <value>The drafting one time suspense amount.</value>
        public DraftingOneTimeSuspenseAmountField DraftingOneTimeSuspenseAmount
        {
            get
            {
                draftingOneTimeSuspenseAmount = draftingOneTimeSuspenseAmount ?? new DraftingOneTimeSuspenseAmountField(LoanNumber);
                UpdateOtherFields(draftingOneTimeSuspenseAmount, true);
                return draftingOneTimeSuspenseAmount;
            }
            set
            {
                draftingOneTimeSuspenseAmount = draftingOneTimeSuspenseAmount ?? new DraftingOneTimeSuspenseAmountField(LoanNumber);
                UpdateOtherFields(draftingOneTimeSuspenseAmount, false);
                draftingOneTimeSuspenseAmount = value;
            }
        }
    }
}