#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCom2ReasonField delinquencyCom2Reason;

        /// <summary>
        /// Gets or sets the delinquency com2 reason.
        /// </summary>
        /// <value>The delinquency com2 reason.</value>
        public DelinquencyCom2ReasonField DelinquencyCom2Reason
        {
            get
            {
                delinquencyCom2Reason = delinquencyCom2Reason ?? new DelinquencyCom2ReasonField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Reason, true);
                return delinquencyCom2Reason;
            }
            set
            {
                delinquencyCom2Reason = delinquencyCom2Reason ?? new DelinquencyCom2ReasonField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Reason, false);
                delinquencyCom2Reason = value;
            }
        }
    }
}