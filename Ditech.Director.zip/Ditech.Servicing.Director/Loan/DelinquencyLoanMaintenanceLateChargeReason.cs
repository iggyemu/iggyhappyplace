#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyLoanMaintenanceLateChargeReasonField delinquencyLoanMaintenanceLateChargeReason;

        /// <summary>
        /// Gets or sets the delinquency loan maintenance late charge reason.
        /// </summary>
        /// <value>The delinquency loan maintenance late charge reason.</value>
        public DelinquencyLoanMaintenanceLateChargeReasonField DelinquencyLoanMaintenanceLateChargeReason
        {
            get
            {
                delinquencyLoanMaintenanceLateChargeReason = delinquencyLoanMaintenanceLateChargeReason ?? new DelinquencyLoanMaintenanceLateChargeReasonField(LoanNumber);
                UpdateOtherFields(delinquencyLoanMaintenanceLateChargeReason, true);
                return delinquencyLoanMaintenanceLateChargeReason;
            }
            set
            {
                delinquencyLoanMaintenanceLateChargeReason = delinquencyLoanMaintenanceLateChargeReason ?? new DelinquencyLoanMaintenanceLateChargeReasonField(LoanNumber);
                UpdateOtherFields(delinquencyLoanMaintenanceLateChargeReason, false);
                delinquencyLoanMaintenanceLateChargeReason = value;
            }
        }
    }
}