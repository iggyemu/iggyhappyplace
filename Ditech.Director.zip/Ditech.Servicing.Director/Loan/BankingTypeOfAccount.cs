﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankingTypeOfAccountField bankingTypeOfAccount;

        /// <summary>
        /// Gets or sets the banking type of account.
        /// </summary>
        /// <value>The banking type of account.</value>
        public BankingTypeOfAccountField BankingTypeOfAccount
        {
            get
            {
                bankingTypeOfAccount = bankingTypeOfAccount ?? new BankingTypeOfAccountField(LoanNumber);
                UpdateOtherFields(bankingTypeOfAccount, true);
                return bankingTypeOfAccount;
            }
            set
            {
                bankingTypeOfAccount = bankingTypeOfAccount ?? new BankingTypeOfAccountField(LoanNumber);
                UpdateOtherFields(bankingTypeOfAccount, false);
                bankingTypeOfAccount = value;
            }
        }
    }
}