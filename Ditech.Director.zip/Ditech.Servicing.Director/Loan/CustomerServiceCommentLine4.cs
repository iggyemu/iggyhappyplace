#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine4Field customerServiceCommentLine4;


        /// <summary>
        /// Gets or sets the SER1 Note Line 4.
        /// </summary>
        /// <value>The SER1 Note Line 4.</value>
        public CustomerServiceCommentLine4Field CustomerServiceCommentLine4
        {
            get
            {
                customerServiceCommentLine4 = customerServiceCommentLine4 ?? new CustomerServiceCommentLine4Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine4, true);
                return customerServiceCommentLine4;
            }
            set
            {
                customerServiceCommentLine4 = customerServiceCommentLine4 ?? new CustomerServiceCommentLine4Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine4, false);
                customerServiceCommentLine4 = value;
            }
        }
    }
}