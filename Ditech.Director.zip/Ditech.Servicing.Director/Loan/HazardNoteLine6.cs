﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine6Field hazardNoteLine6;

        /// <summary>
        /// Gets or sets the hazard note line6.
        /// </summary>
        /// <value>The hazard note line6.</value>
        public HazardNoteLine6Field HazardNoteLine6
        {
            get
            {
                hazardNoteLine6 = hazardNoteLine6 ?? new HazardNoteLine6Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine6, true);
                return hazardNoteLine6;
            }
            set
            {
                hazardNoteLine6 = hazardNoteLine6 ?? new HazardNoteLine6Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine6, false);
                hazardNoteLine6 = value;
            }
        }
    }
}