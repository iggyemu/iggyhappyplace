﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        #region Fields (1)

        private BillingNewRequestOptionsResetAlphaUserTableField billingNewRequestOptionsResetAlphaUserTable;

        #endregion Fields

        #region Properties (1)

        /// <summary>
        /// Gets or sets the billing new request loan number.
        /// </summary>
        /// <value>The billing new request loan number.</value>
        public BillingNewRequestOptionsResetAlphaUserTableField BillingNewRequestOptionsResetAlphaUserTable
        {
            get
            {
                billingNewRequestOptionsResetAlphaUserTable = billingNewRequestOptionsResetAlphaUserTable ?? new BillingNewRequestOptionsResetAlphaUserTableField(LoanNumber);
                UpdateOtherFields(billingNewRequestOptionsResetAlphaUserTable, true);
                return billingNewRequestOptionsResetAlphaUserTable;
            }
            set
            {
                billingNewRequestOptionsResetAlphaUserTable = billingNewRequestOptionsResetAlphaUserTable ?? new BillingNewRequestOptionsResetAlphaUserTableField(LoanNumber);
                UpdateOtherFields(billingNewRequestOptionsResetAlphaUserTable, false);
                billingNewRequestOptionsResetAlphaUserTable = value;
            }
        }

        #endregion Properties
    }
}