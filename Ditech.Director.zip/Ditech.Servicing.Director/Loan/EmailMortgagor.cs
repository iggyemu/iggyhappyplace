#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EmailCoMortgagorField emailCoMortgagor;

        /// <summary>
        /// Gets or sets the email co mortgagor.
        /// </summary>
        /// <value>The email co mortgagor.</value>
        public EmailCoMortgagorField EmailCoMortgagor
        {
            get
            {
                emailCoMortgagor = emailCoMortgagor ?? new EmailCoMortgagorField(LoanNumber);
                UpdateOtherFields(emailCoMortgagor, true);
                return emailCoMortgagor;
            }
            set
            {
                emailCoMortgagor = emailCoMortgagor ?? new EmailCoMortgagorField(LoanNumber);
                UpdateOtherFields(emailCoMortgagor, false);
                emailCoMortgagor = value;
            }
        }
    }
}