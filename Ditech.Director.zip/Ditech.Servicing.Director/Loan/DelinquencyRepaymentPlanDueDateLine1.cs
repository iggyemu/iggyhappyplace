﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyRepaymentPlanDueDateLine1Field delinquencyRepaymentPlanDueDateLine1;

        /// <summary>
        /// Gets or sets the delinquency repayment plan due date line 1.
        /// </summary>
        /// <value>The delinquency repayment plan due date line 1.</value>
        public DelinquencyRepaymentPlanDueDateLine1Field DelinquencyRepaymentPlanDueDateLine1
        {
            get
            {
                delinquencyRepaymentPlanDueDateLine1 = delinquencyRepaymentPlanDueDateLine1 ?? new DelinquencyRepaymentPlanDueDateLine1Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanDueDateLine1, true);
                return delinquencyRepaymentPlanDueDateLine1;
            }
            set
            {
                delinquencyRepaymentPlanDueDateLine1 = delinquencyRepaymentPlanDueDateLine1 ?? new DelinquencyRepaymentPlanDueDateLine1Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanDueDateLine1, false);
                delinquencyRepaymentPlanDueDateLine1 = value;
            }
        }
    }
}