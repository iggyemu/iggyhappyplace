﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAccountTypeField draftingOneTimeAccountType;

        /// <summary>
        /// Gets or sets the type of the drafting one time account.
        /// </summary>
        /// <value>The type of the drafting one time account.</value>
        public DraftingOneTimeAccountTypeField DraftingOneTimeAccountType
        {
            get
            {
                draftingOneTimeAccountType = draftingOneTimeAccountType ?? new DraftingOneTimeAccountTypeField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountType, true);
                return draftingOneTimeAccountType;
            }
            set
            {
                draftingOneTimeAccountType = draftingOneTimeAccountType ?? new DraftingOneTimeAccountTypeField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAccountType, false);
                draftingOneTimeAccountType = value;
            }
        }
    }
}