#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CreditConditionField creditCondition;

        /// <summary>
        /// Gets or sets the credit condition.
        /// </summary>
        /// <value>The credit condition.</value>
        public CreditConditionField CreditCondition
        {
            get
            {
                creditCondition = creditCondition ?? new CreditConditionField(LoanNumber);
                UpdateOtherFields(creditCondition, true);
                return creditCondition;
            }
            set
            {
                creditCondition = creditCondition ?? new CreditConditionField(LoanNumber);
                UpdateOtherFields(creditCondition, false);
                creditCondition = value;
            }
        }
    }
}