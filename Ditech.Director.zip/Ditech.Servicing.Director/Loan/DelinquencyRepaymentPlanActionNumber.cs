﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyRepaymentPlanActionNumberField delinquencyRepaymentPlanActionNumber;

        /// <summary>
        /// Gets or sets the delinquency repayment plan action number.
        /// </summary>
        /// <value>The delinquency repayment plan action number.</value>
        public DelinquencyRepaymentPlanActionNumberField DelinquencyRepaymentPlanActionNumber
        {
            get
            {
                delinquencyRepaymentPlanActionNumber = delinquencyRepaymentPlanActionNumber ?? new DelinquencyRepaymentPlanActionNumberField(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanActionNumber, true);
                return delinquencyRepaymentPlanActionNumber;
            }
            set
            {
                delinquencyRepaymentPlanActionNumber = delinquencyRepaymentPlanActionNumber ?? new DelinquencyRepaymentPlanActionNumberField(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanActionNumber, false);
                delinquencyRepaymentPlanActionNumber = value;
            }
        }
    }
}