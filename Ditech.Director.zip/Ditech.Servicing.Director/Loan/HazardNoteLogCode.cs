﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLogCodeField hazardNoteLogCode;

        /// <summary>
        /// Gets or sets the hazard note log code.
        /// </summary>
        /// <value>The hazard note log code.</value>
        public HazardNoteLogCodeField HazardNoteLogCode
        {
            get
            {
                hazardNoteLogCode = hazardNoteLogCode ?? new HazardNoteLogCodeField(LoanNumber);
                UpdateOtherFields(hazardNoteLogCode, true);
                return hazardNoteLogCode;
            }
            set
            {
                hazardNoteLogCode = hazardNoteLogCode ?? new HazardNoteLogCodeField(LoanNumber);
                UpdateOtherFields(hazardNoteLogCode, false);
                hazardNoteLogCode = value;
            }
        }
    }
}