﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine8Field hazardNoteLine8;

        /// <summary>
        /// Gets or sets the hazard note line8.
        /// </summary>
        /// <value>The hazard note line8.</value>
        public HazardNoteLine8Field HazardNoteLine8
        {
            get
            {
                hazardNoteLine8 = hazardNoteLine8 ?? new HazardNoteLine8Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine8, true);
                return hazardNoteLine8;
            }
            set
            {
                hazardNoteLine8 = hazardNoteLine8 ?? new HazardNoteLine8Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine8, false);
                hazardNoteLine8 = value;
            }
        }
    }
}