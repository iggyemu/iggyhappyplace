#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLogCodeField customerServiceProcessNoteLogCode;


        /// <summary>
        /// Gets or sets the SER2 log code.
        /// </summary>
        /// <value>The SER2 log code.</value>
        public CustomerServiceProcessNoteLogCodeField CustomerServiceProcessNoteLogCode
        {
            get
            {
                customerServiceProcessNoteLogCode = customerServiceProcessNoteLogCode ?? new CustomerServiceProcessNoteLogCodeField(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLogCode, true);
                return customerServiceProcessNoteLogCode;
            }
            set
            {
                customerServiceProcessNoteLogCode = customerServiceProcessNoteLogCode ?? new CustomerServiceProcessNoteLogCodeField(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLogCode, false);
                customerServiceProcessNoteLogCode = value;
            }
        }
    }
}