﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardNoteLine7Field hazardNoteLine7;

        /// <summary>
        /// Gets or sets the hazard note line7.
        /// </summary>
        /// <value>The hazard note line7.</value>
        public HazardNoteLine7Field HazardNoteLine7
        {
            get
            {
                hazardNoteLine7 = hazardNoteLine7 ?? new HazardNoteLine7Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine7, true);
                return hazardNoteLine7;
            }
            set
            {
                hazardNoteLine7 = hazardNoteLine7 ?? new HazardNoteLine7Field(LoanNumber);
                UpdateOtherFields(hazardNoteLine7, false);
                hazardNoteLine7 = value;
            }
        }
    }
}