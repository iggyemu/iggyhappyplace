﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeActionField draftingOneTimeAction;

        /// <summary>
        /// Gets or sets the drafting one time action.
        /// </summary>
        /// <value>The drafting one time action.</value>
        public DraftingOneTimeActionField DraftingOneTimeAction
        {
            get
            {
                draftingOneTimeAction = draftingOneTimeAction ?? new DraftingOneTimeActionField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAction, true);
                return draftingOneTimeAction;
            }
            set
            {
                draftingOneTimeAction = draftingOneTimeAction ?? new DraftingOneTimeActionField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAction, false);
                draftingOneTimeAction = value;
            }
        }
    }
}