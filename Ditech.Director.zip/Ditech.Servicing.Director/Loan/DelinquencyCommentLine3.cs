﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCommentLine3Field delinquencyCommentLine3;

        /// <summary>
        /// Gets or sets the delinquency comment line3.
        /// </summary>
        /// <value>The delinquency comment line3.</value>
        public DelinquencyCommentLine3Field DelinquencyCommentLine3
        {
            get
            {
                delinquencyCommentLine3 = delinquencyCommentLine3 ?? new DelinquencyCommentLine3Field(LoanNumber);
                UpdateOtherFields(delinquencyCommentLine3, true);
                return delinquencyCommentLine3;
            }
            set
            {
                delinquencyCommentLine3 = delinquencyCommentLine3 ?? new DelinquencyCommentLine3Field(LoanNumber);
                UpdateOtherFields(delinquencyCommentLine3, false);
                delinquencyCommentLine3 = value;
            }
        }
    }
}
