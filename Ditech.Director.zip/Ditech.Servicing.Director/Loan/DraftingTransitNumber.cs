#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingTransitNumberField draftingTransitNumber;

        /// <summary>
        /// Gets or sets the drafting transit number.
        /// </summary>
        /// <value>The drafting transit number.</value>
        public DraftingTransitNumberField DraftingTransitNumber
        {
            get
            {
                draftingTransitNumber = draftingTransitNumber ?? new DraftingTransitNumberField(LoanNumber);
                UpdateOtherFields(draftingTransitNumber, true);
                return draftingTransitNumber;
            }
            set
            {
                draftingTransitNumber = draftingTransitNumber ?? new DraftingTransitNumberField(LoanNumber);
                UpdateOtherFields(draftingTransitNumber, false);
                draftingTransitNumber = value;
            }
        }
    }
}