#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingAccountNumberField draftingAccountNumber;


        /// <summary>
        /// Gets or sets the drafting account number.
        /// </summary>
        /// <value>The drafting account number.</value>
        public DraftingAccountNumberField DraftingAccountNumber
        {
            get
            {
                draftingAccountNumber = draftingAccountNumber ?? new DraftingAccountNumberField(LoanNumber);
                UpdateOtherFields(draftingAccountNumber, true);
                return draftingAccountNumber;
            }
            set
            {
                draftingAccountNumber = draftingAccountNumber ?? new DraftingAccountNumberField(LoanNumber);
                UpdateOtherFields(draftingAccountNumber, false);
                draftingAccountNumber = value;
            }
        }
    }
}