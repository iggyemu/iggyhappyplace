﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeRoutingOrTransactionNumberField draftingOneTimeRoutingOrTransactionNumber;

        /// <summary>
        /// Gets or sets the drafting one time routing or transaction number.
        /// </summary>
        /// <value>The drafting one time routing or transaction number.</value>
        public DraftingOneTimeRoutingOrTransactionNumberField DraftingOneTimeRoutingOrTransactionNumber
        {
            get
            {
                draftingOneTimeRoutingOrTransactionNumber = draftingOneTimeRoutingOrTransactionNumber ?? new DraftingOneTimeRoutingOrTransactionNumberField(LoanNumber);
                UpdateOtherFields(draftingOneTimeRoutingOrTransactionNumber, true);
                return draftingOneTimeRoutingOrTransactionNumber;
            }
            set
            {
                draftingOneTimeRoutingOrTransactionNumber = draftingOneTimeRoutingOrTransactionNumber ?? new DraftingOneTimeRoutingOrTransactionNumberField(LoanNumber);
                UpdateOtherFields(draftingOneTimeRoutingOrTransactionNumber, false);
                draftingOneTimeRoutingOrTransactionNumber = value;
            }
        }
    }
}