﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeOnLineLetterWriterField draftingOneTimeOnLineLetterWriter;

        /// <summary>
        /// Gets or sets the drafting one time on line letter writer.
        /// </summary>
        /// <value>The drafting one time on line letter writer.</value>
        public DraftingOneTimeOnLineLetterWriterField DraftingOneTimeOnLineLetterWriter
        {
            get
            {
                draftingOneTimeOnLineLetterWriter = draftingOneTimeOnLineLetterWriter ?? new DraftingOneTimeOnLineLetterWriterField(LoanNumber);
                UpdateOtherFields(draftingOneTimeOnLineLetterWriter, true);
                return draftingOneTimeOnLineLetterWriter;
            }
            set
            {
                draftingOneTimeOnLineLetterWriter = draftingOneTimeOnLineLetterWriter ?? new DraftingOneTimeOnLineLetterWriterField(LoanNumber);
                UpdateOtherFields(draftingOneTimeOnLineLetterWriter, false);
                draftingOneTimeOnLineLetterWriter = value;
            }
        }
    }
}