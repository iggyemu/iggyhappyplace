#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCom2ForebearanceField delinquencyCom2Forebearance;

        /// <summary>
        /// Gets or sets the delinquency com2 forebearance.
        /// </summary>
        /// <value>The delinquency com2 forebearance.</value>
        public DelinquencyCom2ForebearanceField DelinquencyCom2Forebearance
        {
            get
            {
                delinquencyCom2Forebearance = delinquencyCom2Forebearance ?? new DelinquencyCom2ForebearanceField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Forebearance, true);
                return delinquencyCom2Forebearance;
            }
            set
            {
                delinquencyCom2Forebearance = delinquencyCom2Forebearance ?? new DelinquencyCom2ForebearanceField(LoanNumber);
                UpdateOtherFields(delinquencyCom2Forebearance, false);
                delinquencyCom2Forebearance = value;
            }
        }
    }
}