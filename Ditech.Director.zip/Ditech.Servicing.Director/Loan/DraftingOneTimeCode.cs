﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeCodeField draftingOneTimeCode;

        /// <summary>
        /// Gets or sets the drafting one time code.
        /// </summary>
        /// <value>The drafting one time code.</value>
        public DraftingOneTimeCodeField DraftingOneTimeCode
        {
            get
            {
                draftingOneTimeCode = draftingOneTimeCode ?? new DraftingOneTimeCodeField(LoanNumber);
                UpdateOtherFields(draftingOneTimeCode, true);
                return draftingOneTimeCode;
            }
            set
            {
                draftingOneTimeCode = draftingOneTimeCode ?? new DraftingOneTimeCodeField(LoanNumber);
                UpdateOtherFields(draftingOneTimeCode, false);
                draftingOneTimeCode = value;
            }
        }
    }
}