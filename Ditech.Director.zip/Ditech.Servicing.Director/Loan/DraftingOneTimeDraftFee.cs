﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeDraftFeeField draftingOneTimeDraftFee;

        /// <summary>
        /// Gets or sets the drafting one time draft fee.
        /// </summary>
        /// <value>The drafting one time draft fee.</value>
        public DraftingOneTimeDraftFeeField DraftingOneTimeDraftFee
        {
            get
            {
                draftingOneTimeDraftFee = draftingOneTimeDraftFee ?? new DraftingOneTimeDraftFeeField(LoanNumber);
                UpdateOtherFields(draftingOneTimeDraftFee, true);
                return draftingOneTimeDraftFee;
            }
            set
            {
                draftingOneTimeDraftFee = draftingOneTimeDraftFee ?? new DraftingOneTimeDraftFeeField(LoanNumber);
                UpdateOtherFields(draftingOneTimeDraftFee, false);
                draftingOneTimeDraftFee = value;
            }
        }
    }
}