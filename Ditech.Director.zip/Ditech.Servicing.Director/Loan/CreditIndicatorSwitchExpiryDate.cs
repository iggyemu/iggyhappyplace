#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CreditIndicatorSwitchExpiryDateField creditIndicatorSwitchExpiryDate;

        /// <summary>
        /// Gets or sets the credit indicator switch expiry date.
        /// </summary>
        /// <value>The credit indicator switch expiry date.</value>
        public CreditIndicatorSwitchExpiryDateField CreditIndicatorSwitchExpiryDate
        {
            get
            {
                creditIndicatorSwitchExpiryDate = creditIndicatorSwitchExpiryDate ?? new CreditIndicatorSwitchExpiryDateField(LoanNumber);
                UpdateOtherFields(creditIndicatorSwitchExpiryDate, true);
                return creditIndicatorSwitchExpiryDate;
            }
            set
            {
                creditIndicatorSwitchExpiryDate = creditIndicatorSwitchExpiryDate ?? new CreditIndicatorSwitchExpiryDateField(LoanNumber);
                UpdateOtherFields(creditIndicatorSwitchExpiryDate, false);
                creditIndicatorSwitchExpiryDate = value;
            }
        }
    }
}