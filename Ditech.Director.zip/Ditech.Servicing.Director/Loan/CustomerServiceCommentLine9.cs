#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine9Field customerServiceCommentLine9;


        /// <summary>
        /// Gets or sets the SER1 Note Line 9.
        /// </summary>
        /// <value>The SER1 Note Line 9.</value>
        public CustomerServiceCommentLine9Field CustomerServiceCommentLine9
        {
            get
            {
                customerServiceCommentLine9 = customerServiceCommentLine9 ?? new CustomerServiceCommentLine9Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine9, true);
                return customerServiceCommentLine9;
            }
            set
            {
                customerServiceCommentLine9 = customerServiceCommentLine9 ?? new CustomerServiceCommentLine9Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine9, false);
                customerServiceCommentLine9 = value;
            }
        }
    }
}