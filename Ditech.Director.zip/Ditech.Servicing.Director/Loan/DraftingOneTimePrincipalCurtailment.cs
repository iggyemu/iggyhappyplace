﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimePrincipalCurtailmentField draftingOneTimePrincipalCurtailment;

        /// <summary>
        /// Gets or sets the drafting one time principal curtailment.
        /// </summary>
        /// <value>The drafting one time principal curtailment.</value>
        public DraftingOneTimePrincipalCurtailmentField DraftingOneTimePrincipalCurtailment
        {
            get
            {
                draftingOneTimePrincipalCurtailment = draftingOneTimePrincipalCurtailment ?? new DraftingOneTimePrincipalCurtailmentField(LoanNumber);
                UpdateOtherFields(draftingOneTimePrincipalCurtailment, true);
                return draftingOneTimePrincipalCurtailment;
            }
            set
            {
                draftingOneTimePrincipalCurtailment = draftingOneTimePrincipalCurtailment ?? new DraftingOneTimePrincipalCurtailmentField(LoanNumber);
                UpdateOtherFields(draftingOneTimePrincipalCurtailment, false);
                draftingOneTimePrincipalCurtailment = value;
            }
        }
    }
}