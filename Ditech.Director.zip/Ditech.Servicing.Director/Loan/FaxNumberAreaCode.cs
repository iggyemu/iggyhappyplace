#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FaxNumberAreaCodeField faxNumberAreaCode;

        /// <summary>
        /// Gets or sets the fax number area code.
        /// </summary>
        /// <value>The fax number area code.</value>
        public FaxNumberAreaCodeField FaxNumberAreaCode
        {
            get
            {
                faxNumberAreaCode = faxNumberAreaCode ?? new FaxNumberAreaCodeField(LoanNumber);
                UpdateOtherFields(faxNumberAreaCode, true);
                return faxNumberAreaCode;
            }
            set
            {
                faxNumberAreaCode = faxNumberAreaCode ?? new FaxNumberAreaCodeField(LoanNumber);
                UpdateOtherFields(faxNumberAreaCode, false);
                faxNumberAreaCode = value;
            }
        }
    }
}