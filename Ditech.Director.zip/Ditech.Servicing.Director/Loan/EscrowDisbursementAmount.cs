﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementAmountField escrowDisbursementAmount;

        /// <summary>
        /// Gets or sets the escrow disbursement amount.
        /// </summary>
        /// <value>The escrow disbursement amount.</value>
        public EscrowDisbursementAmountField EscrowDisbursementAmount
        {
            get
            {
                escrowDisbursementAmount = escrowDisbursementAmount ?? new EscrowDisbursementAmountField(LoanNumber);
                UpdateOtherFields(escrowDisbursementAmount, true);
                return escrowDisbursementAmount;
            }
            set
            {
                escrowDisbursementAmount = escrowDisbursementAmount ?? new EscrowDisbursementAmountField(LoanNumber);
                UpdateOtherFields(escrowDisbursementAmount, false);
                escrowDisbursementAmount = value;
            }
        }
    }
}