﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAdditionalEscrowField draftingOneTimeAdditionalEscrow;

        /// <summary>
        /// Gets or sets the drafting one time additional escrow.
        /// </summary>
        /// <value>The drafting one time additional escrow.</value>
        public DraftingOneTimeAdditionalEscrowField DraftingOneTimeAdditionalEscrow
        {
            get
            {
                draftingOneTimeAdditionalEscrow = draftingOneTimeAdditionalEscrow ?? new DraftingOneTimeAdditionalEscrowField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAdditionalEscrow, true);
                return draftingOneTimeAdditionalEscrow;
            }
            set
            {
                draftingOneTimeAdditionalEscrow = draftingOneTimeAdditionalEscrow ?? new DraftingOneTimeAdditionalEscrowField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAdditionalEscrow, false);
                draftingOneTimeAdditionalEscrow = value;
            }
        }
    }
}