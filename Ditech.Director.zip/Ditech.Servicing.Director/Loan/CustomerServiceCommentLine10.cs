#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine10Field customerServiceCommentLine10;


        /// <summary>
        /// Gets or sets the SER1 Note Line 10.
        /// </summary>
        /// <value>The SER1 Note Line 10.</value>
        public CustomerServiceCommentLine10Field CustomerServiceCommentLine10
        {
            get
            {
                customerServiceCommentLine10 = customerServiceCommentLine10 ?? new CustomerServiceCommentLine10Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine10, true);
                return customerServiceCommentLine10;
            }
            set
            {
                customerServiceCommentLine10 = customerServiceCommentLine10 ?? new CustomerServiceCommentLine10Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine10, false);
                customerServiceCommentLine10 = value;
            }
        }
    }
}