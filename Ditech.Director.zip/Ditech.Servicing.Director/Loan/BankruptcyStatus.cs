#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyStatusField bankruptcyStatus;

        /// <summary>
        /// Gets or sets the bankruptcy status.
        /// </summary>
        /// <value>The bankruptcy status.</value>
        public BankruptcyStatusField BankruptcyStatus
        {
            get
            {
                bankruptcyStatus = bankruptcyStatus ?? new BankruptcyStatusField(LoanNumber);
                UpdateOtherFields(bankruptcyStatus, true);
                return bankruptcyStatus;
            }
            set
            {
                bankruptcyStatus = bankruptcyStatus ?? new BankruptcyStatusField(LoanNumber);
                UpdateOtherFields(bankruptcyStatus, false);
                bankruptcyStatus = value;
            }
        }
    }
}