﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyRepaymentPlanDueDateLine2Field delinquencyRepaymentPlanDueDateLine2;

        /// <summary>
        /// Gets or sets the delinquency repayment plan due date line2.
        /// </summary>
        /// <value>The delinquency repayment plan due date line2.</value>
        public DelinquencyRepaymentPlanDueDateLine2Field DelinquencyRepaymentPlanDueDateLine2
        {
            get
            {
                delinquencyRepaymentPlanDueDateLine2 = delinquencyRepaymentPlanDueDateLine2 ?? new DelinquencyRepaymentPlanDueDateLine2Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanDueDateLine2, true);
                return delinquencyRepaymentPlanDueDateLine2;
            }
            set
            {
                delinquencyRepaymentPlanDueDateLine2 = delinquencyRepaymentPlanDueDateLine2 ?? new DelinquencyRepaymentPlanDueDateLine2Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanDueDateLine2, false);
                delinquencyRepaymentPlanDueDateLine2 = value;
            }
        }
    }
}
