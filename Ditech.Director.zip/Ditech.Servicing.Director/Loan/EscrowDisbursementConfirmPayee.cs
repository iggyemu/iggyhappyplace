﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementConfirmPayeeField escrowDisbursementConfirmPayee;

        /// <summary>
        /// Gets or sets the escrow disbursement confirm payee.
        /// </summary>
        /// <value>The escrow disbursement confirm payee.</value>
        public EscrowDisbursementConfirmPayeeField EscrowDisbursementConfirmPayee
        {
            get
            {
                escrowDisbursementConfirmPayee = escrowDisbursementConfirmPayee ?? new EscrowDisbursementConfirmPayeeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementConfirmPayee, true);
                return escrowDisbursementConfirmPayee;
            }
            set
            {
                escrowDisbursementConfirmPayee = escrowDisbursementConfirmPayee ?? new EscrowDisbursementConfirmPayeeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementConfirmPayee, false);
                escrowDisbursementConfirmPayee = value;
            }
        }
    }
}