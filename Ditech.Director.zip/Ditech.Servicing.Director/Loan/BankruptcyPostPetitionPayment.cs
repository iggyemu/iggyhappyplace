﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyPostPetitionPaymentField bankruptcyPostPetitionPayment;

        /// <summary>
        /// Gets or sets the bankruptcy post petition payment.
        /// </summary>
        /// <value>The bankruptcy post petition payment.</value>
        public BankruptcyPostPetitionPaymentField BankruptcyPostPetitionPayment
        {
            get
            {
                bankruptcyPostPetitionPayment = bankruptcyPostPetitionPayment ?? new BankruptcyPostPetitionPaymentField(LoanNumber);
                UpdateOtherFields(bankruptcyPostPetitionPayment, true);
                return bankruptcyPostPetitionPayment;
            }
            set
            {
                bankruptcyPostPetitionPayment = bankruptcyPostPetitionPayment ?? new BankruptcyPostPetitionPaymentField(LoanNumber);
                UpdateOtherFields(bankruptcyPostPetitionPayment, false);
                bankruptcyPostPetitionPayment = value;
            }
        }
    }
}