#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private FaxNumberLocal3Field faxNumberLocal3;

        /// <summary>
        /// Gets or sets the fax number local3.
        /// </summary>
        /// <value>The fax number local3.</value>
        public FaxNumberLocal3Field FaxNumberLocal3
        {
            get
            {
                faxNumberLocal3 = faxNumberLocal3 ?? new FaxNumberLocal3Field(LoanNumber);
                UpdateOtherFields(faxNumberLocal3, true);
                return faxNumberLocal3;
            }
            set
            {
                faxNumberLocal3 = faxNumberLocal3 ?? new FaxNumberLocal3Field(LoanNumber);
                UpdateOtherFields(faxNumberLocal3, false);
                faxNumberLocal3 = value;
            }
        }
    }
}