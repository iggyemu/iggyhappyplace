﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CoMortgagorLast4SsnField coMortgagorLast4Ssn;

        /// <summary>
        /// Gets the co mortgagor last4 SSN.
        /// </summary>
        /// <value>The co mortgagor last4 SSN.</value>
        public CoMortgagorLast4SsnField CoMortgagorLast4Ssn
        {
            get
            {
                coMortgagorLast4Ssn = coMortgagorLast4Ssn ?? new CoMortgagorLast4SsnField(LoanNumber);
                UpdateOtherFields(coMortgagorLast4Ssn, true);
                return coMortgagorLast4Ssn;
            }
        }
    }
}