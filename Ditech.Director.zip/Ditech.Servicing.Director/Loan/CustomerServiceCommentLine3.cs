#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceCommentLine3Field customerServiceCommentLine3;


        /// <summary>
        /// Gets or sets the SER1 NoteLine3.
        /// </summary>
        /// <value>The SER1 Note Line 1.</value>
        public CustomerServiceCommentLine3Field CustomerServiceCommentLine3
        {
            get
            {
                customerServiceCommentLine3 = customerServiceCommentLine3 ?? new CustomerServiceCommentLine3Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine3, true);
                return customerServiceCommentLine3;
            }
            set
            {
                customerServiceCommentLine3 = customerServiceCommentLine3 ?? new CustomerServiceCommentLine3Field(LoanNumber);
                UpdateOtherFields(customerServiceCommentLine3, false);
                customerServiceCommentLine3 = value;
            }
        }
    }
}