﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ForeclosureAttorneyPhoneNumberField foreclosureAttorneyPhoneNumber;

        /// <summary>
        /// Gets or sets the foreclosure attorney phone number.
        /// </summary>
        /// <value>The foreclosure attorney phone number.</value>
        public ForeclosureAttorneyPhoneNumberField ForeclosureAttorneyPhoneNumber
        {
            get
            {
                foreclosureAttorneyPhoneNumber = foreclosureAttorneyPhoneNumber ?? new ForeclosureAttorneyPhoneNumberField(LoanNumber);
                UpdateOtherFields(foreclosureAttorneyPhoneNumber, true);
                return foreclosureAttorneyPhoneNumber;
            }
            set
            {
                foreclosureAttorneyPhoneNumber = foreclosureAttorneyPhoneNumber ?? new ForeclosureAttorneyPhoneNumberField(LoanNumber);
                UpdateOtherFields(foreclosureAttorneyPhoneNumber, false);
                foreclosureAttorneyPhoneNumber = value;
            }
        }
    }
}