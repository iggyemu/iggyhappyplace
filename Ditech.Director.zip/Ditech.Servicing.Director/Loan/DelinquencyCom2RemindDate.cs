#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCom2RemindDate delinquencyCom2RemindDate;

        /// <summary>
        /// Gets or sets the delinquency com2 remind date.
        /// </summary>
        /// <value>The delinquency com2 remind date.</value>
        public DelinquencyCom2RemindDate DelinquencyCom2RemindDate
        {
            get
            {
                delinquencyCom2RemindDate = delinquencyCom2RemindDate ?? new DelinquencyCom2RemindDate(LoanNumber);
                UpdateOtherFields(delinquencyCom2RemindDate, true);
                return delinquencyCom2RemindDate;
            }
            set
            {
                delinquencyCom2RemindDate = delinquencyCom2RemindDate ?? new DelinquencyCom2RemindDate(LoanNumber);
                UpdateOtherFields(delinquencyCom2RemindDate, false);
                delinquencyCom2RemindDate = value;
            }
        }
    }
}