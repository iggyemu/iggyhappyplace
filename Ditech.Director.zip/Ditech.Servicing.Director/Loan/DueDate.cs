﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DueDateField dueDate;

        /// <summary>
        /// Gets or sets the due date.
        /// </summary>
        /// <value>The due date.</value>
       public DueDateField DueDate
        {
            get
            {
                dueDate = dueDate ?? new DueDateField(LoanNumber);
                UpdateOtherFields(dueDate, true);
                return dueDate;
            }
            set
            {
                dueDate = dueDate ?? new DueDateField(LoanNumber);
                UpdateOtherFields(dueDate, false);
                dueDate = value;
            }
        }
    }
}