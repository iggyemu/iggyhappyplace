﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeRequestorField draftingOneTimeRequestor;

        /// <summary>
        /// Gets or sets the drafting one time requestor.
        /// </summary>
        /// <value>The drafting one time requestor.</value>
        public DraftingOneTimeRequestorField DraftingOneTimeRequestor
        {
            get
            {
                draftingOneTimeRequestor = draftingOneTimeRequestor ?? new DraftingOneTimeRequestorField(LoanNumber);
                UpdateOtherFields(draftingOneTimeRequestor, true);
                return draftingOneTimeRequestor;
            }
            set
            {
                draftingOneTimeRequestor = draftingOneTimeRequestor ?? new DraftingOneTimeRequestorField(LoanNumber);
                UpdateOtherFields(draftingOneTimeRequestor, false);
                draftingOneTimeRequestor = value;
            }
        }
    }
}