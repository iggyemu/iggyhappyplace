﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowPaymentField escrowPayment;

        /// <summary>
        /// Gets the escrow payment amount.
        /// </summary>
        /// <value>The escrow payment amount.</value>
        public EscrowPaymentField EscrowPayment
        {
            get
            {
                escrowPayment = escrowPayment ?? new EscrowPaymentField(LoanNumber);
                UpdateOtherFields(escrowPayment, true);
                return escrowPayment;
            }
        }
    }
}