﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeAdditionalFeesField draftingOneTimeAdditionalFees;

        /// <summary>
        /// Gets or sets the drafting one time additional fees.
        /// </summary>
        /// <value>The drafting one time additional fees.</value>
       public DraftingOneTimeAdditionalFeesField DraftingOneTimeAdditionalFees
        {
            get
            {
                draftingOneTimeAdditionalFees = draftingOneTimeAdditionalFees ?? new DraftingOneTimeAdditionalFeesField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAdditionalFees, true);
                return draftingOneTimeAdditionalFees;
            }
            set
            {
                draftingOneTimeAdditionalFees = draftingOneTimeAdditionalFees ?? new DraftingOneTimeAdditionalFeesField(LoanNumber);
                UpdateOtherFields(draftingOneTimeAdditionalFees, false);
                draftingOneTimeAdditionalFees = value;
            }
        }
    }
}