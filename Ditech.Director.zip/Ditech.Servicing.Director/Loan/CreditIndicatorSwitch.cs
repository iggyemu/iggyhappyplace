#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CreditIndicatorSwitchField creditIndicatorSwitch;

        /// <summary>
        /// Gets or sets the Credit Indicator Switch.
        /// </summary>
        public CreditIndicatorSwitchField CreditIndicatorSwitch
        {
            get
            {
                creditIndicatorSwitch = creditIndicatorSwitch ?? new CreditIndicatorSwitchField(LoanNumber);
                UpdateOtherFields(creditIndicatorSwitch, true);
                return creditIndicatorSwitch;
            }
            set
            {
                creditIndicatorSwitch = creditIndicatorSwitch ?? new CreditIndicatorSwitchField(LoanNumber);
                UpdateOtherFields(creditIndicatorSwitch, false);
                creditIndicatorSwitch = value;
            }
        }
    }
}