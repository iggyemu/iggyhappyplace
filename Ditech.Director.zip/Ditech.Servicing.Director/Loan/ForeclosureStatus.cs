using Ditech.Servicing.Director.MspFields;

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ForeclosureStatusField foreclosureStatus;

        /// <summary>
        /// Gets or sets the foreclosure status .
        /// </summary>
        /// <value>The foreclosure status .</value>
        public ForeclosureStatusField ForeclosureStatus
        {
            get
            {
                foreclosureStatus = foreclosureStatus ?? new ForeclosureStatusField(LoanNumber);
                UpdateOtherFields(foreclosureStatus, true);
                return foreclosureStatus;
            }
            set
            {
                foreclosureStatus = foreclosureStatus ?? new ForeclosureStatusField(LoanNumber);
                UpdateOtherFields(foreclosureStatus, false);
                foreclosureStatus = value;
            }
        }
    }
}