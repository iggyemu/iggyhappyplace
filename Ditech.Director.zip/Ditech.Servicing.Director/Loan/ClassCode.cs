﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private ClassCodeField classCode;

        /// <summary>
        /// Gets or sets the class code.
        /// </summary>
        /// <value>The class code.</value>
        public ClassCodeField ClassCode
        {
            get
            {
                classCode = classCode ?? new ClassCodeField(LoanNumber);
                UpdateOtherFields(classCode, true);
                return classCode;
            }
            set
            {
                classCode = classCode ?? new ClassCodeField(LoanNumber);
                UpdateOtherFields(classCode, false);
                classCode = value;
            }
        }
    }
}