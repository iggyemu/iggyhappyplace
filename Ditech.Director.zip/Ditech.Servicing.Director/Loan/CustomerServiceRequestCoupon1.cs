#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceRequestCoupon1Field customerServiceRequestCoupon1;

        /// <summary>
        /// Gets or sets the customer service request coupon1.
        /// </summary>
        /// <value>The customer service request coupon1.</value>
        public CustomerServiceRequestCoupon1Field CustomerServiceRequestCoupon1
        {
            get
            {
                customerServiceRequestCoupon1 = customerServiceRequestCoupon1 ?? new CustomerServiceRequestCoupon1Field(LoanNumber);
                UpdateOtherFields(customerServiceRequestCoupon1, true);
                return customerServiceRequestCoupon1;
            }
            set
            {
                customerServiceRequestCoupon1 = customerServiceRequestCoupon1 ?? new CustomerServiceRequestCoupon1Field(LoanNumber);
                UpdateOtherFields(customerServiceRequestCoupon1, false);
                customerServiceRequestCoupon1 = value;
            }
        }
    }
}