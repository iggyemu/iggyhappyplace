﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimeSourceField draftingOneTimeSource;

        /// <summary>
        /// Gets or sets the drafting one time source.
        /// </summary>
        /// <value>The drafting one time source.</value>
        public DraftingOneTimeSourceField DraftingOneTimeSource
        {
            get
            {
                draftingOneTimeSource = draftingOneTimeSource ?? new DraftingOneTimeSourceField(LoanNumber);
                UpdateOtherFields(draftingOneTimeSource, true);
                return draftingOneTimeSource;
            }
            set
            {
                draftingOneTimeSource = draftingOneTimeSource ?? new DraftingOneTimeSourceField(LoanNumber);
                UpdateOtherFields(draftingOneTimeSource, false);
                draftingOneTimeSource = value;
            }
        }
    }
}