﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyChapterField bankruptcyChapter;

        /// <summary>
        /// Gets or sets the bankruptcy chapter.
        /// </summary>
        /// <value>The bankruptcy chapter.</value>
        public BankruptcyChapterField BankruptcyChapter
        {
            get
            {
                bankruptcyChapter = bankruptcyChapter ?? new BankruptcyChapterField(LoanNumber);
                UpdateOtherFields(bankruptcyChapter, true);
                return bankruptcyChapter;
            }
            set
            {
                bankruptcyChapter = bankruptcyChapter ?? new BankruptcyChapterField(LoanNumber);
                UpdateOtherFields(bankruptcyChapter, false);
                bankruptcyChapter = value;
            }
        }
    }
}