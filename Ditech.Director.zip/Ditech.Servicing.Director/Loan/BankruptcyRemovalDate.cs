﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BankruptcyRemovalDateField bankruptcyRemovalDate;

        /// <summary>
        /// Gets or sets the bankruptcy removal date.
        /// </summary>
        /// <value>The bankruptcy removal date.</value>
        public BankruptcyRemovalDateField BankruptcyRemovalDate
        {
            get
            {
                bankruptcyRemovalDate = bankruptcyRemovalDate ?? new BankruptcyRemovalDateField(LoanNumber);
                UpdateOtherFields(bankruptcyRemovalDate, true);
                return bankruptcyRemovalDate;
            }
            set
            {
                bankruptcyRemovalDate = bankruptcyRemovalDate ?? new BankruptcyRemovalDateField(LoanNumber);
                UpdateOtherFields(bankruptcyRemovalDate, false);
                bankruptcyRemovalDate = value;
            }
        }
    }
}