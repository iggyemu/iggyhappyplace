﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyCommentLine2Field delinquencyCommentLine2;

        /// <summary>
        /// Gets or sets the delinquency comment line2.
        /// </summary>
        /// <value>The delinquency comment line2.</value>
        public DelinquencyCommentLine2Field DelinquencyCommentLine2
        {
            get
            {
                delinquencyCommentLine2 = delinquencyCommentLine2 ?? new DelinquencyCommentLine2Field(LoanNumber);
                UpdateOtherFields(delinquencyCommentLine2, true);
                return delinquencyCommentLine2;
            }
            set
            {
                delinquencyCommentLine2 = delinquencyCommentLine2 ?? new DelinquencyCommentLine2Field(LoanNumber);
                UpdateOtherFields(delinquencyCommentLine2, false);
                delinquencyCommentLine2 = value;
            }
        }
    }
}
