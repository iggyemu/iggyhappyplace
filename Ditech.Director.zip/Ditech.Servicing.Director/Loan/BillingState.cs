﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private BillingStateField billingState;

        /// <summary>
        /// Gets or sets the state of the billing.
        /// </summary>
        /// <value>The state of the billing.</value>
        public BillingStateField BillingState
        {
            get
            {
                billingState = billingState ?? new BillingStateField(LoanNumber);
                UpdateOtherFields(billingState, true);
                return billingState;
            }
            set
            {
                billingState = billingState ?? new BillingStateField(LoanNumber);
                UpdateOtherFields(billingState, false);
                billingState = value;
            }
        }
    }
}
