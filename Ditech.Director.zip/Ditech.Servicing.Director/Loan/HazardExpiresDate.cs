﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private HazardExpiresDateField hazardExpiresDate;

        /// <summary>
        /// Gets or sets the hazard expires date.
        /// </summary>
        /// <value>The hazard expires date.</value>
        public HazardExpiresDateField HazardExpiresDate
        {
            get
            {
                hazardExpiresDate = hazardExpiresDate ?? new HazardExpiresDateField(LoanNumber);
                UpdateOtherFields(hazardExpiresDate, true);
                return hazardExpiresDate;
            }
            set
            {
                hazardExpiresDate = hazardExpiresDate ?? new HazardExpiresDateField(LoanNumber);
                UpdateOtherFields(hazardExpiresDate, false);
                hazardExpiresDate = value;
            }
        }
    }
}