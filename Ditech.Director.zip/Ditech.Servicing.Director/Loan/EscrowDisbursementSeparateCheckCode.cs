﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementSeparateCheckCodeField escrowDisbursementSeparateCheckCode;

        /// <summary>
        /// Gets or sets the escrow disbursement separate check code.
        /// </summary>
        /// <value>The escrow disbursement separate check code.</value>
        public EscrowDisbursementSeparateCheckCodeField EscrowDisbursementSeparateCheckCode
        {
            get
            {
                escrowDisbursementSeparateCheckCode = escrowDisbursementSeparateCheckCode ?? new EscrowDisbursementSeparateCheckCodeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementSeparateCheckCode, true);
                return escrowDisbursementSeparateCheckCode;
            }
            set
            {
                escrowDisbursementSeparateCheckCode = escrowDisbursementSeparateCheckCode ?? new EscrowDisbursementSeparateCheckCodeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementSeparateCheckCode, false);
                escrowDisbursementSeparateCheckCode = value;
            }
        }
    }
}