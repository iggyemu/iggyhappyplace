#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine4Field customerServiceProcessNoteLine4;


        /// <summary>
        /// Gets or sets the SER2 Note Line 4.
        /// </summary>
        /// <value>The SER2 Note Line 4.</value>
        public CustomerServiceProcessNoteLine4Field CustomerServiceProcessNoteLine4
        {
            get
            {
                customerServiceProcessNoteLine4 = customerServiceProcessNoteLine4 ?? new CustomerServiceProcessNoteLine4Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine4, true);
                return customerServiceProcessNoteLine4;
            }
            set
            {
                customerServiceProcessNoteLine4 = customerServiceProcessNoteLine4 ?? new CustomerServiceProcessNoteLine4Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine4, false);
                customerServiceProcessNoteLine4 = value;
            }
        }
    }
}