#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private AmortizationLoanNumberField amortizationLoanNumber;

        /// <summary>
        /// Gets or sets the amortization loan number.
        /// </summary>
        /// <value>The amortization loan number.</value>
        public AmortizationLoanNumberField AmortizationLoanNumber
        {
            get
            {
                amortizationLoanNumber = amortizationLoanNumber ?? new AmortizationLoanNumberField(LoanNumber);
                UpdateOtherFields(amortizationLoanNumber, true);
                return amortizationLoanNumber;
            }
            set
            {
                amortizationLoanNumber = amortizationLoanNumber ?? new AmortizationLoanNumberField(LoanNumber);
                UpdateOtherFields(amortizationLoanNumber, false);
                amortizationLoanNumber = value;
            }
        }
    }
}