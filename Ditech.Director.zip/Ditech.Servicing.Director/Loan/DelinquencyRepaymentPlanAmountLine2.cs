﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyRepaymentPlanAmountLine2Field delinquencyRepaymentPlanAmountLine2;

        /// <summary>
        /// Gets or sets the delinquency repayment plan amount line2.
        /// </summary>
        /// <value>The delinquency repayment plan amount line2.</value>
        public DelinquencyRepaymentPlanAmountLine2Field DelinquencyRepaymentPlanAmountLine2
        {
            get
            {
                delinquencyRepaymentPlanAmountLine2 = delinquencyRepaymentPlanAmountLine2 ?? new DelinquencyRepaymentPlanAmountLine2Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanAmountLine2, true);
                return delinquencyRepaymentPlanAmountLine2;
            }
            set
            {
                delinquencyRepaymentPlanAmountLine2 = delinquencyRepaymentPlanAmountLine2 ?? new DelinquencyRepaymentPlanAmountLine2Field(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanAmountLine2, false);
                delinquencyRepaymentPlanAmountLine2 = value;
            }
        }
    }
}
