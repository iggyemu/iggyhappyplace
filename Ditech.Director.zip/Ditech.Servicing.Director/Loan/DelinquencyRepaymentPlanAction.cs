﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DelinquencyRepaymentPlanActionField delinquencyRepaymentPlanAction;

        /// <summary>
        /// Gets or sets the delinquency repayment plan due date.
        /// </summary>
        /// <value>The delinquency repayment plan due date.</value>
        public DelinquencyRepaymentPlanActionField DelinquencyRepaymentPlanAction
        {
            get
            {
                delinquencyRepaymentPlanAction = delinquencyRepaymentPlanAction ?? new DelinquencyRepaymentPlanActionField(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanAction, true);
                return delinquencyRepaymentPlanAction;
            }
            set
            {
                delinquencyRepaymentPlanAction = delinquencyRepaymentPlanAction ?? new DelinquencyRepaymentPlanActionField(LoanNumber);
                UpdateOtherFields(delinquencyRepaymentPlanAction, false);
                delinquencyRepaymentPlanAction = value;
            }
        }
    }
}