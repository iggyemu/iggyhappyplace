#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingAccountTypeField draftingAccountType;

        /// <summary>
        /// Gets or sets the type of the drafting account.
        /// </summary>
        /// <value>The type of the drafting account.</value>
        public DraftingAccountTypeField DraftingAccountType
        {
            get
            {
                draftingAccountType = draftingAccountType ?? new DraftingAccountTypeField(LoanNumber);
                UpdateOtherFields(draftingAccountType, true);
                return draftingAccountType;
            }
            set
            {
                draftingAccountType = draftingAccountType ?? new DraftingAccountTypeField(LoanNumber);
                UpdateOtherFields(draftingAccountType, false);
                draftingAccountType = value;
            }
        }
    }
}