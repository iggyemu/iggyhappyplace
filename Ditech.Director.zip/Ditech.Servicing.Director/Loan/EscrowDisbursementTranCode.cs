﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private EscrowDisbursementTranCodeField escrowDisbursementTranCode;

        /// <summary>
        /// Gets or sets the escrow disbursement tran code.
        /// </summary>
        /// <value>The escrow disbursement tran code.</value>
        public EscrowDisbursementTranCodeField EscrowDisbursementTranCode
        {
            get
            {
                escrowDisbursementTranCode = escrowDisbursementTranCode ?? new EscrowDisbursementTranCodeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementTranCode, true);
                return escrowDisbursementTranCode;
            }
            set
            {
                escrowDisbursementTranCode = escrowDisbursementTranCode ?? new EscrowDisbursementTranCodeField(LoanNumber);
                UpdateOtherFields(escrowDisbursementTranCode, false);
                escrowDisbursementTranCode = value;
            }
        }
    }
}