#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private CustomerServiceProcessNoteLine1Field customerServiceProcessNoteLine1;


        /// <summary>
        /// Gets or sets the SER2 Note Line 1.
        /// </summary>
        /// <value>The SER2 Note Line 1.</value>
        public CustomerServiceProcessNoteLine1Field CustomerServiceProcessNoteLine1
        {
            get
            {
                customerServiceProcessNoteLine1 = customerServiceProcessNoteLine1 ?? new CustomerServiceProcessNoteLine1Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine1, true);
                return customerServiceProcessNoteLine1;
            }
            set
            {
                customerServiceProcessNoteLine1 = customerServiceProcessNoteLine1 ?? new CustomerServiceProcessNoteLine1Field(LoanNumber);
                UpdateOtherFields(customerServiceProcessNoteLine1, false);
                customerServiceProcessNoteLine1 = value;
            }
        }
    }
}