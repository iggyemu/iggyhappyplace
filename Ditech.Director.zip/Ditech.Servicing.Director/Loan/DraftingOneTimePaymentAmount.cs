﻿#region

using Ditech.Servicing.Director.MspFields;

#endregion

namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        private DraftingOneTimePaymentAmountField draftingOneTimePaymentAmount;

        /// <summary>
        /// Gets or sets the drafting one time payment amount.
        /// </summary>
        /// <value>The drafting one time payment amount.</value>
        public DraftingOneTimePaymentAmountField DraftingOneTimePaymentAmount
        {
            get
            {
                draftingOneTimePaymentAmount = draftingOneTimePaymentAmount ?? new DraftingOneTimePaymentAmountField(LoanNumber);
                UpdateOtherFields(draftingOneTimePaymentAmount, true);
                return draftingOneTimePaymentAmount;
            }
            set
            {
                draftingOneTimePaymentAmount = draftingOneTimePaymentAmount ?? new DraftingOneTimePaymentAmountField(LoanNumber);
                UpdateOtherFields(draftingOneTimePaymentAmount, false);
                draftingOneTimePaymentAmount = value;
            }
        }
    }
}