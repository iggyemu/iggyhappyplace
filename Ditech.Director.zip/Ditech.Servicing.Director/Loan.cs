#region

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using Ditech.Servicing.Director.Forms;
using Ditech.Servicing.Director.MspFields;
using Ditech.Windows.Forms;

#endregion

namespace Ditech.Servicing.Director
{
    /// <summary>
    /// The main Loan object.  Additional loan attributes are contained within the partial class files in the 'Loan' folder.
    /// </summary>
    public partial class Loan
    {
        #region�Fields�(4)

        /// <summary>
        /// Gets or sets the servicing loan.
        /// </summary>
        /// <value>The servicing loan.</value>
        private bool isUpdating;
        public string LoanNumber;
        public static string PreviousLoanNumber;

        #endregion�Fields

        #region�Constructors�(4)

        /// <summary>
        /// Initializes a new instance of the <see cref="Loan"/> class.
        /// </summary>
        /// <param name="loanNumber">The loan number.</param>
        public Loan(string loanNumber)
        {
            Initialize(loanNumber);
        }

        private void Initialize(string loanNumber)
        {
            // this is to assign the previous loan number which could be from a passed loan number or from a Form.  If it's passed PreviousLoanNumber will start out as null.
            if (PreviousLoanNumber == null)
            {
                PreviousLoanNumber = Msp3270.LoanNumber;
            }
            LoanNumber = loanNumber;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Loan"/> class.
        /// </summary>
        public Loan()
        {
            new GetLoanNumber(null).ShowDialog();
            LoanNumber = Msp3270.LoanNumber;
        }


        #endregion�Constructors

        #region�Methods�(2)

        //�Private�Methods�(2)�

        /// <summary>
        /// This method will get the values for all fields the are noted as being on the same screen as the current referenced field.
        /// This will reduce click charges by getting all values on a screen the first time we hit it.
        /// </summary>
        /// <param name="currentScreen">The current screen.</param>
        /// <param name="currentWindow">The current window.</param>
        private void GetFieldsOnSameScreen(string currentScreen, string currentWindow)
        {
            // Fidelity has a weird glitch that prevents going directly to the P190 screen from another loan.
            // Because it takes you through the P192 screen on the way to P190, we might as well grab
            // all of the P192 fields along the way.
            if (!Msp3270.LoanNumber.Equals(LoanNumber) && currentScreen.Equals("P190") &&
                (Msp3270.CurrentScreen.Equals("P190") || Msp3270.CurrentScreen.Equals("P192")))
            {
                GetFieldsOnSameScreen("P192", string.Empty);
            }

            Type type = GetType();

            foreach (PropertyInfo propertyInfo in type.GetProperties())
            {
                if (propertyInfo.PropertyType.BaseType == typeof(MspField))
                {
                    var method = propertyInfo.GetAccessors(true)[0];

                    var mspField = (MspField)method.Invoke(this, null);

                    if (mspField.ReadScreenName == currentScreen && mspField.ReadWindowName == currentWindow &&
                        mspField.ReadAdditionalKeys == null)
                    {
                        mspField.GetValue(true);
                    }
                    else if (mspField.WriteScreenName == currentScreen && mspField.WriteWindowName == currentWindow &&
                             mspField.WriteAdditionalKeys == null)
                    {
                        mspField.GetValue(false);
                    }
                }
            }
        }

        /// <summary>
        /// This is a controller that determines whether to use the source field's Read or Write screen properties to feed into GetFieldsOnSameScreen.
        /// We set the isUpdating flag to true at the beginning, then false at the end to prevent and endless update loop.
        /// </summary>
        /// <param name="currentField">The current field.</param>
        /// <param name="useReadScreen">if set to <c>true</c> [use read screen], otherwise [use write screen].</param>
        private void UpdateOtherFields(MspField currentField, bool useReadScreen)
        {
            if (isUpdating == false)
            {
                isUpdating = true;

                if (useReadScreen)
                {
                    if (currentField.ReadAdditionalKeys == null && !string.IsNullOrEmpty(currentField.ReadScreenName))
                    {
                        GetFieldsOnSameScreen(currentField.ReadScreenName, currentField.ReadWindowName);
                    }
                }
                else
                {
                    if (currentField.WriteAdditionalKeys == null && !string.IsNullOrEmpty(currentField.WriteScreenName))
                    {
                        GetFieldsOnSameScreen(currentField.WriteScreenName, currentField.WriteWindowName);
                    }
                }
                isUpdating = false;
            }
        }

        #endregion�Methods
    }
}