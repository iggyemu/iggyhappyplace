namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        /// <summary>
        /// Gets a value indicating whether this instance is active bankruptcy.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is active bankruptcy; otherwise, <c>false</c>.
        /// </value>
        public bool IsActiveBankruptcy
        {
            get { return (BankruptcyStatus.Value == "A"); }
        }
    }
}