﻿namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        /// <summary>
        /// Gets a value indicating whether this instance is active reo.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is active reo; otherwise, <c>false</c>.
        /// </value>
        public bool IsActiveReo
        {
            get { return (ReoStatus.Value == "A"); }
        }
    }
}