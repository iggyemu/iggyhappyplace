namespace Ditech.Servicing.Director
{
    public partial class Loan
    {
        /// <summary>
        /// Gets a value indicating whether this instance is ELOC.
        /// </summary>
        /// <value><c>true</c> if this instance is ELOC; otherwise, <c>false</c>.</value>
        public bool IsActiveEloc
        {
            get { return (ElocStatus.Value == "A"); }
        }
    }
}