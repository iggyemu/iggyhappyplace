﻿namespace Ditech.Servicing.Director
{
    /// <summary>
    /// A static class for the HLLAPI Special Keys
    /// </summary>
    public static class DirectorKeys
    {
		#region Fields (44) 

        public static readonly string AtCharacter = "@@";
        public static readonly string Attention = "@A@Q";
        public static readonly string Backspace = "@<";
        public static readonly string Backtab = "@B";
        public static readonly string Clear = "@C";
        public static readonly string CursorDown = "@V";
        public static readonly string CursorLeft = "@L";
        public static readonly string CursorRight = "@Z";
        public static readonly string CursorUp = "@U";
        public static readonly string Delete = "@D";
        public static readonly string Enter = "@E";
        public static readonly string EraseEof = "@F";
        public static readonly string Home = "@0";
        public static readonly string Insert = "@I";
        public static readonly string PA1 = "@x";
        public static readonly string PA2 = "@y";
        public static readonly string PA3 = "@z";
        public static readonly string PF1 = "@1";
        public static readonly string PF10 = "@a";
        public static readonly string PF11 = "@b";
        public static readonly string PF12 = "@c";
        public static readonly string PF13 = "@d";
        public static readonly string PF14 = "@e";
        public static readonly string PF15 = "@f";
        public static readonly string PF16 = "@g";
        public static readonly string PF17 = "@h";
        public static readonly string PF18 = "@i";
        public static readonly string PF19 = "@j";
        public static readonly string PF2 = "@2";
        public static readonly string PF20 = "@k";
        public static readonly string PF21 = "@l";
        public static readonly string PF22 = "@m";
        public static readonly string PF23 = "@n";
        public static readonly string PF24 = "@o";
        public static readonly string PF3 = "@3";
        public static readonly string PF4 = "@4";
        public static readonly string PF5 = "@5";
        public static readonly string PF6 = "@6";
        public static readonly string PF7 = "@7";
        public static readonly string PF8 = "@8";
        public static readonly string PF9 = "@9";
        public static readonly string Reset = "@R";
        public static readonly string SystemRequest = "@A@H";
        public static readonly string Tab = "@T";

		#endregion Fields 
    }
}